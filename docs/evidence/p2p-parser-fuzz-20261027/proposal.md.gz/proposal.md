# P2P-PARSER-SEEDED-FUZZ-08 — independent proposal

**UNEXECUTED.** Broker has not applied/imported/compiled/run P2P code. Sole P2P integrator owns real tests-first RED/GREEN and campaign execution. No generated-case campaign has run here.

Base `9efb421a6d22ec23312d6bd8ffb466f87103fb1c`, tree `d02201aa99c0ca332fc2004df228178789ad10f5`. Original packet `libfile_c2cf0593aa80819195ab8d021c9ffb58` v0,15704bytes,SHA256 `1119f92c4c279bfdead04ea1514bd7b691298425d933357f48d74d2d85354e48`; retained parser/import-header bytes separately verified from PROTOCOL06.

Only two absent files. Helper and selftests are separate Sonnet proposals with a frozen API. Initial054returned no implementation;056was output-capped/incomplete and discarded.055helper was corrected by057and reviewed statically;058supplies complete selftests. All charged requests are accounted below.

The helper is a deterministic synthetic test tool, not production RNG/cryptography, a second runner or app capability. No HOST07/parser/protocol/browser/runner/package/golden edits. Actual mapping/family/error expectations remain subject to execution; any future failing harness test is not automatically a product defect.

## Exact files, adaptations and request accounting

```json
{
  "base_sha": "9efb421a6d22ec23312d6bd8ffb466f87103fb1c",
  "base_tree": "d02201aa99c0ca332fc2004df228178789ad10f5",
  "status": "UNEXECUTED inert proposal only; no P2P code applied/imported/compiled/tested",
  "files": [
    {
      "path": "scripts/tests/evm-agreement-fuzz.test.mjs",
      "baseState": "absent",
      "base_sha256": null,
      "target_bytes": 21209,
      "target_lines": 378,
      "target_sha256": "26ba88a05fcc4eaa6734d34fe9e91dbd6fe7dc09d6f0360b9d38a8bb0a63661b"
    },
    {
      "path": "scripts/fuzz-evm-agreement-input.mjs",
      "baseState": "absent",
      "base_sha256": null,
      "target_bytes": 32193,
      "target_lines": 454,
      "target_sha256": "4d50652a8737478c0a5b4c20bf2082b2402543a302bcc3452ddc512733d5cd15"
    }
  ],
  "provenance_requests": [
    "054 no code",
    "055 helper",
    "056 incomplete discarded",
    "057 correction",
    "058 complete tests"
  ],
  "broker_adjustments": [
    "Normalized model correction hunk context/counts monotonically against exact055 source, preserving unchanged line suffix where producer abbreviated context",
    "Applied producer057explicit quotedMAXP1key precision correction",
    "Added one bounded test comparing actual accepted generated text across seeds rather than metadata digest alone",
    "Rejected057 false text-before-all-decimals assumption: actual privateAgreement validates fiatMinorUnits before paymentInstructions. Replaced compound2fieldresourcecase with one40digitfiatwidth refusal INVALID_INPUT/instrumentedBigInt40 guard; existing code-unit/UTF8 tests remain."
  ],
  "correction_application": [
    {
      "hunk": 1,
      "offset": 285,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 2,
      "offset": 763,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 4,
      "offset": 7339,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 5,
      "offset": 8017,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 6,
      "offset": 9478,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 7,
      "offset": 12980,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 8,
      "offset": 14523,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 9,
      "offset": 15860,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 10,
      "offset": 17080,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 11,
      "offset": 19407,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 12,
      "offset": 19965,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 13,
      "offset": 20563,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 14,
      "offset": 21741,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 15,
      "offset": 22551,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 16,
      "offset": 24060,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 17,
      "offset": 27825,
      "mode": "exact producer line-prefix replacement preserving unchanged suffix"
    },
    {
      "hunk": 18,
      "offset": 28547,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 19,
      "offset": 28918,
      "mode": "exact monotonic context"
    },
    {
      "hunk": 20,
      "offset": 30461,
      "mode": "exact monotonic context"
    }
  ],
  "test_generation_scope_limits": [
    "No campaign or test executed by broker; sole integrator must reproduce missing-helper RED and actual GREEN",
    "Invalid counterexample could reflect generator expectation/evaluator bug; never label unexecuted proposal as parser defect",
    "Fixture/source graphs elsewhere remain untouched"
  ],
  "request_evidence": [
    {
      "tag": "p2p-parser-seeded-fuzz-054",
      "model": "claude-sonnet-5-5",
      "timestamp_utc": "2026-10-27T03:48:17.861881+00:00",
      "completed_at_utc": "2026-10-27T03:48:28.716930+00:00",
      "request_id": "req_011CgS4KgETP9Pi7t3EmWR3L",
      "usage": {
        "input_tokens": 15274,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 1118,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.041728"
    },
    {
      "tag": "p2p-parser-fuzz-helper-055",
      "model": "claude-sonnet-5-5",
      "timestamp_utc": "2026-10-27T03:51:38.764574+00:00",
      "completed_at_utc": "2026-10-27T03:53:05.934822+00:00",
      "request_id": "req_011CgS4aV2wLuX6s7HZiPAJG",
      "usage": {
        "input_tokens": 17634,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 16422,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.199488"
    },
    {
      "tag": "p2p-parser-fuzz-selftests-056",
      "model": "claude-sonnet-5-5",
      "timestamp_utc": "2026-10-27T03:51:38.771796+00:00",
      "completed_at_utc": "2026-10-27T03:52:43.144470+00:00",
      "request_id": "req_011CgS4aUwUSVi8vmbKr6yUN",
      "usage": {
        "input_tokens": 17735,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 12000,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "max_tokens",
      "estimated_cost_usd": "0.15547"
    },
    {
      "tag": "p2p-parser-fuzz-helper-correction-057",
      "model": "claude-sonnet-5-5",
      "timestamp_utc": "2026-10-27T03:56:57.372897+00:00",
      "completed_at_utc": "2026-10-27T03:57:41.130948+00:00",
      "request_id": "req_011CgS4yy91ForVqcTYXviqc",
      "usage": {
        "input_tokens": 34028,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 8260,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.150656"
    },
    {
      "tag": "p2p-parser-fuzz-selftests-complete-058",
      "model": "claude-sonnet-5-5",
      "timestamp_utc": "2026-10-27T03:56:57.375700+00:00",
      "completed_at_utc": "2026-10-27T03:57:47.313868+00:00",
      "request_id": "req_011CgS4yy9WS2PbkctuCdpSp",
      "usage": {
        "input_tokens": 34327,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 9282,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.161474"
    }
  ],
  "total_assignment_estimated_usd": "0.708816"
}
```

## TESTS FIRST — apply only this patch for genuine missing-helper RED

```diff
--- /dev/null
+++ b/scripts/tests/evm-agreement-fuzz.test.mjs
@@ -0,0 +1,378 @@
+// P2P-PARSER-SEEDED-FUZZ-08 selftests. UNEXECUTED TEST-FIRST proposal for the sole integrator's real RED/GREEN.
+// Node built-ins only. Uses only bounded, known-safe descriptors/accepted cases; never traverses hostile graphs.
+import test from 'node:test';
+import assert from 'node:assert/strict';
+import { spawnSync } from 'node:child_process';
+import { mkdtempSync, rmSync, writeFileSync, symlinkSync, mkdirSync, readFileSync, existsSync, readdirSync } from 'node:fs';
+import { tmpdir } from 'node:os';
+import path from 'node:path';
+import { fileURLToPath } from 'node:url';
+
+const HERE = path.dirname(fileURLToPath(import.meta.url));
+const ROOT = path.resolve(HERE, '..', '..');
+const HELPER_PATH = path.resolve(HERE, '..', 'fuzz-evm-agreement-input.mjs');
+const helperUrl = new URL('../fuzz-evm-agreement-input.mjs', import.meta.url);
+const helper = await import(helperUrl.href).catch(error => {
+  // Exact missing helper target only; a transitive missing module must never be hidden.
+  if (error?.code === 'ERR_MODULE_NOT_FOUND' && error?.url === helperUrl.href) return {};
+  throw error;
+});
+const need = name => { assert.equal(typeof helper[name], 'function', 'missing helper export ' + name); return helper[name]; };
+const generateCase = (...a) => need('generateCase')(...a);
+const evaluateCase = (...a) => need('evaluateCase')(...a);
+const runCampaign = (...a) => need('runCampaign')(...a);
+const main = (...a) => need('main')(...a);
+
+const FAMILIES = ['instruction-text', 'text-mutation', 'decimal', 'hex-address', 'capabilities', 'signature-views', 'shape', 'resource'];
+const CODES = new Set(['INVALID_INPUT', 'LIMIT_EXCEEDED', 'UNSUPPORTED_VERSION']);
+const SEEDS = [0, 1, 7, 1592598566, 4294967295];
+const withTemp = fn => {
+  const dir = mkdtempSync(path.join(tmpdir(), 'fuzz08-'));
+  try { return fn(dir); } finally { rmSync(dir, { recursive: true, force: true }); }
+};
+const cli = args => spawnSync(process.execPath, [HELPER_PATH, ...args], { encoding: 'utf8', timeout: 120000, cwd: tmpdir() });
+// Real-parser wrapper used to forward normally while a case is evaluated; wipes owned signatures like production callers.
+const wipe = snap => { try { for (const a of snap?.acceptances ?? []) a.signature.fill(0); } catch { /* ignore */ } };
+// Known-safe bounded descriptor view (plain JSON data produced by the helper, never hostile input).
+const safeDesc = c => JSON.stringify(c.descriptor);
+
+test('missing helper reports the exact missing target export (RED guard)', () => {
+  for (const n of ['generateCase', 'evaluateCase', 'runCampaign', 'main']) assert.equal(typeof helper[n], 'function', 'missing helper export ' + n);
+});
+
+test('generateCase is deterministic for same seed/index and descriptors are bounded safe data', () => {
+  for (const seed of SEEDS) for (const index of [0, 1, 2, 3, 4, 5, 6, 7, 8, 17, 255, 1023, 4095]) {
+    const a = generateCase(seed, index), b = generateCase(seed, index);
+    assert.equal(safeDesc(a), safeDesc(b));
+    assert.deepEqual(a.expected, b.expected);
+    assert.equal(a.descriptor.index, index);
+    assert.equal(a.descriptor.family, FAMILIES[index % 8]);
+    assert.equal(typeof a.descriptor.version, 'string');
+    assert.ok(Buffer.byteLength(safeDesc(a)) <= 4096, 'descriptor bounded');
+    assert.ok(a.expected.accepted === true || CODES.has(a.expected.code));
+    assert.ok(!safeDesc(a).includes('PRIVATE-FIXTURE'), 'descriptor leaks no private input');
+  }
+});
+
+test('generateCase family assignment is periodic with period 8 for every seed', () => {
+  for (const seed of [3, 4294967295]) for (let i = 0; i < 24; i++) {
+    assert.equal(generateCase(seed, i).descriptor.family, generateCase(seed, i % 8).descriptor.family);
+    assert.equal(generateCase(seed, i).descriptor.family, FAMILIES[i % 8]);
+  }
+});
+
+test('different seeds actually vary generated descriptors/corpus, not only metadata', () => {
+  const sigs = seeds => seeds.map(s => Array.from({ length: 64 }, (_, i) => generateCase(s, i).descriptor.digest).join(','));
+  const [x, y] = sigs([11, 12]);
+  assert.notEqual(x, y);
+  let differing = 0;
+  for (let i = 0; i < 64; i++) if (generateCase(11, i).descriptor.digest !== generateCase(12, i).descriptor.digest) differing++;
+  assert.ok(differing > 0, 'at least one actual case differs between seeds');
+  const c11 = runCampaign({ seed: 11, cases: 64 }), c12 = runCampaign({ seed: 12, cases: 64 });
+  assert.notEqual(c11.corpusDigest, c12.corpusDigest);
+});
+
+test('runCampaign executes 256 actual cases (not 4096), 32 per family, with exact accounting', () => {
+  const m = runCampaign({ seed: 1592598566 });
+  assert.equal(m.status, 'pass');
+  assert.equal(m.requestedCases, 256);
+  assert.equal(m.executedCases, 256);
+  assert.equal(m.generatedCases, 256);
+  assert.notEqual(m.requestedCases, 4096);
+  assert.equal(m.generatedValidVariations + m.mutatedCases, 256);
+  assert.equal(m.mappingVersion, helper.MAPPING_VERSION ?? m.mappingVersion);
+  assert.equal(typeof m.corpusDigest, 'string');
+  assert.equal(m.firstFailure, null);
+  assert.equal(m.coverageGuided, false);
+  assert.equal(m.shrinking, false);
+  for (const f of FAMILIES) assert.equal(m.perFamily[f].executed, 32, 'family ' + f);
+  const again = runCampaign({ seed: 1592598566 });
+  assert.equal(again.corpusDigest, m.corpusDigest, 'corpus digest deterministic and excludes duration');
+});
+
+test('single-index replay executes exactly one case matching the generated descriptor/outcome', () => {
+  for (const idx of [0, 5, 17, 100, 255]) {
+    const m = runCampaign({ seed: 1592598566, cases: 256, caseIndex: idx });
+    assert.equal(m.status, 'pass');
+    assert.equal(m.executedCases, 1);
+    assert.equal(m.generatedCases, 1);
+    assert.equal(m.requestedCases, 256);
+    assert.equal(m.replayCaseIndex, idx);
+    const fam = FAMILIES[idx % 8];
+    assert.equal(m.perFamily[fam].executed, 1);
+    for (const f of FAMILIES) if (f !== fam) assert.equal(m.perFamily[f].executed, 0);
+    const c = generateCase(1592598566, idx);
+    const r = evaluateCase(c);
+    assert.equal(r.status, 'pass');
+  }
+  assert.throws(() => runCampaign({ seed: 1, cases: 256, caseIndex: 256 }));
+  assert.throws(() => runCampaign({ seed: 1, cases: 8, caseIndex: 8 }));
+});
+
+test('strict parameter validation rejects bad seed/cases/index before generation', () => {
+  for (const bad of [{ seed: -1 }, { seed: 4294967296 }, { seed: 1.5 }, { seed: '1' }, { seed: 1, cases: 7 }, { seed: 1, cases: 4097 },
+    { seed: 1, cases: 8.5 }, { seed: 1, cases: 64, caseIndex: -1 }, { seed: 1, cases: 64, caseIndex: 64 }]) {
+    assert.throws(() => runCampaign(bad), undefined, JSON.stringify(bad));
+  }
+  assert.throws(() => generateCase(-1, 0));
+  assert.throws(() => generateCase(0, -1));
+});
+
+test('real parser: accepted cases pass (frozen independent snapshots) and refused cases carry genuine codes', () => {
+  let accepted = 0, refused = 0;
+  const seen = new Set();
+  for (const seed of [5, 1592598566]) for (let i = 0; i < 128; i++) {
+    const c = generateCase(seed, i);
+    const r = evaluateCase(c);
+    assert.equal(r.status, 'pass', 'seed ' + seed + ' index ' + i + ' ' + c.descriptor.mutation + ' -> ' + JSON.stringify(r).slice(0, 300));
+    if (c.expected.accepted) { accepted++; assert.equal(r.observed, 'accept'); }
+    else { refused++; assert.equal(r.observed, c.expected.code); seen.add(c.expected.code); }
+  }
+  assert.ok(accepted > 0 && refused > 0, 'both accepted and refusal oracles exercised');
+  assert.ok(seen.has('INVALID_INPUT') && seen.has('LIMIT_EXCEEDED'));
+});
+
+test('real parser: accepted snapshot oracle retains exact values and compact owned signatures; wiping is harmless', () => {
+  for (let i = 0; i < 64; i++) {
+    const c = generateCase(9, i);
+    if (!c.expected.accepted) continue;
+    const real = helper.realParser;
+    assert.equal(typeof real, 'function');
+    const snap = real(c.input);
+    try {
+      assert.ok(Object.isFrozen(snap) && Object.isFrozen(snap.privateAgreement) && Object.isFrozen(snap.acceptances));
+      assert.equal(snap.privateAgreement.paymentInstructions, c.input.privateAgreement.paymentInstructions);
+      for (let j = 0; j < 2; j++) {
+        const s = snap.acceptances[j].signature, src = c.input.acceptances[j].signature;
+        assert.equal(s.length, 65); assert.equal(s.byteOffset, 0); assert.equal(s.buffer.byteLength, 65);
+        assert.notEqual(s.buffer, src.buffer);
+        assert.deepEqual(Buffer.from(s), Buffer.from(src.buffer, src.byteOffset, 65));
+      }
+    } finally { wipe(snap); }
+    for (const a of snap.acceptances) assert.ok(a.signature.every(b => b === 0), 'owned signatures wiped');
+  }
+});
+
+test('deliberately permissive fake parser is rejected by invalid-case oracle', () => {
+  let rejected = 0;
+  for (let i = 0; i < 64; i++) {
+    const c = generateCase(21, i);
+    if (c.expected.accepted) continue;
+    // Test-local permissive parser: accepts everything without validation, without touching hostile graphs beyond returning a frozen empty shape.
+    const r = evaluateCase(c, () => Object.freeze({}));
+    assert.notEqual(r.status, 'pass', 'permissive parser must not satisfy refusal oracle at index ' + i);
+    assert.ok(r.status === 'counterexample' || r.status === 'harness-error');
+    rejected++;
+  }
+  assert.ok(rejected > 0);
+});
+
+test('broken snapshot oracle: fake that mutates, aliases, or drops fields fails accepted cases', () => {
+  const real = helper.realParser;
+  let checked = 0;
+  for (let i = 0; i < 64; i++) {
+    const c = generateCase(33, i);
+    if (!c.expected.accepted) continue;
+    const mutate = (fn) => (input) => { const s = real(input); try { return fn(s, input); } finally { /* evaluateCase owns wiping its returned object */ } };
+    const aliased = (input) => { const s = real(input); return Object.freeze({ ...s, acceptances: Object.freeze(input.acceptances.map(a => Object.freeze({ ...a }))) }); };
+    const unfrozen = (input) => { const s = real(input); return { ...s }; };
+    const dropped = (input) => { const s = real(input); return Object.freeze({ ...s, privateAgreement: Object.freeze({ ...s.privateAgreement, paymentInstructions: s.privateAgreement.paymentInstructions + 'x' }) }); };
+    for (const fake of [aliased, unfrozen, dropped]) {
+      const c2 = generateCase(33, i);
+      const r = evaluateCase(c2, fake);
+      assert.equal(r.status, 'counterexample', fake.name + ' at ' + i + ' ' + JSON.stringify(r).slice(0, 200));
+    }
+    void mutate;
+    checked++;
+  }
+  assert.ok(checked > 0);
+});
+
+test('wrong-code and throwing-nonparser fakes fail oracle; instrumentation faults are not expected refusals', () => {
+  const c = generateCase(2, 1);
+  const refusal = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map(i => generateCase(2, i)).find(x => !x.expected.accepted && x.expected.code === 'INVALID_INPUT');
+  assert.ok(refusal);
+  const r1 = evaluateCase(refusal, () => { const e = new Error('Invalid core data.'); e.code = 'INVALID_INPUT'; throw e; });
+  assert.notEqual(r1.status, 'pass', 'foreign Error with right code is not a genuine CoreSchemaError');
+  const r2 = evaluateCase(refusal, () => { throw new RangeError('PRIVATE-FIXTURE secret'); });
+  assert.notEqual(r2.status, 'pass');
+  assert.ok(!JSON.stringify(r2).includes('PRIVATE-FIXTURE'), 'diagnostics sanitized');
+  void c;
+});
+
+test('resource-family instrumentation restores TextEncoder/BigInt/Uint8Array.set and never leaks into later state', () => {
+  const encode = TextEncoder.prototype.encode, big = globalThis.BigInt, set = Uint8Array.prototype.set;
+  const resourceCases = Array.from({ length: 64 }, (_, i) => generateCase(4, i)).filter(x => x.descriptor.family === 'resource');
+  assert.ok(resourceCases.length >= 8);
+  for (const c of resourceCases) {
+    const r = evaluateCase(c);
+    assert.equal(r.status, 'pass', c.descriptor.mutation + ' ' + JSON.stringify(r).slice(0, 200));
+    assert.equal(TextEncoder.prototype.encode, encode);
+    assert.equal(globalThis.BigInt, big);
+    assert.equal(Uint8Array.prototype.set, set);
+  }
+  // A parser that throws mid-evaluation must still restore intrinsics.
+  evaluateCase(resourceCases[0], () => { throw new Error('boom'); });
+  assert.equal(TextEncoder.prototype.encode, encode);
+  assert.equal(globalThis.BigInt, big);
+  assert.equal(Uint8Array.prototype.set, set);
+});
+
+test('resource oracle catches a parser that encodes oversized text or feeds overlength decimals to BigInt', () => {
+  const find = pred => { for (let s = 0; s < 8; s++) for (let i = 0; i < 64; i++) { const c = generateCase(s, i); if (pred(c)) return c; } return null; };
+  const textCase = find(c => c.descriptor.family === 'resource' && c.descriptor.mutation === 'text-4097');
+  const decCase = find(c => c.descriptor.family === 'resource' && String(c.descriptor.mutation).startsWith('decimal5000-'));
+  assert.ok(textCase && decCase, 'resource family generates both budget cases');
+  const real = helper.realParser;
+  const naiveText = input => { new TextEncoder().encode(input.privateAgreement.paymentInstructions); return real(input); };
+  const r1 = evaluateCase(textCase, naiveText);
+  assert.notEqual(r1.status, 'pass', 'oversized text must not reach TextEncoder');
+  const naiveDec = input => {
+    const t = input.terms;
+    for (const v of [t.revision, t.amountBaseUnits, t.acceptBeforeSeconds, t.escrowExpirySeconds, input.domain.chainId, input.privateAgreement.fiatMinorUnits])
+      if (typeof v === 'string' && v.length >= 5000) BigInt(v);
+    return real(input);
+  };
+  const r2 = evaluateCase(decCase, naiveDec);
+  assert.notEqual(r2.status, 'pass', 'overlength decimal must not reach BigInt');
+});
+
+test('metrics are bounded and private: no instruction text, signature bytes, or private fixture strings', () => {
+  const m = runCampaign({ seed: 1592598566 });
+  const text = JSON.stringify(m);
+  assert.ok(Buffer.byteLength(text) <= 1048576);
+  assert.ok(!text.includes('PRIVATE-FIXTURE'));
+  assert.ok(!/(?:0x)?[0-9a-f]{130}/.test(text), 'no 65-byte signature hex');
+  for (const k of ['seed', 'mappingVersion', 'requestedCases', 'executedCases', 'generatedCases', 'perFamily', 'corpusDigest', 'status', 'elapsedMs'])
+    assert.ok(k in m, 'metrics field ' + k);
+  assert.equal(typeof m.elapsedMs, 'number');
+  // Failure path: forced counterexample records seed/index/mapping/family/mutation and stays <=4KiB without private strings.
+  const bad = runCampaign({ seed: 1, cases: 16 }, () => Object.freeze({}));
+  assert.equal(bad.status, 'counterexample');
+  const ff = bad.firstFailure;
+  assert.ok(ff && Buffer.byteLength(JSON.stringify(ff)) <= 4096);
+  assert.equal(ff.seed, 1);
+  assert.equal(typeof ff.index, 'number');
+  assert.equal(ff.mappingVersion, bad.mappingVersion);
+  assert.ok(typeof ff.family === 'string' && typeof ff.mutation === 'string');
+  assert.ok(bad.executedCases <= bad.generatedCases);
+  assert.ok(bad.executedCases < 16, 'stops at first failure');
+  assert.ok(!JSON.stringify(bad).includes('PRIVATE-FIXTURE'));
+});
+
+test('global state restored after generation and campaign', () => {
+  const enc = TextEncoder.prototype.encode, big = globalThis.BigInt, set = Uint8Array.prototype.set, rnd = Math.random, now = Date.now;
+  runCampaign({ seed: 77, cases: 32 });
+  assert.equal(TextEncoder.prototype.encode, enc);
+  assert.equal(globalThis.BigInt, big);
+  assert.equal(Uint8Array.prototype.set, set);
+  assert.equal(Math.random, rnd);
+  assert.equal(Date.now, now);
+});
+
+test('generation does not depend on Math.random or time (deterministic under patched globals)', () => {
+  const rnd = Math.random, now = Date.now;
+  const base = generateCase(123, 9).descriptor.digest;
+  try {
+    Math.random = () => { throw new Error('Math.random forbidden'); };
+    Date.now = () => { throw new Error('Date.now forbidden'); };
+    assert.equal(generateCase(123, 9).descriptor.digest, base);
+  } finally { Math.random = rnd; Date.now = now; }
+});
+
+test('CLI: valid run writes bounded metrics outside source; overwrite refused; replay writes single case', () => {
+  withTemp(dir => {
+    const out = path.join(dir, 'm.json');
+    const r = cli(['--seed', '1592598566', '--cases', '256', '--output', out]);
+    assert.equal(r.status, 0, r.stderr);
+    const m = JSON.parse(readFileSync(out, 'utf8'));
+    assert.equal(m.status, 'pass'); assert.equal(m.executedCases, 256);
+    const before = readFileSync(out, 'utf8');
+    const again = cli(['--seed', '1592598566', '--cases', '256', '--output', out]);
+    assert.notEqual(again.status, 0);
+    assert.equal(readFileSync(out, 'utf8'), before, 'existing output untouched');
+    const rep = path.join(dir, 'r.json');
+    const rr = cli(['--seed', '1592598566', '--cases', '256', '--case-index', '17', '--output', rep]);
+    assert.equal(rr.status, 0, rr.stderr);
+    const rm = JSON.parse(readFileSync(rep, 'utf8'));
+    assert.equal(rm.executedCases, 1); assert.equal(rm.replayCaseIndex, 17);
+  });
+});
+
+test('CLI: invalid arguments fail nonzero and write no output', () => {
+  withTemp(dir => {
+    const out = path.join(dir, 'x.json');
+    const bads = [
+      [], ['--seed', '1'], ['--output', out], ['--seed', '1', '--output', out, '--unknown', '1'],
+      ['--seed', '1', '--seed', '2', '--output', out], ['--seed', '01', '--output', out], ['--seed', '-1', '--output', out],
+      ['--seed', '4294967296', '--output', out], ['--seed', '1.5', '--output', out], ['--seed', 'abc', '--output', out],
+      ['--seed', '1', '--cases', '7', '--output', out], ['--seed', '1', '--cases', '4097', '--output', out],
+      ['--seed', '1', '--cases', '9999999999999999999', '--output', out],
+      ['--seed', '1', '--cases', '64', '--case-index', '64', '--output', out], ['--seed', '1', '--case-index', '-1', '--output', out],
+      ['--seed', '1', '--output', 'relative/out.json'], ['--seed', '1', '--output', path.join(dir, 'missing', 'o.json')],
+      ['--seed', '1', '--output', path.join(dir, 'x.json'), '--cases'], ['--seed', '1', '--output', out, '--cases', '64', '--cases', '64']
+    ];
+    for (const args of bads) {
+      const r = cli(args);
+      assert.notEqual(r.status, 0, JSON.stringify(args));
+      assert.ok(!existsSync(out), 'no output for ' + JSON.stringify(args));
+      assert.ok(!existsSync(path.join(dir, 'missing')));
+    }
+    assert.deepEqual(readdirSync(dir), []);
+  });
+});
+
+test('CLI: output inside source and symlinked parent resolving inside source are refused with no output', () => {
+  withTemp(dir => {
+    const inside = path.join(ROOT, 'fuzz08-selftest-should-not-exist.json');
+    const r1 = cli(['--seed', '1', '--output', inside]);
+    assert.notEqual(r1.status, 0);
+    assert.ok(!existsSync(inside), 'no file created inside source');
+    const link = path.join(dir, 'link-to-source');
+    symlinkSync(ROOT, link, 'dir');
+    const viaLink = path.join(link, 'fuzz08-selftest-symlink.json');
+    const r2 = cli(['--seed', '1', '--output', viaLink]);
+    assert.notEqual(r2.status, 0);
+    assert.ok(!existsSync(path.join(ROOT, 'fuzz08-selftest-symlink.json')), 'no file created via symlinked parent');
+    const subLink = path.join(dir, 'link-to-scripts');
+    symlinkSync(path.join(ROOT, 'scripts'), subLink, 'dir');
+    const r3 = cli(['--seed', '1', '--output', path.join(subLink, 'fuzz08-selftest-sub.json')]);
+    assert.notEqual(r3.status, 0);
+    assert.ok(!existsSync(path.join(ROOT, 'scripts', 'fuzz08-selftest-sub.json')));
+  });
+});
+
+test('main(argv) returns nonzero for invalid arguments without running a campaign; importing runs nothing', () => {
+  withTemp(dir => {
+    const stderr = process.stderr.write;
+    let captured = '';
+    process.stderr.write = chunk => { captured += String(chunk); return true; };
+    try {
+      assert.notEqual(main(['--seed', 'nope', '--output', path.join(dir, 'a.json')]), 0);
+      assert.notEqual(main([]), 0);
+      assert.equal(main(['--seed', '1', '--cases', '8', '--output', path.join(dir, 'ok.json')]), 0);
+    } finally { process.stderr.write = stderr; }
+    assert.ok(!captured.includes('PRIVATE-FIXTURE'));
+    assert.ok(existsSync(path.join(dir, 'ok.json')));
+    assert.ok(!existsSync(path.join(dir, 'a.json')));
+  });
+});
+
+test('source fixtures are unchanged by selftests: no stray files created in repository scripts/test dirs', () => {
+  const names = readdirSync(path.join(ROOT, 'scripts'));
+  assert.ok(!names.some(n => /fuzz08-selftest/.test(n)));
+  assert.ok(!readdirSync(ROOT).some(n => /fuzz08-selftest/.test(n)));
+  assert.ok(existsSync(path.join(ROOT, 'packages', 'schemas', 'src', 'evm-agreement-input.ts')));
+  mkdirSync; writeFileSync; // imported for temp usage patterns; referenced to keep lint quiet
+});
+
+// Broker's small static oracle correction: descriptor.digest itself includes seed, so compare actual safe input fields.
+test('different seeds vary actual accepted instruction fields', () => {
+  let varied = false;
+  for (let slot = 0; slot < 16; slot++) {
+    const a = generateCase(11, slot * 8), b = generateCase(12, slot * 8);
+    assert.equal(a.expected.accepted, true); assert.equal(b.expected.accepted, true);
+    if (a.input.privateAgreement.paymentInstructions !== b.input.privateAgreement.paymentInstructions) varied = true;
+  }
+  assert.ok(varied, 'seed must vary generated field values, not only descriptor metadata');
+});
```

## IMPLEMENTATION — only after preserved RED

```diff
--- /dev/null
+++ b/scripts/fuzz-evm-agreement-input.mjs
@@ -0,0 +1,454 @@
+// P2P-PARSER-SEEDED-FUZZ-08 helper. UNEXECUTED proposal. Test glue only; NONSECURITY deterministic test-input generation.
+// Uses node:crypto SHA-256 counter mode over a fixed seed/index layout. No randomBytes/Math.random/time in generation.
+import { createHash } from 'node:crypto';
+import { existsSync, statSync, writeFileSync, realpathSync } from 'node:fs';
+import path from 'node:path';
+import { fileURLToPath, pathToFileURL } from 'node:url';
+
+export const MAPPING_VERSION = 'p2p-parser-fuzz-08/v1';
+const LABEL = 'p2p-parser-fuzz-08/nonsecurity-test-input';
+const HERE = fileURLToPath(import.meta.url);
+const ROOT = path.resolve(path.dirname(HERE), '..');
+const PARSER_URL = new URL('../packages/schemas/src/evm-agreement-input.ts', import.meta.url).href;
+const parserModule = await import(PARSER_URL);
+export const realParser = parserModule.parseEvmAgreementInput;
+const CORE_URL = new URL('../packages/schemas/src/core.ts', import.meta.url).href;
+const CoreSchemaError = (await import(CORE_URL)).CoreSchemaError;
+
+export const FAMILIES = ['instruction-text', 'text-mutation', 'decimal', 'hex-address', 'capabilities', 'signature-views', 'shape', 'resource'];
+const MAX_METRICS_BYTES = 1048576;
+const MAX_COUNTEREXAMPLE_BYTES = 4096;
+
+class HarnessFault extends Error {}
+
+// ---------- deterministic byte stream ----------
+class Stream {
+  constructor(seed, index, family) { this.seed = seed; this.index = index; this.family = family; this.ctr = 0; this.buf = Buffer.alloc(0); this.pos = 0; }
+  refill() {
+    const h = createHash('sha256');
+    const hdr = Buffer.alloc(12);
+    hdr.writeUInt32BE(this.seed >>> 0, 0); hdr.writeUInt32BE(this.index >>> 0, 4); hdr.writeUInt32BE(this.ctr++ >>> 0, 8);
+    h.update(LABEL); h.update('\0'); h.update(MAPPING_VERSION); h.update('\0'); h.update(hdr);
+    this.buf = h.digest(); this.pos = 0;
+  }
+  byte() { if (this.pos >= this.buf.length) this.refill(); return this.buf[this.pos++]; }
+  u32() { return ((this.byte() << 24) | (this.byte() << 16) | (this.byte() << 8) | this.byte()) >>> 0; }
+  below(n) { return n <= 1 ? 0 : this.u32() % n; }
+  range(lo, hi) { return lo + this.below(hi - lo + 1); }
+  pick(arr) { return arr[this.below(arr.length)]; }
+  hexChars(n, alphabet = '0123456789abcdef') { let s = ''; for (let i = 0; i < n; i++) s += alphabet[this.below(alphabet.length)]; return s; }
+}
+
+// ---------- fresh valid base graph (factory shape from parser tests) ----------
+const h = c => c.repeat(64);
+const A = c => '0x' + c.repeat(40);
+function makeBase() {
+  return {
+    privateAgreement: { v: 1, orderId: h('a'), revision: '1', fiatCurrency: 'USD', fiatMinorUnits: '10000', fiatScale: 2,
+      paymentInstructions: 'PRIVATE-FIXTURE pay', capabilities: [{ id: 'alpha', version: '1', policyHash: h('b') }], agreementSalt: h('c') },
+    domain: { chainId: '11155111', verifyingContract: A('1') },
+    terms: { orderId: h('a'), revision: '1', networkId: 'eip155-1', deploymentId: 'escrow-v1', seller: A('2'), buyer: A('3'),
+      assetKind: 'erc20', asset: A('4'), amountBaseUnits: '1000', privateAgreementHash: h('d'), capabilitiesHash: h('e'),
+      sellerNonce: h('f'), acceptBeforeSeconds: '100', escrowExpirySeconds: '5000' },
+    acceptances: [
+      { termsHash: h('9'), role: 'seller', walletAccount: A('2'), signature: new Uint8Array(65).fill(7) },
+      { termsHash: h('9'), role: 'buyer', walletAccount: A('3'), signature: new Uint8Array(65).fill(8) }]
+  };
+}
+
+// ---------- generation helpers ----------
+const SCALARS = {
+  ascii: ['a', 'Z', '0', ' ', '~', '"', '\\', '\n', '\t'],
+  two: ['\u00e9', '\u03a9', '\u0416', '\u07ff'],
+  three: ['\u20ac', '\u4e2d', '\uffff', '\u0800', '\u0301'],
+  four: ['\u{1F600}', '\u{10000}', '\u{10FFFF}', '\u{1D11E}']
+};
+function pickScalar(s, kind) { return s.pick(SCALARS[kind]); }
+const U8LEN = { ascii: 1, two: 2, three: 3, four: 4 };
+const KINDS = ['ascii', 'two', 'three', 'four'];
+// Valid text of exactly utf8 byte target (<=4096), mixing scalar kinds.
+function textOfBytes(s, target) {
+  let out = '', bytes = 0, guardN = 0;
+  while (bytes < target && guardN++ < 5000) {
+    const rem = target - bytes;
+    const kinds = KINDS.filter(k => U8LEN[k] <= rem);
+    const k = s.below(3) === 0 ? 'ascii' : s.pick(kinds);
+    const kk = U8LEN[k] <= rem ? k : 'ascii';
+    out += pickScalar(s, kk); bytes += U8LEN[kk];
+  }
+  return out;
+}
+// Largest valid text whose UTF-16 length <= 4096 and utf8 <= 4096: use mix. Byte-boundary biased targets.
+function boundaryLen(s, cap) { return s.pick([0, 1, 2, cap - 2, cap - 1, cap, s.range(0, cap)]); }
+function jsonRoundtrip(str) { return JSON.parse(JSON.stringify(str)); }
+const BAD_SURROGATES = [
+  { name: 'lone-high', make: p => p + '\uD800' },
+  { name: 'lone-low', make: p => p + '\uDC00' },
+  { name: 'reversed', make: p => p + '\uDC00\uD800' },
+  { name: 'high-then-ascii', make: p => p + '\uD83Da' },
+  { name: 'low-first', make: p => '\uDE00' + p }
+];
+function digitsStr(s, n) { // canonical decimal of exactly n digits, first nonzero
+  let r = String(s.range(1, 9));
+  for (let i = 1; i < n; i++) r += String(s.below(10));
+  return r;
+}
+const LIMITS = {
+  revision: { cap: 20, min: '1', max: '18446744073709551615' },
+  fiatMinorUnits: { cap: 39, min: '1', max: '340282366920938463463374607431768211455' },
+  chainId: { cap: 78, min: '1', max: '115792089237316195423570985008687907853269984665640564039457584007913129639935' },
+  amountBaseUnits: { cap: 78, min: '1', max: '115792089237316195423570985008687907853269984665640564039457584007913129639935' },
+  acceptBeforeSeconds: { cap: 20, min: '0', max: '18446744073709551615' },
+  escrowExpirySeconds: { cap: 20, min: '0', max: '18446744073709551615' }
+};
+const DEC_FIELDS = Object.keys(LIMITS);
+function setDec(input, field, value) {
+  if (field === 'fiatMinorUnits' || field === 'revision') input.privateAgreement[field] = value;
+  if (field === 'revision') input.terms.revision = value;
+  if (field === 'chainId') input.domain.chainId = value;
+  if (field === 'amountBaseUnits' || field === 'acceptBeforeSeconds' || field === 'escrowExpirySeconds') input.terms[field] = value;
+}
+function decValid(s, field) {
+  const L = LIMITS[field];
+  const choice = s.below(5);
+  if (choice === 0) return L.min;
+  if (choice === 1) return L.max;
+  if (choice === 2) return L.min === '0' ? '1' : '2';
+  return digitsStr(s, s.range(1, L.max.length - 1));
+}
+function hexAlphabetBad(s, n) { return s.hexChars(n - 1) + s.pick(['g', 'G', 'x', 'Z', ' ', '-']); }
+
+// ---------- family generators: return { input, expected, mutation, controls } ----------
+function fam0(s) { // valid instruction text
+  const input = makeBase();
+  const mode = s.below(4);
+  let txt;
+  if (mode === 0) { // only one scalar kind
+    const k = s.pick(KINDS); const unit = U8LEN[k]; const maxN = Math.min(Math.floor(4096 / unit), k === 'four' ? 1024 : 4096);
+    const n = s.pick([0, 1, maxN, maxN - 1, s.range(0, maxN)]); txt = '';
+    for (let i = 0; i < n; i++) txt += pickScalar(s, k);
+  } else if (mode === 1) { // byte-boundary biased mix
+    txt = textOfBytes(s, boundaryLen(s, 4096));
+  } else if (mode === 2) { // JSON escapes + combining
+    let raw = '';
+    const n = s.range(0, 64);
+    for (let i = 0; i < n; i++) raw += s.pick(['"', '\\', '\n', '\t', '\u0301', '\u0000', '\u001f', 'x', '\u20ac', '\u{1F600}']);
+    txt = raw;
+  } else { txt = ''; }
+  if (s.below(2) === 0) txt = jsonRoundtrip(txt);
+  if (Buffer.byteLength(txt, 'utf8') > 4096 || txt.length > 4096) txt = 'ok';
+  input.privateAgreement.paymentInstructions = txt;
+  return { input, expected: { accepted: true }, mutation: 'valid-text-' + mode, boundary: mode === 1,
+    meta: { textUnits: txt.length, textBytes: Buffer.byteLength(txt, 'utf8'), textDigest: sha(txt).slice(0, 16) } };
+}
+function fam1(s) { // text mutation
+  const input = makeBase();
+  const m = s.below(7);
+  let mutation, expected;
+  if (m === 0) { input.privateAgreement.paymentInstructions = 'a'.repeat(4097); mutation = 'ascii-4097'; expected = { accepted: false, code: 'LIMIT_EXCEEDED' }; }
+  else if (m === 1) { input.privateAgreement.paymentInstructions = '\u20ac'.repeat(s.range(1366, 1400)); mutation = 'three-byte-bytes-over'; expected = { accepted: false, code: 'LIMIT_EXCEEDED' }; }
+  else if (m === 2) { // 1025 four-byte scalars => 2050 units, 4100 bytes
+    input.privateAgreement.paymentInstructions = '\u{1F600}'.repeat(s.range(1025, 1030)); mutation = 'four-byte-utf8-over'; expected = { accepted: false, code: 'LIMIT_EXCEEDED' };
+  } else if (m === 3) { // surrogate patterns within code-unit cap -> INVALID_INPUT
+    const bs = s.pick(BAD_SURROGATES); input.privateAgreement.paymentInstructions = bs.make(textOfBytes(s, s.range(0, 64))); mutation = 'surrogate-' + bs.name; expected = { accepted: false, code: 'INVALID_INPUT' };
+  } else if (m === 4) { // over cap AND lone surrogate: code-unit cap first -> LIMIT_EXCEEDED
+    input.privateAgreement.paymentInstructions = 'a'.repeat(4097) + '\uD800'; mutation = 'overcap-plus-surrogate'; expected = { accepted: false, code: 'LIMIT_EXCEEDED' };
+  } else if (m === 5) { // wellformed surrogate pairs valid within cap
+    let t = ''; const n = s.range(1, 64); for (let i = 0; i < n; i++) t += pickScalar(s, 'four'); input.privateAgreement.paymentInstructions = t; mutation = 'wellformed-pairs'; expected = { accepted: true };
+  } else { input.privateAgreement.paymentInstructions = s.below(2) ? 7 : null; mutation = 'nonstring-text'; expected = { accepted: false, code: 'INVALID_INPUT' }; }
+  const pt = input.privateAgreement.paymentInstructions;
+  return { input, expected, mutation, meta: typeof pt === 'string' ? { textUnits: pt.length, textDigest: sha(pt).slice(0, 16) } : { textType: typeof pt } };
+}
+function fam2(s) { // decimals
+  const input = makeBase();
+  const field = s.pick(DEC_FIELDS);
+  const L = LIMITS[field];
+  const kind = s.below(10);
+  const MAXP1 = { '18446744073709551615': '18446744073709551616', '340282366920938463463374607431768211455': '340282366920938463463374607431768211456',
+    '115792089237316195423570985008687907853269984665640564039457584007913129639935': '115792089237316195423570985008687907853269984665640564039457584007913129639936' };
+  let mutation, expected = { accepted: false, code: 'INVALID_INPUT' };
+  if (kind <= 2) { setDec(input, field, decValid(s, field)); mutation = 'valid-' + field; expected = { accepted: true }; }
+  else if (kind === 3) { setDec(input, field, L.min === '0' ? '00' : '01'); mutation = 'leading-zero-' + field; }
+  else if (kind === 4) { setDec(input, field, s.pick(['-1', '+1', '1.0', '1e3', ' 1', '0x1', ''])); mutation = 'syntax-' + field; }
+  else if (kind === 5) { setDec(input, field, s.pick([1, null, 10n, {}, undefined])); mutation = 'nonstring-' + field; }
+  else if (kind === 6) { setDec(input, field, digitsStr(s, L.cap + 1)); mutation = 'overwidth-' + field; }
+  else if (kind === 7) { setDec(input, field, digitsStr(s, 5000)); mutation = 'digits5000-' + field; }
+  else if (kind === 8) { setDec(input, field, MAXP1[L.max]); mutation = 'max-plus-one-' + field; }
+  else if (L.min === '1') { setDec(input, field, '0'); mutation = 'zero-below-min-' + field; }
+  else { setDec(input, field, L.max); mutation = 'valid-max-' + field; expected = { accepted: true }; }
+  return { input, expected, mutation, boundary: kind <= 1 || kind === 9, meta: { field, kind } };
+}
+function fam3(s) { // hex/address
+  const input = makeBase();
+  const kind = s.below(9);
+  let mutation, expected = { accepted: false, code: 'INVALID_INPUT' };
+  if (kind <= 2) {
+    input.privateAgreement.orderId = s.hexChars(64); input.terms.orderId = input.privateAgreement.orderId;
+    input.privateAgreement.agreementSalt = s.hexChars(64); input.terms.sellerNonce = s.hexChars(64);
+    input.domain.verifyingContract = '0x' + s.hexChars(39) + '1';
+    input.terms.seller = '0x' + s.hexChars(39) + '2'; input.terms.buyer = '0x' + s.hexChars(39) + '3'; input.terms.asset = '0x' + s.hexChars(39) + '4';
+    input.acceptances[0].termsHash = s.hexChars(64); input.acceptances[1].termsHash = s.hexChars(64);
+    input.acceptances[0].walletAccount = input.terms.seller; input.acceptances[1].walletAccount = input.terms.buyer;
+    mutation = 'valid-hex'; expected = { accepted: true };
+  } else if (kind === 3) { input.privateAgreement.orderId = s.hexChars(63); mutation = 'hash-len-63'; }
+  else if (kind === 4) { input.privateAgreement.agreementSalt = s.hexChars(64).toUpperCase().replace(/[0-9]/g, 'A'); mutation = 'hash-uppercase'; }
+  else if (kind === 5) { input.terms.seller = '0x' + 'A'.repeat(40); mutation = 'address-uppercase'; }
+  else if (kind === 6) { input.domain.verifyingContract = '0x' + '0'.repeat(40); mutation = 'zero-verifying-contract'; }
+  else if (kind === 7) { input.terms.buyer = hexAlphabetBad(s, 40).replace(/^/, '0x'); mutation = 'address-alphabet'; }
+  else { input.acceptances[s.below(2)].signature = s.pick(['ab'.repeat(65), 'QQ'.repeat(65), 'A'.repeat(88), '0x' + 'ab'.repeat(65)]); mutation = 'signature-string'; }
+  return { input, expected, mutation, meta: { kind } };
+}
+function fam4(s) { // capabilities
+  const input = makeBase();
+  const kind = s.below(9);
+  let mutation, expected = { accepted: false, code: 'INVALID_INPUT' };
+  const mkCap = (id) => ({ id, version: String(s.range(1, 99)), policyHash: s.hexChars(64) });
+  const ids = n => { const set = new Set(); while (set.size < n) set.add('c' + s.hexChars(s.range(1, 6))); return [...set].sort(); };
+  if (kind <= 2) {
+    const n = s.pick([0, 1, 8, s.range(0, 8)]); input.privateAgreement.capabilities = ids(n).map(mkCap); mutation = 'valid-caps-' + n; expected = { accepted: true };
+  } else if (kind === 3) { input.privateAgreement.capabilities = ids(9).map(mkCap); mutation = 'nine-caps'; expected = { accepted: false, code: 'LIMIT_EXCEEDED' }; }
+  else if (kind === 4) { const [a, b] = ids(2); input.privateAgreement.capabilities = [mkCap(b), mkCap(a)]; mutation = 'unsorted'; }
+  else if (kind === 5) { const [a] = ids(1); input.privateAgreement.capabilities = [mkCap(a), mkCap(a)]; mutation = 'duplicate'; }
+  else if (kind === 6) { const arr = [mkCap('a1')]; arr.length = 2; input.privateAgreement.capabilities = arr; mutation = 'sparse'; }
+  else if (kind === 7) { const c = mkCap('a1'); Object.defineProperty(c, 'id', { get() { throw new Error('PRIVATE-FIXTURE getter'); }, enumerable: true }); input.privateAgreement.capabilities = [c]; mutation = 'accessor-cap'; }
+  else { const c = mkCap('a1'); c.extra = 'x'; input.privateAgreement.capabilities = [c]; mutation = 'extra-field'; }
+  return { input, expected, mutation, meta: { kind } };
+}
+function fam5(s) { // signature views
+  const input = makeBase();
+  const kind = s.below(8);
+  let mutation, expected = { accepted: false, code: 'INVALID_INPUT' };
+  const viewAt = (len, fillFn) => { const total = s.range(len + 1, 1024); const off = s.range(1, Math.min(total - len, 512)); const buf = new ArrayBuffer(total); const v = new Uint8Array(buf, off, len); for (let i = 0; i < len; i++) v[i] = fillFn(i); return v; };
+  if (kind <= 3) {
+    const a = viewAt(65, i => (s.byte() + i) & 255), b = viewAt(65, i => (s.byte() ^ i) & 255); b[0] = (a[0] + 1) & 255;
+    input.acceptances[0].signature = a; input.acceptances[1].signature = b; mutation = 'offset-views'; expected = { accepted: true };
+  } else if (kind === 4) { input.acceptances[s.below(2)].signature = viewAt(s.pick([64, 66]), i => i); mutation = 'bad-length-view'; }
+  else if (kind === 5) { input.acceptances[s.below(2)].signature = Array.from({ length: 65 }, () => 7); mutation = 'plain-array'; }
+  else if (kind === 6) { input.acceptances[s.below(2)].signature = new Uint8Array(new SharedArrayBuffer(65)); mutation = 'shared-buffer'; }
+  else { const ab = new ArrayBuffer(65); const v = new Uint8Array(ab); structuredCloneTransfer(ab); input.acceptances[s.below(2)].signature = v; mutation = 'detached'; }
+  return { input, expected, mutation, meta: { kind } };
+}
+function structuredCloneTransfer(ab) { if (typeof ab.transfer === 'function') ab.transfer(); else structuredClone(ab, { transfer: [ab] }); }
+function fam6(s) { // exact-field shapes
+  const input = makeBase();
+  const targets = [input, input.privateAgreement, input.domain, input.terms, input.acceptances[0]];
+  const t = s.pick(targets);
+  const kind = s.below(9);
+  let mutation, expected = { accepted: false, code: 'INVALID_INPUT' };
+  let getterCalled = { n: 0 };
+  const firstKey = Object.keys(t)[0];
+  if (kind === 0) { t.zzExtra = 1; mutation = 'extra'; }
+  else if (kind === 1) { delete t[firstKey]; mutation = 'missing'; }
+  else if (kind === 2) { Object.defineProperty(t, firstKey, { value: t[firstKey], enumerable: false, writable: true, configurable: true }); mutation = 'nonenumerable'; }
+  else if (kind === 3) { t[Symbol('x')] = 1; mutation = 'symbol-key'; }
+  else if (kind === 4) { const v = t[firstKey]; Object.defineProperty(t, firstKey, { get() { getterCalled.n++; return v; }, enumerable: true, configurable: true }); mutation = 'accessor'; }
+  else if (kind === 5) { Object.setPrototypeOf(t, { inherited: 1 }); mutation = 'custom-proto'; }
+  else if (kind === 6) { const { proxy, revoke } = Proxy.revocable({}, {}); revoke(); if (t === input) { return { input: proxy, expected, mutation: 'revoked-proxy-root', meta: { kind, root: true } }; } input[Object.keys(input)[s.below(4)]] = proxy; mutation = 'revoked-proxy'; }
+  else if (kind === 7) { const p = new Proxy(t, { ownKeys() { throw Object.assign(new Error('PRIVATE-FIXTURE forged'), { code: 'LIMIT_EXCEEDED' }); } }); if (t === input) return { input: p, expected, mutation: 'forged-throw-proxy-root', meta: { kind, root: true } }; const slot = Object.keys(input).find(k => input[k] === t); if (slot) input[slot] = p; else input.acceptances[0] = p; mutation = 'forged-throw-proxy'; }
+  else { input.acceptances = [input.acceptances[0]]; mutation = 'arity-short'; }
+  return { input, expected, mutation, getterCalled, meta: { kind } };
+}
+function fam7(s) { // resource refusal
+  const input = makeBase();
+  const kind = s.below(6);
+  let mutation, expected, instr = null;
+  if (kind === 0) { input.privateAgreement.paymentInstructions = 'b'.repeat(4097); mutation = 'text-4097'; expected = { accepted: false, code: 'LIMIT_EXCEEDED' }; instr = { noEncodeLen: 4097 }; }
+  else if (kind === 1) { const f = s.pick(DEC_FIELDS); setDec(input, f, digitsStr(s, 5000)); mutation = 'decimal5000-' + f; expected = { accepted: false, code: 'INVALID_INPUT' }; instr = { noBigIntLen: 5000 }; }
+  else if (kind === 2) { input.privateAgreement.capabilities = Array.from({ length: 9 }, (_, i) => ({ id: 'c' + i, version: '1', policyHash: h('b') })); mutation = 'caps-9'; expected = { accepted: false, code: 'LIMIT_EXCEEDED' }; instr = {}; }
+  else if (kind === 3) { input.acceptances[s.below(2)].signature = new Uint8Array(66); mutation = 'signature-66'; expected = { accepted: false, code: 'INVALID_INPUT' }; instr = { noSigCopy: true }; }
+  else if (kind === 4) { input.acceptances.push({ termsHash: h('9'), role: 'seller', walletAccount: A('2'), signature: new Uint8Array(65) }); mutation = 'acceptances-3'; expected = { accepted: false, code: 'LIMIT_EXCEEDED' }; instr = {}; }
+  else { input.privateAgreement.fiatMinorUnits = digitsStr(s, 40); mutation = 'fiat-width-40'; expected = { accepted: false, code: 'INVALID_INPUT' }; instr = { noBigIntLen: 40 }; }
+  return { input, expected, mutation, instr, meta: { kind } };
+}
+const GENS = [fam0, fam1, fam2, fam3, fam4, fam5, fam6, fam7];
+
+function sha(str) { return createHash('sha256').update(str).digest('hex'); }
+function assertInt(n, lo, hi, name) { if (!Number.isInteger(n) || n < lo || n > hi) throw new RangeError('invalid ' + name); }
+
+export function generateCase(seed, index) {
+  assertInt(seed, 0, 4294967295, 'seed'); assertInt(index, 0, 4095, 'index');
+  const family = index % 8;
+  const s = new Stream(seed, index, family);
+  const g = GENS[family](s);
+  // Descriptor material comes ONLY from trusted generator metadata; never traverse the (possibly hostile) graph.
+  const material = g.meta || {};
+  const descriptor = {
+    version: MAPPING_VERSION, index, family: FAMILIES[family], familyIndex: family, mutation: g.mutation,
+    expected: g.expected.accepted ? 'accept' : g.expected.code, boundaryControl: g.boundary === true, material
+  };
+  descriptor.digest = sha(JSON.stringify(descriptor) + ':' + seed);
+  return { descriptor, input: g.input, expected: g.expected, extra: { instr: g.instr || null, getterCalled: g.getterCalled || null } };
+}
+
+// ---------- evaluation ----------
+function safeCode(error) { try { const c = error && error.code; return typeof c === 'string' && c.length <= 32 ? c : 'unknown'; } catch { return 'unknown'; } }
+function bounded(obj) { let t = JSON.stringify(obj); if (t.length > MAX_COUNTEREXAMPLE_BYTES) obj = { truncated: true, kind: obj.kind, observed: obj.observed }; return obj; }
+
+function deepFrozen(v, seen = new Set()) {
+  if (v === null || typeof v !== 'object') return true;
+  if (v instanceof Uint8Array) return true;
+  if (seen.has(v)) return true; seen.add(v);
+  if (!Object.isFrozen(v)) return false;
+  return Object.values(v).every(x => deepFrozen(x, seen));
+}
+
+export function evaluateCase(caseData, parser = realParser) {
+  const { descriptor, input, expected, extra } = caseData;
+  const info = { index: descriptor.index, family: descriptor.family, mutation: descriptor.mutation, expected: expected.accepted ? 'accept' : expected.code };
+  const instr = extra && extra.instr;
+  const origEncode = TextEncoder.prototype.encode, origBigInt = globalThis.BigInt, origSet = Uint8Array.prototype.set;
+  const calls = { encodeMax: 0, bigintMaxLen: 0, bigintCalls: 0, sigSet: 0 };
+  let snapshot, thrown, didThrow = false;
+  let wrapperFault = false;
+  const sentinel = new HarnessFault('wrapper');
+  try {
+    try {
+    if (instr) {
+      TextEncoder.prototype.encode = function (...a) { try { const v = a[0]; if (typeof v === 'string' && v.length > calls.encodeMax) calls.encodeMax = v.length; } catch { wrapperFault = true; throw sentinel; } return origEncode.apply(this, a); };
+      const Wrapped = function (...a) { try { calls.bigintCalls++; const v = a[0]; if (typeof v === 'string' && v.length > calls.bigintMaxLen) calls.bigintMaxLen = v.length; } catch { wrapperFault = true; throw sentinel; } return origBigInt(...a); };
+      try { Object.defineProperties(Wrapped, Object.getOwnPropertyDescriptors(origBigInt)); } catch { /* ignore */ }
+      globalThis.BigInt = Wrapped;
+    }
+    try { snapshot = parser(input); } catch (e) { didThrow = true; thrown = e; }
+    } finally {
+      TextEncoder.prototype.encode = origEncode; globalThis.BigInt = origBigInt; Uint8Array.prototype.set = origSet;
+    }
+    if (wrapperFault || thrown === sentinel) return { status: 'harness-error', ...info, observed: 'wrapper-fault' };
+    const fail = (observed, why) => ({ status: 'counterexample', ...info, observed, why });
+    if (thrown instanceof HarnessFault) return { status: 'harness-error', ...info, observed: 'harness-fault' };
+    if (expected.accepted) {
+      if (didThrow) return fail(safeCode(thrown), 'unexpected-refusal');
+      return checkAccept(snapshot, input, info, fail);
+    }
+    if (!didThrow) return fail('accepted', 'unexpected-accept');
+    let isCore = false;
+    try { isCore = thrown instanceof CoreSchemaError; } catch { isCore = false; }
+    if (!isCore) return fail('foreign', 'foreign-error');
+    const msg = thrown.message;
+    if (msg !== 'Invalid core data.') return fail(safeCode(thrown), 'unsanitized-message');
+    if (thrown.code !== expected.code) return fail(thrown.code, 'wrong-code');
+    if (extra && extra.getterCalled && extra.getterCalled.n !== 0) return fail(thrown.code, 'getter-invoked');
+    if (instr && instr.noEncodeLen && calls.encodeMax >= instr.noEncodeLen) return fail(thrown.code, 'oversized-text-encoded');
+    if (instr && instr.noBigIntLen && calls.bigintMaxLen >= instr.noBigIntLen) return fail(thrown.code, 'overlength-decimal-bigint');
+    return { status: 'pass', ...info, observed: thrown.code };
+  } catch {
+    return { status: 'harness-error', ...info, observed: 'evaluator-error' };
+  } finally {
+    try { if (snapshot && snapshot.acceptances) for (const a of snapshot.acceptances) { try { a.signature.fill(0); } catch { /* ignore */ } } } catch { /* ignore */ }
+  }
+}
+function checkAccept(snap, input, info, fail) {
+  if (!snap || typeof snap !== 'object') return fail('none', 'no-snapshot');
+  if (!deepFrozen(snap)) return fail('accepted', 'snapshot-not-frozen');
+  const pa = input.privateAgreement;
+  if (snap.privateAgreement.paymentInstructions !== pa.paymentInstructions) return fail('accepted', 'text-changed');
+  for (const k of ['orderId', 'revision', 'fiatCurrency', 'fiatMinorUnits', 'fiatScale', 'agreementSalt']) if (snap.privateAgreement[k] !== pa[k]) return fail('accepted', 'field-changed:' + k);
+  if (snap.domain.chainId !== input.domain.chainId || snap.domain.verifyingContract !== input.domain.verifyingContract) return fail('accepted', 'domain-changed');
+  for (const k of Object.keys(input.terms)) if (snap.terms[k] !== input.terms[k]) return fail('accepted', 'terms-changed:' + k);
+  if (snap.privateAgreement.capabilities.length !== pa.capabilities.length) return fail('accepted', 'caps-count');
+  for (let i = 0; i < pa.capabilities.length; i++) for (const k of ['id', 'version', 'policyHash']) if (snap.privateAgreement.capabilities[i][k] !== pa.capabilities[i][k]) return fail('accepted', 'cap-changed');
+  if (snap.acceptances.length !== 2) return fail('accepted', 'acceptance-count');
+  for (let i = 0; i < 2; i++) {
+    const out = snap.acceptances[i], src = input.acceptances[i];
+    if (out.termsHash !== src.termsHash || out.role !== src.role || out.walletAccount !== src.walletAccount) return fail('accepted', 'acceptance-fields');
+    const sig = out.signature;
+    if (!(sig instanceof Uint8Array) || sig.length !== 65 || sig.byteOffset !== 0 || sig.buffer.byteLength !== 65) return fail('accepted', 'signature-not-compact');
+    if (sig.buffer === src.signature.buffer) return fail('accepted', 'signature-aliased');
+    for (let j = 0; j < 65; j++) if (sig[j] !== src.signature[j]) return fail('accepted', 'signature-bytes');
+  }
+  // source-mutation isolation: mutate source after parse, snapshot must not change
+  const before = Buffer.from(snap.acceptances[0].signature).toString('hex');
+  const s0 = input.acceptances[0].signature; const orig = s0[0]; s0[0] = (orig + 1) & 255;
+  const after = Buffer.from(snap.acceptances[0].signature).toString('hex'); s0[0] = orig;
+  if (before !== after) return fail('accepted', 'signature-not-isolated');
+  return { status: 'pass', ...info, observed: 'accept' };
+}
+
+// ---------- campaign ----------
+export function validateParams({ seed, cases = 256, caseIndex } = {}) {
+  assertInt(seed, 0, 4294967295, 'seed'); assertInt(cases, 8, 4096, 'cases');
+  if (caseIndex !== undefined) assertInt(caseIndex, 0, cases - 1, 'caseIndex');
+}
+export function runCampaign(params, parser = realParser) {
+  const { seed, cases = 256, caseIndex } = params;
+  validateParams({ seed, cases, caseIndex });
+  const started = process.hrtime.bigint();
+  const indices = caseIndex !== undefined ? [caseIndex] : Array.from({ length: cases }, (_, i) => i);
+  const perFamily = Object.fromEntries(FAMILIES.map(f => [f, { executed: 0, accepted: 0, refused: 0, boundaryControls: 0 }]));
+  const digest = createHash('sha256').update(MAPPING_VERSION + '|' + seed + '|');
+  const metrics = {
+    tool: 'fuzz-evm-agreement-input', mappingVersion: MAPPING_VERSION, domainLabel: LABEL, seed, requestedCases: cases,
+    replayCaseIndex: caseIndex === undefined ? null : caseIndex, executedCases: 0, generatedCases: 0, generatedValidVariations: 0,
+    passedCases: 0, mutatedCases: 0, boundaryControlCases: 0, perFamily, corpusDigest: null, status: 'pass', firstFailure: null,
+    coverageGuided: false, shrinking: false, replayNote: caseIndex === undefined ? null : 'single case replayed; not full requested campaign', elapsedMs: 0
+  };
+  for (const index of indices) {
+    let c;
+    try { c = generateCase(seed, index); } catch { metrics.status = 'harness-error'; metrics.firstFailure = { index, kind: 'generation-error' }; break; }
+    metrics.generatedCases++;
+    digest.update(c.descriptor.digest);
+    if (c.expected.accepted) metrics.generatedValidVariations++; else metrics.mutatedCases++;
+    if (c.descriptor.boundaryControl) metrics.boundaryControlCases++;
+    const r = evaluateCase(c, parser);
+    const pf = perFamily[c.descriptor.family];
+    metrics.executedCases++; pf.executed++;
+    if (r.status === 'pass') {
+      metrics.passedCases++;
+      if (c.expected.accepted) pf.accepted++; else pf.refused++;
+      if (c.descriptor.boundaryControl) pf.boundaryControls++;
+      continue;
+    }
+    metrics.status = r.status;
+    metrics.firstFailure = bounded({ kind: r.status, seed, index, mappingVersion: MAPPING_VERSION, family: c.descriptor.family, mutation: c.descriptor.mutation, expected: r.expected, observed: r.observed, why: r.why || null, descriptor: c.descriptor, completed: metrics.passedCases, generated: metrics.generatedCases });
+    break;
+  }
+  metrics.corpusDigest = digest.digest('hex');
+  metrics.elapsedMs = Number((process.hrtime.bigint() - started) / 1000000n);
+  return metrics;
+}
+
+// ---------- CLI ----------
+function parseArgs(argv) {
+  const known = new Set(['--seed', '--cases', '--output', '--case-index']);
+  const got = new Map();
+  if (!Array.isArray(argv) || argv.length > 8) throw new RangeError('args');
+  for (let i = 0; i < argv.length; i += 2) {
+    const k = argv[i], v = argv[i + 1];
+    if (!known.has(k) || got.has(k) || typeof v !== 'string' || v.startsWith('--') || v.length > 4096) throw new RangeError('args');
+    got.set(k, v);
+  }
+  if (!got.has('--seed') || !got.has('--output')) throw new RangeError('args');
+  const dec = (s, name) => { if (!/^(0|[1-9][0-9]{0,9})$/.test(s)) throw new RangeError(name); return Number(s); };
+  const seed = dec(got.get('--seed'), 'seed');
+  const cases = got.has('--cases') ? dec(got.get('--cases'), 'cases') : 256;
+  const caseIndex = got.has('--case-index') ? dec(got.get('--case-index'), 'case-index') : undefined;
+  validateParams({ seed, cases, caseIndex });
+  const out = got.get('--output');
+  if (!path.isAbsolute(out) || out.includes('\0')) throw new RangeError('output');
+  const resolved = path.resolve(out);
+  if (existsSync(resolved)) throw new RangeError('output-exists');
+  const parent = path.dirname(resolved);
+  let st, realParent, realRoot;
+  try { st = statSync(parent); realParent = realpathSync(parent); realRoot = realpathSync(ROOT); } catch { throw new RangeError('output-parent'); }
+  if (!st.isDirectory()) throw new RangeError('output-parent');
+  const rel = path.relative(realRoot, path.join(realParent, path.basename(resolved)));
+  if (rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel))) throw new RangeError('output-in-source');
+  return { seed, cases, caseIndex, output: path.join(realParent, path.basename(resolved)) };
+}
+export function main(argv) {
+  let p;
+  try { p = parseArgs(argv); } catch (e) { process.stderr.write('fuzz-evm-agreement-input: invalid arguments (' + (e && e.message ? String(e.message).slice(0, 32) : 'error') + ')\n'); return 2; }
+  let metrics;
+  try { metrics = runCampaign({ seed: p.seed, cases: p.cases, caseIndex: p.caseIndex }); }
+  catch { process.stderr.write('fuzz-evm-agreement-input: harness error\n'); return 3; }
+  let text = JSON.stringify(metrics, null, 1);
+  if (Buffer.byteLength(text) > MAX_METRICS_BYTES) { metrics.firstFailure = metrics.firstFailure && { kind: metrics.firstFailure.kind, truncated: true }; metrics.perFamily = undefined; text = JSON.stringify(metrics); }
+  try { writeFileSync(p.output, text + '\n', { flag: 'wx', mode: 0o600 }); }
+  catch { process.stderr.write('fuzz-evm-agreement-input: cannot write output\n'); return 3; }
+  if (metrics.status === 'pass') return 0;
+  return metrics.status === 'counterexample' ? 1 : 3;
+}
+
+if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
+  process.exitCode = main(process.argv.slice(2));
+}
```

## Unexecuted acceptance and limits

Use original packet commands: explicit `node --test scripts/tests/evm-agreement-fuzz.test.mjs`, then a fresh OUTSIDE-SOURCE output for the actual seed1592598566/default256campaign, reproducible single-case replay, existing aggregate/build/boundary/policy gates. CLI mutation cases exercise the real structural parser; signatures are synthetic public test data and parsing proves no cryptographic/current/trading authority. Keep all original guards/limits.

- Code has only static inspection and lossless patch construction here; syntax/types/actual expected codes must be verified by the sole integrator.
- The optional noSigCopy flag remains informational; no pre-import intrinsic-copy spy acceptance is claimed. TextEncoder/BigInt instrumentation must be verified in actual selftests.
- Seeded generation/mutation and replay are intended; there is no coverage-guided engine or shrinking claim. No campaign pass/count is claimed until actual execution.
- Preserve real failed-before output and all counterexamples; fix harness defects separately from parser defects. No automatic retries or threshold/case reductions.
