# P2P HOST07 — complete Claude proposal

**UNEXECUTED.** Three-file source/tests/isolated-browser proposal for the sole P2P integrator to verify/apply test-first and run actual RED/GREEN. Broker has not applied/imported/compiled/run P2P code. All model requests are terminal. No app/Worker transport, public facade, trust or trading permission added.

Fable066has RETURNED: bounded static PASS for exact Sonnet064host after061blockingfindings. This is static review, not tested correctness, audit certification or browser acceptance. InitialbroadFable053was knowncompletedat48000thinking-onlycap/no proposal; allcostsremainaccounted. Currentretainedsource dependencies and inputnativepacket were hashverified beforetransmission.

## Exact identities, ownership and request ledger

```json
{
  "assignment": "P2P-G16-PRIVATE-HOST-07",
  "release_stage": "Complete source/tests/browserfixture proposal, UNEXECUTED",
  "base_sha": "9efb421a6d22ec23312d6bd8ffb466f87103fb1c",
  "base_tree": "d02201aa99c0ca332fc2004df228178789ad10f5",
  "input_library": "libfile_7bce3324aea48191a60e89287fd4b2ecv0",
  "input_bytes": 44452,
  "input_sha256": "e9784f4a79bdb561cb5db1e5383f825ef03f83b5f772e4af18da5ecba63c56eb",
  "files": [
    {
      "path": "packages/wallet/test/evm-agreement-host.test.mjs",
      "baseState": "absent",
      "target_bytes": 22923,
      "target_lines": 327,
      "target_sha256": "05fe16336f995a7ecc9bd1b561d9d029559fca0e82e78f760d0ec471c62d7ded"
    },
    {
      "path": "packages/wallet/src/evm-agreement-host.ts",
      "baseState": "absent",
      "target_bytes": 13211,
      "target_lines": 261,
      "target_sha256": "06d9f7b803cd9ede59e3d386cde01a08ccdf6080fb90f5b1ae8b7527872215f3"
    },
    {
      "path": "scripts/fixtures/g16-browser.mjs",
      "baseState": "existing",
      "base_bytes": 22979,
      "base_sha256": "3d0cc3d7b2d983504d3c976bc0dcf2bcae634ba2e29f13a3042168aa490d75e8",
      "target_bytes": 28333,
      "target_lines": 378,
      "target_sha256": "4cbbb6283bf7c238b9e6133564f84a24813e808927efb5f4033d40b123270426"
    }
  ],
  "review": "Fable066returned end_turn/staticPASS exact064host after061blockingfindings; noNode/browserexecutionclaim",
  "review_sha256": "c804feae532e266c15618eef2f7c6b22260dcd579b8e87d9796b520facc490a2",
  "requests": [
    {
      "tag": "p2p-private-host-053",
      "model": "claude-fable-5-1",
      "state": "completed",
      "request_id": "req_011CgS4KgGCSE2Jquprwsnxn",
      "usage": {
        "input_tokens": 53409,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 48000,
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard",
        "output_tokens_details": {
          "thinking_tokens": 48000
        }
      },
      "stop_reason": "max_tokens",
      "estimated_cost_usd": "2.93409",
      "worst_case_reserved_usd": "5.00116"
    },
    {
      "tag": "p2p-host-invariant-review-059",
      "model": "claude-fable-5-1",
      "state": "completed",
      "request_id": "req_011CgS5VzxUzeHVvEqJwdJ1D",
      "usage": {
        "input_tokens": 11354,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 6100,
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard",
        "output_tokens_details": {
          "thinking_tokens": 2909
        }
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.41854",
      "worst_case_reserved_usd": "1.47208"
    },
    {
      "tag": "p2p-host-implementation-060",
      "model": "claude-sonnet-5-5",
      "state": "completed",
      "request_id": "req_011CgS5hJhtFBN3EZCr6QdRe",
      "usage": {
        "input_tokens": 53453,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 5640,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.163306",
      "worst_case_reserved_usd": "2.16"
    },
    {
      "tag": "p2p-host-concrete-review-061",
      "model": "claude-fable-5-1",
      "state": "completed",
      "request_id": "req_011CgS639urMVCxxFgdw4b1P",
      "usage": {
        "input_tokens": 19269,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 7368,
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard",
        "output_tokens_details": {
          "thinking_tokens": 4508
        }
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.56109",
      "worst_case_reserved_usd": "1.66872"
    },
    {
      "tag": "p2p-host-selftests-062",
      "model": "claude-sonnet-5-5",
      "state": "completed",
      "request_id": "req_011CgS639w6RmLXbjxUut4Y4",
      "usage": {
        "input_tokens": 58292,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 7930,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.195884",
      "worst_case_reserved_usd": "2.18"
    },
    {
      "tag": "p2p-host-browser-fixture-063",
      "model": "claude-sonnet-5-5",
      "state": "completed",
      "request_id": "req_011CgS67qD7Ji1tJTqwzpBq9",
      "usage": {
        "input_tokens": 58360,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 2025,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.13697",
      "worst_case_reserved_usd": "2.1"
    },
    {
      "tag": "p2p-host-corrected-source-064",
      "model": "claude-sonnet-5-5",
      "state": "completed",
      "request_id": "req_011CgS6T2LcVSHDK89QwQDac",
      "usage": {
        "input_tokens": 19466,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 5763,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.096562",
      "worst_case_reserved_usd": "2.16"
    },
    {
      "tag": "p2p-host-tests-correction-065",
      "model": "claude-sonnet-5-5",
      "state": "completed",
      "request_id": "req_011CgS6T2KNGnCc751GbqEpE",
      "usage": {
        "input_tokens": 67280,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 10344,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.238",
      "worst_case_reserved_usd": "2.18"
    },
    {
      "tag": "p2p-host-final-review-066",
      "model": "claude-fable-5-1",
      "state": "completed",
      "request_id": "req_011CgS6n4Xr5dB7TzFiAqewr",
      "usage": {
        "input_tokens": 19567,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 4629,
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard",
        "output_tokens_details": {
          "thinking_tokens": 2763
        }
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.42712",
      "worst_case_reserved_usd": "1.59446"
    },
    {
      "tag": "p2p-host-browser-focused-067",
      "model": "claude-sonnet-5-5",
      "state": "completed",
      "request_id": "req_011CgS6n4WrTAr4P9fAuqTtG",
      "usage": {
        "input_tokens": 16939,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 2601,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.059888",
      "worst_case_reserved_usd": "2.1"
    },
    {
      "tag": "p2p-host-browser-oracle-correction-068",
      "model": "claude-sonnet-5-5",
      "state": "completed",
      "request_id": "req_011CgS71XxyXQsFiDTrJMtZB",
      "usage": {
        "input_tokens": 19483,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 3262,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "estimated_cost_usd": "0.071586",
      "worst_case_reserved_usd": "2.1"
    }
  ],
  "host_assignment_completed_estimated_usd": "5.303036",
  "whole_implementation053": "Knowncompletedmax_tokens48000allthinking/no visiblecode,2.93409USD; no accessdenial/transportuncertainty",
  "no_P2P_code_applied_imported_or_tested_by_broker": true,
  "source_corrections": "Sonnet064source and065testreplacement supersede060/062; no brokeralgorithm adaptations",
  "open_oracle_limits": [
    "Bodyparserpreimportcopyspy is conditional: emptycapture doesnotprovehostcopyzeroization; integratormustqualifypositiveobservationorretainexplicitgap",
    "Trustedclockfault/nonterminal behavior andpromptlogicalcancel engineeringdispositions documented, notnewfinancialauthority",
    "Isolatedbrowserfixture proposal nowcomplete, but notexecuted. Actualmessage/DOM/Worker/appbridge andallfinancial/trust/inclusiongates remainclosed."
  ],
  "broker_adjustments": [
    "Onlynormalizedbrowser068hunklocations/countsagainstuniqueexactbasecontext;source064andtests065codebytesunchanged",
    "Rejected063nopatch and067manualcleanup-before-assert/racyphysicalslot assumptions;068hasprecleanupassertions andexplicitnativebackendcompletion+oneeventloopdrain, no polling/retries"
  ]
}
```

## TESTS FIRST — apply alone for genuine missing-host RED

```diff
--- /dev/null
+++ b/packages/wallet/test/evm-agreement-host.test.mjs
@@ -0,0 +1,327 @@
+import test from 'node:test';
+import assert from 'node:assert/strict';
+import { fixture, acceptances, privateVectors } from './lib/g16-bundle-fixture.mjs';
+
+// UNEXECUTED proposal. Spy installed BEFORE any module import so the body parser's cached
+// %TypedArray%.prototype.set captures the wrapper. The wrapper is a pure pass-through unless `copyHook` is set.
+let copyHook = null;
+const nativeSet = Uint8Array.prototype.set;
+Uint8Array.prototype.set = function spiedSet(...args) { if (copyHook) copyHook(this, args); return nativeSet.apply(this, args); };
+
+// Guard ONLY the exact absent target module (ERR_MODULE_NOT_FOUND with the exact target url); transitive failures rethrow.
+const hostUrl = new URL('../src/evm-agreement-host.ts', import.meta.url);
+let api;
+try {
+  api = await import(hostUrl.href).catch(error => {
+    if (error?.code === 'ERR_MODULE_NOT_FOUND' && error?.url === hostUrl.href) return {};
+    throw error;
+  });
+} finally { Uint8Array.prototype.set = nativeSet; }
+assert.equal(Uint8Array.prototype.set, nativeSet);
+
+const make = options => {
+  assert.equal(typeof api.createEvmAgreementHost, 'function', 'missing createEvmAgreementHost');
+  return api.createEvmAgreementHost(options);
+};
+const deferred = () => { let resolve, reject; const promise = new Promise((a, b) => { resolve = a; reject = b; }); return { promise, resolve, reject }; };
+const tick = async (n = 6) => { for (let i = 0; i < n; i++) await new Promise(r => setImmediate(r)); };
+const zero = bytes => bytes.every(b => b === 0);
+const request = (bundle, requestId, generation = 0) => ({ version: 1, requestId, generation, operation: 'checkEvmAgreement', input: bundle });
+const code = reply => { assert.ok(reply, 'expected a reply'); assert.equal(reply.result.ok, false); return reply.result.error.code; };
+const PRIVATE = /PRIVATE-FIXTURE|paymentInstructions|agreementSalt|signature|https:\/\//;
+const noLeak = reply => assert.doesNotMatch(JSON.stringify(reply), PRIVATE);
+const rejectsSchema = (promise, expected) => assert.rejects(promise, error =>
+  error.name === 'CoreSchemaError' && (expected === undefined || error.code === expected) && !PRIVATE.test(String(error.message)));
+const pump = async (calls, rounds = 6) => { for (let i = 0; i < rounds; i++) { await tick(2); for (const call of calls) call.gate.resolve(); } };
+const waitCall = async (calls, index) => { for (let i = 0; i < 50 && !calls[index]; i++) await tick(1); assert.ok(calls[index], 'SHA call ' + index + ' entered'); return calls[index]; };
+const pendingState = async promise => Promise.race([promise.then(() => 'settled', () => 'settled'), tick(3).then(() => 'pending')]);
+
+/** Held SHA seam: real digest, trusted seam only. Each call is released explicitly or by pump. */
+function heldSha() {
+  const calls = [];
+  const sha256 = bytes => {
+    const gate = deferred(), native = crypto.subtle.digest('SHA-256', bytes), call = { bytes, gate };
+    calls.push(call);
+    return gate.promise.then(() => native);
+  };
+  return { calls, sha256 };
+}
+/** Fake monotonic clock + manual timers; the 30000ms bound itself is exercised without waiting. */
+function fakeTime() {
+  const state = { t: 100, timers: [], delays: [], fault: false, override: undefined, reads: 0 };
+  return { state,
+    now: () => { state.reads++; if (state.fault) throw Error('PRIVATE-FIXTURE clock'); return state.override ?? state.t; },
+    timer: {
+      setTimeout: (callback, ms) => { const timer = { callback, ms, live: true }; state.delays.push(ms); state.timers.push(timer); return timer; },
+      clearTimeout: handle => { handle.live = false; } },
+    advance: ms => { state.t += ms; },
+    fire: () => { for (const timer of state.timers) if (timer.live) { timer.live = false; timer.callback(); } } };
+}
+
+test('coherent native, ERC20 and nonempty-capability requests run the actual verifier with strict code-only replies', async () => {
+  const native = await fixture(), cap = await fixture(structuredClone(privateVectors.privateAgreements[1].input));
+  const erc20 = await fixture(); erc20.terms.assetKind = 'erc20'; erc20.terms.asset = '0x' + '11'.repeat(20);
+  erc20.acceptances = acceptances(erc20.domain, erc20.terms);
+  const host = make(); let id = 0;
+  for (const bundle of [native, cap, erc20]) {
+    const reply = await host.dispatch(request(bundle, ++id));
+    assert.equal(reply.result.ok, true); assert.equal(reply.requestId, id); assert.equal(reply.generation, 0);
+    assert.equal(reply.result.value.testOnly, true); assert.equal(reply.result.value.economicPreparationAllowed, false);
+    assert.equal(reply.result.value.accounts.seller, bundle.terms.seller);
+    assert.equal(reply.result.value.accounts.buyer, bundle.terms.buyer); noLeak(reply);
+  }
+  const tampered = await fixture(); tampered.terms.amountBaseUnits = '2';
+  const failed = await host.dispatch(request(tampered, ++id));
+  assert.equal(code(failed), 'INTEGRITY_FAILURE'); assert.deepEqual(Object.keys(failed.result.error), ['code']); noLeak(failed);
+  const forged = request(await fixture(), ++id); forged.approved = true;
+  await rejectsSchema(host.dispatch(forged), 'INVALID_INPUT');
+  assert.deepEqual(Object.keys(host).sort(), ['dispatch', 'dispose', 'generation', 'invalidate']);
+  host.dispose();
+});
+
+test('B is BUSY while A actually pending (each SHA position); caller mutation cannot change A; next explicit request proceeds', async () => {
+  for (const at of [0, 1]) {
+    const held = heldSha(), host = make({ sha256: held.sha256 }), a = await fixture(), b = await fixture();
+    const sellerA = a.terms.seller;
+    const pendingA = host.dispatch(request(a, 1));
+    for (let i = 0; i < at; i++) { (await waitCall(held.calls, i)).gate.resolve(); }
+    await waitCall(held.calls, at);
+    a.terms.amountBaseUnits = '2'; a.acceptances[0].signature.fill(0); a.privateAgreement.paymentInstructions = 'PRIVATE-FIXTURE late';
+    const before = held.calls.length, busy = await host.dispatch(request(b, 2));
+    assert.equal(code(busy), 'BUSY'); noLeak(busy); assert.equal(held.calls.length, before, 'BUSY starts no verifier');
+    await pump(held.calls);
+    const replyA = await pendingA;
+    assert.equal(replyA.result.ok, true, 'caller mutation after capture never changes A');
+    assert.equal(replyA.result.value.accounts.seller, sellerA);
+    const c = host.dispatch(request(await fixture(), 3));
+    await pump(held.calls);
+    assert.equal((await c).result.ok, true, 'explicit current request after actual settlement proceeds');
+    host.dispose();
+  }
+});
+
+test('replay, wrong generation and last-request bounds fail before any verifier; lower generation never revives', async () => {
+  let hashes = 0; const host = make({ sha256: bytes => { hashes++; return crypto.subtle.digest('SHA-256', bytes); } });
+  assert.equal((await host.dispatch(request(await fixture(), 5))).result.ok, true);
+  const afterOk = hashes;
+  await rejectsSchema(host.dispatch(request(await fixture(), 5)), 'INVALID_INPUT');
+  await rejectsSchema(host.dispatch(request(await fixture(), 4)), 'INVALID_INPUT');
+  await rejectsSchema(host.dispatch(request(await fixture(), 6, 1)), 'INVALID_INPUT');
+  await rejectsSchema(host.dispatch(request(await fixture(), 0)), 'INVALID_INPUT');
+  host.invalidate(); assert.equal(host.generation, 1);
+  assert.equal(code(await host.dispatch(request(await fixture(), 7, 0))), 'CONFLICT');
+  assert.equal(hashes, afterOk, 'refusals start no hash');
+  assert.equal((await host.dispatch(request(await fixture(), 8, 1))).result.ok, true, 'request ids survive generation changes');
+  host.dispose();
+});
+
+test('invalidate at either SHA await: A settles undefined promptly, slot stays BUSY until actual settle, then C proceeds (success and thrown backend)', async () => {
+  for (const mode of ['success', 'throw']) for (const at of [0, 1]) {
+    const calls = [];
+    const sha256 = bytes => {
+      const gate = deferred(), native = crypto.subtle.digest('SHA-256', bytes), index = calls.length; calls.push({ bytes, gate });
+      return gate.promise.then(() => { if (mode === 'throw' && index === at) throw Error('PRIVATE-FIXTURE backend https://private.invalid'); return native; });
+    };
+    const host = make({ sha256 }), pendingA = host.dispatch(request(await fixture(), 1));
+    for (let i = 0; i < at; i++) (await waitCall(calls, i)).gate.resolve();
+    await waitCall(calls, at);
+    const hashesAtInvalidate = calls.length;
+    host.invalidate(); assert.equal(host.generation, 1);
+    assert.equal(await pendingA, undefined, 'logical settlement is prompt and suppressed while underlying hash is still held');
+    assert.equal(zero(calls[at].bytes), true, 'verifier-owned bytes wiped by abort before underlying settle');
+    assert.equal(code(await host.dispatch(request(await fixture(), 2, 1))), 'BUSY', 'physical slot held until the real Promise settles');
+    assert.equal(calls.length, hashesAtInvalidate);
+    for (const call of calls) call.gate.resolve();
+    await tick(4);
+    assert.equal(calls.length, hashesAtInvalidate, 'no second hash starts after the stale guard');
+    const c = host.dispatch(request(await fixture(), 3, 1));
+    await pump(calls);
+    assert.equal((await c).result.ok, true, 'explicit current C runs after actual settlement');
+    host.dispose();
+  }
+});
+
+test('late A finalizer after C starts cannot clear or release C; A settles only after C owns the slot', async () => {
+  const calls = [];
+  const sha256 = bytes => { const gate = deferred(), native = crypto.subtle.digest('SHA-256', bytes); calls.push({ bytes, gate }); return gate.promise.then(() => native); };
+  const host = make({ sha256 }), pendingA = host.dispatch(request(await fixture(), 1));
+  await waitCall(calls, 0);
+  host.invalidate();
+  assert.equal(await pendingA, undefined);
+  // A's underlying promise is still held: C cannot start yet (BUSY), and must not displace A.
+  assert.equal(code(await host.dispatch(request(await fixture(), 2, 1))), 'BUSY');
+  calls[0].gate.resolve(); await tick(4);
+  const pendingC = host.dispatch(request(await fixture(), 3, 1));
+  const cStart = calls.length; await waitCall(calls, cStart);
+  assert.equal(code(await host.dispatch(request(await fixture(), 4, 1))), 'BUSY', 'C owns the slot');
+  await pump(calls);
+  assert.equal((await pendingC).result.ok, true); host.dispose();
+});
+
+test('dispose is terminal and idempotent idle/held/before/after parsing; no later reply, job, or unhandled rejection', async () => {
+  const unhandled = []; const listener = reason => unhandled.push(reason); process.on('unhandledRejection', listener);
+  try {
+    const idle = make(); idle.dispose(); idle.dispose();
+    assert.equal(await idle.dispatch(request(await fixture(), 1)), undefined);
+    let touched = 0; const spy = new Proxy({}, { ownKeys() { touched++; return []; }, getOwnPropertyDescriptor() { touched++; return undefined; } });
+    assert.equal(await idle.dispatch(spy), undefined); assert.equal(touched, 0, 'disposed dispatch does not parse or snapshot input');
+    const held = heldSha(), host = make({ sha256: held.sha256 }), pending = host.dispatch(request(await fixture(), 1));
+    await waitCall(held.calls, 0);
+    host.dispose(); host.dispose();
+    assert.equal(await pending, undefined, 'held job settles undefined promptly on dispose');
+    assert.equal(zero(held.calls[0].bytes), true, 'verifier-owned bytes wiped by abort');
+    const before = held.calls.length;
+    assert.equal(await host.dispatch(request(await fixture(), 2)), undefined);
+    assert.equal(held.calls.length, before, 'no new job after dispose');
+    held.calls[0].gate.resolve(); await tick();
+    const gate = deferred(), h2 = make({ sha256: bytes => { void bytes; return gate.promise; } }), p2 = h2.dispatch(request(await fixture(), 1)); await tick();
+    h2.dispose(); gate.reject(Error('PRIVATE-FIXTURE late')); await tick();
+    assert.equal(await p2, undefined);
+    await tick(10); assert.deepEqual(unhandled, []);
+  } finally { process.off('unhandledRejection', listener); }
+});
+
+test('fixed 30s deadline: 29999 succeeds; 30000 with delayed timer is TIMEOUT; timer fire aborts/wipes while slot stays held', async () => {
+  const early = fakeTime(), heldEarly = heldSha(), hostEarly = make({ sha256: heldEarly.sha256, now: early.now, timer: early.timer });
+  const okPending = hostEarly.dispatch(request(await fixture(), 1)); await waitCall(heldEarly.calls, 0);
+  assert.deepEqual(early.state.delays, [30000], 'production timeout stays fixed at 30000ms');
+  early.advance(29999); await pump(heldEarly.calls);
+  assert.equal((await okPending).result.ok, true); hostEarly.dispose();
+
+  const delayed = fakeTime(), held = heldSha(), host = make({ sha256: held.sha256, now: delayed.now, timer: delayed.timer });
+  const pending = host.dispatch(request(await fixture(), 1)); await waitCall(held.calls, 0);
+  delayed.advance(30000); // clock at the bound, timer callback NOT delivered
+  await pump(held.calls);
+  const reply = await pending; assert.equal(code(reply), 'TIMEOUT', 'no success at/after 30s even when SHA completes before timer delivery'); noLeak(reply);
+  host.dispose();
+
+  const fired = fakeTime(), held2 = heldSha(), host2 = make({ sha256: held2.sha256, now: fired.now, timer: fired.timer });
+  const pending2 = host2.dispatch(request(await fixture(), 1)); await waitCall(held2.calls, 0);
+  fired.advance(30000); fired.fire();
+  assert.equal(code(await pending2), 'TIMEOUT', 'timer TIMEOUT settles logically while the held hash is unresolved');
+  assert.equal(zero(held2.calls[0].bytes), true, 'abort wiped verifier-owned bytes promptly');
+  const before = held2.calls.length;
+  const refused = await host2.dispatch(request(await fixture(), 2));
+  assert.ok(refused === undefined || code(refused) === 'BUSY', 'terminal host after timeout: refuse or BUSY, never a new verifier');
+  assert.equal(held2.calls.length, before);
+  host2.dispose();
+});
+
+test('after timeout the host is terminal; late settlement cannot resurrect it, a late timer callback is a no-op, no retry', async () => {
+  const time = fakeTime(), held = heldSha(), host = make({ sha256: held.sha256, now: time.now, timer: time.timer });
+  const pending = host.dispatch(request(await fixture(), 1)); await waitCall(held.calls, 0);
+  time.advance(30000); time.fire(); assert.equal(code(await pending), 'TIMEOUT');
+  await pump(held.calls); await tick(4);
+  for (const timer of time.state.timers) timer.callback();   // stale timer delivery after settlement must be a no-op
+  const before = held.calls.length;
+  assert.equal(await host.dispatch(request(await fixture(), 2)), undefined, 'terminal host refuses replacement work');
+  assert.equal(held.calls.length, before); host.dispose();
+});
+
+test('timeout boundary also applies when the final reply projection happens after the bound (no late success)', async () => {
+  const time = fakeTime(), held = heldSha(), host = make({ sha256: held.sha256, now: time.now, timer: time.timer });
+  const pending = host.dispatch(request(await fixture(), 1)); await waitCall(held.calls, 0);
+  time.advance(29999); held.calls[0].gate.resolve(); await tick(4);
+  const second = await waitCall(held.calls, 1);
+  time.advance(1); second.gate.resolve();                     // exactly 30000 elapsed at completion
+  assert.equal(code(await pending), 'TIMEOUT');
+  assert.equal(await host.dispatch(request(await fixture(), 2)), undefined, 'emitted TIMEOUT closes the host terminally');
+  host.dispose();
+});
+
+test('clock faults (throw, non-finite, backwards after increase) fail closed code-only; host reusable after actual settlement; invalidation dominates', async () => {
+  for (const fault of ['throw', 'nan', 'backwards']) {
+    const time = fakeTime(), held = heldSha(), host = make({ sha256: held.sha256, now: time.now, timer: time.timer });
+    const pending = host.dispatch(request(await fixture(), 1)); await waitCall(held.calls, 0);
+    if (fault === 'backwards') { time.advance(50); await tick(2); time.state.override = time.state.t - 10; }  // earlier than a prior higher read, still above start
+    else if (fault === 'throw') time.state.fault = true; else time.state.override = Number.NaN;
+    await pump(held.calls);
+    const reply = await pending;
+    assert.equal(code(reply), 'UNAVAILABLE'); noLeak(reply); assert.deepEqual(Object.keys(reply.result.error), ['code']);
+    time.state.fault = false; time.state.override = undefined;
+    const next = host.dispatch(request(await fixture(), 2)); await pump(held.calls);
+    assert.equal((await next).result.ok, true, 'clock fault is not terminal; host reusable after actual settlement');
+    host.dispose();
+  }
+  const time = fakeTime(), held = heldSha(), host = make({ sha256: held.sha256, now: time.now, timer: time.timer });
+  const pending = host.dispatch(request(await fixture(), 1)); await waitCall(held.calls, 0);
+  host.invalidate(); time.state.fault = true;
+  assert.equal(await pending, undefined, 'invalidation dominates a faulty clock'); await pump(held.calls); host.dispose();
+});
+
+test('invalidate dominates a queued TIMEOUT: timer fires after invalidation yields no timeout reply', async () => {
+  const time = fakeTime(), held = heldSha(), host = make({ sha256: held.sha256, now: time.now, timer: time.timer });
+  const pending = host.dispatch(request(await fixture(), 1)); await waitCall(held.calls, 0);
+  host.invalidate(); time.advance(30000); time.fire();
+  assert.equal(await pending, undefined); await pump(held.calls); host.dispose();
+});
+
+test('malformed, accessor, revoked proxy, oversized and forged-throw inputs fail with fresh fixed errors and no getter execution', async () => {
+  const host = make(); let getters = 0, id = 0;
+  const forged = Object.assign(Error('PRIVATE-FIXTURE forged'), { name: 'CoreSchemaError', code: 'LIMIT_EXCEEDED' });
+  const revoked = Proxy.revocable({}, {}); revoked.revoke();
+  const accessor = request(await fixture(), ++id); Object.defineProperty(accessor.input.terms, 'buyer', { enumerable: true, get() { getters++; throw forged; } });
+  for (const bad of [null, 'text', [], revoked.proxy, accessor, new Proxy({}, { ownKeys() { throw forged; } })]) {
+    await assert.rejects(host.dispatch(bad), error => { assert.notEqual(error, forged); return error.name === 'CoreSchemaError' && error.code === 'INVALID_INPUT' && !PRIVATE.test(error.message); });
+  }
+  const oversized = request(await fixture(), 50); oversized.input.privateAgreement.paymentInstructions = 'x'.repeat(4097);
+  await rejectsSchema(host.dispatch(oversized), 'LIMIT_EXCEEDED');
+  const wide = request(await fixture(), 51); wide.input.terms.amountBaseUnits = '9'.repeat(5000);
+  await rejectsSchema(host.dispatch(wide), 'INVALID_INPUT');
+  assert.equal(getters, 0, 'accessor never invoked');
+  assert.equal((await host.dispatch(request(await fixture(), 60))).result.ok, true, 'refusals leave host usable');
+  host.dispose();
+});
+
+test('reentrant dispatch during a strict parse rejects with a fresh fixed INVALID_INPUT without touching nested input; outer proceeds', async () => {
+  const host = make(), bundle = await fixture(); let nestedPromise, nestedTouched = 0, entered = 0;
+  const nestedInput = new Proxy({}, { ownKeys() { nestedTouched++; return []; }, getOwnPropertyDescriptor() { nestedTouched++; return undefined; } });
+  const trap = new Proxy(bundle, { ownKeys(target) {
+    if (!entered++) { nestedPromise = host.dispatch(nestedInput); nestedPromise.catch(() => {}); }
+    return Reflect.ownKeys(target); } });
+  const outer = await host.dispatch(request(trap, 1));
+  assert.ok(nestedPromise, 'trap executed during the outer strict parse');
+  await assert.rejects(nestedPromise, error => error.name === 'CoreSchemaError' && error.code === 'INVALID_INPUT' && !PRIVATE.test(error.message));
+  assert.equal(nestedTouched, 0, 'nested input never inspected');
+  assert.equal(outer.result.ok, true, 'outer coherent request completes with a genuine verified result');
+  assert.equal((await host.dispatch(request(await fixture(), 2))).result.ok, true, 'no retained job; host reusable');
+  host.dispose();
+});
+
+test('BUSY and wrong-generation refusals clear host-owned parsed signature copies (observed via pre-import intrinsic-copy spy)', async () => {
+  const held = heldSha(), host = make({ sha256: held.sha256 }), pendingA = host.dispatch(request(await fixture(), 1));
+  await waitCall(held.calls, 0);
+  const seen = []; copyHook = (target, args) => { if (target.length === 65 && target.buffer.byteLength === 65 && args[0]?.length === 65) seen.push(target); };
+  let busy, lower;
+  try {
+    busy = await host.dispatch(request(await fixture(), 2));
+    host.invalidate();
+    lower = await host.dispatch(request(await fixture(), 3, 0));
+  } finally { copyHook = null; }
+  assert.equal(code(busy), 'BUSY'); assert.equal(code(lower), 'CONFLICT');
+  // Observable limits: the spy sees only copies made through the cached intrinsic set during these dispatches; if the
+  // engine/parser routes copies elsewhere the list is empty and host-copy zeroization is reported unobservable, not claimed.
+  if (seen.length) assert.equal(seen.every(zero), true, 'refused requests leave no live host-owned signature copy');
+  assert.equal(await pendingA, undefined); await pump(held.calls); host.dispose();
+});
+
+test('host-owned vs verifier-owned buffers clear separately; caller-owned bytes are never erased; abort wipe precedes underlying settle', async () => {
+  const bundle = await fixture(), callerCopies = bundle.acceptances.map(a => Uint8Array.from(a.signature)), owned = [], held = heldSha();
+  copyHook = (target, args) => { if (target.length === 65 && target.buffer.byteLength === 65 && args[0]?.length === 65) owned.push(target); };
+  let pending;
+  try { pending = make({ sha256: held.sha256 }).dispatch(request(bundle, 1)); await waitCall(held.calls, 0); } finally { copyHook = null; }
+  const callerIntact = () => bundle.acceptances.every((a, i) => a.signature.every((b, j) => b === callerCopies[i][j]));
+  assert.equal(callerIntact(), true, 'caller-owned bytes untouched while pending');
+  await pump(held.calls);
+  assert.equal((await pending).result.ok, true); assert.equal(callerIntact(), true, 'caller bytes never erased');
+  if (owned.length) assert.equal(owned.every(zero), true, 'host-owned snapshot signature copies cleared after settlement');
+  else assert.ok(owned.length === 0, 'host copy path unobservable through the cached intrinsic; copy zeroization not claimed');
+  assert.equal(held.calls.every(call => zero(call.bytes)), true, 'verifier-owned encoded arrays cleared on settlement');
+
+  const held2 = heldSha(), host = make({ sha256: held2.sha256 }), pending2 = host.dispatch(request(await fixture(), 1));
+  await waitCall(held2.calls, 0);
+  host.invalidate();
+  assert.equal(zero(held2.calls[0].bytes), true, 'immediate abort wipes verifier-owned bytes while the hash is still held');
+  assert.equal(await pending2, undefined);
+  for (const call of held2.calls) call.gate.resolve(); await tick(); host.dispose();
+});
```

## IMPLEMENTATION — after preserved actual RED

```diff
--- /dev/null
+++ b/packages/wallet/src/evm-agreement-host.ts
@@ -0,0 +1,261 @@
+/** Private host lifecycle for the EVM agreement consistency check. UNEXECUTED proposal; not exported by any facade.
+ * Owns request/generation ordering, one actual verifier job, 30s deadline, invalidation and reply projection.
+ * Imported request fields are correlation data only; the actual imported verifier supplies all verdicts.
+ * Limits: caller strings and native SHA internals are outside erasure; no physical rollback/cancellation of the
+ * underlying hash is claimed; the host closes terminally on timeout or counter exhaustion.
+ * Logical settlement (what the caller sees) is separate from physical slot release (underlying promise settles).
+ */
+import { CoreSchemaError } from '../../schemas/src/core.ts';
+import { MAX_RUNTIME_SEQUENCE, RUNTIME_REQUEST_TIMEOUT_MS } from '../../schemas/src/runtime.ts';
+import { parseEvmAgreementCheckRequest, parseEvmAgreementCheckReply,
+  type EvmAgreementCheckReply, type EvmAgreementCheckRequest, type EvmAgreementFailureCode } from '../../schemas/src/evm-agreement-protocol.ts';
+import { verifyEvmAgreementBundle } from './evm-agreement.ts';
+
+/** Trusted constructor-only seams for deterministic tests. Production leaves all undefined. */
+export interface EvmAgreementHostTimer {
+  readonly setTimeout: (callback: () => void, ms: number) => unknown;
+  readonly clearTimeout: (handle: unknown) => void;
+}
+export interface EvmAgreementHostOptions {
+  /** Passed to the actual verifier as its existing context.sha256. */
+  readonly sha256?: (bytes: Uint8Array<ArrayBuffer>) => Promise<ArrayBuffer>;
+  /** Trusted monotonic millisecond clock; must be finite and nondecreasing. Default performance.now. */
+  readonly now?: () => number;
+  /** Timer seam; the 30000ms bound itself is not configurable. */
+  readonly timer?: EvmAgreementHostTimer;
+}
+export interface EvmAgreementHost {
+  dispatch(input: unknown): Promise<Readonly<EvmAgreementCheckReply> | undefined>;
+  invalidate(): void;
+  dispose(): void;
+  readonly generation: number;
+}
+
+type Verdict = Awaited<ReturnType<typeof verifyEvmAgreementBundle>>;
+/** Logical settlement outcome of a job. 'suppressed' = invalidate/dispose/stale; distinct from timeout. */
+type Outcome = 'timeout' | 'suppressed' | { readonly kind: 'value'; readonly value: Verdict } | { readonly kind: 'threw' };
+
+interface Job {
+  readonly id: number;
+  readonly generation: number;
+  readonly controller: AbortController;
+  readonly signatures: Uint8Array[];
+  readonly started: number;
+  /** Highest clock reading seen; any reading below it is a clock fault. */
+  last: number;
+  timer: unknown;
+  timedOut: boolean;
+  logicallyDone: boolean;
+  /** Underlying verifier promise has actually settled. */
+  settled: boolean;
+  /** Idempotent logical deferred resolver (first outcome wins). */
+  resolve: (outcome: Outcome) => void;
+}
+
+export function createEvmAgreementHost(options: EvmAgreementHostOptions = {}): EvmAgreementHost {
+  const sha256 = options.sha256, nowSeam = options.now, timerSeam = options.timer;
+  const nativeSet = globalThis.setTimeout, nativeClear = globalThis.clearTimeout;
+  const clock = (): number => nowSeam ? nowSeam() : performance.now();
+  const setTimer = (cb: () => void, ms: number): unknown => timerSeam ? timerSeam.setTimeout(cb, ms) : nativeSet(cb, ms);
+  const clearTimer = (handle: unknown): void => { if (timerSeam) timerSeam.clearTimeout(handle); else nativeClear(handle as ReturnType<typeof setTimeout>); };
+
+  let generation = 0, lastRequest = 0, nextJobId = 1;
+  let disposed = false, closed = false;
+  let active: Job | undefined;
+  /** Parse reservation: set synchronously before the strict parser so a reentrant dispatch cannot parse concurrently. */
+  let parsing = false;
+
+  const reply = (requestId: number, gen: number, failureCode?: EvmAgreementFailureCode, value?: unknown): Readonly<EvmAgreementCheckReply> =>
+    parseEvmAgreementCheckReply({ version: 1, requestId, generation: gen, operation: 'checkEvmAgreement', kind: 'response',
+      result: failureCode !== undefined ? { ok: false, error: { code: failureCode } } : { ok: true, value } });
+
+  const wipe = (bytes: readonly Uint8Array[]): void => { for (const b of bytes) b.fill(0); };
+  const stopTimer = (job: Job): void => {
+    if (job.timer !== undefined) { const t = job.timer; job.timer = undefined; try { clearTimer(t); } catch { /* seam fault ignored */ } }
+  };
+  /** Logical termination: abort, wipe host-owned signatures, stop timer, settle the logical deferred as suppressed
+   * (no-op if already settled with a verdict/timeout). Physical slot release stays with the underlying promise. */
+  const terminate = (job: Job): void => {
+    job.logicallyDone = true;
+    try { job.controller.abort(); } catch { /* ignore */ }
+    wipe(job.signatures);
+    stopTimer(job);
+    job.resolve('suppressed');
+  };
+  /** Ownership holds until the physical slot is released: logical projection happens while active === job. */
+  const liveOwned = (job: Job): boolean =>
+    !disposed && !closed && active === job && !job.logicallyDone && !job.timedOut && job.generation === generation;
+  /** Finite, never-decreasing (versus every prior read) clock; undefined when faulty. */
+  const elapsed = (job: Job): number | undefined => {
+    try {
+      const t = clock();
+      if (typeof t !== 'number' || !Number.isFinite(t) || t < job.last) return undefined;
+      job.last = t;
+      return t - job.started;
+    } catch { return undefined; }
+  };
+
+  const invalidate = (): void => {
+    if (disposed) return;
+    const job = active;
+    if (generation >= MAX_RUNTIME_SEQUENCE) { closed = true; if (job) terminate(job); return; }
+    generation++;
+    if (job) terminate(job);
+  };
+  const dispose = (): void => {
+    if (disposed) return;
+    disposed = true; closed = true;
+    const job = active;
+    if (job) terminate(job);
+    // `active` is retained until the underlying promise actually settles (identity-bound release below).
+  };
+
+  async function dispatch(input: unknown): Promise<Readonly<EvmAgreementCheckReply> | undefined> {
+    if (disposed || closed) return undefined;
+    if (parsing) {
+      // Reentrant dispatch during an in-progress strict parse: refuse without touching the input.
+      throw new CoreSchemaError('INVALID_INPUT');
+    }
+    parsing = true;
+    let request: Readonly<EvmAgreementCheckRequest> | undefined;
+    try { request = parseEvmAgreementCheckRequest(input); }
+    catch (error) {
+      parsing = false;
+      // Genuine parser codes stay intact; anything foreign becomes a fresh fixed error.
+      if (error instanceof CoreSchemaError) throw new CoreSchemaError(error.code);
+      throw new CoreSchemaError('INVALID_INPUT');
+    }
+    parsing = false;
+    input = undefined; // raw caller input no longer needed; avoid retaining it across the await
+
+    const signatures = request.input.acceptances.map(a => a.signature as Uint8Array);
+    const requestId = request.requestId, requestGeneration = request.generation;
+    const refuse = (code: EvmAgreementFailureCode): Readonly<EvmAgreementCheckReply> | undefined => {
+      wipe(signatures);
+      if (disposed || closed) return undefined;
+      return reply(requestId, requestGeneration, code);
+    };
+    if (disposed || closed) { wipe(signatures); return undefined; }
+    if (requestId <= lastRequest) {
+      wipe(signatures);
+      throw new CoreSchemaError('INVALID_INPUT');
+    }
+    lastRequest = requestId;
+    if (requestGeneration < generation) return refuse('CONFLICT');
+    if (requestGeneration > generation) { wipe(signatures); throw new CoreSchemaError('INVALID_INPUT'); }
+    if (active) return refuse('BUSY');
+
+    const started = (() => { try { const t = clock(); return typeof t === 'number' && Number.isFinite(t) ? t : NaN; } catch { return NaN; } })();
+    if (Number.isNaN(started)) return refuse('UNAVAILABLE');
+    // Clock seam may have reentered invalidate/dispose before a job exists.
+    if (disposed || closed) { wipe(signatures); return undefined; }
+    if (requestGeneration !== generation) { wipe(signatures); return undefined; }
+
+    let resolveLogical: (outcome: Outcome) => void = () => {};
+    const logical = new Promise<Outcome>(resolve => { resolveLogical = resolve; });
+    let decided = false;
+    const job: Job = { id: nextJobId++, generation, controller: new AbortController(), signatures, started, last: started,
+      timer: undefined, timedOut: false, logicallyDone: false, settled: false,
+      resolve: (outcome: Outcome) => { if (decided) return; decided = true; resolveLogical(outcome); } };
+    active = job;
+
+    try {
+      job.timer = setTimer(() => {
+        // No-op after physical or logical settlement (delayed delivery despite clearTimeout).
+        if (job.settled || job.logicallyDone || job.timedOut) return;
+        job.timedOut = true;
+        terminate(job); // wipes/aborts/stops timer; its 'suppressed' resolve is overridden below only if still undecided
+        // Host is terminal after a request timeout; the slot stays held until the real job settles.
+        closed = true;
+      }, RUNTIME_REQUEST_TIMEOUT_MS);
+    } catch { terminate(job); active = undefined; return refuse('UNAVAILABLE'); }
+
+    // Timer seam may have reentered invalidate/dispose during setup: stop before starting the verifier.
+    if (job.logicallyDone || disposed || closed || job.generation !== generation) {
+      terminate(job);
+      if (active === job) active = undefined;
+      return undefined;
+    }
+
+    const isCurrent = (): boolean => {
+      if (!liveOwned(job)) return false;
+      const e = elapsed(job);
+      return e !== undefined && e < RUNTIME_REQUEST_TIMEOUT_MS;
+    };
+    const verifierContext = sha256
+      ? { isCurrent, signal: job.controller.signal, sha256 }
+      : { isCurrent, signal: job.controller.signal };
+
+    let underlying: Promise<Verdict>;
+    try { underlying = Promise.resolve(verifyEvmAgreementBundle(request.input, verifierContext)); }
+    catch { underlying = Promise.reject(new Error()); }
+    // Verifier's synchronous prefix has already snapshotted everything; drop the request reference.
+    request = undefined;
+
+    // Physical release bound to real settlement, identity-checked. The logical verdict is delivered while
+    // active === job (resolve occurs BEFORE the slot is released), so a normal reply is not self-suppressed.
+    void underlying.then(
+      (value): Outcome => ({ kind: 'value', value }),
+      (): Outcome => ({ kind: 'threw' }),
+    ).then(outcome => {
+      job.settled = true;
+      if (job.timedOut) job.resolve('timeout');
+      else if (job.logicallyDone) job.resolve('suppressed');
+      else {
+        // Decide the final projection now, while the job still owns the slot and before any successor can exist.
+        const e = elapsed(job);
+        if (disposed || job.generation !== generation) job.resolve('suppressed');
+        else if (e === undefined) job.resolve({ kind: 'threw' });
+        else if (e >= RUNTIME_REQUEST_TIMEOUT_MS) { job.timedOut = true; terminate(job); closed = true; job.resolve('timeout'); }
+        else if (!liveOwned(job)) job.resolve('suppressed');
+        else job.resolve(outcome);
+      }
+    }).finally(() => {
+      job.settled = true;
+      stopTimer(job);
+      wipe(job.signatures);
+      if (active === job) active = undefined;
+    });
+
+    // Timer expiry must settle logically even while the underlying hash is still held.
+    const timerWatch = (): void => { /* timeout resolution is performed via polling-free hook below */ };
+    void timerWatch;
+
+    const outcome = await logical;
+
+    wipe(job.signatures);
+    // Precedence: disposal/invalidation/stale dominate any queued TIMEOUT; then timeout; then result.
+    if (disposed || job.generation !== generation) return undefined;
+    if (outcome === 'suppressed') return job.timedOut ? reply(requestId, requestGeneration, 'TIMEOUT') : undefined;
+    if (outcome === 'timeout' || job.timedOut) return reply(requestId, requestGeneration, 'TIMEOUT');
+
+    // Final recheck after logical decision (traps/seams may have reentered, or the clock advanced).
+    const e2 = elapsed(job);
+    if (e2 !== undefined && e2 >= RUNTIME_REQUEST_TIMEOUT_MS) {
+      job.timedOut = true; terminate(job); closed = true;
+      return reply(requestId, requestGeneration, 'TIMEOUT');
+    }
+    if (disposed || job.generation !== generation) return undefined;
+    if (e2 === undefined) { return reply(requestId, requestGeneration, 'UNAVAILABLE'); }
+
+    try {
+      if (outcome.kind === 'threw') return reply(requestId, requestGeneration, 'UNAVAILABLE');
+      const result = outcome.value;
+      if (result.ok === true) {
+        const v = result.value;
+        return reply(requestId, requestGeneration, undefined, { testOnly: v.testOnly, economicPreparationAllowed: v.economicPreparationAllowed,
+          termsHash: v.termsHash, accounts: { seller: v.accounts.seller, buyer: v.accounts.buyer } });
+      }
+      return reply(requestId, requestGeneration, result.error.code);
+    } catch {
+      try { return reply(requestId, requestGeneration, 'UNAVAILABLE'); } catch { return undefined; }
+    }
+  }
+
+  return Object.freeze({
+    dispatch,
+    invalidate,
+    dispose,
+    get generation(): number { return generation; },
+  });
+}
```

## ISOLATED BROWSER FIXTURE — after Node focus GREEN

```diff
--- a/scripts/fixtures/g16-browser.mjs
+++ b/scripts/fixtures/g16-browser.mjs
@@ -4,6 +4,7 @@
 import { keccak256, stringWord, addressWord, uintWord, eip712Digest, domainSeparator,
   tradeTermsStructHash, evmTermsHash, verifyEoaSignature, verifyEoaAcceptance, TRADE_TERMS_TYPE } from '../../packages/wallet/src/evm-terms.ts';
 import { verifyEvmAgreementBundle } from '../../packages/wallet/src/evm-agreement.ts';
+import { createEvmAgreementHost } from '../../packages/wallet/src/evm-agreement-host.ts';
 import { encodePrivateAgreement, encodeCapabilities, sha256Hex } from '../../packages/domain/index.ts';
 import { parseEvmAgreementInput } from '../../packages/schemas/src/evm-agreement-input.ts';
 import { parseEvmAgreementCheckRequest, parseEvmAgreementCheckReply } from '../../packages/schemas/src/evm-agreement-protocol.ts';
@@ -282,6 +283,93 @@
   check(parseEvmAgreementCheckReply({ version: 1, requestId: 1, generation: 0, operation: 'checkEvmAgreement', kind: 'response',
     result: { ok: false, error: { code: 'BUSY' } } }).result.error.code === 'BUSY', 'PROTO_BUSY_CODE');
   groups.push('private request-reply schema around the real verifier (structural, header IDs are data only)');
+
+  // Actual host lifecycle around the REAL verifier. Only the sha256 seam is supplied (wrapping native digest);
+  // no fake verifier, clock or timer, so the 30s bound is not exercised. Direct host calls: not transport/app inclusion.
+  // Oracle rule: observed verifier arrays are asserted cleared BEFORE any test-owned cleanup; cleanup never masks assertions.
+  {
+    const hostRequest = (id, gen, input) => ({ version: 1, requestId: id, generation: gen, operation: 'checkEvmAgreement', input });
+    const hostWipe = arrays => { for (const bytes of arrays) bytes.fill(0); };
+    // One event-loop turn: drain barrier AFTER known backend completion, not a retry or poll.
+    const drain = () => new Promise(done => setTimeout(done, 0));
+    // Coherent: every corpus bundle through the real verifier via the host.
+    {
+      const observed = [], host = createEvmAgreementHost({ sha256: async bytes => {
+        observed.push(bytes); return crypto.subtle.digest('SHA-256', bytes);
+      } });
+      try {
+        for (let index = 0; index < corpus.bundles.length; index++) {
+          const hostReply = await host.dispatch(hostRequest(index + 1, 0, bundleAt(index)));
+          check(hostReply !== undefined && hostReply.requestId === index + 1 && hostReply.generation === 0 && hostReply.result.ok === true, 'HOST_COHERENT_OK');
+          check(hostReply.result.value.termsHash === corpus.nodeDigests[index], 'HOST_NODE_DIGEST_PARITY');
+          check(hostReply.result.value.testOnly === true && hostReply.result.value.economicPreparationAllowed === false, 'HOST_SPENDING_DISABLED');
+          check(!/paymentInstructions|agreementSalt|signature|capabilities/.test(JSON.stringify(hostReply)), 'HOST_PRIVATE_REPLY');
+        }
+        check(observed.length > 0, 'HOST_REAL_HASH_USED');
+        check(cleared(observed), 'HOST_OBSERVED_CLEARED');
+      } finally { host.dispose(); hostWipe(observed); }
+    }
+    // Held SHA at first and second await: invalidate, BUSY while held, backend completion + drain, then recovery.
+    for (const at of [1, 2]) {
+      const observed = [], entered = deferred(), gate = deferred(), backendDone = deferred();
+      const host = createEvmAgreementHost({ sha256: async bytes => {
+        observed.push(bytes);
+        const native = crypto.subtle.digest('SHA-256', bytes);
+        if (observed.length === at) {
+          entered.resolve();
+          await gate.promise;
+          try { return await native; } finally { backendDone.resolve(); }
+        }
+        return native;
+      } });
+      try {
+        const pending = host.dispatch(hostRequest(1, 0, bundleAt(0)));
+        await entered.promise;
+        host.invalidate();
+        check(host.generation === 1, 'HOST_INVALIDATE_GENERATION');
+        // Physical slot still held: current-generation request must be BUSY BEFORE the gate is released.
+        const busy = await host.dispatch(hostRequest(2, 1, bundleAt(0)));
+        check(busy !== undefined && busy.requestId === 2 && busy.generation === 1 && busy.result.ok === false && busy.result.error.code === 'BUSY', 'HOST_BUSY_UNTIL_SETTLED');
+        gate.resolve();
+        check(await pending === undefined, 'HOST_INVALIDATED_QUIET');
+        // Explicit completion of the held backend digest, then one event-loop turn to drain verifier/host finalizers.
+        await backendDone.promise;
+        await drain();
+        check(observed.length >= at, 'HOST_HELD_REACHED');
+        check(cleared(observed), 'HOST_HELD_OBSERVED_CLEARED_BEFORE_RECOVERY');
+        const fresh = await host.dispatch(hostRequest(3, 1, bundleAt(0)));
+        check(fresh !== undefined && fresh.requestId === 3 && fresh.generation === 1 && fresh.result.ok === true && fresh.result.value.termsHash === corpus.nodeDigests[0], 'HOST_RECOVERY_AFTER_RELEASE');
+        check(cleared(observed), 'HOST_HELD_OBSERVED_CLEARED_FINAL');
+      } finally { gate.resolve(); host.dispose(); hostWipe(observed); }
+    }
+    // Dispose is quiet: a held job disposed settles to no reply and later dispatches are refused silently.
+    {
+      const observed = [], entered = deferred(), gate = deferred(), backendDone = deferred();
+      const host = createEvmAgreementHost({ sha256: async bytes => {
+        observed.push(bytes);
+        const native = crypto.subtle.digest('SHA-256', bytes);
+        if (observed.length === 1) {
+          entered.resolve();
+          await gate.promise;
+          try { return await native; } finally { backendDone.resolve(); }
+        }
+        return native;
+      } });
+      try {
+        const pending = host.dispatch(hostRequest(1, 0, bundleAt(0)));
+        await entered.promise;
+        host.dispose();
+        gate.resolve();
+        check(await pending === undefined, 'HOST_DISPOSE_QUIET');
+        await backendDone.promise;
+        await drain();
+        check(observed.length >= 1, 'HOST_DISPOSE_REACHED');
+        check(cleared(observed), 'HOST_DISPOSE_OBSERVED_CLEARED');
+        check(await host.dispatch(hostRequest(2, 0, bundleAt(0))) === undefined, 'HOST_DISPOSED_REFUSES');
+      } finally { gate.resolve(); host.dispose(); hostWipe(observed); }
+    }
+    groups.push('actual host lifecycle around real verifier (direct call; invalidate, BUSY while held, backend-completion drain, quiet dispose)');
+  }
   return Object.freeze({ assertions, groups, independentKeccakKats: 2, independentG16Digests: 6,
     independentG16Signatures: signatures, officialMailRecovery: true, retainedPrivateEncodingVectors: 2,
     sameProviderIntegrationBundles: corpus.bundles.length, heldCancellationSchedules: 4,
```

## Returned Fable066review — static only

# Final static review — corrected 064 host vs 061 blocking issues

Nothing executed; all statements are traces of the 064 source as supplied. No product defect is claimed.

## Verdict: PASS — all 061 blocking/material items resolved, no new blocking regression found. No must-fix.

### C1 (normal completion suppressed by `finally`) — RESOLVED
Trace, normal success: `underlying.then(map).then(cb).finally(release)`. In `cb`, `job.settled = true`, timedOut/logicallyDone false, `elapsed` finite, `disposed`/generation ok, `liveOwned(job)` is evaluated **while `active === job`** (release has not run yet), so `job.resolve(outcome)` fires with the real verdict. The `await logical` continuation is enqueued at that point; the `finally` reaction is enqueued only after `cb` returns. Either way the post-await path in `dispatch` never consults `active`/`liveOwned` again — it only checks `disposed`, generation, `timedOut`, outcome and `elapsed`. Every ok:true and verifier failure code is therefore projected. Confirmed: logical settlement precedes physical slot release.

### Stale A must not clobber C — HOLDS
`finally` clears `active` only on identity match; `stopTimer`/`wipe` touch only `job`. After invalidation, A's logical deferred is already decided (`suppressed`), so A's late `cb` branches to the `logicallyDone` no-op resolve. C can only be admitted after A's `finally` releases the slot; A's `dispatch` continuation (already returned `undefined`) cannot run again. No cross-job state is written.

### C3 (monotonic clock) — RESOLVED
`Job.last` initialised to `started`; `elapsed` rejects `t < job.last` and advances `last`. A 29000→28000 regression between any two reads now yields `undefined` → verifier `isCurrent` false (CANCELLED inside verifier) and, in `cb`/post-await, `UNAVAILABLE` (not closed, per the A3 disposition "clock fault UNAVAILABLE / nonterminal").

### C5 + all TIMEOUT branches terminal — RESOLVED
Three timeout sources, each sets `timedOut`, aborts/wipes via `terminate`, and sets `closed = true`:
1. Timer callback: `timedOut = true; terminate(job); closed = true` — synchronous before the continuation can resume.
2. `cb` deadline check (`e >= 30000`): same triple; `terminate` resolves `'suppressed'` first, the following `resolve('timeout')` is a no-op, and post-await `outcome === 'suppressed' && job.timedOut` → TIMEOUT reply. Correct.
3. Post-await `e2 >= 30000`: same triple before returning TIMEOUT.
Slot stays held until physical settlement in all three (`active` untouched); no successor can run (`closed`).

### F1 (delayed timer after settlement) — RESOLVED
Callback guard `if (job.settled || job.logicallyDone || job.timedOut) return;`. `settled` is set in `cb` before `finally`, so a late delivery after a legitimate success is a no-op; a late delivery after invalidate hits `logicallyDone`. Confirmed no-op after settlement.

### A7 / invalidate–dispose prompt logical settle while physically BUSY — RESOLVED
`terminate` → `job.resolve('suppressed')` resolves the caller's `dispatch` promptly; `active` is retained, so a subsequent valid request gets `BUSY` (`invalidate` does not set `closed`; `dispose` does, so post-dispose dispatch returns `undefined`). After the held SHA settles, `finally` releases and explicit request C may run. Matches test item 3 ordering.

### F2 / A5 precedence — implemented as disposed
Post-await first check `if (disposed || job.generation !== generation) return undefined` runs before the timeout branches, so invalidate/dispose arriving after the timer fired dominates the queued TIMEOUT. Consistent with "invalidate/dispose dominates queued timeout".

### C4 (raw input retention) — RESOLVED
`input = undefined` immediately after parse; `request = undefined` immediately after `Promise.resolve(verifyEvmAgreementBundle(request.input, …))`, whose synchronous prefix has already snapshotted/encoded. Host-owned `signatures` remains the only retained private bytes and is wiped on every exit (refuse/throw paths, `terminate`, `finally`, post-await).

### Reentrancy — as disposed
`parsing` flag set before the strict parser; reentrant `dispatch` rejects with a fixed `CoreSchemaError('INVALID_INPUT')` without reading `input`. Genuine parser codes re-thrown as fresh `CoreSchemaError(code)`. requestId consumed before generation/BUSY gates (unchanged).

## Non-blocking notes (no action required)
- `timerWatch` is dead code; harmless, could be deleted.
- `request` is declared `| undefined`; depending on TS control-flow narrowing across the try/catch, `request.input` may need a non-null assertion. Compile-time only, not lifecycle.
- Clock-fault `UNAVAILABLE` leaves the host open and the slot released; this matches the stated disposition, not a regression.

Static only; Node/browser evidence remains the integrator's pending work.

## Actual integrator qualification still required

Run packetcommands: newNodehosttests (testpatchalonefortrueRED), focusedexistingverifier/body/protocoltests, privateChromiumdocument/Workerfixture, aggregate/build/boundaries/buildpolicy, unchangedgoldens/appgraph exclusionchecks. Preserve original206assertions/12groups; no newpassedcountsareclaimedhere. Directhostcallsprove onlyin-runtimehostbehavior whenexecuted, notactualmessage/route/DOM/Workerbridgeorappinclusion.

Theconditionalpreimportcopyspy mustproducepositiveobservations before claiming host-copyzeroization coverage; emptycapture is an explicit gap, not memoryproof. Verifier-ownedencodedarrays and caller-ownedbytes remainseparate. Fixed30s is exercisedonlybytrustedNodeclock/timerseams, notby browsergroup. No physical erasure/rollback/cancellationofnativehash ispromised.

Futureappbridge/currentrequestauthority, nativeprovider/disclosure andfinancial/trust/releasegates remainclosed. Nodefactory uses existingNoble-familysyntheticpublicsigning, notnewindependentcryptoqualification. Allproposedcode requiresactualtypes/tests; anyharnessfalseoracle mustbe fixed separatelyfromactualproductdefects. No automaticretry, testcase/deadline/coverage/KDF reduction, sourcetransfer beyondapprovedscope, publicationorreal funds.
