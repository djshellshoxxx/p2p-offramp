# P2P-G16-PRECLONE-02 — corrected Claude proposal, UNEXECUTED

Private delivery to sole P2P integrator. No P2P source was applied in GhostPay and no P2P code/commands, including syntax/type/tests/browser, were executed by this broker. All outcomes below are PROPOSED until the integrator runs them. This is not app inclusion or security/provider qualification.

Base commit `4e3f3ccde34ada7908026a66c6647c689c130574`; base tree `939ddea89e4f9cdde5908847c1e19c0d0d75d9c6`. Input Library `libfile_9dc276ac3e80819190180aef917ed909` v0,74740bytes/1049lines,SHA256 `efc2e35767832af098b2bd08c97e0a24acf118e254b8acd4ca16f7b90439cf5c`. Complete native read and all12provided source/excerpt block hashes matched. New files were absent; no fabricated empty-file base hash.

## Applied to proposal data only

- Sonnet033 generated parser, missing-entry RED unit tests and private browser extension.
- Fable034 returned HTTP200/max_tokens with18000thinking tokens and no visible findings/patch; charged$1.39462. Nothing from it was claimed reviewed/applied. It was not an access denial or unknown inference; no automatic retry.
- Targeted Fable035 corrected the concrete constructor/species hazard: fixed owned65byte allocation and intrinsic typed-array copy, registration before copy, owned-byte cleanup and safe revoked-proxy error handling, with adversarial tests. Medium effort and narrower verified packet excerpts were used after checking official effort documentation; adaptive thinking remained on. No invented fast/disabled mode.
- Sonnet037 corrected false4096-byte expectation, specific-sentinel BigInt oracle, missing-entry/transitive-import handling, forged-error privacy and parser->real-verifier browser evidence. Owned browser snapshots are wiped in finally where added; original153assertions/9groups and independent expected digests remain.
- Broker only reconstructed/checked exact old hunks in memory and regenerated ordinary diff headers. The standalone forged-error test insertion had no location in the returned bare hunk; it is appended at top level. One reviewed guard tightening uses exact `error.url === moduleUrl.href` only: a loose message-substring fallback could also match a transitive error's importer, contrary to the packet. This is explicit; no silent logic rewrite or P2P execution.

Only the three reserved output paths occur. Public facade/app/Worker wiring, existing encoders/verifier/goldens, dependencies, financial/provider policy, ReleaseEnabled0 and spending settings are untouched. Parser remains synchronous structural data only, not commitment/signature/account/trust verification. Outputs own130signature bytes; caller must wipe them. Fixed offset views are copied without retaining the whole backing buffer; detached/shared/resizable storage rejects. Prototype restriction remains as proposed; broader cross-realm acceptance is not claimed. Engine/OOM/meta-trap isolation and immutable-string erasure are not promised.

## Source and patch correspondence

```json
[
  {
    "path": "packages/schemas/test/evm-agreement-input.test.mjs",
    "base_state": "absent",
    "base_sha256": null,
    "proposed_sha256": "f2aa35af47dbb51f0fe1b9fc2f029af58d16cf5b576d4ee0938d206a2fe531cb",
    "proposed_bytes": 18966,
    "patch_sha256": "b2e87578c9abbbc173a45f9e0b8f5228751bbfdb4c9cf474c4e64ed830e75aed",
    "patch": "P2P-G16-PRECLONE02-test.patch"
  },
  {
    "path": "packages/schemas/src/evm-agreement-input.ts",
    "base_state": "absent",
    "base_sha256": null,
    "proposed_sha256": "7b3e0a67bf70a53b1ebcc241097bd16a372197f0596f0868af448ce6e823af3d",
    "proposed_bytes": 13966,
    "patch_sha256": "15a74568b2d65c0c9fc6d71283e2fc95c9d3f4efafa27cc8d32b785bd8f30699",
    "patch": "P2P-G16-PRECLONE02-implementation.patch"
  },
  {
    "path": "scripts/fixtures/g16-browser.mjs",
    "base_state": "existing",
    "base_sha256": "62c1aba5f99794e9020ced78d623f8e391647821647de8f88f169243a8378e92",
    "proposed_sha256": "1fb7b6f8d138fc88117c0fedb92126fcf7b644e9341c90b459461f2d494a5601",
    "proposed_bytes": 17866,
    "patch_sha256": "f15b053427cb73441b7240e2e3c2ae9c630ec300a238ea170f5af1bae3c7dabe",
    "patch": "P2P-G16-PRECLONE02-browser.patch"
  }
]
```

## Actual API accounting (shared ledger, no allowance reset)

Total estimated PRECLONE02 inference cost: $2.671094. The failed-to-deliver thinking-only034 request is included, not hidden. All four inference outcomes are known successful HTTP responses; no P2P test execution follows from them. Separate older Opus fast429 reservation remains held in shared ledger, not spend.

```json
[
  {
    "tag": "p2p-g16-preclone-033",
    "model": "claude-sonnet-5-5",
    "timestamp_utc": "2026-10-27T00:46:48.182199+00:00",
    "completed_at_utc": "2026-10-27T00:48:08.007019+00:00",
    "request_id": "req_011CgRpUx4L7eQyvZ6YdRAP1",
    "usage": {
      "input_tokens": 33724,
      "cache_creation_input_tokens": 0,
      "cache_read_input_tokens": 0,
      "cache_creation": {
        "ephemeral_5m_input_tokens": 0,
        "ephemeral_1h_input_tokens": 0
      },
      "output_tokens": 15728,
      "output_tokens_details": {
        "thinking_tokens": 0
      },
      "service_tier": "standard",
      "inference_geo": "global",
      "speed": "standard"
    },
    "stop_reason": "end_turn",
    "estimated_cost_usd": "0.224728",
    "worst_case_reserved_usd": "2.2",
    "state": "completed"
  },
  {
    "tag": "fable-p2p-preclone-boundary-review-034",
    "model": "claude-fable-5-1",
    "timestamp_utc": "2026-10-27T00:51:10.281494+00:00",
    "completed_at_utc": "2026-10-27T00:55:11.312102+00:00",
    "request_id": "req_011CgRppH3rodLU2WVXfi9oJ",
    "usage": {
      "input_tokens": 49462,
      "cache_creation_input_tokens": 0,
      "cache_read_input_tokens": 0,
      "cache_creation": {
        "ephemeral_5m_input_tokens": 0,
        "ephemeral_1h_input_tokens": 0
      },
      "output_tokens": 18000,
      "output_tokens_details": {
        "thinking_tokens": 18000
      },
      "service_tier": "standard",
      "inference_geo": "global",
      "speed": "standard"
    },
    "stop_reason": "max_tokens",
    "estimated_cost_usd": "1.39462",
    "worst_case_reserved_usd": "3.24986",
    "state": "completed"
  },
  {
    "tag": "fable-p2p-signature-copy-correction-035",
    "model": "claude-fable-5-1",
    "timestamp_utc": "2026-10-27T01:00:32.339517+00:00",
    "completed_at_utc": "2026-10-27T01:03:16.381729+00:00",
    "request_id": "req_011CgRqXhpXpaLTWsz71SJQA",
    "usage": {
      "input_tokens": 20343,
      "cache_creation_input_tokens": 0,
      "cache_read_input_tokens": 0,
      "cache_creation": {
        "ephemeral_5m_input_tokens": 0,
        "ephemeral_1h_input_tokens": 0
      },
      "output_tokens": 14806,
      "output_tokens_details": {
        "thinking_tokens": 8053
      },
      "service_tier": "standard",
      "inference_geo": "global",
      "speed": "standard"
    },
    "stop_reason": "end_turn",
    "estimated_cost_usd": "0.94373",
    "worst_case_reserved_usd": "2.24398",
    "state": "completed"
  },
  {
    "tag": "p2p-preclone-final-oracle-corrections-037",
    "model": "claude-sonnet-5-5",
    "timestamp_utc": "2026-10-27T01:10:43.261394+00:00",
    "completed_at_utc": "2026-10-27T01:11:01.675819+00:00",
    "request_id": "req_011CgRrJjobceZXomf8D3GEa",
    "usage": {
      "input_tokens": 36778,
      "cache_creation_input_tokens": 0,
      "cache_read_input_tokens": 0,
      "cache_creation": {
        "ephemeral_5m_input_tokens": 0,
        "ephemeral_1h_input_tokens": 0
      },
      "output_tokens": 3446,
      "output_tokens_details": {
        "thinking_tokens": 0
      },
      "service_tier": "standard",
      "inference_geo": "global",
      "speed": "standard"
    },
    "stop_reason": "end_turn",
    "estimated_cost_usd": "0.108016",
    "worst_case_reserved_usd": "2.12",
    "state": "completed"
  }
]
```

## Integrator execution order — all UNEXECUTED here

1. Verify exact clean base and fixture hash. Apply TEST patch only; run the first command and record genuine missing-parser RED. Missing transitive dependency must rethrow, never be treated as a pass/skip.
2. Apply IMPLEMENTATION and BROWSER patches; inspect scope/type errors and run actual focused GREEN plus unchanged full gates below. Keep declared environment limitations honest; no security/header changes to expose SharedArrayBuffer.
3. Preserve all153original private Chromium assertions/9groups in document+Worker; totals may grow. Do not equate pure-parser tests with the later Worker cancellation/generation command lifecycle or app inclusion.

```text
node --test packages/schemas/test/evm-agreement-input.test.mjs
# After implementation/browser patches:
node --test packages/schemas/test/evm-agreement-input.test.mjs packages/domain/test/trade-terms.test.mjs packages/wallet/test/evm-terms.test.mjs packages/wallet/test/evm-agreement.test.mjs
P2P_CHROMIUM=/usr/bin/chromium node scripts/test-g16-browser.mjs
npm test
npm run build
npm run check:boundaries
npm run test:build-policy
```

## TEST — P2P-G16-PRECLONE02-test.patch

```diff
diff --git a/packages/schemas/test/evm-agreement-input.test.mjs b/packages/schemas/test/evm-agreement-input.test.mjs
new file mode 100644
--- /dev/null
+++ b/packages/schemas/test/evm-agreement-input.test.mjs
@@ -0,0 +1,255 @@
+import test from 'node:test';
+import assert from 'node:assert/strict';
+// Test-scoped spy over the intrinsic copy method. The module caches %TypedArray%.prototype.set at import time, so the
+// wrapper must be installed before the dynamic import and is restored in `finally` immediately after it. `copyHook` is
+// null except inside the one test that opts in, making the captured wrapper a pure pass-through otherwise.
+let copyHook = null;
+const nativeSet = Uint8Array.prototype.set;
+Uint8Array.prototype.set = function spiedSet(...args) { if (copyHook) copyHook(this, args); return nativeSet.apply(this, args); };
+let api;
+const moduleUrl = new URL('../src/evm-agreement-input.ts', import.meta.url);
+try {
+  api = await import(moduleUrl.href).catch(error => {
+    const target = error?.url === moduleUrl.href; // Exact missing target only; importer text must never hide a transitive miss.
+    if (error?.code === 'ERR_MODULE_NOT_FOUND' && target) return {};
+    throw error;
+  });
+}
+finally { Uint8Array.prototype.set = nativeSet; }
+assert.equal(Uint8Array.prototype.set, nativeSet);
+const parse = (...args) => { assert.equal(typeof api.parseEvmAgreementInput, 'function', 'missing parseEvmAgreementInput'); return api.parseEvmAgreementInput(...args); };
+const h = c => c.repeat(64);
+const A = c => '0x' + c.repeat(40);
+const make = () => ({
+  privateAgreement: { v: 1, orderId: h('a'), revision: '1', fiatCurrency: 'USD', fiatMinorUnits: '10000', fiatScale: 2,
+    paymentInstructions: 'PRIVATE-FIXTURE pay', capabilities: [{ id: 'alpha', version: '1', policyHash: h('b') }], agreementSalt: h('c') },
+  domain: { chainId: '11155111', verifyingContract: A('1') },
+  terms: { orderId: h('a'), revision: '1', networkId: 'eip155:1'.replace(':', '-'), deploymentId: 'escrow-v1', seller: A('2'), buyer: A('3'),
+    assetKind: 'erc20', asset: A('4'), amountBaseUnits: '1000', privateAgreementHash: h('d'), capabilitiesHash: h('e'),
+    sellerNonce: h('f'), acceptBeforeSeconds: '100', escrowExpirySeconds: '5000' },
+  acceptances: [
+    { termsHash: h('9'), role: 'seller', walletAccount: A('2'), signature: new Uint8Array(65).fill(7) },
+    { termsHash: h('9'), role: 'buyer', walletAccount: A('3'), signature: new Uint8Array(65).fill(8) }]
+});
+const bad = (mutate, code = 'INVALID_INPUT') => {
+  const input = make(); mutate(input);
+  assert.throws(() => parse(input), error => error.code === code && !String(error.message).includes('PRIVATE-FIXTURE'));
+};
+
+test('valid input yields frozen independent snapshot with owned signature copies', () => {
+  const input = make(); const out = parse(input);
+  assert.deepEqual(Object.keys(out).sort(), ['acceptances', 'domain', 'privateAgreement', 'terms']);
+  for (const o of [out, out.privateAgreement, out.domain, out.terms, out.acceptances, out.acceptances[0], out.privateAgreement.capabilities, out.privateAgreement.capabilities[0]]) assert.ok(Object.isFrozen(o));
+  assert.ok(!Object.isFrozen(out.acceptances[0].signature));
+  assert.equal(out.acceptances[0].signature.byteLength, 65);
+  assert.equal(out.acceptances[0].signature.buffer.byteLength, 65);
+  assert.notEqual(out.acceptances[0].signature.buffer, input.acceptances[0].signature.buffer);
+  input.acceptances[0].signature.fill(0); input.privateAgreement.paymentInstructions = 'x'; input.terms.amountBaseUnits = '9'; input.privateAgreement.capabilities[0].id = 'zzz';
+  assert.equal(out.acceptances[0].signature[0], 7);
+  assert.equal(out.privateAgreement.paymentInstructions, 'PRIVATE-FIXTURE pay');
+  assert.equal(out.terms.amountBaseUnits, '1000');
+  assert.equal(out.privateAgreement.capabilities[0].id, 'alpha');
+  assert.ok(!('verified' in out) && !('approved' in out));
+});
+test('native asset, buyer-first order, mismatched claims and arbitrary signature bytes are accepted structurally', () => {
+  const input = make(); input.terms.assetKind = 'native'; input.terms.asset = A('0');
+  input.acceptances.reverse(); input.acceptances[0].walletAccount = A('5'); input.acceptances[1].termsHash = h('1');
+  const out = parse(input); assert.equal(out.acceptances[0].role, 'buyer');
+});
+test('nonzero-offset view: exactly 65 independently owned bytes; constructor/species/byteLength/iterator/subarray never invoked', () => {
+  const input = make(); const backing = new ArrayBuffer(1000); new Uint8Array(backing).fill(1);
+  const view = new Uint8Array(backing, 100, 65); view.fill(5); view[0] = 3; view[64] = 9;
+  let calls = 0; const trap = () => { calls++; throw new Error('override invoked'); };
+  const species = { get [Symbol.species]() { return trap(); } };
+  for (const target of [view, backing]) {
+    Object.defineProperty(target, 'constructor', { get() { calls++; return species; }, configurable: true });
+    Object.defineProperty(target, 'byteLength', { get: trap, configurable: true });
+    Object.defineProperty(target, 'slice', { value: trap, configurable: true });
+  }
+  for (const key of ['length', 'byteOffset', 'buffer']) Object.defineProperty(view, key, { get: trap, configurable: true });
+  for (const key of [Symbol.iterator, 'subarray', 'set', 'at', 'valueOf', 'toString']) Object.defineProperty(view, key, { value: trap, configurable: true });
+  class HostileU8 extends Uint8Array { static get [Symbol.species]() { return trap(); } }
+  const sub = new HostileU8(65); sub.fill(8);
+  Object.defineProperty(sub.buffer, 'constructor', { get() { calls++; return species; }, configurable: true });
+  input.acceptances[0].signature = view; input.acceptances[1].signature = sub;
+  const out = parse(input); const sig = out.acceptances[0].signature;
+  assert.equal(calls, 0);
+  assert.equal(Object.getPrototypeOf(sig), Uint8Array.prototype);
+  assert.equal(Object.getPrototypeOf(out.acceptances[1].signature), Uint8Array.prototype);
+  assert.equal(sig.byteLength, 65); assert.equal(sig.byteOffset, 0); assert.equal(sig.buffer.byteLength, 65);
+  assert.notEqual(sig.buffer, backing); assert.notEqual(out.acceptances[1].signature.buffer, sub.buffer);
+  assert.deepEqual(Array.from(sig), [3, ...Array(63).fill(5), 9]);
+  assert.deepEqual(Array.from(out.acceptances[1].signature), Array(65).fill(8));
+  new Uint8Array(backing).fill(0); nativeSet.call(sub, new Uint8Array(65));
+  assert.equal(sig[0], 3); assert.equal(sig[64], 9); assert.equal(out.acceptances[1].signature[10], 8);
+  assert.equal(calls, 0);
+});
+test('buffer detached by a hostile descriptor meta-trap between validation and copy fails closed and zeros registered output', () => {
+  if (typeof structuredClone !== 'function') { assert.ok(true, 'environment without structuredClone transfer: detach-race case not exercised'); return; }
+  const input = make(); const first = input.acceptances[0].signature;
+  let fired = 0;
+  // acceptances[0] is fully validated before acceptances[1]'s descriptors are read; the trap detaches [0]'s buffer then.
+  input.acceptances[1] = new Proxy(input.acceptances[1], {
+    getOwnPropertyDescriptor(target, key) { if (!fired++) structuredClone(first.buffer, { transfer: [first.buffer] }); return Reflect.getOwnPropertyDescriptor(target, key); }
+  });
+  assert.throws(() => parse(input), e => e.code === 'INVALID_INPUT' && e.name === 'CoreSchemaError');
+  assert.equal(fired > 0, true); assert.equal(first.buffer.byteLength, 0);
+});
+test('hostile trap throwing a revoked proxy still yields fixed CoreSchemaError', () => {
+  const r = Proxy.revocable({}, {}); r.revoke();
+  bad(i => { i.domain = new Proxy({ chainId: '1', verifyingContract: A('1') }, { getPrototypeOf() { throw r.proxy; } }); });
+  bad(i => { i.acceptances[1] = new Proxy(i.acceptances[1], { ownKeys() { throw r.proxy; } }); });
+  bad(i => { i.terms = new Proxy(i.terms, { getOwnPropertyDescriptor() { throw r.proxy; } }); });
+  const input = make(); input.acceptances[0] = new Proxy(input.acceptances[0], { getPrototypeOf() { throw r.proxy; } });
+  assert.throws(() => parse(input), e => e.name === 'CoreSchemaError' && e.message === 'Invalid core data.' && e.code === 'INVALID_INPUT');
+});
+test('signature size and type failures', () => {
+  for (const n of [0, 64, 66, 100000]) bad(i => { i.acceptances[0].signature = new Uint8Array(n); });
+  bad(i => { i.acceptances[0].signature = new Uint16Array(65); });
+  bad(i => { i.acceptances[0].signature = new Proxy(new Uint8Array(65), {}); });
+  bad(i => { i.acceptances[0].signature = Array(65).fill(0); });
+  const r = Proxy.revocable(new Uint8Array(65), {}); r.revoke(); bad(i => { i.acceptances[0].signature = r.proxy; });
+  bad(i => { i.acceptances[0].signature = new Uint8Array(new SharedArrayBuffer(65)); });
+  if (typeof ArrayBuffer.prototype.resize === 'function') bad(i => { i.acceptances[0].signature = new Uint8Array(new ArrayBuffer(65, { maxByteLength: 100 })); });
+  if (typeof structuredClone === 'function') { const b = new ArrayBuffer(65); const v = new Uint8Array(b); structuredClone(b, { transfer: [b] }); bad(i => { i.acceptances[0].signature = v; }); }
+});
+test('bad shapes, extras, accessors and forged fields', () => {
+  bad(i => { delete i.domain; });
+  bad(i => { i.approved = true; });
+  bad(i => { i.terms.mode = 0; });
+  bad(i => { i.privateAgreement.extra = 1; });
+  bad(i => { Object.defineProperty(i.terms, 'buyer', { get() { throw Error('getter'); }, enumerable: true }); });
+  bad(i => { Object.defineProperty(i.domain, 'chainId', { value: '1', enumerable: false }); });
+  bad(i => { i.domain[Symbol('s')] = 1; });
+  bad(i => { i.terms = Object.create({ x: 1 }, Object.getOwnPropertyDescriptors(i.terms)); });
+  bad(i => { delete i.acceptances[0]; });
+  bad(i => { i.acceptances.extra = 1; });
+  bad(i => { i.acceptances = Object.assign(Object.create({}), i.acceptances); });
+  bad(i => { i.privateAgreement.capabilities = new Proxy([], {}); });
+  const r = Proxy.revocable({}, {}); r.revoke(); bad(i => { i.domain = r.proxy; });
+  for (const v of [null, 1, 'x', []]) assert.throws(() => parse(v), e => e.code === 'INVALID_INPUT');
+  bad(i => { i.privateAgreement = Object.freeze(i.privateAgreement); i.privateAgreement.v = 1; i.privateAgreement.capabilities = [{ id: 'a', version: '1', policyHash: h('b'), x: 1 }]; });
+});
+test('version handling', () => {
+  bad(i => { i.privateAgreement.v = 2; }, 'UNSUPPORTED_VERSION');
+  bad(i => { i.privateAgreement.v = '1'; }, 'UNSUPPORTED_VERSION');
+});
+test('instruction byte boundary and code-unit guard', () => {
+  const edge = text => { const i = make(); i.privateAgreement.paymentInstructions = text; return () => parse(i); };
+  assert.equal(parse(make()).privateAgreement.paymentInstructions.length > 0, true);
+  assert.doesNotThrow(edge('a'.repeat(4096))); assert.doesNotThrow(edge(''));
+  assert.doesNotThrow(edge('\u00e9'.repeat(2048))); assert.doesNotThrow(edge('\u20ac'.repeat(1365) + 'x'));
+  assert.throws(edge('\u20ac'.repeat(1365) + 'ab'), e => e.code === 'LIMIT_EXCEEDED');
+  assert.doesNotThrow(edge('\u{1F600}'.repeat(1024)));
+  assert.throws(edge('a'.repeat(4097)), e => e.code === 'LIMIT_EXCEEDED');
+  assert.throws(edge('\u00e9'.repeat(2049)), e => e.code === 'LIMIT_EXCEEDED');
+  assert.throws(edge('\u{1F600}'.repeat(1025)), e => e.code === 'LIMIT_EXCEEDED');
+  assert.throws(edge('\ud800'), e => e.code === 'INVALID_INPUT');
+  assert.throws(edge('\udc00x'), e => e.code === 'INVALID_INPUT');
+  bad(i => { i.privateAgreement.paymentInstructions = 5; });
+});
+test('fixed private fields', () => {
+  for (const [k, v] of [['orderId', 'A'.repeat(64)], ['orderId', 'a'.repeat(63)], ['agreementSalt', 'g'.repeat(64)], ['revision', '0'], ['revision', '01'],
+    ['revision', '18446744073709551616'], ['revision', 1], ['fiatCurrency', 'usd'], ['fiatCurrency', 'USDX'], ['fiatMinorUnits', '0'],
+    ['fiatMinorUnits', '340282366920938463463374607431768211456'], ['fiatMinorUnits', '9'.repeat(5000)], ['fiatScale', 7], ['fiatScale', -1], ['fiatScale', 1.5], ['fiatScale', '2']])
+    bad(i => { i.privateAgreement[k] = v; });
+  const ok = make(); ok.privateAgreement.revision = '18446744073709551615'; ok.privateAgreement.fiatMinorUnits = '340282366920938463463374607431768211455'; ok.privateAgreement.fiatScale = 6; parse(ok);
+});
+test('capabilities', () => {
+  const cap = (id, version = '1') => ({ id, version, policyHash: h('b') });
+  const set = list => { const i = make(); i.privateAgreement.capabilities = list; return () => parse(i); };
+  assert.doesNotThrow(set([])); assert.doesNotThrow(set(Array.from({ length: 8 }, (_, n) => cap('c' + n))));
+  assert.throws(set(Array.from({ length: 9 }, (_, n) => cap('c' + n))), e => e.code === 'LIMIT_EXCEEDED');
+  assert.throws(set([cap('b'), cap('a')]), e => e.code === 'INVALID_INPUT');
+  assert.throws(set([cap('a'), cap('a')]), e => e.code === 'INVALID_INPUT');
+  assert.throws(set([cap('')]), e => e.code === 'INVALID_INPUT');
+  assert.throws(set([cap('a b')]), e => e.code === 'INVALID_INPUT');
+  assert.throws(set([cap('\u00e9')]), e => e.code === 'INVALID_INPUT');
+  assert.throws(set([cap('a'.repeat(65))]), e => e.code === 'LIMIT_EXCEEDED');
+  assert.doesNotThrow(set([cap('a'.repeat(64))]));
+  assert.throws(set([cap('a', '')]), e => e.code === 'INVALID_INPUT');
+  assert.doesNotThrow(set([cap('a', '\u00e9'.repeat(16))]));
+  assert.throws(set([cap('a', '\u00e9'.repeat(17))]), e => e.code === 'LIMIT_EXCEEDED');
+  const spaced = make(); spaced.privateAgreement.capabilities = [cap('a', ' v 1 ')]; assert.equal(parse(spaced).privateAgreement.capabilities[0].version, ' v 1 ');
+  assert.throws(set([{ id: 'a', version: '1', policyHash: 'B'.repeat(64) }]), e => e.code === 'INVALID_INPUT');
+  assert.throws(set([cap('a', 'x'.repeat(33))]), e => e.code === 'LIMIT_EXCEEDED');
+  assert.throws(set(Object.assign([cap('a')], { 1: cap('b') }).slice(0, 1).concat([,])), e => e.code === 'INVALID_INPUT');
+});
+test('domain and terms', () => {
+  const U256 = (1n << 256n) - 1n;
+  const d = v => { const i = make(); i.domain.chainId = v; return () => parse(i); };
+  assert.doesNotThrow(d(U256.toString())); assert.throws(d((U256 + 1n).toString()), e => e.code === 'INVALID_INPUT');
+  for (const v of ['0', '01', '9'.repeat(200), 1, '1.0', '-1']) assert.throws(d(v), e => e.code === 'INVALID_INPUT');
+  for (const v of [A('0'), '0x' + 'A'.repeat(40), '0x1', 5]) bad(i => { i.domain.verifyingContract = v; });
+  bad(i => { i.terms.buyer = i.terms.seller; });
+  bad(i => { i.terms.seller = A('0'); }); bad(i => { i.terms.buyer = A('0'); });
+  bad(i => { i.terms.assetKind = 'native'; });
+  bad(i => { i.terms.asset = A('0'); });
+  bad(i => { i.terms.assetKind = 'spl'; });
+  bad(i => { i.terms.networkId = 'a..b'; }); bad(i => { i.terms.deploymentId = '-x'; }); bad(i => { i.terms.networkId = 'a'.repeat(65); }); bad(i => { i.terms.networkId = ''; });
+  bad(i => { i.terms.amountBaseUnits = '0'; });
+  bad(i => { i.terms.amountBaseUnits = (U256 + 1n).toString(); }); bad(i => { i.terms.amountBaseUnits = '9'.repeat(100); });
+  bad(i => { i.terms.revision = '0'; }); bad(i => { i.terms.revision = '18446744073709551616'; });
+  bad(i => { i.terms.acceptBeforeSeconds = '18446744073709551616'; }); bad(i => { i.terms.escrowExpirySeconds = '-1'; });
+  for (const k of ['orderId', 'privateAgreementHash', 'capabilitiesHash', 'sellerNonce']) bad(i => { i.terms[k] = 'A'.repeat(64); });
+  const ok = make(); ok.terms.acceptBeforeSeconds = '0'; ok.terms.escrowExpirySeconds = '18446744073709551615'; ok.terms.amountBaseUnits = U256.toString(); parse(ok);
+});
+test('acceptance structure', () => {
+  bad(i => { i.acceptances[1].role = 'seller'; });
+  bad(i => { i.acceptances.pop(); });
+  assert.throws(() => { const i = make(); i.acceptances.push({ ...i.acceptances[0] }); parse(i); }, e => e.code === 'LIMIT_EXCEEDED');
+  bad(i => { i.acceptances[0].role = 'admin'; });
+  bad(i => { i.acceptances[0].termsHash = 'A'.repeat(64); });
+  bad(i => { i.acceptances[0].walletAccount = '0x' + 'A'.repeat(40); });
+  bad(i => { i.acceptances[0].extra = 1; });
+  bad(i => { i.acceptances[0] = null; });
+});
+test('injected native-copy failure zeros every observed allocated output', () => {
+  const seen = []; const input = make();
+  copyHook = target => {
+    seen.push(target);
+    if (seen.length === 2) {
+      assert.equal(seen[0].byteLength, 65); assert.equal(seen[0][0], 7, 'first copy completed before injected failure');
+      assert.equal(target.byteLength, 65); assert.ok(target.every(b => b === 0));
+      throw new TypeError('injected copy failure');
+    }
+  };
+  try { assert.throws(() => parse(input), e => e.code === 'INVALID_INPUT' && e.name === 'CoreSchemaError'); }
+  finally { copyHook = null; }
+  assert.equal(seen.length, 2);
+  for (const target of seen) { assert.equal(Object.getPrototypeOf(target), Uint8Array.prototype); assert.equal(target.byteLength, 65); assert.ok(target.every(b => b === 0)); }
+  assert.notEqual(seen[0].buffer, input.acceptances[0].signature.buffer); assert.notEqual(seen[1].buffer, input.acceptances[1].signature.buffer);
+  assert.equal(input.acceptances[0].signature[0], 7); assert.equal(input.acceptances[1].signature[0], 8);
+  assert.equal(Uint8Array.prototype.set, nativeSet);
+  assert.equal(parse(make()).acceptances[1].signature[3], 8);
+});
+test('lengths are bounded before BigInt/encode', () => {
+  const orig = globalThis.BigInt; const sentinel = '9'.repeat(5000); let sentinelCalls = 0;
+  globalThis.BigInt = new Proxy(orig, { apply(t, th, a) { if (a[0] === sentinel) sentinelCalls++; return Reflect.apply(t, th, a); } });
+  try { bad(i => { i.terms.amountBaseUnits = '9'.repeat(5000); }); } finally { globalThis.BigInt = orig; }
+  assert.equal(globalThis.BigInt, orig);
+  assert.equal(sentinelCalls, 0);
+  const te = TextEncoder.prototype.encodeInto; const enc = TextEncoder.prototype.encode; let encodes = 0;
+  TextEncoder.prototype.encode = function (...a) { encodes++; return enc.apply(this, a); };
+  try { bad(i => { i.privateAgreement.paymentInstructions = 'a'.repeat(100000); }, 'LIMIT_EXCEEDED'); } finally { TextEncoder.prototype.encode = enc; }
+  assert.equal(encodes, 0); assert.equal(te, TextEncoder.prototype.encodeInto);
+});
+test('forged CoreSchemaError thrown by hostile meta-traps is replaced by a fresh fixed error without touching accessors', () => {
+  const Core = parse(make()) && Object.getPrototypeOf(((() => { try { parse(null); } catch (e) { return e; } })())).constructor;
+  let touched = 0;
+  const forged = new Core('LIMIT_EXCEEDED');
+  Object.defineProperty(forged, 'message', { get() { touched++; return 'PRIVATE-FIXTURE message'; } });
+  Object.defineProperty(forged, 'code', { get() { touched++; throw new Error('PRIVATE-FIXTURE code'); } });
+  const traps = ['getPrototypeOf', 'ownKeys', 'getOwnPropertyDescriptor'];
+  for (const trap of traps) {
+    const input = make();
+    input.domain = new Proxy(input.domain, { [trap]() { throw forged; } });
+    let caught;
+    try { parse(input); } catch (e) { caught = e; }
+    assert.notEqual(caught, forged);
+    assert.equal(caught.name, 'CoreSchemaError');
+    assert.equal(caught.code, 'INVALID_INPUT');
+    assert.equal(caught.message, 'Invalid core data.');
+  }
+  assert.equal(touched, 0);
+});
```

## IMPLEMENTATION — P2P-G16-PRECLONE02-implementation.patch

```diff
diff --git a/packages/schemas/src/evm-agreement-input.ts b/packages/schemas/src/evm-agreement-input.ts
new file mode 100644
--- /dev/null
+++ b/packages/schemas/src/evm-agreement-input.ts
@@ -0,0 +1,232 @@
+/** Private structural-only snapshot of the in-memory G16 EVM agreement bundle shape. It verifies nothing:
+ * no commitments, digests, signatures, account authority, expiry or trust. Synchronous and stateless.
+ * Input graph is bounded by fixed arity: 4 outer fields, 9 private fields, <=8 capabilities x3 fields,
+ * 2 domain, 14 terms and exactly 2 acceptances x4 fields; every string is length-capped before inspection.
+ * Residual limits: caller-supplied strings are immutable and outside erasure; JS proxy meta-traps and engine
+ * allocation are not isolated. Detached/shared/resizable signature storage is rejected, not raced.
+ */
+import { CoreSchemaError } from './core.ts';
+
+export interface EvmAgreementCapability { readonly id: string; readonly version: string; readonly policyHash: string; }
+export interface EvmAgreementPrivate {
+  readonly v: 1; readonly orderId: string; readonly revision: string; readonly fiatCurrency: string;
+  readonly fiatMinorUnits: string; readonly fiatScale: number; readonly paymentInstructions: string;
+  readonly capabilities: readonly Readonly<EvmAgreementCapability>[]; readonly agreementSalt: string;
+}
+export interface EvmAgreementDomain { readonly chainId: string; readonly verifyingContract: string; }
+export interface EvmAgreementTerms {
+  readonly orderId: string; readonly revision: string; readonly networkId: string; readonly deploymentId: string;
+  readonly seller: string; readonly buyer: string; readonly assetKind: 'native' | 'erc20'; readonly asset: string;
+  readonly amountBaseUnits: string; readonly privateAgreementHash: string; readonly capabilitiesHash: string;
+  readonly sellerNonce: string; readonly acceptBeforeSeconds: string; readonly escrowExpirySeconds: string;
+}
+export interface EvmAgreementAcceptance {
+  readonly termsHash: string; readonly role: 'seller' | 'buyer'; readonly walletAccount: string;
+  readonly signature: Uint8Array<ArrayBuffer>;
+}
+export interface EvmAgreementInputSnapshot {
+  readonly privateAgreement: Readonly<EvmAgreementPrivate>;
+  readonly domain: Readonly<EvmAgreementDomain>;
+  readonly terms: Readonly<EvmAgreementTerms>;
+  readonly acceptances: readonly Readonly<EvmAgreementAcceptance>[];
+}
+
+type Code = CoreSchemaError['code'];
+const fail = (code: Code = 'INVALID_INPUT'): never => { throw new CoreSchemaError(code); };
+const U64 = (1n << 64n) - 1n, U128 = (1n << 128n) - 1n, U256 = (1n << 256n) - 1n;
+const utf8 = new TextEncoder();
+const HEX64 = /^[0-9a-f]{64}$/, ADDR = /^0x[0-9a-f]{40}$/, ZERO = /^0x0{40}$/, ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
+
+const typedProto = Object.getPrototypeOf(Uint8Array.prototype) as object;
+const tagGet = Object.getOwnPropertyDescriptor(typedProto, Symbol.toStringTag)!.get! as (this: unknown) => unknown;
+const lenGet = Object.getOwnPropertyDescriptor(typedProto, 'length')!.get! as (this: unknown) => number;
+const offGet = Object.getOwnPropertyDescriptor(typedProto, 'byteOffset')!.get! as (this: unknown) => number;
+const bufGet = Object.getOwnPropertyDescriptor(typedProto, 'buffer')!.get! as (this: unknown) => ArrayBufferLike;
+const abByteLength = Object.getOwnPropertyDescriptor(ArrayBuffer.prototype, 'byteLength')!.get! as (this: unknown) => number;
+const abResizable = Object.getOwnPropertyDescriptor(ArrayBuffer.prototype, 'resizable')?.get as ((this: unknown) => boolean) | undefined;
+const abDetached = Object.getOwnPropertyDescriptor(ArrayBuffer.prototype, 'detached')?.get as ((this: unknown) => boolean) | undefined;
+/** Cached intrinsic constructor + %TypedArray%.prototype.set: neither consults constructor/Symbol.species nor caller methods. */
+const NativeU8 = Uint8Array, u8Set = Uint8Array.prototype.set;
+const ownKeys = Reflect.ownKeys, getDesc = Object.getOwnPropertyDescriptor, getProto = Object.getPrototypeOf, isArr = Array.isArray;
+
+/** `instanceof` on a revoked/hostile proxy value itself throws; never let that escape a catch. */
+function isSchemaError(error: unknown): error is CoreSchemaError {
+  try { return error instanceof CoreSchemaError; } catch { return false; }
+}
+function guard<T>(read: () => T): T {
+  try { return read(); } catch (error) { if (isSchemaError(error)) throw error; return fail(); }
+}
+/** Untrusted meta-operation boundary: whatever a hostile trap throws (including a forged CoreSchemaError) is
+ * discarded uninspected and replaced by a fresh fixed INVALID_INPUT. */
+function meta<T>(read: () => T): T {
+  try { return read(); } catch { return fail(); }
+}
+function dataRecord(input: unknown, keys: readonly string[]): Record<string, unknown> {
+  return guard(() => {
+    if (typeof input !== 'object' || input === null || isArr(input)) return fail();
+    const proto = meta(() => getProto(input));
+    if (proto !== Object.prototype && proto !== null) return fail();
+    const actual = meta(() => ownKeys(input));
+    if (actual.length !== keys.length || actual.some(k => typeof k !== 'string' || !keys.includes(k))) return fail();
+    const out = Object.create(null) as Record<string, unknown>;
+    for (const key of keys) {
+      const d = meta(() => getDesc(input, key));
+      if (!d || !d.enumerable || !('value' in d)) return fail();
+      out[key] = d.value;
+    }
+    return out;
+  });
+}
+function dataArray(input: unknown, max: number): unknown[] {
+  return guard(() => {
+    if (!isArr(input) || meta(() => getProto(input)) !== Array.prototype) return fail();
+    const ld = meta(() => getDesc(input, 'length'));
+    if (!ld || !('value' in ld) || typeof ld.value !== 'number' || !Number.isSafeInteger(ld.value) || ld.value < 0) return fail();
+    if (ld.value > max) return fail('LIMIT_EXCEEDED');
+    const n = ld.value, keys = meta(() => ownKeys(input));
+    if (keys.length !== n + 1) return fail();
+    const out: unknown[] = [];
+    for (let i = 0; i < n; i++) {
+      const d = meta(() => getDesc(input, String(i)));
+      if (!d || !d.enumerable || !('value' in d)) return fail();
+      out.push(d.value);
+    }
+    return out;
+  });
+}
+function hex64(v: unknown): string { if (typeof v !== 'string' || !HEX64.test(v)) return fail(); return v; }
+function addr(v: unknown, zero: boolean): string {
+  if (typeof v !== 'string' || !ADDR.test(v)) return fail();
+  if (!zero && ZERO.test(v)) return fail();
+  return v;
+}
+/** digitCap is checked on string length BEFORE BigInt conversion. */
+function uint(v: unknown, digitCap: number, max: bigint, min: bigint): string {
+  if (typeof v !== 'string' || v.length > digitCap || !/^(0|[1-9][0-9]*)$/.test(v)) return fail();
+  const n = BigInt(v);
+  if (n < min || n > max) return fail();
+  return v;
+}
+/** Conservative code-unit cap precedes validation and any encoding; UTF-8 bytes >= code units. */
+function text(v: unknown, min: number, max: number, ascii: boolean): string {
+  if (typeof v !== 'string') return fail();
+  if (v.length > max) return fail('LIMIT_EXCEEDED');
+  if (/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/.test(v)) return fail();
+  if (ascii && !/^[\x21-\x7e]*$/.test(v)) return fail();
+  const scratch = utf8.encode(v);
+  const n = scratch.byteLength;
+  scratch.fill(0);
+  if (n < min) return fail();
+  if (n > max) return fail('LIMIT_EXCEEDED');
+  return v;
+}
+
+function privateAgreement(input: unknown): Readonly<EvmAgreementPrivate> {
+  const r = dataRecord(input, ['v', 'orderId', 'revision', 'fiatCurrency', 'fiatMinorUnits', 'fiatScale', 'paymentInstructions', 'capabilities', 'agreementSalt']);
+  if (r.v !== 1) return fail('UNSUPPORTED_VERSION');
+  if (typeof r.fiatCurrency !== 'string' || !/^[A-Z]{3}$/.test(r.fiatCurrency)) return fail();
+  if (typeof r.fiatScale !== 'number' || !Number.isInteger(r.fiatScale) || r.fiatScale < 0 || r.fiatScale > 6) return fail();
+  const orderId = hex64(r.orderId);
+  const revision = uint(r.revision, 20, U64, 1n);
+  const fiatMinorUnits = uint(r.fiatMinorUnits, 39, U128, 1n);
+  const paymentInstructions = text(r.paymentInstructions, 0, 4096, false);
+  const entries = dataArray(r.capabilities, 8);
+  const caps: Readonly<EvmAgreementCapability>[] = [];
+  let previous: string | undefined;
+  for (const raw of entries) {
+    const c = dataRecord(raw, ['id', 'version', 'policyHash']);
+    const id = text(c.id, 1, 64, true);
+    if (previous !== undefined && !(previous < id)) return fail();
+    previous = id;
+    caps.push(Object.freeze({ id, version: text(c.version, 1, 32, false), policyHash: hex64(c.policyHash) }));
+  }
+  const agreementSalt = hex64(r.agreementSalt);
+  return Object.freeze({ v: 1 as const, orderId, revision, fiatCurrency: r.fiatCurrency, fiatMinorUnits, fiatScale: r.fiatScale,
+    paymentInstructions, capabilities: Object.freeze(caps), agreementSalt });
+}
+function domainOf(input: unknown): Readonly<EvmAgreementDomain> {
+  const r = dataRecord(input, ['chainId', 'verifyingContract']);
+  return Object.freeze({ chainId: uint(r.chainId, 78, U256, 1n), verifyingContract: addr(r.verifyingContract, false) });
+}
+function termsOf(input: unknown): Readonly<EvmAgreementTerms> {
+  const r = dataRecord(input, ['acceptBeforeSeconds', 'amountBaseUnits', 'asset', 'assetKind', 'buyer', 'capabilitiesHash', 'deploymentId',
+    'escrowExpirySeconds', 'networkId', 'orderId', 'privateAgreementHash', 'revision', 'seller', 'sellerNonce']);
+  for (const v of [r.networkId, r.deploymentId]) if (typeof v !== 'string' || !ID.test(v) || v.includes('..')) return fail();
+  const seller = addr(r.seller, false), buyer = addr(r.buyer, false);
+  if (seller === buyer) return fail();
+  let assetKind: 'native' | 'erc20', asset: string;
+  if (r.assetKind === 'native') { assetKind = 'native'; asset = addr(r.asset, true); if (!ZERO.test(asset)) return fail(); }
+  else if (r.assetKind === 'erc20') { assetKind = 'erc20'; asset = addr(r.asset, false); }
+  else return fail();
+  return Object.freeze({ orderId: hex64(r.orderId), revision: uint(r.revision, 20, U64, 1n), networkId: r.networkId as string,
+    deploymentId: r.deploymentId as string, seller, buyer, assetKind, asset, amountBaseUnits: uint(r.amountBaseUnits, 78, U256, 1n),
+    privateAgreementHash: hex64(r.privateAgreementHash), capabilitiesHash: hex64(r.capabilitiesHash), sellerNonce: hex64(r.sellerNonce),
+    acceptBeforeSeconds: uint(r.acceptBeforeSeconds, 20, U64, 0n), escrowExpirySeconds: uint(r.escrowExpirySeconds, 20, U64, 0n) });
+}
+
+interface Checked { readonly termsHash: string; readonly role: 'seller' | 'buyer'; readonly walletAccount: string; readonly source: Uint8Array; readonly offset: number }
+/** Validate signature brand/length/storage without copying; returns offset. Intrinsic getters only. */
+function checkSignature(value: unknown): number {
+  return guard(() => {
+    if (typeof value !== 'object' || value === null) return fail();
+    if (tagGet.call(value) !== 'Uint8Array') return fail();
+    if (lenGet.call(value) !== 65) return fail();
+    const buffer = bufGet.call(value);
+    // Intrinsic brand: the ArrayBuffer byteLength getter throws for SharedArrayBuffer/non-ArrayBuffer (guard -> INVALID_INPUT).
+    const total = abByteLength.call(buffer);
+    if (typeof total !== 'number' || getProto(buffer) !== ArrayBuffer.prototype) return fail();
+    if (abDetached?.call(buffer) === true || abResizable?.call(buffer) === true) return fail();
+    const offset = offGet.call(value);
+    if (!Number.isSafeInteger(offset) || offset < 0 || offset + 65 > total) return fail();
+    return offset;
+  });
+}
+function acceptancesOf(input: unknown, owned: Uint8Array<ArrayBuffer>[]): readonly Readonly<EvmAgreementAcceptance>[] {
+  const entries = dataArray(input, 2);
+  if (entries.length !== 2) return fail();
+  const checked: Checked[] = [];
+  for (const raw of entries) {
+    const r = dataRecord(raw, ['termsHash', 'role', 'walletAccount', 'signature']);
+    const termsHash = hex64(r.termsHash);
+    if (r.role !== 'seller' && r.role !== 'buyer') return fail();
+    const walletAccount = addr(r.walletAccount, true);
+    const offset = checkSignature(r.signature);
+    if (checked.some(c => c.role === r.role)) return fail();
+    checked.push({ termsHash, role: r.role, walletAccount, source: r.signature as Uint8Array, offset });
+  }
+  // All data validated. Allocate a fixed owned 65-byte Uint8Array, register it BEFORE copying so any failure zeros it,
+  // then copy exactly [offset, offset+65) through the cached intrinsic view constructor and %TypedArray%.prototype.set.
+  // Unlike ArrayBuffer.prototype.slice this path never reads buffer.constructor / Symbol.species. A buffer detached by a
+  // hostile meta-trap between validation and copy makes the intrinsic constructor/set throw -> fixed INVALID_INPUT.
+  const out: Readonly<EvmAgreementAcceptance>[] = [];
+  for (const c of checked) {
+    const signature = new NativeU8(65);
+    owned.push(signature);
+    try {
+      const buffer = bufGet.call(c.source) as ArrayBuffer;
+      if (abDetached?.call(buffer) === true || abByteLength.call(buffer) < c.offset + 65) return fail();
+      u8Set.call(signature, new NativeU8(buffer, c.offset, 65));
+    } catch (error) {
+      return isSchemaError(error) ? fail(error.code) : fail();
+    }
+    out.push(Object.freeze({ termsHash: c.termsHash, role: c.role, walletAccount: c.walletAccount, signature }));
+  }
+  return Object.freeze(out);
+}
+
+/** Structural snapshot only. Caller owns and must wipe the returned signature bytes. */
+export function parseEvmAgreementInput(input: unknown): Readonly<EvmAgreementInputSnapshot> {
+  const owned: Uint8Array<ArrayBuffer>[] = [];
+  try {
+    const raw = dataRecord(input, ['privateAgreement', 'domain', 'terms', 'acceptances']);
+    const agreement = privateAgreement(raw.privateAgreement);
+    const domain = domainOf(raw.domain);
+    const terms = termsOf(raw.terms);
+    const acceptances = acceptancesOf(raw.acceptances, owned);
+    return Object.freeze({ privateAgreement: agreement, domain, terms, acceptances });
+  } catch (error) {
+    for (const bytes of owned) bytes.fill(0);
+    if (isSchemaError(error)) throw error;
+    throw new CoreSchemaError();
+  }
+}
```

## BROWSER — P2P-G16-PRECLONE02-browser.patch

```diff
diff --git a/scripts/fixtures/g16-browser.mjs b/scripts/fixtures/g16-browser.mjs
--- a/scripts/fixtures/g16-browser.mjs
+++ b/scripts/fixtures/g16-browser.mjs
@@ -5,6 +5,7 @@
   tradeTermsStructHash, evmTermsHash, verifyEoaSignature, verifyEoaAcceptance, TRADE_TERMS_TYPE } from '../../packages/wallet/src/evm-terms.ts';
 import { verifyEvmAgreementBundle } from '../../packages/wallet/src/evm-agreement.ts';
 import { encodePrivateAgreement, encodeCapabilities, sha256Hex } from '../../packages/domain/index.ts';
+import { parseEvmAgreementInput } from '../../packages/schemas/src/evm-agreement-input.ts';
 
 const hex = bytes => Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
 const unhex = text => Uint8Array.from(text.match(/../g) ?? [], pair => Number.parseInt(pair, 16));
@@ -73,6 +74,52 @@
   }
   groups.push('retained Python-implementation private encoding and SHA256 expectations');
 
+  // Structural-only pre-clone snapshot: no crypto, no verifier lifecycle. Counts/codes only.
+  const structCode = mutate => {
+    const bundle = bundleAt(0); mutate(bundle);
+    let snap;
+    try { snap = parseEvmAgreementInput(bundle); return 'OK'; } catch (error) { return error?.code ?? 'OTHER'; }
+    finally { if (snap) for (const acceptance of snap.acceptances) acceptance.signature.fill(0); }
+  };
+  for (let index = 0; index < corpus.bundles.length; index++) {
+    const bundle = bundleAt(index), before = JSON.stringify(bundle), snap = parseEvmAgreementInput(bundle);
+    check(snap.acceptances.length === 2 && Object.isFrozen(snap) && Object.isFrozen(snap.terms) && Object.isFrozen(snap.acceptances), 'STRUCT_FROZEN');
+    check(snap.acceptances.every((a, i) => a.signature.byteLength === 65 && a.signature.buffer.byteLength === 65 &&
+      a.signature.buffer !== bundle.acceptances[i].signature.buffer && !Object.isFrozen(a.signature)), 'STRUCT_SIGNATURE_COPY');
+    bundle.acceptances[0].signature.fill(0); bundle.terms.amountBaseUnits = '2'; bundle.privateAgreement.paymentInstructions = 'changed';
+    check(snap.acceptances[0].signature.some(byte => byte !== 0) && snap.terms.amountBaseUnits !== '2' &&
+      snap.privateAgreement.paymentInstructions !== 'changed', 'STRUCT_INDEPENDENT');
+    check(before !== JSON.stringify(bundle) && !('verified' in snap), 'STRUCT_NO_AUTHORITY');
+    for (const acceptance of snap.acceptances) acceptance.signature.fill(0);
+  }
+  check(structCode(b => { b.acceptances.reverse(); }) === 'OK', 'STRUCT_ORDER');
+  check(structCode(b => { b.acceptances[0].termsHash = 'f'.repeat(64); b.acceptances[0].signature.fill(1); }) === 'OK', 'STRUCT_NOT_VERIFIER');
+  check(structCode(b => { b.privateAgreement.v = 2; }) === 'UNSUPPORTED_VERSION', 'STRUCT_VERSION');
+  check(structCode(b => { b.extra = true; }) === 'INVALID_INPUT', 'STRUCT_EXTRA');
+  check(structCode(b => { b.privateAgreement.paymentInstructions = 'x'.repeat(4097); }) === 'LIMIT_EXCEEDED', 'STRUCT_TEXT_LIMIT');
+  check(structCode(b => { b.terms.amountBaseUnits = '9'.repeat(5000); }) === 'INVALID_INPUT', 'STRUCT_DECIMAL_WIDTH');
+  check(structCode(b => { b.acceptances[0].signature = new Uint8Array(66); }) === 'INVALID_INPUT', 'STRUCT_SIGNATURE_WIDTH');
+  check(structCode(b => { b.acceptances[0].signature = new Proxy(b.acceptances[0].signature, {}); }) === 'INVALID_INPUT', 'STRUCT_PROXY');
+  check(structCode(b => { b.acceptances.push(b.acceptances[0]); }) === 'LIMIT_EXCEEDED', 'STRUCT_ACCEPTANCE_COUNT');
+  let structGetter = 0;
+  check(structCode(b => { Object.defineProperty(b.terms, 'buyer', { enumerable: true, get() { structGetter++; throw Error('PRIVATE-FIXTURE'); } }); }) === 'INVALID_INPUT' && structGetter === 0, 'STRUCT_GETTER');
+  const offset = bundleAt(0), backing = new ArrayBuffer(300), view = new Uint8Array(backing, 100, 65); view.set(offset.acceptances[0].signature);
+  offset.acceptances[0].signature = view; const offsetSnap = parseEvmAgreementInput(offset);
+  check(offsetSnap.acceptances[0].signature.buffer.byteLength === 65 && offsetSnap.acceptances[0].signature.every((byte, i) => byte === view[i]), 'STRUCT_OFFSET_VIEW');
+  for (const acceptance of offsetSnap.acceptances) acceptance.signature.fill(0);
+  groups.push('bounded structural pre-clone input snapshot (parser only, not Worker lifecycle)');
+
+  for (let index = 0; index < corpus.bundles.length; index++) {
+    const source = bundleAt(index);
+    let snap;
+    try {
+      snap = parseEvmAgreementInput(source);
+      const result = ok(await verify(snap));
+      check(result.termsHash === corpus.nodeDigests[index], 'STRUCT_TO_VERIFIER_PARITY');
+    } finally { if (snap) for (const acceptance of snap.acceptances) acceptance.signature.fill(0); }
+  }
+  groups.push('parser snapshot feeds real verifier with independent digest parity');
+
   for (let index = 0; index < corpus.bundles.length; index++) {
     const bundle = bundleAt(index), before = JSON.stringify(bundle), result = ok(await verify(bundle));
     check(result.termsHash === corpus.nodeDigests[index] && result.termsHash === evmTermsHash(bundle.domain, bundle.terms), 'BUNDLE_PARITY');
```
