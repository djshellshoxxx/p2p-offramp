# P2P G13 read-runtime proposal — corrected040, UNEXECUTED

Private proposal for the sole P2P integrator. Base4e3f3ccde34ada7908026a66c6647c689c130574 /tree939ddea89e4f9cdde5908847c1e19c0d0d75d9c6. Only packages/domain/src/read-retry.ts and packages/domain/test/read-retry.test.mjs may change. No PRECLONE02 dependency/overlap. Broker did not apply to a P2P checkout, execute/import code, install software or run any proposed tests.

Sonnet038 initially left callback-triggered cancellation explicitly broken and is preserved as rejected/incomplete, not a qualified fix. Sonnet040 corrects that mandatory scope with deterministic throw/cancellation/staleness oracles and minimal clock/random callback handling. Existing original tests are an exact byte prefix of the proposed test file. All runtime policy constants, attempts/timeouts/jitter ceilings and scheduler/disposer code remain unchanged. Proposed non-finite later clock samples now use fixed UNAVAILABLE together with thrown clock faults; review that compatibility detail during actual integration. No semantic RED/GREEN or full audit is claimed by this broker.

Raw model hunk headers were hand-counted incorrectly. Broker reconstructed each replacement only when its original context matched exactly once in verified packet text, then regenerated ordinary unified diff metadata with difflib. No runtime/test logic was rewritten. This is static patch normalization, not git apply or test execution. No original test was removed. The static expected RED notes below may include individual baseline passes; actual rejection/typing failures must be measured, not inferred from counts.

Apply tests-only patch to exact base first, record true failing-before assertions, then apply implementation and execute focused tests plus packet-prescribed affected gates. No command was executed here. Do not call a scheduling assumption or static concern a verified product defect before reproduction.

```json
{
  "assignment": "P2P-G13-READ-RUNTIME-04",
  "base_commit": "4e3f3ccde34ada7908026a66c6647c689c130574",
  "base_tree": "939ddea89e4f9cdde5908847c1e19c0d0d75d9c6",
  "packet": {
    "project": "p2p",
    "assignment": "P2P-G13-READ-RUNTIME-04",
    "packet_path": "/workspace/ghostpay-intake/P2P-G13-read-runtime-Sonnet-packet-4e3f3cc-20261027.md",
    "packet_bytes": 35438,
    "packet_sha256": "030f1bf7a27e0dd8bd5f026d7be15950d7ae4dfb704a3700c360c6bee17a4c40",
    "library_file_id": "libfile_a4a3e968cb288191ac6464ae0b8e6f9f",
    "version": 0,
    "base_commit": "4e3f3ccde34ada7908026a66c6647c689c130574",
    "base_tree": "939ddea89e4f9cdde5908847c1e19c0d0d75d9c6",
    "files": [
      {
        "path": "packages/domain/src/read-retry.ts",
        "role": "reserved output",
        "wholeFile": true,
        "fileSha256": "b19c0acb856e990d5fd48a9022aac458bde3427e108528ed532558156bd8babf",
        "fileBytes": 6536,
        "startLine": 1,
        "endLine": 114,
        "includedSha256": "b19c0acb856e990d5fd48a9022aac458bde3427e108528ed532558156bd8babf",
        "includedBytes": 6536
      },
      {
        "path": "packages/domain/test/read-retry.test.mjs",
        "role": "reserved output",
        "wholeFile": true,
        "fileSha256": "ffd25ccdbbfe95dacd247fd6177cf890b006f7b9c86839495e8aa874f62003c4",
        "fileBytes": 7508,
        "startLine": 1,
        "endLine": 72,
        "includedSha256": "ffd25ccdbbfe95dacd247fd6177cf890b006f7b9c86839495e8aa874f62003c4",
        "includedBytes": 7508
      },
      {
        "path": "packages/domain/src/errors.ts",
        "role": "read-only review/context",
        "wholeFile": true,
        "fileSha256": "2a8d8bc2f199c4ae803ef3e16ba42a84d3868c66a780dbdb1d15c71320c442a5",
        "fileBytes": 3150,
        "startLine": 1,
        "endLine": 39,
        "includedSha256": "2a8d8bc2f199c4ae803ef3e16ba42a84d3868c66a780dbdb1d15c71320c442a5",
        "includedBytes": 3150
      },
      {
        "path": "packages/schemas/src/core.ts",
        "role": "read-only review/context",
        "wholeFile": false,
        "fileSha256": "079ac1a941b77111500a6642b95430571d89f3e2d93b377a583c27e9cb013f36",
        "fileBytes": 7446,
        "startLine": 24,
        "endLine": 41,
        "includedSha256": "f09ad1505cd2714b0a9d3f8b7877730064ec058eb9312d1f8d2cbe81f5a90d58",
        "includedBytes": 1632
      },
      {
        "path": "00_PLANNING_AND_THREAT_MODELING/feature_0.4_architecture_planning/module_0.4.5_failure_contract/spec-typed-errors-and-retries.md",
        "role": "read-only review/context",
        "wholeFile": true,
        "fileSha256": "446025bb614a5feee14555d96ed41ea9ac54d4c1537f043c4397e10f8146af02",
        "fileBytes": 5421,
        "startLine": 1,
        "endLine": 62,
        "includedSha256": "446025bb614a5feee14555d96ed41ea9ac54d4c1537f043c4397e10f8146af02",
        "includedBytes": 5421
      },
      {
        "path": "tsconfig.json",
        "role": "read-only review/context",
        "wholeFile": true,
        "fileSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
        "fileBytes": 389,
        "startLine": 1,
        "endLine": 16,
        "includedSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
        "includedBytes": 389
      }
    ],
    "verified_source_blocks": 6
  },
  "output_manifest": [
    {
      "path": "packages/domain/test/read-retry.test.mjs",
      "base_sha256": "ffd25ccdbbfe95dacd247fd6177cf890b006f7b9c86839495e8aa874f62003c4",
      "base_bytes": 7508,
      "proposed_sha256": "aad6e76847d16b74b33c7c3dbaf0e0601fcdd05ccccca1f0917203af992afad7",
      "proposed_bytes": 15896,
      "patch_path": "P2P-G13-RUNTIME04-tests.patch",
      "patch_sha256": "cd5e1e079a73b476a783671da52a356b4a833d1f153340d9fbfd85154b77321c",
      "patch_bytes": 8896,
      "status": "UNEXECUTED; inert text reconstruction only"
    },
    {
      "path": "packages/domain/src/read-retry.ts",
      "base_sha256": "b19c0acb856e990d5fd48a9022aac458bde3427e108528ed532558156bd8babf",
      "base_bytes": 6536,
      "proposed_sha256": "167e9a1fa602b50e5d36671b3553f0a388cac9479804e72f2998aa127d43e99e",
      "proposed_bytes": 7475,
      "patch_path": "P2P-G13-RUNTIME04-implementation.patch",
      "patch_sha256": "1ce2cc27b2d3ee889e7fcde8cb10ace4abc65e36b27c8b21cabef63e88e04d6c",
      "patch_bytes": 3044,
      "status": "UNEXECUTED; inert text reconstruction only"
    }
  ],
  "request_records": [
    {
      "tag": "p2p-g13-read-runtime-038",
      "project": "p2p",
      "assignment": "P2P-G13-READ-RUNTIME-04",
      "input_commit": "4e3f3ccde34ada7908026a66c6647c689c130574",
      "model": "claude-sonnet-5-5",
      "timestamp_utc": "2026-10-27T01:26:11.314622+00:00",
      "requested_speed": "standard",
      "source_format": "plain_text_blocks",
      "thinking_type": "between_tools",
      "effort": "medium",
      "source_hashes": [
        {
          "path": "P2P-G13-read-runtime-Sonnet-packet-4e3f3cc-20261027.md",
          "full_file_sha256": "030f1bf7a27e0dd8bd5f026d7be15950d7ae4dfb704a3700c360c6bee17a4c40",
          "transmitted_content_sha256": "030f1bf7a27e0dd8bd5f026d7be15950d7ae4dfb704a3700c360c6bee17a4c40",
          "library_file_id": "libfile_a4a3e968cb288191ac6464ae0b8e6f9f",
          "version": 0
        }
      ],
      "payload_bytes": 37522,
      "max_output_tokens": 14000,
      "worst_case_reserved_usd": "2.14",
      "state": "completed",
      "packet_provenance": {
        "project": "p2p",
        "assignment": "P2P-G13-READ-RUNTIME-04",
        "packet_bytes": 35438,
        "packet_sha256": "030f1bf7a27e0dd8bd5f026d7be15950d7ae4dfb704a3700c360c6bee17a4c40",
        "library_file_id": "libfile_a4a3e968cb288191ac6464ae0b8e6f9f",
        "version": 0,
        "base_commit": "4e3f3ccde34ada7908026a66c6647c689c130574",
        "base_tree": "939ddea89e4f9cdde5908847c1e19c0d0d75d9c6",
        "files": [
          {
            "path": "packages/domain/src/read-retry.ts",
            "role": "reserved output",
            "wholeFile": true,
            "fileSha256": "b19c0acb856e990d5fd48a9022aac458bde3427e108528ed532558156bd8babf",
            "fileBytes": 6536,
            "startLine": 1,
            "endLine": 114,
            "includedSha256": "b19c0acb856e990d5fd48a9022aac458bde3427e108528ed532558156bd8babf",
            "includedBytes": 6536
          },
          {
            "path": "packages/domain/test/read-retry.test.mjs",
            "role": "reserved output",
            "wholeFile": true,
            "fileSha256": "ffd25ccdbbfe95dacd247fd6177cf890b006f7b9c86839495e8aa874f62003c4",
            "fileBytes": 7508,
            "startLine": 1,
            "endLine": 72,
            "includedSha256": "ffd25ccdbbfe95dacd247fd6177cf890b006f7b9c86839495e8aa874f62003c4",
            "includedBytes": 7508
          },
          {
            "path": "packages/domain/src/errors.ts",
            "role": "read-only review/context",
            "wholeFile": true,
            "fileSha256": "2a8d8bc2f199c4ae803ef3e16ba42a84d3868c66a780dbdb1d15c71320c442a5",
            "fileBytes": 3150,
            "startLine": 1,
            "endLine": 39,
            "includedSha256": "2a8d8bc2f199c4ae803ef3e16ba42a84d3868c66a780dbdb1d15c71320c442a5",
            "includedBytes": 3150
          },
          {
            "path": "packages/schemas/src/core.ts",
            "role": "read-only review/context",
            "wholeFile": false,
            "fileSha256": "079ac1a941b77111500a6642b95430571d89f3e2d93b377a583c27e9cb013f36",
            "fileBytes": 7446,
            "startLine": 24,
            "endLine": 41,
            "includedSha256": "f09ad1505cd2714b0a9d3f8b7877730064ec058eb9312d1f8d2cbe81f5a90d58",
            "includedBytes": 1632
          },
          {
            "path": "00_PLANNING_AND_THREAT_MODELING/feature_0.4_architecture_planning/module_0.4.5_failure_contract/spec-typed-errors-and-retries.md",
            "role": "read-only review/context",
            "wholeFile": true,
            "fileSha256": "446025bb614a5feee14555d96ed41ea9ac54d4c1537f043c4397e10f8146af02",
            "fileBytes": 5421,
            "startLine": 1,
            "endLine": 62,
            "includedSha256": "446025bb614a5feee14555d96ed41ea9ac54d4c1537f043c4397e10f8146af02",
            "includedBytes": 5421
          },
          {
            "path": "tsconfig.json",
            "role": "read-only review/context",
            "wholeFile": true,
            "fileSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
            "fileBytes": 389,
            "startLine": 1,
            "endLine": 16,
            "includedSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
            "includedBytes": 389
          }
        ],
        "verified_source_blocks": 6
      },
      "http_status": 200,
      "request_id": "req_011CgRsV9dSqZyRbhHLpQ36p",
      "rate_limit_headers_sanitized": {
        "anthropic-ratelimit-input-tokens-limit": "500000",
        "anthropic-ratelimit-input-tokens-remaining": "492000",
        "anthropic-ratelimit-input-tokens-reset": "2026-10-27T01:26:13Z",
        "anthropic-ratelimit-output-tokens-limit": "80000",
        "anthropic-ratelimit-output-tokens-remaining": "78000",
        "anthropic-ratelimit-output-tokens-reset": "2026-10-27T01:26:32Z",
        "anthropic-ratelimit-requests-limit": "1000",
        "anthropic-ratelimit-requests-remaining": "999",
        "anthropic-ratelimit-requests-reset": "2026-10-27T01:26:11Z",
        "anthropic-ratelimit-tokens-limit": "580000",
        "anthropic-ratelimit-tokens-remaining": "570000",
        "anthropic-ratelimit-tokens-reset": "2026-10-27T01:26:13Z"
      },
      "usage": {
        "input_tokens": 15536,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 3331,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "returned_model": "claude-sonnet-5-5",
      "estimated_cost_usd": "0.064382",
      "response_path": "/workspace/ghostpay-intake/p2p-g13-read-runtime-038-response.txt",
      "completed_at_utc": "2026-10-27T01:26:31.840113+00:00",
      "elapsed_seconds": 20.496
    },
    {
      "tag": "p2p-g13-read-runtime-correction-040",
      "project": "p2p",
      "assignment": "P2P-G13-READ-RUNTIME-04 required cancellation correction",
      "input_commit": "4e3f3ccde34ada7908026a66c6647c689c130574",
      "model": "claude-sonnet-5-5",
      "timestamp_utc": "2026-10-27T01:27:21.158307+00:00",
      "requested_speed": "standard",
      "source_format": "plain_text_blocks",
      "thinking_type": "between_tools",
      "effort": "medium",
      "source_hashes": [
        {
          "path": "P2P-G13-read-runtime-Sonnet-packet-4e3f3cc-20261027.md",
          "full_file_sha256": "030f1bf7a27e0dd8bd5f026d7be15950d7ae4dfb704a3700c360c6bee17a4c40",
          "transmitted_content_sha256": "030f1bf7a27e0dd8bd5f026d7be15950d7ae4dfb704a3700c360c6bee17a4c40",
          "library_file_id": "libfile_a4a3e968cb288191ac6464ae0b8e6f9f",
          "version": 0
        }
      ],
      "payload_bytes": 46172,
      "max_output_tokens": 10000,
      "worst_case_reserved_usd": "2.1",
      "state": "completed",
      "packet_provenance": {
        "project": "p2p",
        "assignment": "P2P-G13-READ-RUNTIME-04",
        "packet_bytes": 35438,
        "packet_sha256": "030f1bf7a27e0dd8bd5f026d7be15950d7ae4dfb704a3700c360c6bee17a4c40",
        "library_file_id": "libfile_a4a3e968cb288191ac6464ae0b8e6f9f",
        "version": 0,
        "base_commit": "4e3f3ccde34ada7908026a66c6647c689c130574",
        "base_tree": "939ddea89e4f9cdde5908847c1e19c0d0d75d9c6",
        "files": [
          {
            "path": "packages/domain/src/read-retry.ts",
            "role": "reserved output",
            "wholeFile": true,
            "fileSha256": "b19c0acb856e990d5fd48a9022aac458bde3427e108528ed532558156bd8babf",
            "fileBytes": 6536,
            "startLine": 1,
            "endLine": 114,
            "includedSha256": "b19c0acb856e990d5fd48a9022aac458bde3427e108528ed532558156bd8babf",
            "includedBytes": 6536
          },
          {
            "path": "packages/domain/test/read-retry.test.mjs",
            "role": "reserved output",
            "wholeFile": true,
            "fileSha256": "ffd25ccdbbfe95dacd247fd6177cf890b006f7b9c86839495e8aa874f62003c4",
            "fileBytes": 7508,
            "startLine": 1,
            "endLine": 72,
            "includedSha256": "ffd25ccdbbfe95dacd247fd6177cf890b006f7b9c86839495e8aa874f62003c4",
            "includedBytes": 7508
          },
          {
            "path": "packages/domain/src/errors.ts",
            "role": "read-only review/context",
            "wholeFile": true,
            "fileSha256": "2a8d8bc2f199c4ae803ef3e16ba42a84d3868c66a780dbdb1d15c71320c442a5",
            "fileBytes": 3150,
            "startLine": 1,
            "endLine": 39,
            "includedSha256": "2a8d8bc2f199c4ae803ef3e16ba42a84d3868c66a780dbdb1d15c71320c442a5",
            "includedBytes": 3150
          },
          {
            "path": "packages/schemas/src/core.ts",
            "role": "read-only review/context",
            "wholeFile": false,
            "fileSha256": "079ac1a941b77111500a6642b95430571d89f3e2d93b377a583c27e9cb013f36",
            "fileBytes": 7446,
            "startLine": 24,
            "endLine": 41,
            "includedSha256": "f09ad1505cd2714b0a9d3f8b7877730064ec058eb9312d1f8d2cbe81f5a90d58",
            "includedBytes": 1632
          },
          {
            "path": "00_PLANNING_AND_THREAT_MODELING/feature_0.4_architecture_planning/module_0.4.5_failure_contract/spec-typed-errors-and-retries.md",
            "role": "read-only review/context",
            "wholeFile": true,
            "fileSha256": "446025bb614a5feee14555d96ed41ea9ac54d4c1537f043c4397e10f8146af02",
            "fileBytes": 5421,
            "startLine": 1,
            "endLine": 62,
            "includedSha256": "446025bb614a5feee14555d96ed41ea9ac54d4c1537f043c4397e10f8146af02",
            "includedBytes": 5421
          },
          {
            "path": "tsconfig.json",
            "role": "read-only review/context",
            "wholeFile": true,
            "fileSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
            "fileBytes": 389,
            "startLine": 1,
            "endLine": 16,
            "includedSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
            "includedBytes": 389
          }
        ],
        "verified_source_blocks": 6
      },
      "context_artifacts": [
        {
          "path": "p2p-g13-read-runtime-038-response.txt",
          "sha256": "a7a7a71d0db8dcf4ac63b58485fc026cb6eab606c46b7b6d0965e48cc0c5ad4a",
          "disposition": "UNEXECUTED incomplete proposal; cancellation invariant explicitly unimplemented"
        }
      ],
      "http_status": 200,
      "request_id": "req_011CgRsaHwtsbJ2dh2Vshc6w",
      "rate_limit_headers_sanitized": {
        "anthropic-ratelimit-input-tokens-limit": "500000",
        "anthropic-ratelimit-input-tokens-remaining": "490000",
        "anthropic-ratelimit-input-tokens-reset": "2026-10-27T01:27:24Z",
        "anthropic-ratelimit-output-tokens-limit": "80000",
        "anthropic-ratelimit-output-tokens-remaining": "79000",
        "anthropic-ratelimit-output-tokens-reset": "2026-10-27T01:28:03Z",
        "anthropic-ratelimit-requests-limit": "1000",
        "anthropic-ratelimit-requests-remaining": "999",
        "anthropic-ratelimit-requests-reset": "2026-10-27T01:27:21Z",
        "anthropic-ratelimit-tokens-limit": "580000",
        "anthropic-ratelimit-tokens-remaining": "569000",
        "anthropic-ratelimit-tokens-reset": "2026-10-27T01:27:24Z"
      },
      "usage": {
        "input_tokens": 19067,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "cache_creation": {
          "ephemeral_5m_input_tokens": 0,
          "ephemeral_1h_input_tokens": 0
        },
        "output_tokens": 6834,
        "output_tokens_details": {
          "thinking_tokens": 0
        },
        "service_tier": "standard",
        "inference_geo": "global",
        "speed": "standard"
      },
      "stop_reason": "end_turn",
      "returned_model": "claude-sonnet-5-5",
      "estimated_cost_usd": "0.106474",
      "response_path": "/workspace/ghostpay-intake/p2p-g13-read-runtime-correction-040-response.txt",
      "completed_at_utc": "2026-10-27T01:28:02.053620+00:00",
      "elapsed_seconds": 40.868
    }
  ],
  "status": "UNEXECUTED proposal; sole P2P integrator must demonstrate RED/GREEN"
}
```

## Independently applicable tests patch

```diff
--- a/packages/domain/test/read-retry.test.mjs
+++ b/packages/domain/test/read-retry.test.mjs
@@ -70,3 +70,109 @@
  const result=await retry(async()=>{calls++;return{get ok(){touched++;throw Error('SECRET');}};},{signal:new AbortController().signal,operationId:id});
  assert.equal(result.error.code,'INTEGRITY_FAILURE');assert.equal(touched,0);assert.equal(calls,1);assert.equal(time.pending,0);
 });
+test('a throwing initial now() resolves a fixed UNAVAILABLE result with zero operation calls',async()=>{
+ const{retry,time}=setup();let calls=0;
+ time.runtime.now=()=>{throw Error('SECRET https://rpc.test');};
+ const result=await retry(async()=>{calls++;return{ok:true,value:1};},{signal:new AbortController().signal,operationId:id});
+ assert.equal(result.ok,false);assert.equal(result.error.code,'UNAVAILABLE');assert.equal(result.error.correlationId,id);
+ assert.equal(calls,0);assert.doesNotMatch(JSON.stringify(result),/SECRET|rpc.test/);assert.equal(time.pending,0);
+});
+test('a later throwing now() after a settled failed attempt stops with UNAVAILABLE, no further reads or timers',async()=>{
+ const{retry,time}=setup();let calls=0,armed=false;
+ time.runtime.now=()=>{if(armed)throw Error('SECRET later');return 0;};
+ const task=retry(async()=>{calls++;armed=true;return failure('UNAVAILABLE');},{signal:new AbortController().signal,operationId:id});
+ await flush();const result=await task;
+ assert.equal(result.ok,false);assert.equal(result.error.code,'UNAVAILABLE');assert.equal(result.error.correlationId,id);
+ assert.equal(calls,1);assert.doesNotMatch(JSON.stringify(result),/SECRET/);
+ await time.advance(50_000);assert.equal(calls,1);assert.equal(time.pending,0);
+});
+test('a throwing random() after a settled retryable read stops with UNAVAILABLE, no backoff or retry',async()=>{
+ const{retry,time}=setup();let calls=0;
+ time.runtime.random=()=>{throw Error('SECRET rng');};
+ const task=retry(async()=>{calls++;return failure('UNAVAILABLE');},{signal:new AbortController().signal,operationId:id});
+ await flush();const result=await task;
+ assert.equal(result.ok,false);assert.equal(result.error.code,'UNAVAILABLE');assert.equal(result.error.correlationId,id);
+ assert.equal(calls,1);assert.doesNotMatch(JSON.stringify(result),/SECRET/);
+ await time.advance(50_000);assert.equal(calls,1);assert.equal(time.pending,0);
+});
+test('initial now() that aborts then throws resolves CANCELLED with zero calls',async()=>{
+ const{retry,time}=setup();const controller=new AbortController();let calls=0;
+ time.runtime.now=()=>{controller.abort();throw Error('SECRET');};
+ const result=await retry(async()=>{calls++;return{ok:true,value:1};},{signal:controller.signal,operationId:id});
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,0);assert.doesNotMatch(JSON.stringify(result),/SECRET/);assert.equal(time.pending,0);
+});
+test('initial now() that aborts then returns a valid number resolves CANCELLED with zero calls',async()=>{
+ const{retry,time}=setup();const controller=new AbortController();let calls=0;
+ time.runtime.now=()=>{controller.abort();return 0;};
+ const result=await retry(async()=>{calls++;return{ok:true,value:1};},{signal:controller.signal,operationId:id});
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,0);assert.equal(time.pending,0);
+});
+test('initial now() that makes isCurrent false then throws resolves CANCELLED',async()=>{
+ const{retry,time}=setup();let live=true,calls=0;
+ time.runtime.now=()=>{live=false;throw Error('SECRET');};
+ const result=await retry(async()=>{calls++;return{ok:true,value:1};},{signal:new AbortController().signal,operationId:id,isCurrent:()=>live});
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,0);assert.doesNotMatch(JSON.stringify(result),/SECRET/);assert.equal(time.pending,0);
+});
+test('now() that aborts while returning a valid number at the budget read before an attempt resolves CANCELLED',async()=>{
+ const{retry,time}=setup();const controller=new AbortController();let calls=0,reads=0;
+ time.runtime.now=()=>{reads++;if(reads===2)controller.abort();return 0;};
+ const result=await retry(async()=>{calls++;return{ok:true,value:1};},{signal:controller.signal,operationId:id});
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,0);assert.equal(time.pending,0);
+});
+test('now() that aborts then returns a non-finite value at the budget-zero path resolves CANCELLED, not TIMEOUT',async()=>{
+ const{retry,time}=setup();const controller=new AbortController();let calls=0,reads=0;
+ time.runtime.now=()=>{reads++;if(reads===2){controller.abort();return Number.NaN;}return 0;};
+ const result=await retry(async()=>{calls++;return{ok:true,value:1};},{signal:controller.signal,operationId:id});
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,0);assert.equal(time.pending,0);
+});
+test('now() that aborts then returns 40000 (budget exhausted) at the first budget read resolves CANCELLED, not TIMEOUT',async()=>{
+ const{retry,time}=setup();const controller=new AbortController();let calls=0,reads=0;
+ time.runtime.now=()=>{reads++;if(reads===2){controller.abort();return 40_000;}return 0;};
+ const result=await retry(async()=>{calls++;return{ok:true,value:1};},{signal:controller.signal,operationId:id});
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,0);assert.equal(time.pending,0);
+});
+test('post-attempt now() that aborts then throws resolves CANCELLED with no retry or timers',async()=>{
+ const{retry,time}=setup();const controller=new AbortController();let calls=0,armed=false;
+ time.runtime.now=()=>{if(armed){controller.abort();throw Error('SECRET');}return 0;};
+ const task=retry(async()=>{calls++;armed=true;return failure('UNAVAILABLE');},{signal:controller.signal,operationId:id});
+ await flush();const result=await task;
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,1);assert.doesNotMatch(JSON.stringify(result),/SECRET/);
+ await time.advance(50_000);assert.equal(calls,1);assert.equal(time.pending,0);
+});
+test('post-attempt now() that makes isCurrent false and returns 40000 resolves CANCELLED, not TIMEOUT',async()=>{
+ const{retry,time}=setup();let live=true,calls=0,armed=false;
+ time.runtime.now=()=>{if(armed){live=false;return 40_000;}return 0;};
+ const task=retry(async()=>{calls++;armed=true;return failure('UNAVAILABLE');},{signal:new AbortController().signal,operationId:id,isCurrent:()=>live});
+ await flush();const result=await task;
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,1);assert.equal(time.pending,0);
+});
+test('random() that aborts then returns a valid number resolves CANCELLED with no backoff scheduled',async()=>{
+ const{retry,time}=setup();const controller=new AbortController();let calls=0;
+ time.runtime.random=()=>{controller.abort();return 0.5;};
+ const task=retry(async()=>{calls++;return failure('UNAVAILABLE');},{signal:controller.signal,operationId:id});
+ await flush();const result=await task;
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,1);assert.equal(time.delays.length,1);assert.equal(time.pending,0);
+ await time.advance(50_000);assert.equal(calls,1);
+});
+test('random() that aborts then throws resolves CANCELLED, not UNAVAILABLE',async()=>{
+ const{retry,time}=setup();const controller=new AbortController();let calls=0;
+ time.runtime.random=()=>{controller.abort();throw Error('SECRET rng');};
+ const task=retry(async()=>{calls++;return failure('UNAVAILABLE');},{signal:controller.signal,operationId:id});
+ await flush();const result=await task;
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,1);assert.doesNotMatch(JSON.stringify(result),/SECRET/);assert.equal(time.pending,0);
+});
+test('random() that makes isCurrent false and returns an invalid value resolves CANCELLED, not UNAVAILABLE',async()=>{
+ const{retry,time}=setup();let live=true,calls=0;
+ time.runtime.random=()=>{live=false;return 2;};
+ const task=retry(async()=>{calls++;return failure('UNAVAILABLE');},{signal:new AbortController().signal,operationId:id,isCurrent:()=>live});
+ await flush();const result=await task;
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,1);assert.equal(time.pending,0);
+});
+test('now() that goes stale at the delay-vs-budget read after a valid random resolves CANCELLED, not TIMEOUT',async()=>{
+ const{retry,time}=setup(0.5);let live=true,calls=0,armed=false;
+ time.runtime.random=()=>{armed=true;return 0.5;};
+ time.runtime.now=()=>{if(armed){live=false;return 40_000;}return 0;};
+ const task=retry(async()=>{calls++;return failure('UNAVAILABLE');},{signal:new AbortController().signal,operationId:id,isCurrent:()=>live});
+ await flush();const result=await task;
+ assert.equal(result.error.code,'CANCELLED');assert.equal(calls,1);assert.equal(time.delays.length,1);assert.equal(time.pending,0);
+});```

## Independently applicable implementation patch

```diff
--- a/packages/domain/src/read-retry.ts
+++ b/packages/domain/src/read-retry.ts
@@ -32,15 +32,23 @@
       try { return !options.signal.aborted && (options.isCurrent === undefined || options.isCurrent() === true); } catch { return false; }
     };
     if (!current()) return error('CANCELLED');
-    const started = time.now();
+    // Runtime callbacks may throw or mutate ownership; faults map to NaN (existing invalid path), never raw text.
+    const sampleNow = (): number => { try { return time.now(); } catch { return Number.NaN; } };
+    const sampleRandom = (): number => { try { return time.random(); } catch { return Number.NaN; } };
+    let clockFault = false;
+    const started = sampleNow();
+    if (!current()) return error('CANCELLED');
     if (!Number.isFinite(started) || started < 0) return error('UNAVAILABLE');
     let elapsed = 0;
+    /** Returns -1 when ownership ended during the callback, otherwise the remaining budget (0 when exhausted or faulted). */
     const remaining = (): number => {
-      const now = time.now();
-      if (!Number.isFinite(now)) return 0;
+      const now = sampleNow();
+      if (!current()) return -1;
+      if (!Number.isFinite(now)) { clockFault = true; return 0; }
       elapsed = Math.max(elapsed, now - started);
       return Math.max(0, READ_OPERATION_BUDGET_MS - elapsed);
     };
+    const exhausted = (): CoreResult<never> => error(clockFault ? 'UNAVAILABLE' : 'TIMEOUT');
     const attempt = (budget: number): Promise<{ readonly result: CoreResult<T>; readonly operationSettled: boolean }> =>
       new Promise(resolve => {
         const controller = new AbortController();
@@ -95,17 +103,23 @@
     for (let index = 0; index < READ_MAX_ATTEMPTS; index++) {
       if (!current()) return error('CANCELLED');
       const budget = remaining();
-      if (budget <= 0) return error('TIMEOUT');
+      if (budget < 0) return error('CANCELLED');
+      if (budget === 0) return exhausted();
       const { result, operationSettled } = await attempt(budget);
       last = result;
       if (!current()) return error('CANCELLED');
-      if (remaining() <= 0) return error('TIMEOUT');
+      const left = remaining();
+      if (left < 0) return error('CANCELLED');
+      if (left === 0) return exhausted();
       if (result.ok || !result.error.retryable || !operationSettled || index === READ_MAX_ATTEMPTS - 1) return result;
-      const sample = time.random();
+      const sample = sampleRandom();
+      if (!current()) return error('CANCELLED');
       if (!Number.isFinite(sample) || sample < 0 || sample >= 1) return error('UNAVAILABLE');
       const ceiling = index === 0 ? 500 : 1000;
       const delay = Math.floor(sample * (ceiling + 1));
-      if (delay >= remaining()) return error('TIMEOUT');
+      const room = remaining();
+      if (room < 0) return error('CANCELLED');
+      if (delay >= room) return clockFault ? error('UNAVAILABLE') : error('TIMEOUT');
       if (!await backoff(delay)) return error('CANCELLED');
     }
     return last;
```

## Claude040 rationale and explicit limits



- **Ordering invariant.** Every injected callback (`now` at start, `now` inside `remaining`, `random`) is followed by a `current()` check before any return or scheduling. A callback that aborts, flips `isCurrent`, throws, or returns a valid, invalid or budget-exhausting number therefore resolves CANCELLED if ownership ended.
- **Preserved existing behavior.**
  - The existing `current()` guard before `started` is unchanged.
  - The existing "delayed runtime" test returns 40000 with a live owner. `remaining()` then returns 0 with `clockFault` false, so the result is still TIMEOUT.
  - The existing "UNAVAILABLE when random out of range" path is still reached with a live owner.
- **Exhausted versus fault.** `exhausted()` returns TIMEOUT for genuine budget exhaustion and UNAVAILABLE after a faulted (non-finite or thrown) clock sample, per the packet's fixed-error requirement. The final `delay >= room` branch inlines the same `clockFault` selection. `room === 0` with a live owner cannot reach `backoff` because `delay >= 0` always holds.
- **Budget-zero paths.** Both the pre-attempt and post-attempt `remaining()` calls distinguish stale (`-1`, CANCELLED) from exhausted (`0`).
- **No new timers.** Every new return occurs before `attempt()` or `backoff()` schedules. `backoff()` itself is unchanged.
- **Typing.** `error()` returns `CoreResult<never>`, assignable to `CoreResult<T>`. The new helper functions are declared before use inside the closure.

**Not changed, per scope, and found independently:** `time.schedule` and its returned disposer are called unguarded in `attempt`, `backoff` and `finish`. A throwing scheduler would reject the Promise or leave it pending. I have not patched it, since it is out of scope.

**Integrator commands (not run by me):** `node --test packages/domain/test/read-retry.test.mjs`; `node --test packages/domain/test/read-retry.test.mjs packages/domain/test/errors.test.mjs`; `npm test`; `npm run build`; `npm run check:boundaries`; `npm run test:build-policy`.

## Prior038 preserved disposition

The prior v0 artifact contained the raw incomplete038 proposal (SHA2569afaefb881c2240b107203840dbe0147a8195892da4f29a537a65f977a47ec98). Its request/cost remains in the manifest above; do not duplicate either inference. Full raw returns remain producer-local. Corrected040 remains unexecuted.
