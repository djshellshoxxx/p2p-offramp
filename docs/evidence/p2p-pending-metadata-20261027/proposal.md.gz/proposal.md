# P2P pending metadata privacy05 — Claude046 proposal, UNEXECUTED

Private source-pinned proposal for the sole P2P integrator. Base6519f05f71e31579d1c5caad206089d85c2824f8/tree4525cc92067f37814dbffe1dea036220614af4eb. Exactly three allowlisted paths; no existing test edited. No P2P checkout/source was applied, imported, compiled, tested or executed by this broker. Every RED/GREEN/acceptance command remains UNEXECUTED here.

The model proposes explicit2/3primitive-field frozen metadata while preserving full outgoing postMessage command and existing authority checks. This is direct-field minimization only; retained closures/caller strings/transport copies/physical erasure are outside its guarantee. Static inspection is not a test, heap audit or application inclusion approval. Existing G13/storage/Worker/protocol/G16/public interfaces are unchanged.

Normalization above removes explicitly withdrawn drafts, tightens the missing-entry import guard to the exact target URL per packet and regenerates hunk metadata. No runtime logic was independently invented or P2P Git history reconstructed. The integrator must apply tests first at exact base, measure genuine missing-helper RED, then apply helper/runtime and execute all unchanged packet gates. Reject unexpected outcomes rather than skip/assert less.

```json
{
  "assignment": "P2P-G16-PENDING-PRIVACY-05",
  "status": "UNEXECUTED inert proposal; sole P2P integrator applies/tests",
  "input": {
    "library_file_id": "libfile_f348b4b81c54819195701b59913b1768",
    "version": 1,
    "bytes": 154395,
    "sha256": "1c3683132698785514245bb9adfb508b0f0b3293d92eca5e9edd3ef739095f08",
    "source_blocks_verified": 15,
    "manifest": {
      "assignment": "P2P-G16-PENDING-PRIVACY-05",
      "baseSha": "6519f05f71e31579d1c5caad206089d85c2824f8",
      "baseTree": "4525cc92067f37814dbffe1dea036220614af4eb",
      "preparationOnly": true,
      "allowedProposalPaths": [
        {
          "path": "apps/web/src/runtime/app-runtime.ts",
          "baseState": "existing",
          "baseSha256": "ffed5657e175961de52eefa5366fd6114ea127314681ad48438925115b10e746",
          "baseBytes": 16843
        },
        {
          "path": "apps/web/src/runtime/pending-metadata.ts",
          "baseState": "absent",
          "baseSha256": null,
          "baseBytes": null
        },
        {
          "path": "apps/web/test/pending-metadata.test.mjs",
          "baseState": "absent",
          "baseSha256": null,
          "baseBytes": null
        }
      ],
      "implementationApplied": false,
      "testsBuildsRun": false,
      "paidCalls": 0,
      "appInclusion": false,
      "publicFacadeChangesAllowed": false,
      "sourceBlocks": [
        {
          "path": "apps/web/src/runtime/app-runtime.ts",
          "role": "only existing proposed output; complete AppRuntime and all lifecycle/request/reply functions",
          "wholeFile": true,
          "fileSha256": "ffed5657e175961de52eefa5366fd6114ea127314681ad48438925115b10e746",
          "fileBytes": 16843,
          "startLine": 1,
          "endLine": 259,
          "includedSha256": "ffed5657e175961de52eefa5366fd6114ea127314681ad48438925115b10e746",
          "includedBytes": 16843
        },
        {
          "path": "apps/web/test/app-runtime.test.mjs",
          "role": "read-only existing regression suite, complete; retain bytes/tests without modifications",
          "wholeFile": true,
          "fileSha256": "fec258b1adbf63bc356724e9f092fdf638b63687a9aaba8773a1a13c3d6da88b",
          "fileBytes": 16422,
          "startLine": 1,
          "endLine": 140,
          "includedSha256": "fec258b1adbf63bc356724e9f092fdf638b63687a9aaba8773a1a13c3d6da88b",
          "includedBytes": 16422
        },
        {
          "path": "packages/schemas/src/runtime.ts",
          "role": "read-only exact RuntimeCommand/response/error/limits and complete parsers; no protocol change allowed",
          "wholeFile": true,
          "fileSha256": "dc94e4cb60f486c783d34fa4aad11b675281d806a1f6752380265f73202f3cc4",
          "fileBytes": 13904,
          "startLine": 1,
          "endLine": 188,
          "includedSha256": "dc94e4cb60f486c783d34fa4aad11b675281d806a1f6752380265f73202f3cc4",
          "includedBytes": 13904
        },
        {
          "path": "apps/web/src/runtime/worker-endpoint.ts",
          "role": "read-only existing one-active-job/abort/generation ownership; no endpoint modifications allowed",
          "wholeFile": true,
          "fileSha256": "a086298074e6131111d98a448ca315b34ff3d7807e0b271f6ecffb0852e41b27",
          "fileBytes": 11663,
          "startLine": 1,
          "endLine": 183,
          "includedSha256": "a086298074e6131111d98a448ca315b34ff3d7807e0b271f6ecffb0852e41b27",
          "includedBytes": 11663
        },
        {
          "path": "packages/schemas/src/evm-agreement-input.ts",
          "role": "read-only integrated private G16 input interfaces; implementation already present, not missing",
          "wholeFile": false,
          "fileSha256": "7b3e0a67bf70a53b1ebcc241097bd16a372197f0596f0868af448ce6e823af3d",
          "fileBytes": 13966,
          "startLine": 1,
          "endLine": 33,
          "includedSha256": "4f37d4d7014e0dd56e2cfc3adf8e7d1b60f9802d70b58673b6384eded3889dbc",
          "includedBytes": 2196
        },
        {
          "path": "packages/schemas/src/evm-agreement-input.ts",
          "role": "read-only complete integrated parse entry; helper bodies intentionally omitted because this assignment must not change/use the parser",
          "wholeFile": false,
          "fileSha256": "7b3e0a67bf70a53b1ebcc241097bd16a372197f0596f0868af448ce6e823af3d",
          "fileBytes": 13966,
          "startLine": 217,
          "endLine": 232,
          "includedSha256": "dacf008888b2f733fed50733e5a00c167ac955bb95e4e4c97e701c3e41396a6c",
          "includedBytes": 768
        },
        {
          "path": "packages/wallet/src/evm-agreement.ts",
          "role": "read-only existing private verifier context/public-result interfaces; no provider/signing/app inclusion",
          "wholeFile": false,
          "fileSha256": "f7acb2d484db116c4cebac89d3c9d4e375af63bfe2f8aa3646e2117c19792991",
          "fileBytes": 6796,
          "startLine": 1,
          "endLine": 20,
          "includedSha256": "d743bd513125d5cc6b5ef8a78806ad4b29494d39e9998c60d7663d39576bff42",
          "includedBytes": 1339
        },
        {
          "path": "packages/schemas/index.ts",
          "role": "read-only current facade/import context; do not modify or add exports",
          "wholeFile": true,
          "fileSha256": "bccd9ce750e47dd4d39e6b2fd8cd7e9c93ea69f0739b3045fe9ccbe23b26108a",
          "fileBytes": 708,
          "startLine": 1,
          "endLine": 15,
          "includedSha256": "bccd9ce750e47dd4d39e6b2fd8cd7e9c93ea69f0739b3045fe9ccbe23b26108a",
          "includedBytes": 708
        },
        {
          "path": "docs/reviews/G16_BROWSER_DISPOSITION_2026-10-27.md",
          "role": "read-only existing conditional review requirements; old intake-gap wording is superseded by integrated PREALLOC/PRECLONE",
          "wholeFile": false,
          "fileSha256": "a8f026acf030f41190710ccb2b7f241a552c88049bbdaf09fb041537a501c47c",
          "fileBytes": 9447,
          "startLine": 16,
          "endLine": 28,
          "includedSha256": "02d83f60255b2e9fedf213cab1190c57b4e10db069200a6527fe6df35ebed825",
          "includedBytes": 2773
        },
        {
          "path": "docs/handoffs/P2P_G16_PRECLONE_2026-10-27.md",
          "role": "read-only next-prerequisite scope; G13 has since completed at b15179c and IDB timed out without report",
          "wholeFile": false,
          "fileSha256": "877154babadbbea35934537b3c0356471a0429159a5943db9d68d9facf389fe4",
          "fileBytes": 8443,
          "startLine": 43,
          "endLine": 48,
          "includedSha256": "6164dffa5cf3c42e92e5245bbb304bda9a82d59f4d2ee29449a777ff2c8fcf80",
          "includedBytes": 1418
        },
        {
          "path": "05_ADVANCED_PRIVACY_INFRASTRUCTURE/feature_5.3_client_security/spec-rainbow-book-data-remanence-and-memory-sanitization.md",
          "role": "read-only complete normative memory-lifetime paragraph; no physical-erasure guarantee",
          "wholeFile": false,
          "fileSha256": "8957370a33c60f3f7154bf5e77805808776a5b43671a94f372389046010d54eb",
          "fileBytes": 14705,
          "startLine": 20,
          "endLine": 20,
          "includedSha256": "94cebb1cd1a2fdea2a2d4d44942c92234ae64104923e2194a47e957a0bb4388e",
          "includedBytes": 483
        },
        {
          "path": "05_ADVANCED_PRIVACY_INFRASTRUCTURE/feature_5.3_client_security/spec-rainbow-book-data-remanence-and-memory-sanitization.md",
          "role": "read-only complete normative memory-lifetime paragraph; no physical-erasure guarantee",
          "wholeFile": false,
          "fileSha256": "8957370a33c60f3f7154bf5e77805808776a5b43671a94f372389046010d54eb",
          "fileBytes": 14705,
          "startLine": 71,
          "endLine": 71,
          "includedSha256": "5c5473c15b9aa219c2341ef4b9cefbde86ccdb96adc834853241ec7542c22ae6",
          "includedBytes": 380
        },
        {
          "path": "package.json",
          "role": "read-only actual commands/pins; no installs or dependency edits",
          "wholeFile": true,
          "fileSha256": "e5f8bbebfee3834201ee13b17bcfe531ddef25b9679b4349297ff56a75369707",
          "fileBytes": 1395,
          "startLine": 1,
          "endLine": 34,
          "includedSha256": "e5f8bbebfee3834201ee13b17bcfe531ddef25b9679b4349297ff56a75369707",
          "includedBytes": 1395
        },
        {
          "path": "tsconfig.json",
          "role": "read-only strict type options",
          "wholeFile": true,
          "fileSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
          "fileBytes": 389,
          "startLine": 1,
          "endLine": 16,
          "includedSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
          "includedBytes": 389
        },
        {
          "path": "apps/web/tsconfig.runtime.json",
          "role": "read-only document runtime compilation root",
          "wholeFile": true,
          "fileSha256": "fcf9b93d83f70aabd5ab90af8bcc962aecd4822e97be117b7561c08f6c54808e",
          "fileBytes": 135,
          "startLine": 1,
          "endLine": 5,
          "includedSha256": "fcf9b93d83f70aabd5ab90af8bcc962aecd4822e97be117b7561c08f6c54808e",
          "includedBytes": 135
        }
      ]
    }
  },
  "output_manifest": [
    {
      "path": "apps/web/test/pending-metadata.test.mjs",
      "base_state": "absent",
      "base_bytes": null,
      "base_sha256": null,
      "proposed_bytes": 7069,
      "proposed_sha256": "94d03e919b7958d86cdb7666a5091c078b5c50d5fa534a3ab3a9de04ed5f58eb",
      "patch_sha256": "3da76aba38882c4d695da2a9e59d1698338365c29b551fbe92d309ebbc87f98a"
    },
    {
      "path": "apps/web/src/runtime/pending-metadata.ts",
      "base_state": "absent",
      "base_bytes": null,
      "base_sha256": null,
      "proposed_bytes": 1355,
      "proposed_sha256": "c580db1dd24b50c8cf2bd8c4a02c7479d7fd9528f950bfc745245317cf3143cf",
      "patch_sha256": "513805563c36a2c9f60ab79327c58e7ebe5c2f338672ae5f6f9bb480f6963ad4"
    },
    {
      "path": "apps/web/src/runtime/app-runtime.ts",
      "base_state": "existing",
      "base_bytes": 16843,
      "base_sha256": "ffed5657e175961de52eefa5366fd6114ea127314681ad48438925115b10e746",
      "proposed_bytes": 16975,
      "proposed_sha256": "e3d150419605dcd29d878ace31c855d343e5304a356e53bb61ededc7b5654f19",
      "patch_sha256": "5b76e39a2a1cd6c06fd5da23f41d5cd7529675bb92f7cc0cd3c3c35a8dd9e0c9"
    }
  ],
  "request": {
    "tag": "p2p-pending-metadata-046",
    "project": "p2p",
    "assignment": "P2P-G16-PENDING-PRIVACY-05",
    "input_commit": "6519f05f71e31579d1c5caad206089d85c2824f8",
    "model": "claude-sonnet-5-5",
    "timestamp_utc": "2026-10-27T02:18:47.143917+00:00",
    "requested_speed": "standard",
    "source_format": "plain_text_blocks",
    "thinking_type": "between_tools",
    "effort": "medium",
    "source_hashes": [
      {
        "path": "P2P-G16-PENDING-PRIVACY-05-packet.md",
        "full_file_sha256": "1c3683132698785514245bb9adfb508b0f0b3293d92eca5e9edd3ef739095f08",
        "transmitted_content_sha256": "3cb18a7631a2b7bb10c2cf77f590339e4ca6ad6b53fbf42503449cddcf9e268a",
        "library_file_id": "libfile_f348b4b81c54819195701b59913b1768",
        "version": 1,
        "original_packet_line_ranges": [
          [
            1,
            1337
          ]
        ]
      }
    ],
    "payload_bytes": 106855,
    "max_output_tokens": 16000,
    "worst_case_reserved_usd": "2.16",
    "state": "completed",
    "packet_provenance": {
      "project": "p2p",
      "assignment": "P2P-G16-PENDING-PRIVACY-05",
      "packet_bytes": 154395,
      "packet_sha256": "1c3683132698785514245bb9adfb508b0f0b3293d92eca5e9edd3ef739095f08",
      "library_file_id": "libfile_f348b4b81c54819195701b59913b1768",
      "version": 1,
      "base_commit": "6519f05f71e31579d1c5caad206089d85c2824f8",
      "base_tree": "4525cc92067f37814dbffe1dea036220614af4eb",
      "allowed_paths": [
        {
          "path": "apps/web/src/runtime/app-runtime.ts",
          "baseState": "existing",
          "baseSha256": "ffed5657e175961de52eefa5366fd6114ea127314681ad48438925115b10e746",
          "baseBytes": 16843
        },
        {
          "path": "apps/web/src/runtime/pending-metadata.ts",
          "baseState": "absent",
          "baseSha256": null,
          "baseBytes": null
        },
        {
          "path": "apps/web/test/pending-metadata.test.mjs",
          "baseState": "absent",
          "baseSha256": null,
          "baseBytes": null
        }
      ],
      "source_blocks": [
        {
          "path": "apps/web/src/runtime/app-runtime.ts",
          "role": "only existing proposed output; complete AppRuntime and all lifecycle/request/reply functions",
          "wholeFile": true,
          "fileSha256": "ffed5657e175961de52eefa5366fd6114ea127314681ad48438925115b10e746",
          "fileBytes": 16843,
          "startLine": 1,
          "endLine": 259,
          "includedSha256": "ffed5657e175961de52eefa5366fd6114ea127314681ad48438925115b10e746",
          "includedBytes": 16843
        },
        {
          "path": "apps/web/test/app-runtime.test.mjs",
          "role": "read-only existing regression suite, complete; retain bytes/tests without modifications",
          "wholeFile": true,
          "fileSha256": "fec258b1adbf63bc356724e9f092fdf638b63687a9aaba8773a1a13c3d6da88b",
          "fileBytes": 16422,
          "startLine": 1,
          "endLine": 140,
          "includedSha256": "fec258b1adbf63bc356724e9f092fdf638b63687a9aaba8773a1a13c3d6da88b",
          "includedBytes": 16422
        },
        {
          "path": "packages/schemas/src/runtime.ts",
          "role": "read-only exact RuntimeCommand/response/error/limits and complete parsers; no protocol change allowed",
          "wholeFile": true,
          "fileSha256": "dc94e4cb60f486c783d34fa4aad11b675281d806a1f6752380265f73202f3cc4",
          "fileBytes": 13904,
          "startLine": 1,
          "endLine": 188,
          "includedSha256": "dc94e4cb60f486c783d34fa4aad11b675281d806a1f6752380265f73202f3cc4",
          "includedBytes": 13904
        },
        {
          "path": "apps/web/src/runtime/worker-endpoint.ts",
          "role": "read-only existing one-active-job/abort/generation ownership; no endpoint modifications allowed",
          "wholeFile": true,
          "fileSha256": "a086298074e6131111d98a448ca315b34ff3d7807e0b271f6ecffb0852e41b27",
          "fileBytes": 11663,
          "startLine": 1,
          "endLine": 183,
          "includedSha256": "a086298074e6131111d98a448ca315b34ff3d7807e0b271f6ecffb0852e41b27",
          "includedBytes": 11663
        },
        {
          "path": "packages/schemas/src/evm-agreement-input.ts",
          "role": "read-only integrated private G16 input interfaces; implementation already present, not missing",
          "wholeFile": false,
          "fileSha256": "7b3e0a67bf70a53b1ebcc241097bd16a372197f0596f0868af448ce6e823af3d",
          "fileBytes": 13966,
          "startLine": 1,
          "endLine": 33,
          "includedSha256": "4f37d4d7014e0dd56e2cfc3adf8e7d1b60f9802d70b58673b6384eded3889dbc",
          "includedBytes": 2196
        },
        {
          "path": "packages/schemas/src/evm-agreement-input.ts",
          "role": "read-only complete integrated parse entry; helper bodies intentionally omitted because this assignment must not change/use the parser",
          "wholeFile": false,
          "fileSha256": "7b3e0a67bf70a53b1ebcc241097bd16a372197f0596f0868af448ce6e823af3d",
          "fileBytes": 13966,
          "startLine": 217,
          "endLine": 232,
          "includedSha256": "dacf008888b2f733fed50733e5a00c167ac955bb95e4e4c97e701c3e41396a6c",
          "includedBytes": 768
        },
        {
          "path": "packages/wallet/src/evm-agreement.ts",
          "role": "read-only existing private verifier context/public-result interfaces; no provider/signing/app inclusion",
          "wholeFile": false,
          "fileSha256": "f7acb2d484db116c4cebac89d3c9d4e375af63bfe2f8aa3646e2117c19792991",
          "fileBytes": 6796,
          "startLine": 1,
          "endLine": 20,
          "includedSha256": "d743bd513125d5cc6b5ef8a78806ad4b29494d39e9998c60d7663d39576bff42",
          "includedBytes": 1339
        },
        {
          "path": "packages/schemas/index.ts",
          "role": "read-only current facade/import context; do not modify or add exports",
          "wholeFile": true,
          "fileSha256": "bccd9ce750e47dd4d39e6b2fd8cd7e9c93ea69f0739b3045fe9ccbe23b26108a",
          "fileBytes": 708,
          "startLine": 1,
          "endLine": 15,
          "includedSha256": "bccd9ce750e47dd4d39e6b2fd8cd7e9c93ea69f0739b3045fe9ccbe23b26108a",
          "includedBytes": 708
        },
        {
          "path": "docs/reviews/G16_BROWSER_DISPOSITION_2026-10-27.md",
          "role": "read-only existing conditional review requirements; old intake-gap wording is superseded by integrated PREALLOC/PRECLONE",
          "wholeFile": false,
          "fileSha256": "a8f026acf030f41190710ccb2b7f241a552c88049bbdaf09fb041537a501c47c",
          "fileBytes": 9447,
          "startLine": 16,
          "endLine": 28,
          "includedSha256": "02d83f60255b2e9fedf213cab1190c57b4e10db069200a6527fe6df35ebed825",
          "includedBytes": 2773
        },
        {
          "path": "docs/handoffs/P2P_G16_PRECLONE_2026-10-27.md",
          "role": "read-only next-prerequisite scope; G13 has since completed at b15179c and IDB timed out without report",
          "wholeFile": false,
          "fileSha256": "877154babadbbea35934537b3c0356471a0429159a5943db9d68d9facf389fe4",
          "fileBytes": 8443,
          "startLine": 43,
          "endLine": 48,
          "includedSha256": "6164dffa5cf3c42e92e5245bbb304bda9a82d59f4d2ee29449a777ff2c8fcf80",
          "includedBytes": 1418
        },
        {
          "path": "05_ADVANCED_PRIVACY_INFRASTRUCTURE/feature_5.3_client_security/spec-rainbow-book-data-remanence-and-memory-sanitization.md",
          "role": "read-only complete normative memory-lifetime paragraph; no physical-erasure guarantee",
          "wholeFile": false,
          "fileSha256": "8957370a33c60f3f7154bf5e77805808776a5b43671a94f372389046010d54eb",
          "fileBytes": 14705,
          "startLine": 20,
          "endLine": 20,
          "includedSha256": "94cebb1cd1a2fdea2a2d4d44942c92234ae64104923e2194a47e957a0bb4388e",
          "includedBytes": 483
        },
        {
          "path": "05_ADVANCED_PRIVACY_INFRASTRUCTURE/feature_5.3_client_security/spec-rainbow-book-data-remanence-and-memory-sanitization.md",
          "role": "read-only complete normative memory-lifetime paragraph; no physical-erasure guarantee",
          "wholeFile": false,
          "fileSha256": "8957370a33c60f3f7154bf5e77805808776a5b43671a94f372389046010d54eb",
          "fileBytes": 14705,
          "startLine": 71,
          "endLine": 71,
          "includedSha256": "5c5473c15b9aa219c2341ef4b9cefbde86ccdb96adc834853241ec7542c22ae6",
          "includedBytes": 380
        },
        {
          "path": "package.json",
          "role": "read-only actual commands/pins; no installs or dependency edits",
          "wholeFile": true,
          "fileSha256": "e5f8bbebfee3834201ee13b17bcfe531ddef25b9679b4349297ff56a75369707",
          "fileBytes": 1395,
          "startLine": 1,
          "endLine": 34,
          "includedSha256": "e5f8bbebfee3834201ee13b17bcfe531ddef25b9679b4349297ff56a75369707",
          "includedBytes": 1395
        },
        {
          "path": "tsconfig.json",
          "role": "read-only strict type options",
          "wholeFile": true,
          "fileSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
          "fileBytes": 389,
          "startLine": 1,
          "endLine": 16,
          "includedSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
          "includedBytes": 389
        },
        {
          "path": "apps/web/tsconfig.runtime.json",
          "role": "read-only document runtime compilation root",
          "wholeFile": true,
          "fileSha256": "fcf9b93d83f70aabd5ab90af8bcc962aecd4822e97be117b7561c08f6c54808e",
          "fileBytes": 135,
          "startLine": 1,
          "endLine": 5,
          "includedSha256": "fcf9b93d83f70aabd5ab90af8bcc962aecd4822e97be117b7561c08f6c54808e",
          "includedBytes": 135
        }
      ],
      "all15sourceblockhashesverified": true
    },
    "http_status": 200,
    "request_id": "req_011CgRwVmoXasp44e9x9nDgT",
    "rate_limit_headers_sanitized": {
      "anthropic-ratelimit-input-tokens-limit": "500000",
      "anthropic-ratelimit-input-tokens-remaining": "463000",
      "anthropic-ratelimit-input-tokens-reset": "2026-10-27T02:18:52Z",
      "anthropic-ratelimit-output-tokens-limit": "80000",
      "anthropic-ratelimit-output-tokens-remaining": "78000",
      "anthropic-ratelimit-output-tokens-reset": "2026-10-27T02:19:30Z",
      "anthropic-ratelimit-requests-limit": "1000",
      "anthropic-ratelimit-requests-remaining": "999",
      "anthropic-ratelimit-requests-reset": "2026-10-27T02:18:47Z",
      "anthropic-ratelimit-tokens-limit": "580000",
      "anthropic-ratelimit-tokens-remaining": "541000",
      "anthropic-ratelimit-tokens-reset": "2026-10-27T02:18:52Z"
    },
    "usage": {
      "input_tokens": 43678,
      "cache_creation_input_tokens": 0,
      "cache_read_input_tokens": 0,
      "cache_creation": {
        "ephemeral_5m_input_tokens": 0,
        "ephemeral_1h_input_tokens": 0
      },
      "output_tokens": 7052,
      "output_tokens_details": {
        "thinking_tokens": 0
      },
      "service_tier": "standard",
      "inference_geo": "global",
      "speed": "standard"
    },
    "stop_reason": "end_turn",
    "returned_model": "claude-sonnet-5-5",
    "estimated_cost_usd": "0.157876",
    "response_path": "/workspace/ghostpay-intake/p2p-pending-metadata-046-response.txt",
    "completed_at_utc": "2026-10-27T02:19:29.251010+00:00",
    "elapsed_seconds": 42.091
  },
  "broker_normalization": [
    "Removed three explicitly model-withdrawn unused/dead swallowed imports",
    "Exact missing target error.url guard replaces error.message.includes to avoid swallowing transitive import errors",
    "Implemented model explicit corrected final pending-construction edit, not withdrawn no-op hunk",
    "Regenerated correct ordinary unified diff hunks from exact old source strings, preserving complete original regression files"
  ],
  "runtime_replacement_counts": [
    {
      "original_text": "} from '../../../../packages/schemas/index.ts';\n",
      "replacements": 1
    },
    {
      "original_text": "  readonly command: RuntimeCommand;",
      "replacements": 1
    },
    {
      "original_text": "value.command.operation",
      "replacements": 1
    },
    {
      "original_text": "pending.command.operation",
      "replacements": 6
    },
    {
      "original_text": "pending.command.generation",
      "replacements": 1
    },
    {
      "original_text": "pending.command.profileId",
      "replacements": 2
    },
    {
      "original_text": "const pending: Pending = { command, resolve, timer, removeAbort: () => signal?.removeEventListener('abort', abort) };",
      "replacements": 1
    }
  ],
  "no_p2p_code_execution_or_git_apply": true,
  "runner_appendix": "17 mappings extracted separately for sole runner worker; no P2P suite execution here"
}
```

## Independently applicable tests-first patch

```diff
--- /dev/null
+++ b/apps/web/test/pending-metadata.test.mjs
@@ -0,0 +1,101 @@
+import test,{beforeEach,afterEach} from 'node:test';
+import assert from 'node:assert/strict';
+import { parseRuntimeCommand } from '../../../packages/schemas/index.ts';
+// Static expectation (UNEXECUTED): module is absent at base, so the missing-entry oracle fails before implementation.
+const HELPER_URL=new URL('../src/runtime/pending-metadata.ts',import.meta.url).href;
+const helper=await import('../src/runtime/pending-metadata.ts').catch(error=>{
+ if(error?.code==='ERR_MODULE_NOT_FOUND'&&error.url===HELPER_URL)return{};
+ throw error;
+});
+const capture=command=>{assert.equal(typeof helper.capturePendingMetadata,'function','missing capturePendingMetadata');return helper.capturePendingMetadata(command);};
+const PROFILE='a'.repeat(32);
+const SECRET='SECRET runtime page passphrase';
+const SOURCE='SECRET source page passphrase';
+const DEST='SECRET destination page passphrase';
+const config={version:1,ReleaseEnabled:0,connectOrigins:[]};
+const build=(operation,fields={})=>parseRuntimeCommand({version:1,requestId:7,generation:3,operation,...fields});
+const valid=()=>({
+ init:build('init',{config}),
+ unlock:build('unlock',{profileId:PROFILE,passphrase:SECRET}),
+ create:build('create',{passphrase:SECRET}),
+ restore:build('restore',{bytes:new Uint8Array(4096).fill(7),sourcePassphrase:SOURCE,destinationPassphrase:DEST}),
+ exportEncrypted:build('exportEncrypted',{profileId:PROFILE}),
+ status:build('status'),listProfiles:build('listProfiles'),lock:build('lock'),dispose:build('dispose'),activity:build('activity'),
+});
+test('capturePendingMetadata returns exactly operation/generation(/profileId) for every current operation',()=>{
+ for(const [operation,command] of Object.entries(valid())){
+  const meta=capture(command);
+  const withProfile=operation==='unlock'||operation==='exportEncrypted';
+  assert.deepEqual(Reflect.ownKeys(meta),withProfile?['operation','generation','profileId']:['operation','generation'],operation);
+  assert.equal(meta.operation,operation);assert.equal(meta.generation,3);
+  if(withProfile)assert.equal(meta.profileId,PROFILE);else assert.equal('profileId' in meta,false);
+  assert.equal(Object.isFrozen(meta),true,operation);
+  for(const key of Reflect.ownKeys(meta))assert.equal(Object.getOwnPropertyDescriptor(meta,key).enumerable,true);
+  assert.notEqual(capture(command),meta,'fresh record per projection');
+ }
+});
+test('metadata never holds secret values, buffers, config or full command; inputs unchanged',()=>{
+ const all=valid();
+ for(const [operation,command] of Object.entries(all)){
+  const snapshot=operation==='restore'?new Uint8Array(command.bytes):undefined;
+  const meta=capture(command);
+  assert.notEqual(meta,command);
+  for(const key of Reflect.ownKeys(meta)){
+   const value=meta[key];
+   assert.equal(typeof value==='string'||typeof value==='number',true,`${operation}.${String(key)} primitive`);
+   assert.notEqual(value,SECRET);assert.notEqual(value,SOURCE);assert.notEqual(value,DEST);
+   assert.equal(['passphrase','sourcePassphrase','destinationPassphrase','bytes','config','requestId','version'].includes(key),false);
+  }
+  assert.equal(Object.values(meta).some(v=>typeof v==='object'),false);
+  if(snapshot){assert.deepEqual(command.bytes,snapshot);assert.equal(command.bytes.length,4096);}
+ }
+ assert.equal(all.unlock.passphrase,SECRET);assert.equal(all.restore.sourcePassphrase,SOURCE);assert.equal(all.restore.destinationPassphrase,DEST);
+});
+// Integration with the real AppRuntime through the existing public contract only. Fixed synthetic inputs.
+let oldSecure;
+beforeEach(()=>{oldSecure=Object.getOwnPropertyDescriptor(globalThis,'isSecureContext');Object.defineProperty(globalThis,'isSecureContext',{configurable:true,value:true});});
+afterEach(()=>{if(oldSecure)Object.defineProperty(globalThis,'isSecureContext',oldSecure);else delete globalThis.isSecureContext;});
+const api=await import('../src/runtime/app-runtime.ts');
+const clone=v=>structuredClone(v);
+const flush=()=>new Promise(resolve=>setImmediate(resolve));
+class Port extends EventTarget{
+ sent=[];terminated=0;handler;
+ postMessage(value){const command=clone(value);this.sent.push(command);queueMicrotask(()=>this.handler?.(command));}
+ reply(value){const data=clone(value);queueMicrotask(()=>this.dispatchEvent(new MessageEvent('message',{data})));}
+ terminate(){this.terminated++;}
+}
+const response=(command,value={state:'locked',handle:null})=>({...command,kind:'response',result:{ok:true,value}});
+const stripped=command=>{const {config:c,profileId:p,passphrase:s,bytes:b,sourcePassphrase:a,destinationPassphrase:d,...base}=command;return base;};
+const startRuntime=async port=>{
+ port.handler=command=>port.reply(response(stripped(command)));
+ const started=await api.AppRuntime.start(config,{createWorker:()=>port,lifecycle:false});
+ assert.equal(started.ok,true);return started.value;
+};
+test('held fake-Port unlock posts the full command once, stays BUSY, and a late old-generation reply never publishes',async()=>{
+ const port=new Port();const runtime=await startRuntime(port);let held;
+ port.handler=command=>{if(command.operation==='unlock'){held=command;return;}port.reply(response(stripped(command)));};
+ const controller=new AbortController();
+ const pending=runtime.unlock(PROFILE,SECRET,controller.signal);await flush();
+ const unlocks=port.sent.filter(c=>c.operation==='unlock');
+ assert.equal(unlocks.length,1);assert.equal(unlocks[0].profileId,PROFILE);assert.equal(unlocks[0].passphrase,SECRET);
+ const busy=await runtime.status();assert.equal(busy.ok,false);assert.equal(busy.error.code,'BUSY');
+ controller.abort();assert.equal(runtime.current.state,'locked');
+ const result=await pending;assert.equal(result.ok,false);assert.equal(result.error.code,'CANCELLED');
+ port.reply(response(stripped(held),{state:'unlocked',handle:{id:'A'.repeat(43),generation:held.generation,purpose:'vault',profileId:PROFILE}}));
+ await flush();assert.equal(runtime.current.state,'locked');
+ await runtime.dispose();
+});
+test('wrong-profile unlock reply is still a protocol failure after the metadata change',async()=>{
+ const port=new Port();const runtime=await startRuntime(port);
+ port.handler=command=>port.reply(response(stripped(command),command.operation==='unlock'?{state:'unlocked',handle:{id:'A'.repeat(43),generation:command.generation,purpose:'vault',profileId:'b'.repeat(32)}}:{state:'locked',handle:null}));
+ const result=await runtime.unlock(PROFILE,SECRET);
+ assert.equal(result.ok,false);assert.equal(result.error.code,'PROTOCOL_ERROR');assert.equal(runtime.current.state,'locked');assert.equal(port.terminated,1);
+ await runtime.dispose();
+});
+test('wrong operation in a reply is rejected as protocol error after the metadata change',async()=>{
+ const port=new Port();const runtime=await startRuntime(port);
+ port.handler=command=>port.reply({...response(stripped(command)),operation:'status'});
+ const result=await runtime.create('fresh runtime page passphrase');
+ assert.equal(result.ok,false);assert.equal(result.error.code,'PROTOCOL_ERROR');assert.equal(port.terminated,1);
+ await runtime.dispose();
+});
```

## Minimal implementation patch

```diff
--- /dev/null
+++ b/apps/web/src/runtime/pending-metadata.ts
@@ -0,0 +1,19 @@
+/** Internal pure projection of an already-validated RuntimeCommand into frozen, primitive-only pending metadata.
+ * Not a boundary parser and not an authorization constructor. No secrets, bytes, config or request ids are copied.
+ * Retained closures, caller Strings, transport copies and physical erasure are outside this guarantee.
+ */
+import type { RuntimeCommand, RuntimeOperation } from '../../../../packages/schemas/index.ts';
+
+export type PendingMetadata =
+  | Readonly<{ operation: 'unlock' | 'exportEncrypted'; generation: number; profileId: string }>
+  | Readonly<{ operation: Exclude<RuntimeOperation, 'unlock' | 'exportEncrypted'>; generation: number }>;
+
+export function capturePendingMetadata(command: RuntimeCommand): PendingMetadata {
+  switch (command.operation) {
+    case 'unlock': return Object.freeze({ operation: 'unlock', generation: command.generation, profileId: command.profileId });
+    case 'exportEncrypted': return Object.freeze({ operation: 'exportEncrypted', generation: command.generation, profileId: command.profileId });
+    case 'init': case 'create': case 'restore': case 'status': case 'listProfiles': case 'lock': case 'dispose': case 'activity':
+      return Object.freeze({ operation: command.operation, generation: command.generation });
+    default: { const unhandled: never = command; return unhandled; }
+  }
+}
--- a/apps/web/src/runtime/app-runtime.ts
+++ b/apps/web/src/runtime/app-runtime.ts
@@ -5,6 +5,7 @@
   type RuntimeCommand, type RuntimeErrorCode, type RuntimeExport, type RuntimeHandle, type RuntimeInventory, type RuntimeMessage,
   type RuntimeOperation, type RuntimeRestore, type RuntimeResult, type RuntimeStatus, type RuntimeValue,
 } from '../../../../packages/schemas/index.ts';
+import { capturePendingMetadata, type PendingMetadata } from './pending-metadata.ts';
 
 export type RuntimeWorkerPort = Pick<Worker, 'postMessage' | 'addEventListener' | 'removeEventListener' | 'terminate'>;
 export interface AppRuntimeOptions {
@@ -13,7 +14,7 @@
   readonly now?: () => number;
 }
 interface Pending {
-  readonly command: RuntimeCommand;
+  readonly metadata: PendingMetadata;
   readonly resolve: (result: RuntimeResult<RuntimeValue>) => void;
   readonly timer: ReturnType<typeof setTimeout>;
   readonly removeAbort: () => void;
@@ -104,7 +105,7 @@
   #activity = (event: Event): void => {
     this.#checkIdle();
     if (!event.isTrusted || this.#closed || this.#disposing || this.#current.state !== 'unlocked' ||
-        [...this.#pending.values()].some(value => value.command.operation === 'activity')) return;
+        [...this.#pending.values()].some(value => value.metadata.operation === 'activity')) return;
     try {
       this.#arm();
       // No public reset API exists. Only the captured document's trusted-event handler sends this control.
@@ -132,11 +133,11 @@
     this.#worker.terminate();
   }
   #acceptStatus(message: Extract<RuntimeMessage, { kind: 'response' }>, value: RuntimeStatus, pending: Pending): boolean {
-    const operation = pending.command.operation;
+    const operation = pending.metadata.operation;
     const opening = operation === 'unlock' || operation === 'create';
     if (value.state === 'unlocked') {
       if (operation === 'init' || operation === 'lock' || operation === 'dispose' ||
-          (pending.command.operation === 'unlock' && value.handle.profileId !== pending.command.profileId)) return false;
+          (pending.metadata.operation === 'unlock' && value.handle.profileId !== pending.metadata.profileId)) return false;
       if (!opening && (this.#current.state !== 'unlocked' || !sameHandle(this.#current.handle, value.handle))) return false;
       const handle = this.#current.state === 'unlocked' && sameHandle(this.#current.handle, value.handle) ? this.#current.handle : value.handle;
       const changed = this.#current.state !== 'unlocked' || this.#current.handle !== handle;
@@ -159,15 +160,15 @@
     if (message.kind === 'locked') { if (!this.#disposing) void this.lock(); return; }
     const pending = this.#pending.get(message.requestId);
     if (!pending) { if (message.requestId > this.#sequence) this.#close('PROTOCOL_ERROR'); return; }
-    if (pending.command.operation !== message.operation || pending.command.generation !== message.generation) { this.#close('PROTOCOL_ERROR'); return; }
+    if (pending.metadata.operation !== message.operation || pending.metadata.generation !== message.generation) { this.#close('PROTOCOL_ERROR'); return; }
     this.#checkIdle(); if (!this.#pending.has(message.requestId)) return;
     if (message.result.ok && message.operation !== 'exportEncrypted' && message.operation !== 'listProfiles' && message.operation !== 'restore') {
       if (!this.#acceptStatus(message, message.result.value, pending)) { this.#close('PROTOCOL_ERROR'); return; }
       this.#settle(message.requestId, Object.freeze({ ok: true, value: this.#current }));
     } else {
-      if (!message.result.ok && (pending.command.operation === 'unlock' || pending.command.operation === 'create')) this.#resetStatus();
+      if (!message.result.ok && (pending.metadata.operation === 'unlock' || pending.metadata.operation === 'create')) this.#resetStatus();
       if (message.result.ok && message.operation === 'exportEncrypted') {
-        if (pending.command.operation !== 'exportEncrypted' || parseBackupBytes(message.result.value.bytes).envelope.profileId !== pending.command.profileId) { this.#close('PROTOCOL_ERROR'); return; }
+        if (pending.metadata.operation !== 'exportEncrypted' || parseBackupBytes(message.result.value.bytes).envelope.profileId !== pending.metadata.profileId) { this.#close('PROTOCOL_ERROR'); return; }
       }
       this.#settle(message.requestId, message.result);
     }
@@ -186,7 +187,7 @@
     return new Promise(resolve => {
       const abort = (): void => { if (!this.#closed && !this.#disposing && this.#invalidate('CANCELLED')) void this.#request('lock', {}, undefined, true); };
       const timer = setTimeout(() => this.#close('TIMEOUT'), operation === 'dispose' ? RUNTIME_DISPOSE_TIMEOUT_MS : RUNTIME_REQUEST_TIMEOUT_MS);
-      const pending: Pending = { command, resolve, timer, removeAbort: () => signal?.removeEventListener('abort', abort) };
+      const pending: Pending = { metadata: capturePendingMetadata(command), resolve, timer, removeAbort: () => signal?.removeEventListener('abort', abort) };
       this.#pending.set(command.requestId, pending); signal?.addEventListener('abort', abort, { once: true });
       if (signal?.aborted) { abort(); return; }
       try { this.#worker.postMessage(command); } catch { this.#close('STORAGE_UNAVAILABLE'); }
```

## Required sole-integrator commands — UNEXECUTED

```text
node --test apps/web/test/pending-metadata.test.mjs
node --test apps/web/test/pending-metadata.test.mjs apps/web/test/app-runtime.test.mjs apps/web/test/worker-endpoint.test.mjs apps/web/test/app-services.test.mjs
npm test
npm run build
npm run check:boundaries
npm run test:build-policy
P2P_CHROMIUM=/usr/bin/chromium npm run test:web:browser
```

Retain all original timeouts, job limits, cancellation/generation and profile-binding checks. Keep G16 excluded, ReleaseEnabled0 and connectOrigins[] unchanged. No claim of zero secret reachability through Promise/control closures, physical erasure, real funds or device qualification. Do not duplicate request046.
