# P2P-G16-PRIVATE-PROTOCOL-06 — Claude proposal 050

**UNEXECUTED.** Private inert tests-first/source/fixture proposal for the sole P2P integrator. Broker did not apply/import/execute P2P code or run tests/builds.

Base `a74ff8ba5a29d958e026f6727e1ec999d22dfa5c`, tree `e92e4c0804347e4a86e59e1cf860769249fdd1a9`. Verified original Library packet `libfile_a575afd14b888191aa86389b05d9bec2` v0, 85217 bytes, SHA256 `f45eddaf2f2650a51212f5aba0dae5dd9f12e044abcd460604cf50b052018bd3`; all eleven source-block hashes matched.

Sonnet `claude-sonnet-5-5`, request `req_011CgRzzMSjLYAmBwN6GtS2h`, 37945 input / 13286 output tokens, end_turn, $0.20875 estimated. No cache tokens or retries. Hunk counts/locations were normalized from exact unique source context; no proposal code adaptations.

The header IDs remain data only. Actual host job authority/cancellation, application inclusion and financial/trust gates stay excluded. Existing body parser, verifier, public facades, all other source, locks and golden bytes are unchanged by this proposal.

## Provenance and target identities

```json
{
  "assignment": "P2P-G16-PRIVATE-PROTOCOL-06",
  "status": "UNEXECUTED inert proposal; no P2P code applied, imported, compiled, tested or browser-run by broker",
  "input_packet": {
    "project": "p2p",
    "assignment": "P2P-G16-PRIVATE-PROTOCOL-06",
    "packet_path": "/workspace/ghostpay-intake/P2P-G16-PRIVATE-PROTOCOL-06-packet.md",
    "packet_bytes": 85217,
    "packet_sha256": "f45eddaf2f2650a51212f5aba0dae5dd9f12e044abcd460604cf50b052018bd3",
    "library_file_id": "libfile_a575afd14b888191aa86389b05d9bec2",
    "version": 0,
    "base_commit": "a74ff8ba5a29d958e026f6727e1ec999d22dfa5c",
    "base_tree": "e92e4c0804347e4a86e59e1cf860769249fdd1a9",
    "allowed_paths": [
      {
        "path": "packages/schemas/src/evm-agreement-protocol.ts",
        "baseState": "absent",
        "baseSha256": null,
        "baseBytes": null
      },
      {
        "path": "packages/schemas/test/evm-agreement-protocol.test.mjs",
        "baseState": "absent",
        "baseSha256": null,
        "baseBytes": null
      },
      {
        "path": "scripts/fixtures/g16-browser.mjs",
        "baseState": "existing",
        "baseSha256": "8d89b7fffee4b13f836783b6ed2cb138ec10283dc034d9feae6a2342ae0bdde8",
        "baseBytes": 17877
      }
    ],
    "source_blocks": [
      {
        "path": "packages/schemas/src/evm-agreement-input.ts",
        "role": "read-only complete integrated body parser and structural types; reuse, do not reimplement/edit",
        "wholeFile": true,
        "fileSha256": "7b3e0a67bf70a53b1ebcc241097bd16a372197f0596f0868af448ce6e823af3d",
        "fileBytes": 13966,
        "startLine": 1,
        "endLine": 232,
        "includedSha256": "7b3e0a67bf70a53b1ebcc241097bd16a372197f0596f0868af448ce6e823af3d",
        "includedBytes": 13966
      },
      {
        "path": "scripts/fixtures/g16-browser.mjs",
        "role": "only existing proposed output; complete current private document/Worker fixture, retain182assertions/11groups",
        "wholeFile": true,
        "fileSha256": "8d89b7fffee4b13f836783b6ed2cb138ec10283dc034d9feae6a2342ae0bdde8",
        "fileBytes": 17877,
        "startLine": 1,
        "endLine": 234,
        "includedSha256": "8d89b7fffee4b13f836783b6ed2cb138ec10283dc034d9feae6a2342ae0bdde8",
        "includedBytes": 17877
      },
      {
        "path": "packages/wallet/src/evm-agreement.ts",
        "role": "read-only complete existing verifier and public outcome; reuse, no crypto/provider changes",
        "wholeFile": true,
        "fileSha256": "f7acb2d484db116c4cebac89d3c9d4e375af63bfe2f8aa3646e2117c19792991",
        "fileBytes": 6796,
        "startLine": 1,
        "endLine": 90,
        "includedSha256": "f7acb2d484db116c4cebac89d3c9d4e375af63bfe2f8aa3646e2117c19792991",
        "includedBytes": 6796
      },
      {
        "path": "scripts/test-g16-browser.mjs",
        "role": "read-only complete isolated Chromium driver/corpus/graph assertions; no edits",
        "wholeFile": true,
        "fileSha256": "fb2a00ad0ec4482df33ad444117b2d64f0382a8b7d5e68aed3a4788591aee3d7",
        "fileBytes": 9202,
        "startLine": 1,
        "endLine": 117,
        "includedSha256": "fb2a00ad0ec4482df33ad444117b2d64f0382a8b7d5e68aed3a4788591aee3d7",
        "includedBytes": 9202
      },
      {
        "path": "packages/schemas/src/core.ts",
        "role": "read-only complete CoreErrorCode/result/error contracts; no new error semantics",
        "wholeFile": false,
        "fileSha256": "079ac1a941b77111500a6642b95430571d89f3e2d93b377a583c27e9cb013f36",
        "fileBytes": 7446,
        "startLine": 24,
        "endLine": 40,
        "includedSha256": "9644495698492bf71ea25a94b3fc922c489f1c6a50c17923550cd486f46169e1",
        "includedBytes": 1630
      },
      {
        "path": "packages/schemas/src/runtime.ts",
        "role": "read-only existing sequence/resource/BUSY/error constants; legacy runtime remains unchanged",
        "wholeFile": false,
        "fileSha256": "dc94e4cb60f486c783d34fa4aad11b675281d806a1f6752380265f73202f3cc4",
        "fileBytes": 13904,
        "startLine": 1,
        "endLine": 20,
        "includedSha256": "8eeeb80fde2c73ed45fdfd7b5eb9dadcd7a64bd0caee368eea6d996b38bdc7de",
        "includedBytes": 1772
      },
      {
        "path": "apps/web/src/runtime/pending-metadata.ts",
        "role": "read-only complete integrated PENDING05 interface; no new G16 values may be cast into RuntimeCommand",
        "wholeFile": true,
        "fileSha256": "c580db1dd24b50c8cf2bd8c4a02c7479d7fd9528f950bfc745245317cf3143cf",
        "fileBytes": 1355,
        "startLine": 1,
        "endLine": 19,
        "includedSha256": "c580db1dd24b50c8cf2bd8c4a02c7479d7fd9528f950bfc745245317cf3143cf",
        "includedBytes": 1355
      },
      {
        "path": "packages/schemas/test/evm-agreement-input.test.mjs",
        "role": "read-only complete native structural fixture factory/bad helper; exact noncrypto input shape for focused tests",
        "wholeFile": false,
        "fileSha256": "f418b42ac3c234fce71a4d3faf9247e7c5bccd5d05b104e49efdda81fbf1ef5b",
        "fileBytes": 19056,
        "startLine": 1,
        "endLine": 38,
        "includedSha256": "ca128299331ae81938104e5222b5058461625cc58024b85f34662e99237831f9",
        "includedBytes": 2454
      },
      {
        "path": "docs/reviews/G16_BROWSER_DISPOSITION_2026-10-27.md",
        "role": "read-only conditional requirements; old preallocation gap wording superseded by current integrated code",
        "wholeFile": false,
        "fileSha256": "a8f026acf030f41190710ccb2b7f241a552c88049bbdaf09fb041537a501c47c",
        "fileBytes": 9447,
        "startLine": 16,
        "endLine": 28,
        "includedSha256": "02d83f60255b2e9fedf213cab1190c57b4e10db069200a6527fe6df35ebed825",
        "includedBytes": 2773
      },
      {
        "path": "package.json",
        "role": "read-only existing commands/pins; no dependency/tool changes",
        "wholeFile": true,
        "fileSha256": "e5f8bbebfee3834201ee13b17bcfe531ddef25b9679b4349297ff56a75369707",
        "fileBytes": 1395,
        "startLine": 1,
        "endLine": 34,
        "includedSha256": "e5f8bbebfee3834201ee13b17bcfe531ddef25b9679b4349297ff56a75369707",
        "includedBytes": 1395
      },
      {
        "path": "tsconfig.json",
        "role": "read-only strict core compilation contract",
        "wholeFile": true,
        "fileSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
        "fileBytes": 389,
        "startLine": 1,
        "endLine": 16,
        "includedSha256": "a22c2ba6653ed46db9afc70a1c8fe6185cdbe841df3f9c0f6dbbdebc2a599f89",
        "includedBytes": 389
      }
    ],
    "all11sourceblockhashesverified": true
  },
  "request": {
    "tag": "p2p-private-protocol-050",
    "model": "claude-sonnet-5-5",
    "timestamp_utc": "2026-10-27T03:04:35.250501+00:00",
    "completed_at_utc": "2026-10-27T03:05:47.071350+00:00",
    "request_id": "req_011CgRzzMSjLYAmBwN6GtS2h",
    "http_status": 200,
    "usage": {
      "input_tokens": 37945,
      "cache_creation_input_tokens": 0,
      "cache_read_input_tokens": 0,
      "cache_creation": {
        "ephemeral_5m_input_tokens": 0,
        "ephemeral_1h_input_tokens": 0
      },
      "output_tokens": 13286,
      "output_tokens_details": {
        "thinking_tokens": 0
      },
      "service_tier": "standard",
      "inference_geo": "global",
      "speed": "standard"
    },
    "stop_reason": "end_turn",
    "elapsed_seconds": 71.788,
    "estimated_cost_usd": "0.20875",
    "worst_case_reserved_usd": "2.2"
  },
  "files": [
    {
      "path": "packages/schemas/test/evm-agreement-protocol.test.mjs",
      "base_bytes": null,
      "base_sha256": null,
      "target_bytes": 13294,
      "target_lines": 178,
      "target_sha256": "0b80569625c8f4149856d6ade7233f22a56b174ce6b3b3ac8ab4bce7372005d8",
      "base_state": "absent"
    },
    {
      "path": "packages/schemas/src/evm-agreement-protocol.ts",
      "base_bytes": null,
      "base_sha256": null,
      "target_bytes": 6378,
      "target_lines": 108,
      "target_sha256": "0c4f12029f02957c237eb5ecf512733125e8233107964d2747c53496090e5577",
      "base_state": "absent"
    },
    {
      "path": "scripts/fixtures/g16-browser.mjs",
      "base_bytes": 17877,
      "base_sha256": "8d89b7fffee4b13f836783b6ed2cb138ec10283dc034d9feae6a2342ae0bdde8",
      "target_bytes": 22979,
      "target_lines": 290,
      "target_sha256": "3d0cc3d7b2d983504d3c976bc0dcf2bcae634ba2e29f13a3042168aa490d75e8",
      "base_state": "existing"
    }
  ],
  "broker_adjustments": [
    "Recomputed hunk counts and locations from exact unique old context and new-file added lines; source/test/fixture code bytes otherwise unchanged from model proposal."
  ],
  "remaining": [
    "Sole P2P integrator must reproduce true tests-first RED, implementation GREEN, private fixture graph and full retained acceptance checks.",
    "Strictly structural data envelope does not authorize host job, current request/generation, trust, money or application inclusion."
  ]
}
```

## Tests-first — apply alone for actual missing-module RED

```diff
--- /dev/null
+++ b/packages/schemas/test/evm-agreement-protocol.test.mjs
@@ -0,0 +1,178 @@
+import test from 'node:test';
+import assert from 'node:assert/strict';
+// UNEXECUTED tests. Exact missing-target guard only: transitive failures are rethrown.
+const moduleUrl = new URL('../src/evm-agreement-protocol.ts', import.meta.url);
+const api = await import(moduleUrl.href).catch(error => {
+  if (error?.code === 'ERR_MODULE_NOT_FOUND' && error?.url === moduleUrl.href) return {};
+  throw error;
+});
+const parseReq = (...a) => { assert.equal(typeof api.parseEvmAgreementCheckRequest, 'function', 'missing parseEvmAgreementCheckRequest'); return api.parseEvmAgreementCheckRequest(...a); };
+const parseRep = (...a) => { assert.equal(typeof api.parseEvmAgreementCheckReply, 'function', 'missing parseEvmAgreementCheckReply'); return api.parseEvmAgreementCheckReply(...a); };
+const MAX = Number.MAX_SAFE_INTEGER - 1;
+const h = c => c.repeat(64);
+const A = c => '0x' + c.repeat(40);
+const body = () => ({
+  privateAgreement: { v: 1, orderId: h('a'), revision: '1', fiatCurrency: 'USD', fiatMinorUnits: '10000', fiatScale: 2,
+    paymentInstructions: 'PRIVATE-FIXTURE pay', capabilities: [{ id: 'alpha', version: '1', policyHash: h('b') }], agreementSalt: h('c') },
+  domain: { chainId: '11155111', verifyingContract: A('1') },
+  terms: { orderId: h('a'), revision: '1', networkId: 'eip155-1', deploymentId: 'escrow-v1', seller: A('2'), buyer: A('3'),
+    assetKind: 'erc20', asset: A('4'), amountBaseUnits: '1000', privateAgreementHash: h('d'), capabilitiesHash: h('e'),
+    sellerNonce: h('f'), acceptBeforeSeconds: '100', escrowExpirySeconds: '5000' },
+  acceptances: [
+    { termsHash: h('9'), role: 'seller', walletAccount: A('2'), signature: new Uint8Array(65).fill(7) },
+    { termsHash: h('9'), role: 'buyer', walletAccount: A('3'), signature: new Uint8Array(65).fill(8) }]
+});
+const req = (over = {}) => ({ version: 1, requestId: 1, generation: 0, operation: 'checkEvmAgreement', input: body(), ...over });
+const okResult = () => ({ ok: true, value: { testOnly: true, economicPreparationAllowed: false, termsHash: h('1'), accounts: { seller: A('2'), buyer: A('3') } } });
+const rep = (over = {}) => ({ version: 1, requestId: 1, generation: 0, operation: 'checkEvmAgreement', kind: 'response', result: okResult(), ...over });
+const badReq = (r, code = 'INVALID_INPUT') => assert.throws(() => parseReq(r), e => e.name === 'CoreSchemaError' && e.code === code && !String(e.message).includes('PRIVATE-FIXTURE'));
+const badRep = r => assert.throws(() => parseRep(r), e => e.name === 'CoreSchemaError' && e.code === 'INVALID_INPUT' && e.message === 'Invalid core data.');
+const wipe = r => { for (const a of r.input.acceptances) a.signature.fill(0); };
+
+test('request: valid minimal snapshot is fresh, frozen and owned', () => {
+  const src = req(), out = parseReq(src);
+  try {
+    assert.ok(Object.isFrozen(out) && Object.isFrozen(out.input) && Object.isFrozen(out.input.terms));
+    assert.deepEqual(Object.keys(out).sort(), ['generation', 'input', 'operation', 'requestId', 'version']);
+    assert.notEqual(out, src); assert.notEqual(out.input, src.input);
+    assert.equal(out.input.acceptances.length, 2);
+    assert.notEqual(out.input.acceptances[0].signature.buffer, src.input.acceptances[0].signature.buffer);
+    src.input.acceptances[0].signature.fill(0); src.input.terms.amountBaseUnits = '2';
+    assert.ok(out.input.acceptances[0].signature.some(b => b !== 0));
+    assert.equal(out.input.terms.amountBaseUnits, '1000');
+  } finally { wipe(out); }
+});
+
+test('request: native assetKind also structurally valid', () => {
+  const src = req(); src.input.terms.assetKind = 'native'; src.input.terms.asset = A('0');
+  const out = parseReq(src);
+  try { assert.equal(out.input.terms.assetKind, 'native'); } finally { wipe(out); }
+});
+
+test('request: header counter bounds', () => {
+  for (const requestId of [1, 2, MAX]) { const out = parseReq(req({ requestId })); try { assert.equal(out.requestId, requestId); } finally { wipe(out); } }
+  for (const generation of [0, 1, MAX]) { const out = parseReq(req({ generation })); try { assert.equal(out.generation, generation); } finally { wipe(out); } }
+  for (const requestId of [0, MAX + 1, -1, 1.5, NaN, Infinity, '1', null, 2 ** 53]) badReq(req({ requestId }));
+  for (const generation of [-1, MAX + 1, 0.5, NaN, Infinity, '0', null, 2 ** 53]) badReq(req({ generation }));
+  badReq(req({ version: 2 })); badReq(req({ version: '1' })); badReq(req({ operation: 'status' })); badReq(req({ operation: 'checkevmagreement' }));
+});
+
+test('request: outer exact fields, symbols, accessors, non-plain', () => {
+  const missing = req(); delete missing.generation; badReq(missing);
+  badReq(req({ extra: true }));
+  const sym = req(); sym[Symbol('x')] = 1; badReq(sym);
+  const hid = req(); Object.defineProperty(hid, 'requestId', { enumerable: false, value: 1 }); badReq(hid);
+  let calls = 0; const acc = req(); Object.defineProperty(acc, 'generation', { enumerable: true, get() { calls++; throw Error('PRIVATE-FIXTURE'); } });
+  badReq(acc); assert.equal(calls, 0);
+  badReq(Object.assign(Object.create({ x: 1 }), req()));
+  badReq([]); badReq(null); badReq('x'); badReq(7);
+  const nullProto = Object.assign(Object.create(null), req()); const out = parseReq(nullProto); wipe(out);
+});
+
+test('request: bad header fails before the body is touched', () => {
+  let touched = 0;
+  const spy = new Proxy(body(), {
+    ownKeys(t) { touched++; return Reflect.ownKeys(t); },
+    getOwnPropertyDescriptor(t, k) { touched++; return Reflect.getOwnPropertyDescriptor(t, k); },
+    get(t, k) { touched++; return Reflect.get(t, k); }, getPrototypeOf(t) { touched++; return Reflect.getPrototypeOf(t); }
+  });
+  badReq({ version: 1, requestId: 0, generation: 0, operation: 'checkEvmAgreement', input: spy });
+  badReq({ version: 1, requestId: 1, generation: -1, operation: 'checkEvmAgreement', input: spy });
+  badReq({ version: 3, requestId: 1, generation: 0, operation: 'checkEvmAgreement', input: spy });
+  badReq({ version: 1, requestId: 1, generation: 0, operation: 'x', input: spy });
+  assert.equal(touched, 0);
+});
+
+test('request: body errors are the original native typed errors', () => {
+  const lim = req(); lim.input.privateAgreement.paymentInstructions = 'x'.repeat(4097); badReq(lim, 'LIMIT_EXCEEDED');
+  const ver = req(); ver.input.privateAgreement.v = 2; badReq(ver, 'UNSUPPORTED_VERSION');
+  const ext = req(); ext.input.extra = 1; badReq(ext);
+  const dec = req(); dec.input.terms.amountBaseUnits = '9'.repeat(5000); badReq(dec);
+  const sig = req(); sig.input.acceptances[0].signature = new Uint8Array(66); badReq(sig);
+  const sur = req(); sur.input.privateAgreement.paymentInstructions = '\ud800'; badReq(sur);
+  const px = req(); px.input.acceptances[0].signature = new Proxy(px.input.acceptances[0].signature, {}); badReq(px);
+  const sw = req(); sw.input.acceptances[0].termsHash = h('f'); const out = parseReq(sw); wipe(out); // bytes never prove a signature
+});
+
+test('request: meta-trap throws become fresh fixed INVALID_INPUT', () => {
+  const forged = Object.assign(new Error('PRIVATE-FIXTURE forged'), { name: 'CoreSchemaError', code: 'LIMIT_EXCEEDED' });
+  const trap = new Proxy({}, { ownKeys() { throw forged; }, getPrototypeOf() { throw forged; } });
+  assert.throws(() => parseReq(req({ input: trap })), e => e !== forged && e.name === 'CoreSchemaError' && e.code === 'INVALID_INPUT' && e.message === 'Invalid core data.');
+  const outerTrap = new Proxy(req(), { ownKeys() { throw forged; }, getPrototypeOf() { throw forged; } });
+  assert.throws(() => parseReq(outerTrap), e => e !== forged && e.code === 'INVALID_INPUT' && e.message === 'Invalid core data.');
+  const r = Proxy.revocable(req(), {}); r.revoke(); badReq(r.proxy);
+  const rr = Proxy.revocable({}, {}); rr.revoke(); badReq(req({ input: rr.proxy }));
+  badRep((() => { const p = new Proxy(rep(), { ownKeys() { throw forged; }, getPrototypeOf() { throw forged; } }); return p; })());
+  const rv = Proxy.revocable(rep(), {}); rv.revoke(); badRep(rv.proxy);
+});
+
+test('reply: valid success and every known failure code', () => {
+  const out = parseRep(rep());
+  assert.ok(Object.isFrozen(out) && Object.isFrozen(out.result) && Object.isFrozen(out.result.value) && Object.isFrozen(out.result.value.accounts));
+  assert.deepEqual(Object.keys(out).sort(), ['generation', 'kind', 'operation', 'requestId', 'result', 'version']);
+  assert.equal(out.result.value.testOnly, true); assert.equal(out.result.value.economicPreparationAllowed, false);
+  const codes = ['INVALID_INPUT', 'UNSUPPORTED_VERSION', 'UNSUPPORTED_PROVIDER', 'WRONG_CHAIN', 'UNAUTHORIZED', 'USER_REJECTED', 'LOCKED', 'CONFLICT', 'UNAVAILABLE', 'TIMEOUT', 'CANCELLED', 'LIMIT_EXCEEDED', 'INTEGRITY_FAILURE', 'BROADCAST_UNKNOWN', 'EXPIRED', 'BUSY'];
+  for (const code of codes) {
+    const f = parseRep(rep({ result: { ok: false, error: { code } } }));
+    assert.equal(f.result.ok, false); assert.equal(f.result.error.code, code); assert.ok(Object.isFrozen(f.result.error));
+  }
+});
+
+test('reply: header bounds and exact discriminators', () => {
+  for (const requestId of [1, MAX]) parseRep(rep({ requestId }));
+  for (const generation of [0, MAX]) parseRep(rep({ generation }));
+  for (const requestId of [0, MAX + 1, -1, 1.5, NaN, '1']) badRep(rep({ requestId }));
+  for (const generation of [-1, MAX + 1, 0.5, Infinity, '0']) badRep(rep({ generation }));
+  badRep(rep({ version: 2 })); badRep(rep({ operation: 'status' })); badRep(rep({ kind: 'event' })); badRep(rep({ kind: 'request' }));
+});
+
+test('reply: rich errors, unknown codes and authority fields reject', () => {
+  badRep(rep({ result: { ok: false, error: { code: 'BOGUS' } } }));
+  badRep(rep({ result: { ok: false, error: { code: 'busy' } } }));
+  badRep(rep({ result: { ok: false, error: { code: 'INVALID_INPUT', retryable: false } } }));
+  badRep(rep({ result: { ok: false, error: { code: 'INVALID_INPUT', retryable: false, action: 'none', correlationId: 'x', messageKey: 'k' } } }));
+  badRep(rep({ result: { ok: false, error: {} } }));
+  badRep(rep({ result: { ok: false } })); badRep(rep({ result: { ok: false, error: null } }));
+  badRep(rep({ result: { ok: false, error: { code: 'BUSY' }, value: okResult().value } }));
+  badRep(rep({ result: { ok: 'true', value: okResult().value } }));
+  badRep(rep({ result: { ok: true } }));
+  badRep(rep({ result: { ok: true, value: okResult().value, error: { code: 'BUSY' } } }));
+  badRep(rep({ result: null })); badRep(rep({ result: [] }));
+  badRep(rep({ extra: 1 })); badRep(rep({ handle: 'x' })); badRep(rep({ status: 'ok' }));
+});
+
+test('reply: value flags, hashes and accounts', () => {
+  const v = over => rep({ result: { ok: true, value: { ...okResult().value, ...over } } });
+  badRep(v({ testOnly: false })); badRep(v({ economicPreparationAllowed: true })); badRep(v({ approved: true }));
+  badRep(v({ termsHash: 'A'.repeat(64) })); badRep(v({ termsHash: 'a'.repeat(63) })); badRep(v({ termsHash: 5 }));
+  badRep(v({ accounts: { seller: A('2'), buyer: A('2') } }));
+  badRep(v({ accounts: { seller: A('0'), buyer: A('3') } })); badRep(v({ accounts: { seller: A('2'), buyer: A('0') } }));
+  badRep(v({ accounts: { seller: '0x' + 'A'.repeat(40), buyer: A('3') } }));
+  badRep(v({ accounts: { seller: A('2') } })); badRep(v({ accounts: { seller: A('2'), buyer: A('3'), extra: 1 } }));
+  const noFlag = { ...okResult().value }; delete noFlag.testOnly; badRep(rep({ result: { ok: true, value: noFlag } }));
+});
+
+test('reply: data-only; invented values and mismatched ids parse structurally', () => {
+  const out = parseRep(rep({ requestId: 999, generation: 42, result: { ok: true, value: { testOnly: true, economicPreparationAllowed: false, termsHash: h('7'), accounts: { seller: A('5'), buyer: A('6') } } } }));
+  assert.equal(out.requestId, 999); assert.equal(out.generation, 42);
+});
+
+test('reply: symbols, non-enumerable, accessors and custom prototypes', () => {
+  const sym = rep(); sym[Symbol('x')] = 1; badRep(sym);
+  const hid = rep(); Object.defineProperty(hid, 'kind', { enumerable: false, value: 'response' }); badRep(hid);
+  let calls = 0;
+  const acc = rep(); Object.defineProperty(acc, 'result', { enumerable: true, get() { calls++; throw Error('PRIVATE-FIXTURE'); } }); badRep(acc);
+  const vacc = rep(); Object.defineProperty(vacc.result.value, 'termsHash', { enumerable: true, get() { calls++; throw Error('PRIVATE-FIXTURE'); } }); badRep(vacc);
+  const eacc = rep({ result: { ok: false, error: {} } }); Object.defineProperty(eacc.result.error, 'code', { enumerable: true, get() { calls++; throw Error('PRIVATE-FIXTURE'); } }); badRep(eacc);
+  assert.equal(calls, 0);
+  badRep(Object.assign(Object.create({ x: 1 }), rep()));
+  badRep(rep({ result: Object.assign(Object.create({ x: 1 }), okResult()) }));
+  badRep(rep({ result: { ok: true, value: Object.assign(Object.create({ x: 1 }), okResult().value) } }));
+  badRep([]); badRep(null); badRep(undefined); badRep('x');
+  parseRep(Object.assign(Object.create(null), rep()));
+});
+
+test('reply: errors contain no private sentinel and are fixed', () => {
+  const sentinel = rep({ result: { ok: false, error: { code: 'PRIVATE-FIXTURE secret' } } });
+  assert.throws(() => parseRep(sentinel), e => e.name === 'CoreSchemaError' && e.message === 'Invalid core data.' && !JSON.stringify(e).includes('PRIVATE-FIXTURE'));
+});
```

## Implementation — only after RED evidence

```diff
--- /dev/null
+++ b/packages/schemas/src/evm-agreement-protocol.ts
@@ -0,0 +1,108 @@
+/** Private strict request/reply SCHEMA for the in-memory EVM agreement consistency check. Structural parsing only:
+ * it proves no signature, payment, chain state, trust or funding, and carries no authority. Header IDs are data;
+ * the future host owns current request/generation, cancellation and job state. Synchronous, stateless, no timers.
+ * Fixed outer arity (5 request / 6 reply fields); the body is delegated unchanged to parseEvmAgreementInput after the
+ * whole header is accepted. Failures carry only a fixed core code, never foreign error objects or messages.
+ * Caller must wipe the returned owned signature bytes. Not exported by any package facade.
+ */
+import { CoreSchemaError, type CoreErrorCode } from './core.ts';
+import { MAX_RUNTIME_SEQUENCE } from './runtime.ts';
+import { parseEvmAgreementInput, type EvmAgreementInputSnapshot } from './evm-agreement-input.ts';
+
+export type EvmAgreementFailureCode = CoreErrorCode | 'BUSY';
+export interface EvmAgreementCheckRequest {
+  readonly version: 1; readonly requestId: number; readonly generation: number;
+  readonly operation: 'checkEvmAgreement'; readonly input: Readonly<EvmAgreementInputSnapshot>;
+}
+export interface EvmAgreementCheckValue {
+  readonly testOnly: true; readonly economicPreparationAllowed: false; readonly termsHash: string;
+  readonly accounts: Readonly<{ readonly seller: string; readonly buyer: string }>;
+}
+export type EvmAgreementCheckResult =
+  | Readonly<{ ok: true; value: Readonly<EvmAgreementCheckValue> }>
+  | Readonly<{ ok: false; error: Readonly<{ code: EvmAgreementFailureCode }> }>;
+export interface EvmAgreementCheckReply {
+  readonly version: 1; readonly requestId: number; readonly generation: number;
+  readonly operation: 'checkEvmAgreement'; readonly kind: 'response'; readonly result: EvmAgreementCheckResult;
+}
+
+const FAILURE_CODES: readonly string[] = ['INVALID_INPUT', 'UNSUPPORTED_VERSION', 'UNSUPPORTED_PROVIDER', 'WRONG_CHAIN', 'UNAUTHORIZED',
+  'USER_REJECTED', 'LOCKED', 'CONFLICT', 'UNAVAILABLE', 'TIMEOUT', 'CANCELLED', 'LIMIT_EXCEEDED', 'INTEGRITY_FAILURE',
+  'BROADCAST_UNKNOWN', 'EXPIRED', 'BUSY'];
+const HEX64 = /^[0-9a-f]{64}$/, ADDR = /^0x[0-9a-f]{40}$/, ZERO = /^0x0{40}$/;
+const ownKeys = Reflect.ownKeys, getDesc = Object.getOwnPropertyDescriptor, getProto = Object.getPrototypeOf, isArr = Array.isArray;
+
+const fail = (): never => { throw new CoreSchemaError('INVALID_INPUT'); };
+/** Untrusted meta-operation boundary: whatever a hostile trap throws is discarded uninspected. */
+function meta<T>(read: () => T): T {
+  try { return read(); } catch { return fail(); }
+}
+/** Exact-field plain/null-prototype data record. Returns the own data values only (no copy of nested graphs). */
+function exact(input: unknown, keys: readonly string[]): Record<string, unknown> {
+  if (typeof input !== 'object' || input === null) return fail();
+  const arr = meta(() => isArr(input));
+  if (arr) return fail();
+  const proto = meta(() => getProto(input));
+  if (proto !== Object.prototype && proto !== null) return fail();
+  const actual = meta(() => ownKeys(input));
+  if (actual.length !== keys.length) return fail();
+  for (const k of actual) if (typeof k !== 'string' || !keys.includes(k)) return fail();
+  const out = Object.create(null) as Record<string, unknown>;
+  for (const key of keys) {
+    const d = meta(() => getDesc(input, key));
+    if (!d || !d.enumerable || !('value' in d)) return fail();
+    out[key] = d.value;
+  }
+  return out;
+}
+function counter(v: unknown, min: number): number {
+  if (typeof v !== 'number' || !Number.isSafeInteger(v) || v < min || v > MAX_RUNTIME_SEQUENCE) return fail();
+  return v;
+}
+
+/** Header (version/ids/operation) is fully validated BEFORE the body is read, copied or parsed. */
+export function parseEvmAgreementCheckRequest(input: unknown): Readonly<EvmAgreementCheckRequest> {
+  const r = exact(input, ['version', 'requestId', 'generation', 'operation', 'input']);
+  if (r.version !== 1 || r.operation !== 'checkEvmAgreement') return fail();
+  const requestId = counter(r.requestId, 1), generation = counter(r.generation, 0);
+  const snapshot = parseEvmAgreementInput(r.input);
+  return Object.freeze({ version: 1 as const, requestId, generation, operation: 'checkEvmAgreement' as const, input: snapshot });
+}
+
+function failureCode(v: unknown): EvmAgreementFailureCode {
+  if (typeof v !== 'string' || !FAILURE_CODES.includes(v)) return fail();
+  return v as EvmAgreementFailureCode;
+}
+function result(input: unknown): EvmAgreementCheckResult {
+  if (typeof input !== 'object' || input === null || meta(() => isArr(input))) return fail();
+  const ok = meta(() => {
+    const d = getDesc(input, 'ok');
+    return d && d.enumerable && 'value' in d ? d.value : undefined;
+  });
+  if (ok === true) {
+    const r = exact(input, ['ok', 'value']);
+    const v = exact(r.value, ['testOnly', 'economicPreparationAllowed', 'termsHash', 'accounts']);
+    if (v.testOnly !== true || v.economicPreparationAllowed !== false) return fail();
+    if (typeof v.termsHash !== 'string' || !HEX64.test(v.termsHash)) return fail();
+    const a = exact(v.accounts, ['seller', 'buyer']);
+    const seller = a.seller, buyer = a.buyer;
+    if (typeof seller !== 'string' || typeof buyer !== 'string' || !ADDR.test(seller) || !ADDR.test(buyer) ||
+        ZERO.test(seller) || ZERO.test(buyer) || seller === buyer) return fail();
+    return Object.freeze({ ok: true as const, value: Object.freeze({ testOnly: true as const, economicPreparationAllowed: false as const,
+      termsHash: v.termsHash, accounts: Object.freeze({ seller, buyer }) }) });
+  }
+  if (ok === false) {
+    const r = exact(input, ['ok', 'error']);
+    const e = exact(r.error, ['code']);
+    return Object.freeze({ ok: false as const, error: Object.freeze({ code: failureCode(e.code) }) });
+  }
+  return fail();
+}
+
+export function parseEvmAgreementCheckReply(input: unknown): Readonly<EvmAgreementCheckReply> {
+  const r = exact(input, ['version', 'requestId', 'generation', 'operation', 'kind', 'result']);
+  if (r.version !== 1 || r.operation !== 'checkEvmAgreement' || r.kind !== 'response') return fail();
+  const requestId = counter(r.requestId, 1), generation = counter(r.generation, 0);
+  return Object.freeze({ version: 1 as const, requestId, generation, operation: 'checkEvmAgreement' as const,
+    kind: 'response' as const, result: result(r.result) });
+}
```

## Isolated real-verifier browser fixture — retained floors/graphs

```diff
--- a/scripts/fixtures/g16-browser.mjs
+++ b/scripts/fixtures/g16-browser.mjs
@@ -6,6 +6,7 @@
 import { verifyEvmAgreementBundle } from '../../packages/wallet/src/evm-agreement.ts';
 import { encodePrivateAgreement, encodeCapabilities, sha256Hex } from '../../packages/domain/index.ts';
 import { parseEvmAgreementInput } from '../../packages/schemas/src/evm-agreement-input.ts';
+import { parseEvmAgreementCheckRequest, parseEvmAgreementCheckReply } from '../../packages/schemas/src/evm-agreement-protocol.ts';
 
 const hex = bytes => Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
 const unhex = text => Uint8Array.from(text.match(/../g) ?? [], pair => Number.parseInt(pair, 16));
@@ -226,6 +227,61 @@
     check(observed.length === at && cleared(observed), 'FAILED_BACKEND_WIPE');
   }
   groups.push('sanitized hash failure and terminal buffer clearing');
+
+  // Private request -> REAL verifier -> strict reply. Structural schema only: header IDs are data, not authority,
+  // and the trusted verifier context (isCurrent/signal/sha256) never travels in the request or reply.
+  const MAXSEQ = Number.MAX_SAFE_INTEGER - 1;
+  const wipeReq = request => { if (request) for (const acceptance of request.input.acceptances) acceptance.signature.fill(0); };
+  const protoCode = fn => { try { fn(); return 'OK'; } catch (error) { return error?.name === 'CoreSchemaError' ? error.code : 'OTHER'; } };
+  const toReply = (requestId, generation, result) => ({ version: 1, requestId, generation, operation: 'checkEvmAgreement', kind: 'response',
+    result: result.ok ? { ok: true, value: { testOnly: result.value.testOnly, economicPreparationAllowed: result.value.economicPreparationAllowed,
+      termsHash: result.value.termsHash, accounts: { seller: result.value.accounts.seller, buyer: result.value.accounts.buyer } } }
+      : { ok: false, error: { code: result.error.code } } });
+  for (let index = 0; index < corpus.bundles.length; index++) {
+    let request;
+    try {
+      request = parseEvmAgreementCheckRequest({ version: 1, requestId: index + 1, generation: 3, operation: 'checkEvmAgreement', input: bundleAt(index) });
+      check(Object.isFrozen(request) && request.input.acceptances.length === 2 && request.requestId === index + 1, 'PROTO_REQUEST_SHAPE');
+      const verified = await verify(request.input);
+      const reply = parseEvmAgreementCheckReply(toReply(request.requestId, request.generation, verified));
+      check(reply.result.ok === true && reply.result.value.termsHash === corpus.nodeDigests[index], 'PROTO_NODE_DIGEST_PARITY');
+      check(reply.result.value.testOnly === true && reply.result.value.economicPreparationAllowed === false && Object.isFrozen(reply.result), 'PROTO_SPENDING_DISABLED');
+      check(!/paymentInstructions|agreementSalt|signature|capabilities/.test(JSON.stringify(reply)), 'PROTO_PRIVATE_REPLY');
+    } finally { wipeReq(request); }
+  }
+  // Real failed CoreResult -> code-only reply projection (not the richer error object).
+  {
+    let request;
+    try {
+      const tampered = bundleAt(0); tampered.terms.amountBaseUnits = '2';
+      request = parseEvmAgreementCheckRequest({ version: 1, requestId: 7, generation: 0, operation: 'checkEvmAgreement', input: tampered });
+      const verified = await verify(request.input);
+      check(verified.ok === false, 'PROTO_EXPECT_FAILURE');
+      const reply = parseEvmAgreementCheckReply(toReply(7, 0, verified));
+      check(reply.result.ok === false && reply.result.error.code === verified.error.code && Object.keys(reply.result.error).length === 1, 'PROTO_FAILURE_CODE_ONLY');
+      check(protoCode(() => parseEvmAgreementCheckReply({ ...toReply(7, 0, verified), result: verified })) === 'INVALID_INPUT', 'PROTO_RICH_ERROR_REJECTED');
+    } finally { wipeReq(request); }
+  }
+  // Header/shape refusal before body touch, meta-trap sanitization, privacy.
+  let bodyTouched = 0;
+  const spyBody = new Proxy(bundleAt(0), { ownKeys(t) { bodyTouched++; return Reflect.ownKeys(t); },
+    getOwnPropertyDescriptor(t, k) { bodyTouched++; return Reflect.getOwnPropertyDescriptor(t, k); } });
+  for (const header of [{ version: 1, requestId: 0, generation: 0 }, { version: 1, requestId: MAXSEQ + 1, generation: 0 },
+    { version: 1, requestId: 1, generation: -1 }, { version: 2, requestId: 1, generation: 0 }]) {
+    check(protoCode(() => parseEvmAgreementCheckRequest({ ...header, operation: 'checkEvmAgreement', input: spyBody })) === 'INVALID_INPUT', 'PROTO_HEADER_REFUSAL');
+  }
+  check(protoCode(() => parseEvmAgreementCheckRequest({ version: 1, requestId: 1, generation: 0, operation: 'status', input: spyBody })) === 'INVALID_INPUT', 'PROTO_OPERATION_REFUSAL');
+  check(bodyTouched === 0, 'PROTO_BODY_TOUCHED');
+  const forged = Object.assign(new Error('PRIVATE-FIXTURE forged'), { name: 'CoreSchemaError', code: 'LIMIT_EXCEEDED' });
+  let sanitized;
+  try { parseEvmAgreementCheckRequest({ version: 1, requestId: 1, generation: 0, operation: 'checkEvmAgreement', input: new Proxy({}, { ownKeys() { throw forged; } }) }); }
+  catch (error) { sanitized = error; }
+  check(sanitized !== undefined && sanitized !== forged && sanitized.code === 'INVALID_INPUT' && !String(sanitized.message).includes('PRIVATE-FIXTURE'), 'PROTO_TRAP_SANITIZED');
+  check(protoCode(() => parseEvmAgreementCheckReply({ version: 1, requestId: 1, generation: 0, operation: 'checkEvmAgreement', kind: 'response', extra: 1,
+    result: { ok: false, error: { code: 'BUSY' } } })) === 'INVALID_INPUT', 'PROTO_REPLY_EXTRA');
+  check(parseEvmAgreementCheckReply({ version: 1, requestId: 1, generation: 0, operation: 'checkEvmAgreement', kind: 'response',
+    result: { ok: false, error: { code: 'BUSY' } } }).result.error.code === 'BUSY', 'PROTO_BUSY_CODE');
+  groups.push('private request-reply schema around the real verifier (structural, header IDs are data only)');
   return Object.freeze({ assertions, groups, independentKeccakKats: 2, independentG16Digests: 6,
     independentG16Signatures: signatures, officialMailRecovery: true, retainedPrivateEncodingVectors: 2,
     sameProviderIntegrationBundles: corpus.bundles.length, heldCancellationSchedules: 4,
```

## Original model static limitations and notes

Three ordinary unified diffs follow. Nothing was executed; every test and fixture expectation is UNEXECUTED, and no product defect is claimed.

## Scope, bases, limitations

| Path | Base | Base bytes | Base SHA256 | Target hash |
|---|---|---|---|---|
| `packages/schemas/src/evm-agreement-protocol.ts` | absent (`/dev/null`) | none | none | broker computes |
| `packages/schemas/test/evm-agreement-protocol.test.mjs` | absent (`/dev/null`) | none | none | broker computes |
| `scripts/fixtures/g16-browser.mjs` | existing | 17877 | `8d89b7fffee4b13f836783b6ed2cb138ec10283dc034d9feae6a2342ae0bdde8` | broker computes |

Static limitations:
- **Hunk metadata:** the fixture patch's hunk line counts and the new-file hunk counts were hand-computed. The broker must regenerate or verify them.
- **EOF markers:** the new files are specified to end with a trailing newline. The fixture patch inserts text only before existing lines and does not touch the file's EOF.
- **Type-check:** the TS module was never compiled. If `tsc` flags a cast, treat it as a static typing nit rather than a behavior defect.
- **Reply codes:** `CoreErrorCode` is not available at runtime, so the 15 core codes are duplicated as a local list, plus `'BUSY'`. The list was copied from `core.ts` lines 24-40.
- **Test input shape:** the tests inline their own structurally valid input factory, because the existing test file does not export its factory.
- **Fixture trap:** the "Proxy body fails before body touch" case relies on the Proxy `ownKeys`/`getOwnPropertyDescriptor` counters staying at 0. That holds because the header is validated first.
- **Fixture wipe:** the new fixture groups wipe signatures in `finally`.
- **Not claimed:** parsing is structural only and proves nothing about signatures, payment, chain state or funding.

## Notes for the broker

- **Assertion counts:** the fixture patch adds `check` calls and one group, which the packet permits. The prior 182-assertion and 11-group floor is raised, not lowered.
- **Document/Worker parity:** the document and Worker runs compare `assertions` and `groups` for equality, so both will grow equally.
- **Import path:** the fixture imports the new module by relative `.ts` path, as the existing imports do, so the Vite lib build picks it up. The driver's graph assertions reject `g16-bundle-fixture`, `packages/identity`, `evm-adapter` and `apps/web`, none of which the new module imports.
- **Typed-array typing:** `parseEvmAgreementCheckRequest` returns `snapshot` as produced by `parseEvmAgreementInput`, so ownership and wiping behavior are inherited unchanged.
- **Failure-path leak:** the request parser validates the whole header before calling the body parser. The body parser clears its owned arrays on its own failures. Nothing in the new module allocates signature bytes, so there is no new leak path.