import datetime, hashlib, json, os, re, subprocess, sys, tempfile
from pathlib import Path
repo=Path('/workspace/scratch/dcf03ef9bee8/p2p-funding-proposal-codec-g35')
root=Path(__file__).parent
name, *command=sys.argv[1:]
record=root/(name+'.json'); assert not record.exists()
def git(*args, env=None): return subprocess.check_output(['git',*args], cwd=repo, env=env)
head=git('rev-parse','HEAD').decode().strip()
with tempfile.TemporaryDirectory(prefix='g35-index-') as tmp:
    env=dict(os.environ, GIT_INDEX_FILE=str(Path(tmp)/'index'))
    git('read-tree','HEAD',env=env); git('add','-A',env=env)
    tree=git('write-tree',env=env).decode().strip()
patch=git('diff','--binary','--full-index',head,tree)
(root/(name+'.patch')).write_bytes(patch)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
log=root/(name+'.log')
with log.open('wb') as out: result=subprocess.run(command,cwd=repo,stdout=out,stderr=subprocess.STDOUT)
raw=log.read_bytes(); counts={}
for label,value in re.findall(r'(?:#|ℹ) (tests|pass|fail|cancelled|skipped|todo) (\d+)',raw.decode(errors='replace')): counts[label]=int(value)
item={'name':name,'command':command,'cwd':str(repo),'source':head,'executionTree':tree,'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'counts':counts,'log':str(log),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'patch':str(root/(name+'.patch')),'patchBytes':len(patch),'patchSha256':hashlib.sha256(patch).hexdigest()}
record.write_text(json.dumps(item,indent=2)+'\n')
print(json.dumps(item))
sys.exit(result.returncode)
