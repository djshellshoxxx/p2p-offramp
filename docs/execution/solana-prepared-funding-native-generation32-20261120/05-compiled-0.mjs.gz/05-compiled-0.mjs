#!/usr/bin/env node
import { createRequire } from "node:module";
import { spawn, spawnSync } from "node:child_process";
import { createHash, randomBytes } from "node:crypto";
import { accessSync, closeSync, constants, existsSync, mkdirSync, mkdtempSync, openSync, readFileSync, realpathSync, statSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { delimiter, dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { isDeepStrictEqual } from "node:util";
import { ed25519 } from "@noble/curves/ed25519.js";
import { sha256 } from "@noble/hashes/sha2.js";
// contracts/solana/vectors/derive.mjs
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const enc$1 = new TextEncoder();
const FORMAT = "p2p-offramp/solana-independent-vectors/v1";
const FIXTURE_PATH = fileURLToPath(new URL("./solana-independent.json", import.meta.url));
const sha256$1 = (...parts) => {
	const h = createHash("sha256");
	for (const p of parts) h.update(p);
	return new Uint8Array(h.digest());
};
const toHex = (b) => Buffer.from(b).toString("hex");
function base58Encode(bytes) {
	let n = 0n;
	for (const b of bytes) n = n << 8n | BigInt(b);
	let out = "";
	while (n > 0n) {
		out = ALPHABET[Number(n % 58n)] + out;
		n /= 58n;
	}
	let zeros = 0;
	while (zeros < bytes.length && bytes[zeros] === 0) zeros++;
	return "1".repeat(zeros) + out;
}
function base58Decode(str, expectedLength = null) {
	if (typeof str !== "string" || str.length === 0) throw new Error("base58: empty input");
	let n = 0n;
	for (const ch of str) {
		const i = ALPHABET.indexOf(ch);
		if (i < 0) throw new Error(`base58: invalid character ${JSON.stringify(ch)}`);
		n = n * 58n + BigInt(i);
	}
	let hex = n.toString(16);
	if (hex.length % 2) hex = "0" + hex;
	let body = n === 0n ? [] : [...Buffer.from(hex, "hex")];
	let zeros = 0;
	while (zeros < str.length && str[zeros] === "1") zeros++;
	const bytes = Uint8Array.from([...new Array(zeros).fill(0), ...body]);
	if (base58Encode(bytes) !== str) throw new Error("base58: non-canonical encoding");
	if (expectedLength !== null && bytes.length !== expectedLength) throw new Error(`base58: expected ${expectedLength} bytes, got ${bytes.length}`);
	return bytes;
}
const decodeKey$1 = (s) => base58Decode(s, 32);
function isOnCurve$1(bytes32) {
	try {
		ed25519.Point.fromBytes(bytes32);
		return true;
	} catch {
		return false;
	}
}
function createProgramAddress(seeds, programId) {
	if (seeds.length > 16) throw new Error("PDA: max 16 seeds");
	for (const s of seeds) if (s.length > 32) throw new Error("PDA: seed longer than 32 bytes");
	if (programId.length !== 32) throw new Error("PDA: program id must be 32 bytes");
	const hash = sha256$1(...seeds, programId, enc$1.encode("ProgramDerivedAddress"));
	if (isOnCurve$1(hash)) throw new Error("PDA: derived address is on curve");
	return hash;
}
function findProgramAddress$1(seeds, programId) {
	for (let bump = 255; bump >= 0; bump--) try {
		return {
			address: createProgramAddress([...seeds, Uint8Array.of(bump)], programId),
			bump
		};
	} catch (e) {
		if (!/on curve/.test(e.message)) throw e;
	}
	throw new Error("PDA: no viable bump");
}
const ATA_PROGRAM_ID$1 = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL";
const SPL_PROGRAM_ID$1 = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
const PROGRAM_ID_ASCII = "escrow-program:p2p-offramp:local";
const PROGRAM_ID = base58Encode(enc$1.encode(PROGRAM_ID_ASCII));
const MINT_ASCII = ["mint-6dp-open:p2p-offramp:local1", "freezable-mint-6dp:p2p-offramp:1"];
const MINTS = MINT_ASCII.map((m) => base58Encode(enc$1.encode(m)));
if (PROGRAM_ID !== "7q2EChqznfQea58ZfUvBzRd97Bc28kwHaey1tYy7ADjq") throw new Error("PROGRAM_ID mismatch");
function findAta(owner, mint) {
	return findProgramAddress$1([
		owner,
		decodeKey$1(SPL_PROGRAM_ID$1),
		mint
	], decodeKey$1(ATA_PROGRAM_ID$1));
}
const pda = (r) => ({
	address: base58Encode(r.address),
	bump: r.bump
});
function discriminator$1(ns, name) {
	return toHex(sha256$1(enc$1.encode(`${ns}:${name}`)).slice(0, 8));
}
function escrowCase(i, seller, nonce, nonceLabel) {
	const programId = decodeKey$1(PROGRAM_ID);
	const escrow = findProgramAddress$1([
		enc$1.encode("p2p-offramp-escrow-v1"),
		seller,
		nonce
	], programId);
	const vault = findProgramAddress$1([enc$1.encode("p2p-offramp-vault-v1"), escrow.address], programId);
	const buyer = sha256$1(enc$1.encode(`vector-buyer-${i}`));
	return {
		index: i,
		seller: base58Encode(seller),
		sellerHex: toHex(seller),
		nonce: base58Encode(nonce),
		nonceHex: toHex(nonce),
		nonceLabel,
		escrow: pda(escrow),
		vault: pda(vault),
		buyer: base58Encode(buyer),
		buyerAtas: MINTS.map((m) => ({
			mint: m,
			ata: pda(findAta(buyer, decodeKey$1(m)))
		}))
	};
}
function buildEscrowCases() {
	const cases = [];
	for (let i = 0; i < 6; i++) {
		const seller = sha256$1(enc$1.encode(`vector-seller-${i}`));
		let nonce = sha256$1(enc$1.encode(`vector-nonce-${i}`));
		let label = "sha256";
		if (i === 2) [nonce, label] = [/* @__PURE__ */ new Uint8Array(32), "all-zero"];
		if (i === 4) [nonce, label] = [(/* @__PURE__ */ new Uint8Array(32)).fill(255), "all-0xff"];
		cases.push(escrowCase(i, seller, nonce, label));
	}
	const low = (c) => [
		c.escrow,
		c.vault,
		...c.buyerAtas.map((a) => a.ata)
	].some((p) => p.bump < 255);
	for (let i = 6; !cases.some(low) && i < 200; i++) {
		const seller = sha256$1(enc$1.encode(`vector-seller-${i}`));
		cases.push(escrowCase(i, seller, sha256$1(enc$1.encode(`vector-nonce-${i}`)), "sha256"));
	}
	return cases;
}
function negativeCases() {
	const attempt = (fn) => {
		try {
			fn();
			return false;
		} catch {
			return true;
		}
	};
	const pid = decodeKey$1(PROGRAM_ID);
	const k = (n) => base58Encode(new Uint8Array(n).fill(1));
	const seeds = (n) => Array.from({ length: n }, () => Uint8Array.of(1));
	return [
		["createProgramAddress with 17 one-byte seeds", () => createProgramAddress(seeds(17), pid)],
		["createProgramAddress with one 33-byte seed", () => createProgramAddress([/* @__PURE__ */ new Uint8Array(33)], pid)],
		["findProgramAddress with 16 user seeds (bump makes 17)", () => findProgramAddress$1(seeds(16), pid)],
		["base58 decode of \"0OIl\" (excluded characters)", () => base58Decode("0OIl")],
		["base58 decode of 31-byte key", () => decodeKey$1(k(31))],
		["base58 decode of 33-byte key", () => decodeKey$1(k(33))]
	].map(([description, fn]) => ({
		description,
		expectError: attempt(fn)
	}));
}
function buildFixture() {
	const req = createRequire(import.meta.url);
	const ver = (p) => {
		const entry = req.resolve(`${p}/utils.js`);
		const root = entry.slice(0, entry.lastIndexOf(`node_modules/${p}/`) + `node_modules/${p}/`.length);
		return JSON.parse(readFileSync(root + "package.json", "utf8")).version;
	};
	const names = [
		"fund_native",
		"fund_spl",
		"release",
		"refund",
		"payout_native",
		"payout_spl"
	];
	const disc = (ns, list) => Object.fromEntries(list.map((n) => [n, discriminator$1(ns, n)]));
	return {
		format: FORMAT,
		generator: {
			file: "contracts/solana/vectors/derive.mjs",
			nodeMajor: process.versions.node.split(".")[0],
			nobleCurves: ver("@noble/curves"),
			nobleHashes: ver("@noble/hashes")
		},
		constants: {
			programId: PROGRAM_ID,
			programIdAscii: PROGRAM_ID_ASCII,
			ataProgramId: ATA_PROGRAM_ID$1,
			tokenProgramId: SPL_PROGRAM_ID$1,
			idsSource: "known-constant-unverified-on-disk",
			escrowSeedPrefix: "p2p-offramp-escrow-v1",
			vaultSeedPrefix: "p2p-offramp-vault-v1",
			mints: MINT_ASCII.map((a, i) => ({
				ascii: a,
				address: MINTS[i]
			}))
		},
		discriminators: {
			accounts: disc("account", ["EscrowV1"]),
			instructions: disc("global", names),
			events: disc("event", [
				"Funded",
				"Released",
				"Refunded",
				"PaidOut"
			])
		},
		escrowCases: buildEscrowCases(),
		negativeCases: negativeCases()
	};
}
const render = () => JSON.stringify(buildFixture(), null, 2) + "\n";
if (process.argv[1] === fileURLToPath(import.meta.url)) {
	const out = render();
	if (process.argv.includes("--write")) writeFileSync(FIXTURE_PATH, out);
	else if (process.argv.includes("--check")) {
		let cur = "";
		try {
			cur = readFileSync(FIXTURE_PATH, "utf8");
		} catch {}
		if (cur !== out) {
			console.error("fixture differs from regenerated output");
			process.exit(1);
		}
	} else {
		console.error("usage: derive.mjs --write | --check");
		process.exit(2);
	}
}
// contracts/solana/localnet/driver.mjs
const SYSTEM_PROGRAM_ID$1 = "11111111111111111111111111111111";
const LOADER_V3_ID$1 = "BPFLoaderUpgradeab1e11111111111111111111111";
const SYSVAR_CLOCK_ID = "SysvarC1ock11111111111111111111111111111111";
const OPEN_MINT = MINTS[0];
const FREEZABLE_MINT = MINTS[1];
const GENESIS_HASH_ASCII = "genesis-hash:p2p-offramp:localv1";
const MAX_TX_BYTES = 1232;
const enc = new TextEncoder();
const concat$1 = (...parts) => new Uint8Array(Buffer.concat(parts.map((p) => Uint8Array.from(p))));
const equalBytes$1 = (a, b) => a.length === b.length && a.every((x, i) => x === b[i]);
const utf8$1 = (s) => enc.encode(s);
function compactU16(n) {
	if (!Number.isInteger(n) || n < 0 || n > 65535) throw new Error(`compact-u16 out of range: ${n}`);
	const out = [];
	for (let v = n;; v >>= 7) {
		if (v < 128) return Uint8Array.from([...out, v]);
		out.push(v & 127 | 128);
	}
}
function u64le(value) {
	const n = BigInt(value);
	if (n < 0n || n > 18446744073709551615n) throw new Error(`u64 out of range: ${value}`);
	const b = /* @__PURE__ */ new Uint8Array(8);
	new DataView(b.buffer).setBigUint64(0, n, true);
	return b;
}
const u32le = (n) => {
	const b = /* @__PURE__ */ new Uint8Array(4);
	new DataView(b.buffer).setUint32(0, n, true);
	return b;
};
function bytes32(value, name) {
	const b = typeof value === "string" ? decodeKey$1(value) : Uint8Array.from(value ?? []);
	if (b.length !== 32) throw new Error(`${name}: expected 32 bytes, got ${b.length}`);
	return b;
}
const view = (data) => new DataView(data.buffer, data.byteOffset, data.byteLength);
const readU64$1 = (data, off) => view(data).getBigUint64(off, true);
const readI64$1 = (data, off) => view(data).getBigInt64(off, true);
const readKey = (data, off) => base58Encode(data.slice(off, off + 32));
function keypairFromSeed(seed) {
	if (seed.length !== 32) throw new Error("keypair: seed must be 32 bytes");
	const publicKey = ed25519.getPublicKey(Uint8Array.from(seed));
	const kp = {
		address: base58Encode(publicKey),
		publicKey
	};
	Object.defineProperty(kp, "seed", {
		value: Uint8Array.from(seed),
		enumerable: false
	});
	kp.toJSON = () => kp.address;
	return kp;
}
const generateKeypair = () => keypairFromSeed(randomBytes(32));
function loadKeypairFile(path) {
	const arr = JSON.parse(readFileSync(path, "utf8"));
	if (!Array.isArray(arr) || arr.length !== 64) throw new Error(`keypair file ${path}: expected a 64-byte array`);
	const bytes = Uint8Array.from(arr);
	const kp = keypairFromSeed(bytes.slice(0, 32));
	if (!equalBytes$1(kp.publicKey, bytes.slice(32))) throw new Error(`keypair file ${path}: public key mismatch`);
	return kp;
}
const meta$2 = (pubkey, isSigner, isWritable) => ({
	pubkey,
	isSigner,
	isWritable
});
function collectAccounts(feePayer, instructions) {
	const metas = /* @__PURE__ */ new Map([[feePayer, {
		signer: true,
		writable: true
	}]]);
	const add = (pubkey, signer, writable) => {
		const m = metas.get(pubkey) ?? {
			signer: false,
			writable: false
		};
		metas.set(pubkey, {
			signer: m.signer || signer,
			writable: m.writable || writable
		});
	};
	for (const ix of instructions) {
		for (const k of ix.keys) add(k.pubkey, k.isSigner, k.isWritable);
		add(ix.programId, false, false);
	}
	const rank = ([addr, m]) => addr === feePayer ? -1 : (m.signer ? 0 : 2) + (m.writable ? 0 : 1);
	return [...metas.entries()].sort((a, b) => rank(a) - rank(b));
}
function compileLegacyMessage$1(feePayer, instructions, recentBlockhash) {
	if (instructions.length === 0) throw new Error("transaction: no instructions");
	const accounts = collectAccounts(feePayer, instructions);
	if (accounts.length > 255) throw new Error("transaction: too many accounts");
	const index = new Map(accounts.map(([a], i) => [a, i]));
	const signers = accounts.filter(([, m]) => m.signer).map(([a]) => a);
	const roSigned = accounts.filter(([, m]) => m.signer && !m.writable).length;
	const roUnsigned = accounts.filter(([, m]) => !m.signer && !m.writable).length;
	const ixBytes = instructions.map((ix) => concat$1([index.get(ix.programId)], compactU16(ix.keys.length), ix.keys.map((k) => index.get(k.pubkey)), compactU16(ix.data.length), ix.data));
	return {
		message: concat$1([
			signers.length,
			roSigned,
			roUnsigned
		], compactU16(accounts.length), ...accounts.map(([a]) => decodeKey$1(a)), bytes32(recentBlockhash, "recentBlockhash"), compactU16(instructions.length), ...ixBytes),
		signers
	};
}
function signTransaction(compiled, keypairs) {
	const byAddress = new Map(keypairs.map((k) => [k.address, k]));
	for (const k of keypairs) if (!compiled.signers.includes(k.address)) throw new Error(`transaction: unexpected signer ${k.address}`);
	const sigs = compiled.signers.map((addr) => {
		const kp = byAddress.get(addr);
		if (!kp) throw new Error(`transaction: missing signer ${addr}`);
		return ed25519.sign(compiled.message, kp.seed);
	});
	const wire = concat$1(compactU16(sigs.length), ...sigs, compiled.message);
	if (wire.length > 1232) throw new Error(`transaction: ${wire.length} bytes exceeds ${MAX_TX_BYTES}`);
	return {
		wire,
		signature: base58Encode(sigs[0])
	};
}
var RpcError = class extends Error {
	constructor(method, error) {
		super(`rpc ${method}: ${error.code} ${error.message}`);
		this.code = error.code;
		this.data = error.data;
	}
};
var Rpc = class {
	constructor(url, timeoutMs = 15e3) {
		this.url = url;
		this.timeoutMs = timeoutMs;
		this.nextId = 1;
	}
	async call(method, params = []) {
		const body = JSON.stringify({
			jsonrpc: "2.0",
			id: this.nextId++,
			method,
			params
		});
		const res = await fetch(this.url, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body,
			signal: AbortSignal.timeout(this.timeoutMs)
		});
		if (!res.ok) throw new Error(`rpc ${method}: HTTP ${res.status}`);
		const json = await res.json();
		if (json.error) throw new RpcError(method, json.error);
		return json.result;
	}
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const LEVELS = {
	processed: 0,
	confirmed: 1,
	finalized: 2
};
async function getAccount(rpc, address, commitment = "confirmed") {
	const res = await rpc.call("getAccountInfo", [address, {
		encoding: "base64",
		commitment
	}]);
	const v = res.value;
	if (!v) return null;
	const data = new Uint8Array(Buffer.from(v.data[0], "base64"));
	return {
		lamports: v.lamports,
		owner: v.owner,
		executable: v.executable,
		data,
		slot: res.context.slot
	};
}
async function getBalance(rpc, address, commitment = "finalized") {
	return (await rpc.call("getBalance", [address, { commitment }])).value;
}
async function readClock(rpc, commitment = "confirmed") {
	const acc = await getAccount(rpc, SYSVAR_CLOCK_ID, commitment);
	if (!acc || acc.data.length < 40) throw new Error("clock sysvar: missing or short");
	return {
		slot: Number(readU64$1(acc.data, 0)),
		epochStartTimestamp: Number(readI64$1(acc.data, 8)),
		epoch: Number(readU64$1(acc.data, 16)),
		unixTimestamp: Number(readI64$1(acc.data, 32))
	};
}
async function waitForSignature(rpc, signature, commitment, timeoutMs) {
	const deadline = Date.now() + timeoutMs;
	for (;;) {
		const st = (await rpc.call("getSignatureStatuses", [[signature], { searchTransactionHistory: true }])).value[0];
		if (st && LEVELS[st.confirmationStatus] >= LEVELS[commitment]) return st;
		if (Date.now() > deadline) throw new Error(`signature ${signature}: not ${commitment} within ${timeoutMs} ms (last ${JSON.stringify(st)})`);
		await sleep(500);
	}
}
function preflightFailure(err) {
	if (!(err instanceof RpcError)) return err;
	const logs = err.data?.logs?.slice(-8).join(" | ") ?? "";
	return /* @__PURE__ */ new Error(`${err.message}; err=${JSON.stringify(err.data?.err ?? null)}; logs: ${logs}`);
}
async function sendTx(rpc, { feePayer, instructions, signers, skipPreflight = false, commitment }) {
	const { value } = await rpc.call("getLatestBlockhash", [{ commitment: "confirmed" }]);
	const { wire, signature } = signTransaction(compileLegacyMessage$1(feePayer.address, instructions, value.blockhash), signers);
	const opts = {
		encoding: "base64",
		skipPreflight,
		preflightCommitment: "confirmed"
	};
	let sent;
	try {
		sent = await rpc.call("sendTransaction", [Buffer.from(wire).toString("base64"), opts]);
	} catch (e) {
		throw preflightFailure(e);
	}
	if (sent !== signature) throw new Error(`sendTransaction returned ${sent}, expected ${signature}`);
	const status = await waitForSignature(rpc, signature, commitment ?? "confirmed", 6e4);
	return {
		signature,
		slot: status.slot,
		err: status.err,
		status
	};
}
const ataAddress = (owner, mint) => base58Encode(findAta(decodeKey$1(owner), decodeKey$1(mint)).address);
function programDataAddress$1(programId) {
	return base58Encode(findProgramAddress$1([decodeKey$1(programId)], decodeKey$1(LOADER_V3_ID$1)).address);
}
function transferIx(from, to, lamports) {
	return {
		programId: SYSTEM_PROGRAM_ID$1,
		keys: [meta$2(from, true, true), meta$2(to, false, true)],
		data: concat$1(u32le(2), u64le(lamports))
	};
}
function createAtaIdempotentIx(payer, owner, mint) {
	const ata = ataAddress(owner, mint);
	const keys = [
		meta$2(payer, true, true),
		meta$2(ata, false, true),
		meta$2(owner, false, false),
		meta$2(mint, false, false),
		meta$2(SYSTEM_PROGRAM_ID$1, false, false),
		meta$2(SPL_PROGRAM_ID$1, false, false)
	];
	return {
		ata,
		ix: {
			programId: ATA_PROGRAM_ID$1,
			keys,
			data: Uint8Array.of(1)
		}
	};
}
function mintToIx(mint, destination, authority, amount) {
	const keys = [
		meta$2(mint, false, true),
		meta$2(destination, false, true),
		meta$2(authority, true, false)
	];
	return {
		programId: SPL_PROGRAM_ID$1,
		keys,
		data: concat$1([7], u64le(amount))
	};
}
function decodeTokenAccount$1(data) {
	if (data.length !== 165) throw new Error(`token account: length ${data.length}`);
	return {
		mint: readKey(data, 0),
		owner: readKey(data, 32),
		amount: readU64$1(data, 64).toString(),
		state: data[108]
	};
}
function decodeProgramDataHeader(data) {
	if (data.length < 45 || view(data).getUint32(0, true) !== 3) throw new Error("loader-v3 ProgramData: bad header");
	const tag = data[12];
	if (tag > 1) throw new Error("loader-v3 ProgramData: bad authority option tag");
	return {
		slot: Number(readU64$1(data, 4)),
		upgradeAuthority: tag === 1 ? readKey(data, 13) : null
	};
}
function mintAccountFile(address, { mintAuthority, freezeAuthority = null, decimals, lamports }) {
	const data = /* @__PURE__ */ new Uint8Array(82);
	data.set(u32le(1), 0);
	data.set(decodeKey$1(mintAuthority), 4);
	data[44] = decimals;
	data[45] = 1;
	if (freezeAuthority) {
		data.set(u32le(1), 46);
		data.set(decodeKey$1(freezeAuthority), 50);
	}
	return {
		pubkey: address,
		account: {
			lamports,
			data: [Buffer.from(data).toString("base64"), "base64"],
			owner: SPL_PROGRAM_ID$1,
			executable: false,
			rentEpoch: 0,
			space: 82
		}
	};
}
// contracts/solana/localnet/tool-path.mjs
/**
* Resolve a developer tool (solana, solana-test-validator, solana-keygen) to an absolute executable path.
* Only absolute PATH entries are searched, and a world-writable entry or candidate is skipped, so a planted
* binary in a shared directory or a relative "." entry is never selected.
*/
function resolveTool(name, searchPath = process.env.PATH ?? "") {
	if (typeof name !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(name)) throw new Error("TOOL_NAME_INVALID");
	for (const directory of String(searchPath).split(delimiter)) {
		if (!isAbsolute(directory) || worldWritable(directory, true)) continue;
		const candidate = join(directory, name);
		if (worldWritable(candidate, false)) continue;
		try {
			accessSync(candidate, constants.X_OK);
			return candidate;
		} catch {}
	}
	throw new Error(`TOOL_NOT_FOUND: ${name}`);
}
/** True when the path is missing, has the wrong kind, or grants write access to every user. */
function worldWritable(path, directory) {
	try {
		const info = statSync(path);
		if (directory ? !info.isDirectory() : !info.isFile()) return true;
		return (info.mode & 2) !== 0;
	} catch {
		return true;
	}
}
/**
* Resolve an operator-supplied path and require that it stays inside one of `roots`. Symlinks are resolved on
* the nearest existing ancestor, so a link inside a root cannot point the harness outside it.
*/
function confinedPath(input, roots = [tmpdir()]) {
	const target = resolve(String(input));
	let ancestor = target;
	while (!existsSync(ancestor)) {
		const parent = dirname(ancestor);
		if (parent === ancestor) throw new Error("PATH_OUTSIDE_ALLOWED_ROOTS");
		ancestor = parent;
	}
	const real = join(realpathSync(ancestor), relative(ancestor, target));
	for (const root of roots) {
		const rel = relative(realpathSync(root), real);
		if (rel === "" || !isAbsolute(rel) && rel !== ".." && !rel.startsWith(`..${sep}`)) return real;
	}
	throw new Error("PATH_OUTSIDE_ALLOWED_ROOTS");
}
// packages/domain/src/errors.ts
const ACTIONS = Object.freeze({
	INVALID_INPUT: "edit-input",
	UNSUPPORTED_VERSION: "export",
	UNSUPPORTED_PROVIDER: "change-provider",
	WRONG_CHAIN: "reconnect",
	UNAUTHORIZED: "reconnect",
	USER_REJECTED: "none",
	LOCKED: "unlock",
	CONFLICT: "reload",
	UNAVAILABLE: "change-provider",
	TIMEOUT: "change-provider",
	CANCELLED: "none",
	LIMIT_EXCEEDED: "none",
	INTEGRITY_FAILURE: "change-provider",
	BROADCAST_UNKNOWN: "reconcile",
	EXPIRED: "edit-input"
});
let diagnosticSequence = 0n;
/** Diagnostic correlation only: never a key, nonce, capability, intent or authorization identifier. */
function createOperationId() {
	const bytes = /* @__PURE__ */ new Uint8Array(16);
	try {
		crypto.getRandomValues(bytes);
		return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
	} catch {
		diagnosticSequence = diagnosticSequence + 1n & (1n << 64n) - 1n;
		return `0000000000000000${diagnosticSequence.toString(16).padStart(16, "0")}`;
	} finally {
		bytes.fill(0);
	}
}
function createCoreError(code, context) {
	const validCode = typeof code === "string" && Object.hasOwn(ACTIONS, code) ? code : "INVALID_INPUT";
	const correlationId = typeof context.operationId === "string" && /^[0-9a-f]{32}$/.test(context.operationId) ? context.operationId : createOperationId();
	return Object.freeze({
		code: validCode,
		retryable: context.readOnly && (validCode === "TIMEOUT" || validCode === "UNAVAILABLE"),
		action: ACTIONS[validCode],
		correlationId,
		messageKey: `core.error.${validCode.toLowerCase()}`
	});
}
function normalizeError(input, context) {
	if (context.phase === "send-started") return createCoreError("BROADCAST_UNKNOWN", {
		operationId: context.operationId,
		readOnly: false
	});
	let code;
	try {
		if (typeof input === "object" && input !== null) {
			const descriptor = Object.getOwnPropertyDescriptor(input, "code");
			if (descriptor && "value" in descriptor) code = descriptor.value;
		}
	} catch {}
	return createCoreError(code === 4001 ? "USER_REJECTED" : typeof code === "string" && Object.hasOwn(ACTIONS, code) ? code : "UNAVAILABLE", {
		operationId: context.operationId,
		readOnly: context.phase === "read"
	});
}
// packages/schemas/src/vault.ts
var ValidationError = class extends Error {
	code;
	constructor(code = "INVALID_INPUT") {
		super("Invalid vault data.");
		this.name = "ValidationError";
		this.code = code;
	}
};
function fail$4(code = "INVALID_INPUT") {
	throw new ValidationError(code);
}
function integer(input, minimum, maximum) {
	if (typeof input !== "number" || !Number.isSafeInteger(input) || input < minimum || input > maximum) fail$4();
	return input;
}
function encodeBase64url(bytes) {
	if (!(bytes instanceof Uint8Array)) fail$4();
	let binary = "";
	for (let offset = 0; offset < bytes.length; offset += 8192) binary += String.fromCharCode(...bytes.subarray(offset, offset + 8192));
	return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}
function decodeBase64url(input, minimum, maximum) {
	integer(minimum, 0, 8388624);
	integer(maximum, minimum, 8388624);
	if (typeof input !== "string") fail$4();
	if (input.length > Math.ceil(maximum * 4 / 3)) fail$4("LIMIT_EXCEEDED");
	if (!/^[A-Za-z0-9_-]*$/.test(input) || input.length % 4 === 1) fail$4();
	let binary;
	try {
		binary = atob(input.replaceAll("-", "+").replaceAll("_", "/"));
	} catch {
		fail$4();
	}
	if (binary.length > maximum) fail$4("LIMIT_EXCEEDED");
	if (binary.length < minimum) fail$4();
	const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
	if (encodeBase64url(bytes) !== input) fail$4();
	return bytes;
}
new TextEncoder();
new TextDecoder("utf-8", { fatal: true });
// packages/schemas/src/core.ts
var CoreSchemaError = class extends Error {
	code;
	constructor(code = "INVALID_INPUT") {
		super("Invalid core data.");
		this.name = "CoreSchemaError";
		this.code = code;
	}
};
function fail$3(code = "INVALID_INPUT") {
	throw new CoreSchemaError(code);
}
function reflect(read) {
	try {
		return read();
	} catch {
		return fail$3();
	}
}
function exact(input, keys) {
	if (typeof input !== "object" || input === null || reflect(() => Array.isArray(input))) fail$3();
	const prototype = reflect(() => Object.getPrototypeOf(input));
	if (prototype !== Object.prototype && prototype !== null) fail$3();
	const actual = reflect(() => Reflect.ownKeys(input));
	if (actual.length !== keys.length || actual.some((key) => typeof key !== "string" || !keys.includes(key))) fail$3();
	const out = Object.create(null);
	for (const key of keys) {
		const descriptor = reflect(() => Object.getOwnPropertyDescriptor(input, key));
		if (!descriptor || !("value" in descriptor)) fail$3();
		out[key] = descriptor.value;
	}
	return out;
}
function text(input, max = 256) {
	if (typeof input !== "string") fail$3();
	if (input.length > max) fail$3("LIMIT_EXCEEDED");
	if (input.length === 0 || !/^[A-Za-z0-9._:~-]+$/.test(input)) fail$3();
	return input;
}
function choice$1(input, values) {
	if (typeof input !== "string" || !values.includes(input)) fail$3();
	return input;
}
function parseTradeBinding(input) {
	const raw = exact(input, [
		"chain",
		"networkId",
		"deploymentId",
		"tradeId"
	]);
	return Object.freeze({
		chain: choice$1(raw.chain, ["evm", "solana"]),
		networkId: text(raw.networkId),
		deploymentId: text(raw.deploymentId),
		tradeId: text(raw.tradeId)
	});
}
// packages/schemas/src/intent.ts
var IntentSchemaError = class extends Error {
	code;
	constructor(code = "INVALID_INPUT") {
		super("Invalid private intent data.");
		this.name = "IntentSchemaError";
		this.code = code;
	}
};
function fail$2(code) {
	throw new IntentSchemaError(code);
}
function parseIntentId(value) {
	let bytes;
	try {
		bytes = decodeBase64url(value, 32, 32);
		return value;
	} catch {
		return fail$2();
	} finally {
		bytes?.fill(0);
	}
}
Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint8Array.prototype), "byteLength").get;
Object.freeze([
	"prepared",
	"signed",
	"sendMarked",
	"sent",
	"unknown",
	"finalized",
	"failed",
	"dropped",
	"cancelled"
]);
Object.freeze([
	"prepared",
	"broadcast-unknown",
	"pending",
	"confirmed",
	"finalized",
	"failed",
	"reorged",
	"expired",
	"replaced"
]);
Number.MAX_SAFE_INTEGER - 1;
Object.freeze([
	"rpc",
	"relay",
	"map",
	"proof",
	"update",
	"wallet"
]);
Number.MAX_SAFE_INTEGER - 1;
Object.freeze([
	"rpc",
	"relay",
	"map",
	"proof",
	"update"
]);
Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint8Array.prototype), "byteLength").get;
Uint8Array.prototype.set;
// packages/domain/src/trade-terms.ts
const SOLANA_PREFIX = "p2p-offramp/solana/basic/v1";
const U64 = (1n << 64n) - 1n;
var TermsError = class extends Error {
	code;
	constructor(code = "INVALID_INPUT") {
		super("Invalid trade terms.");
		this.name = "TermsError";
		this.code = code;
	}
};
const fail$1 = (code) => {
	throw new TermsError(code);
};
/** Snapshot an exact JSON-shaped record using data descriptors only; untrusted accessors are never invoked. */
function exactDataObject(input, fields) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail$1();
		const prototype = Object.getPrototypeOf(input);
		if (prototype !== Object.prototype && prototype !== null) return fail$1();
		const ownKeys = Reflect.ownKeys(input);
		if (ownKeys.length !== fields.length || ownKeys.some((key) => typeof key !== "string" || !fields.includes(key))) return fail$1();
		const copy = Object.create(null);
		for (const field of fields) {
			const descriptor = Object.getOwnPropertyDescriptor(input, field);
			if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) return fail$1();
			Object.defineProperty(copy, field, {
				value: descriptor.value,
				enumerable: true
			});
		}
		return Object.freeze(copy);
	} catch {
		return fail$1();
	}
}
function hex32(input) {
	if (typeof input !== "string" || !/^[0-9a-f]{64}$/.test(input)) return fail$1();
	return Uint8Array.from(input.match(/../g), (pair) => parseInt(pair, 16));
}
/** Canonical unsigned decimal string (no sign, no leading zeros, no exponent/float) bounded by `max`. */
function unsigned(input, max, minimum = 0n) {
	if (typeof input !== "string" || !/^(0|[1-9][0-9]{0,39})$/.test(input)) return fail$1();
	const value = BigInt(input);
	if (value < minimum || value > max) return fail$1();
	return value;
}
const utf8 = new TextEncoder();
function beFixed(value, bytes) {
	const out = new Uint8Array(bytes);
	for (let index = bytes - 1, rest = value; index >= 0; index--, rest >>= 8n) out[index] = Number(rest & 255n);
	return out;
}
function leU64(value) {
	return beFixed(value, 8).reverse();
}
function concat(parts) {
	const out = new Uint8Array(parts.reduce((sum, part) => sum + part.byteLength, 0));
	let offset = 0;
	for (const part of parts) {
		out.set(part, offset);
		offset += part.byteLength;
	}
	return out;
}
function prefix(label) {
	return concat([utf8.encode(label), new Uint8Array([0])]);
}
const BASE58$1 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function solanaKey(input) {
	if (typeof input !== "string" || input.length < 32 || input.length > 44) return fail$1();
	let value = 0n;
	for (const character of input) {
		const digit = BASE58$1.indexOf(character);
		if (digit < 0) return fail$1();
		value = value * 58n + BigInt(digit);
	}
	const leading = input.length - input.replace(/^1+/, "").length;
	const body = value === 0n ? /* @__PURE__ */ new Uint8Array(0) : beFixed(value, value.toString(16).length + 1 >> 1);
	if (leading + body.byteLength !== 32) return fail$1();
	return concat([new Uint8Array(leading), body]);
}
/** G16 Solana raw canonical terms message (signed directly by both Ed25519 keys; termsHash = SHA-256 of it). */
function encodeSolanaTerms(input) {
	const terms = exactDataObject(input, [
		"acceptBeforeSeconds",
		"amountBaseUnits",
		"assetKind",
		"buyer",
		"capabilitiesHash",
		"escrowExpirySeconds",
		"genesisHash",
		"mint",
		"orderId",
		"privateAgreementHash",
		"programId",
		"revision",
		"seller",
		"sellerNonce",
		"tokenProgram"
	]);
	const seller = solanaKey(terms.seller), buyer = solanaKey(terms.buyer);
	if (terms.seller === terms.buyer) return fail$1();
	let mint, tokenProgram, kind;
	if (terms.assetKind === "native") {
		if (terms.mint !== null || terms.tokenProgram !== null) return fail$1();
		mint = /* @__PURE__ */ new Uint8Array(32);
		tokenProgram = /* @__PURE__ */ new Uint8Array(32);
		kind = 0;
	} else if (terms.assetKind === "spl") {
		mint = solanaKey(terms.mint);
		tokenProgram = solanaKey(terms.tokenProgram);
		kind = 2;
	} else return fail$1();
	const accept = unsigned(terms.acceptBeforeSeconds, U64), expiry = unsigned(terms.escrowExpirySeconds, U64);
	return concat([
		prefix(SOLANA_PREFIX),
		solanaKey(terms.genesisHash),
		solanaKey(terms.programId),
		hex32(terms.orderId),
		seller,
		buyer,
		mint,
		tokenProgram,
		hex32(terms.privateAgreementHash),
		hex32(terms.capabilitiesHash),
		hex32(terms.sellerNonce),
		new Uint8Array([1]),
		leU64(unsigned(terms.revision, U64, 1n)),
		new Uint8Array([kind]),
		leU64(unsigned(terms.amountBaseUnits, U64, 1n)),
		leU64(accept),
		leU64(expiry),
		new Uint8Array([0])
	]);
}
/**
* G16 funding-window rule evaluated against an observed chain time: chainTime < acceptBefore and
* 1800 <= expiry - chainTime <= 604800. A funded trade ignores later acceptance expiry; that is the caller's state.
*/
function checkFundingWindow(acceptBeforeSeconds, escrowExpirySeconds, chainTimeSeconds) {
	const accept = unsigned(acceptBeforeSeconds, U64), expiry = unsigned(escrowExpirySeconds, U64), now = unsigned(chainTimeSeconds, U64);
	if (now >= accept) fail$1("EXPIRED");
	if (expiry < now + BigInt(1800) || expiry - now > BigInt(604800)) fail$1();
}
Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint8Array.prototype), "byteLength").get;
Uint8Array.prototype.set;
`${"0".repeat(40)}`;
Object.freeze([]);
`${"0".repeat(40)}`;
Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint8Array.prototype), "byteLength").get;
// packages/chain-solana/src/codec.ts
/** Internal fixed-code failure. Its message never carries input or provider detail. */
var SolanaFailure = class extends Error {
	code;
	constructor(code) {
		super("Solana read failed.");
		this.name = "SolanaFailure";
		this.code = code;
	}
};
const fail = (code = "INTEGRITY_FAILURE") => {
	throw new SolanaFailure(code);
};
/** Maps any thrown value to a fixed code; only our own failures keep their code. */
function failureCode(error, fallback) {
	try {
		return error instanceof SolanaFailure ? error.code : fallback;
	} catch {
		return fallback;
	}
}
const BASE58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const BASE64$1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const U64_MAX = (1n << 64n) - 1n;
function encodeBase58(bytes) {
	let value = 0n;
	for (const byte of bytes) value = value << 8n | BigInt(byte);
	let out = "";
	while (value > 0n) {
		out = BASE58[Number(value % 58n)] + out;
		value /= 58n;
	}
	let zeros = 0;
	while (zeros < bytes.length && bytes[zeros] === 0) zeros++;
	return "1".repeat(zeros) + out;
}
/** Canonical 32-byte base58 key: 32..44 alphabet characters that re-encode to the same string. */
function decodeKey(input, code = "INTEGRITY_FAILURE") {
	if (typeof input !== "string" || input.length < 32 || input.length > 44) return fail(code);
	let value = 0n;
	for (const character of input) {
		const digit = BASE58.indexOf(character);
		if (digit < 0) return fail(code);
		value = value * 58n + BigInt(digit);
	}
	const leading = input.length - input.replace(/^1+/, "").length;
	const body = [];
	for (let rest = value; rest > 0n; rest >>= 8n) body.unshift(Number(rest & 255n));
	if (leading + body.length !== 32) return fail(code);
	const out = /* @__PURE__ */ new Uint8Array(32);
	out.set(body, leading);
	if (encodeBase58(out) !== input) return fail(code);
	return out;
}
/** Returns the input when it is a canonical key; used to validate without keeping bytes. */
function canonicalKey(input, code = "INTEGRITY_FAILURE") {
	decodeKey(input, code);
	return input;
}
/** Strict RFC 4648 standard base64 with mandatory padding and zero pad bits. `maxChars` is checked first. */
function decodeBase64(input, maxChars) {
	if (typeof input !== "string" || input.length > maxChars || input.length % 4 !== 0) return fail();
	if (!/^[A-Za-z0-9+/]*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(input)) return fail();
	const padding = input.endsWith("==") ? 2 : input.endsWith("=") ? 1 : 0;
	const out = new Uint8Array(input.length / 4 * 3 - padding);
	let bits = 0, buffer = 0, index = 0;
	for (const character of input) {
		if (character === "=") break;
		buffer = buffer << 6 | BASE64$1.indexOf(character);
		bits += 6;
		if (bits >= 8) {
			bits -= 8;
			out[index++] = buffer >> bits & 255;
		}
	}
	if ((buffer & (1 << bits) - 1) !== 0) return fail();
	return out;
}
function hex$1(bytes) {
	return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}
/** Lowercase 64-hex digest to 32 bytes. */
function fromHex32(input, code = "INVALID_INPUT") {
	if (typeof input !== "string" || !/^[0-9a-f]{64}$/.test(input)) return fail(code);
	return Uint8Array.from(input.match(/../g), (pair) => parseInt(pair, 16));
}
function readUintLE(bytes, offset, width) {
	if (offset < 0 || offset + width > bytes.length) return fail();
	let value = 0n;
	for (let index = width - 1; index >= 0; index--) value = value << 8n | BigInt(bytes[offset + index]);
	return value;
}
const readU64 = (bytes, offset) => readUintLE(bytes, offset, 8);
const readU32 = (bytes, offset) => Number(readUintLE(bytes, offset, 4));
/** Two's-complement i64. */
function readI64(bytes, offset) {
	const raw = readU64(bytes, offset);
	return raw >= 1n << 63n ? raw - (1n << 64n) : raw;
}
function u64LE(value) {
	if (value < 0n || value > U64_MAX) return fail("INVALID_INPUT");
	const out = /* @__PURE__ */ new Uint8Array(8);
	for (let index = 0, rest = value; index < 8; index++, rest >>= 8n) out[index] = Number(rest & 255n);
	return out;
}
function concatBytes(parts) {
	const out = new Uint8Array(parts.reduce((sum, part) => sum + part.length, 0));
	let offset = 0;
	for (const part of parts) {
		out.set(part, offset);
		offset += part.length;
	}
	return out;
}
function equalBytes(a, b) {
	return a.length === b.length && a.every((byte, index) => byte === b[index]);
}
/** Canonical u64 decimal string: at most 20 digits, no sign or leading zero, below 2^64. */
function decimalU64(input, code = "INVALID_INPUT") {
	if (typeof input !== "string" || !/^(?:0|[1-9][0-9]{0,19})$/.test(input)) return fail(code);
	const value = BigInt(input);
	if (value > U64_MAX) return fail(code);
	return value;
}
// packages/chain-solana/src/address.ts
/** Solana program IDs, the ed25519 on-curve test and PDA/ATA derivation. Pure: no RPC, no key material. */
const SYSTEM_PROGRAM_ID = "11111111111111111111111111111111";
/** Address of the original SPL Token program (a public program ID, not a credential). */
const SPL_PROGRAM_ID = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
const ATA_PROGRAM_ID = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL";
const LOADER_V3_ID = "BPFLoaderUpgradeab1e11111111111111111111111";
const SYSVAR_OWNER_ID = "Sysvar1111111111111111111111111111111111111";
const CLOCK_SYSVAR_ID = "SysvarC1ock11111111111111111111111111111111";
const RENT_SYSVAR_ID = "SysvarRent111111111111111111111111111111111";
/** Wrapped-SOL mints of SPL Token and Token-2022; the program refuses both (network.rs). */
const WRAPPED_SOL_MINTS = Object.freeze(["So11111111111111111111111111111111111111112", "9pan9bMn5HatX4EJdBwg9VgCa7Uz5HL8N1m5D3NdXejP"]);
const ESCROW_SEED = new TextEncoder().encode("p2p-offramp-escrow-v1");
const VAULT_SEED = new TextEncoder().encode("p2p-offramp-vault-v1");
const PDA_MARKER = new TextEncoder().encode("ProgramDerivedAddress");
const MAX_SEEDS = 15;
const MAX_SEED_BYTES = 32;
const P = (1n << 255n) - 19n;
function modPow(base, exponent) {
	let result = 1n, factor = base % P;
	for (let rest = exponent; rest > 0n; rest >>= 1n) {
		if (rest & 1n) result = result * factor % P;
		factor = factor * factor % P;
	}
	return result;
}
const D = (P - 121665n) * modPow(121666n, P - 2n) % P;
/**
* Matches curve25519-dalek `CompressedEdwardsY::decompress().is_some()`: the sign bit is dropped, y is
* reduced mod p (non-canonical y is accepted), and the point exists iff (y²-1)/(d·y²+1) is a square or 0.
* v = d·y²+1 is never 0 because d is a non-square, so Euler's criterion on u·v decides it.
*/
function isOnCurve(bytes32) {
	if (bytes32.length !== 32) return fail("INVALID_INPUT");
	let y = 0n;
	for (let index = 31; index >= 0; index--) y = y << 8n | BigInt(bytes32[index]);
	y = (y & (1n << 255n) - 1n) % P;
	const y2 = y * y % P;
	const legendre = modPow((y2 - 1n + P) % P * ((D * y2 + 1n) % P) % P, (P - 1n) / 2n);
	return legendre === 0n || legendre === 1n;
}
/** First off-curve sha256(seeds ‖ [bump] ‖ programId ‖ marker), bump counting down from 255. */
function findProgramAddress(seeds, programId) {
	if (seeds.length > MAX_SEEDS || seeds.some((seed) => seed.length > MAX_SEED_BYTES) || programId.length !== 32) return fail("INVALID_INPUT");
	for (let bump = 255; bump >= 0; bump--) {
		const candidate = sha256(concatBytes([
			...seeds,
			Uint8Array.of(bump),
			programId,
			PDA_MARKER
		]));
		if (!isOnCurve(candidate)) return Object.freeze({
			address: encodeBase58(candidate),
			bump
		});
	}
	return fail("INVALID_INPUT");
}
const key = (value) => decodeKey(value, "INVALID_INPUT");
function escrowAddress(programId, seller, sellerNonceHex) {
	return findProgramAddress([
		ESCROW_SEED,
		key(seller),
		fromHex32(sellerNonceHex)
	], key(programId));
}
function vaultAddress(programId, escrow) {
	return findProgramAddress([VAULT_SEED, key(escrow)], key(programId));
}
/** Canonical ATA for the original SPL Token program only. */
function associatedTokenAddress(owner, mint) {
	return findProgramAddress([
		key(owner),
		key(SPL_PROGRAM_ID),
		key(mint)
	], key(ATA_PROGRAM_ID));
}
/** Loader-v3 ProgramData account: PDA of [programId] under the upgradeable loader. */
function programDataAddress(programId) {
	return findProgramAddress([key(programId)], key(LOADER_V3_ID));
}
// packages/chain-solana/src/bind.ts
/** Binds a G08 trade binding and G16 Solana terms to one registry deployment. Pure: no RPC. */
const TERMS_KEYS = Object.freeze([
	"acceptBeforeSeconds",
	"amountBaseUnits",
	"assetKind",
	"buyer",
	"capabilitiesHash",
	"escrowExpirySeconds",
	"genesisHash",
	"mint",
	"orderId",
	"privateAgreementHash",
	"programId",
	"revision",
	"seller",
	"sellerNonce",
	"tokenProgram"
]);
const MAX_SAFE_LAMPORTS = BigInt(Number.MAX_SAFE_INTEGER);
/** Only objects produced here carry the brand; builders refuse structurally identical copies. */
const BOUND = /* @__PURE__ */ new WeakSet();
const isBoundSolanaTrade = (value) => typeof value === "object" && value !== null && BOUND.has(value);
function deepFreeze(value) {
	if (typeof value !== "object" || value === null || value instanceof Uint8Array) return value;
	if (Object.isFrozen(value)) return value;
	for (const key of Reflect.ownKeys(value)) deepFreeze(value[key]);
	return Object.freeze(value);
}
/**
* Exactly the 15 G16 fields as own enumerable data properties, copied into a frozen null-prototype object.
* Accessors are never invoked. structuredClone runs only after every value is known to be a primitive data
* property, so it reads nothing new; it refuses Proxy objects without calling any trap.
*/
function snapshotTerms(input) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail("INVALID_INPUT");
		const prototype = Object.getPrototypeOf(input);
		if (prototype !== Object.prototype && prototype !== null) return fail("INVALID_INPUT");
		const keys = Reflect.ownKeys(input);
		if (keys.length !== TERMS_KEYS.length || keys.some((key) => typeof key !== "string" || !TERMS_KEYS.includes(key))) return fail("INVALID_INPUT");
		const copy = Object.create(null);
		for (const key of TERMS_KEYS) {
			const field = Object.getOwnPropertyDescriptor(input, key);
			if (!field || !field.enumerable || !("value" in field)) return fail("INVALID_INPUT");
			if (typeof field.value !== "string" && field.value !== null) return fail("INVALID_INPUT");
			Object.defineProperty(copy, key, {
				value: field.value,
				enumerable: true
			});
		}
		structuredClone(input);
		return Object.freeze(copy);
	} catch {
		return fail("INVALID_INPUT");
	}
}
/** G08 binding for Solana: lowercase 64-hex trade id and a network id without ':'. */
function parseSolanaBinding(input) {
	let binding;
	try {
		binding = parseTradeBinding(input);
	} catch {
		return fail("INVALID_INPUT");
	}
	if (binding.chain !== "solana" || !/^[0-9a-f]{64}$/.test(binding.tradeId) || binding.networkId.includes(":")) return fail("INVALID_INPUT");
	return binding;
}
function finalizedCommitment(network) {
	const finality = network.finality;
	return Object.keys(finality).length === 2 && finality.kind === "solana-commitment" && finality.commitment === "finalized";
}
/** Registry policy only (UNSUPPORTED_PROVIDER): finalized Solana network with an immutable v1 program. */
function resolveDeployment(registry, networkId, deploymentId) {
	try {
		if (networkId.includes(":")) return fail("INVALID_INPUT");
		const network = registry.network(networkId), deployment = registry.deployment(networkId, deploymentId);
		if (!network || !deployment || network.chain !== "solana" || !finalizedCommitment(network)) return fail("UNSUPPORTED_PROVIDER");
		const runtime = deployment.runtime;
		if (deployment.protocolVersion !== 1 || runtime.kind !== "solana-program" || runtime.upgradeAuthority !== null || !/^[0-9a-f]{64}$/.test(runtime.programDataSha256)) return fail("UNSUPPORTED_PROVIDER");
		canonicalKey(network.genesisHash, "UNSUPPORTED_PROVIDER");
		const programData = programDataAddress(canonicalKey(deployment.address, "UNSUPPORTED_PROVIDER"));
		return Object.freeze({
			network,
			deployment,
			programDataAddress: programData.address
		});
	} catch (error) {
		return fail(failureCode(error, "UNSUPPORTED_PROVIDER"));
	}
}
/** Native uses the native asset; SPL needs Tokenkeg, a non-wrapped mint and an exact `spl` asset entry. */
function selectAsset(network, deployment, terms) {
	let asset;
	if (terms.assetKind === "native") asset = network.assets.find((entry) => entry.kind === "native");
	else {
		if (terms.tokenProgram !== "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" || terms.mint === null || WRAPPED_SOL_MINTS.includes(terms.mint)) return fail("UNSUPPORTED_PROVIDER");
		asset = network.assets.find((entry) => entry.kind === "spl" && entry.address === terms.mint);
	}
	if (!asset || !deployment.supportedAssetIds.includes(asset.id)) return fail("UNSUPPORTED_PROVIDER");
	return asset;
}
/** Throwing core shared with the reader; codes follow the spec's pre-RPC order. */
function bindTrade(registry, input, rawTerms) {
	const binding = parseSolanaBinding(input);
	const terms = snapshotTerms(rawTerms);
	let termsHash;
	try {
		termsHash = hex$1(sha256(encodeSolanaTerms(terms)));
	} catch {
		return fail("INVALID_INPUT");
	}
	if (termsHash !== binding.tradeId) return fail("INVALID_INPUT");
	const { network, deployment, programDataAddress: programData } = resolveDeployment(registry, binding.networkId, binding.deploymentId);
	if (terms.genesisHash !== network.genesisHash || terms.programId !== deployment.address) return fail("WRONG_CHAIN");
	const asset = selectAsset(network, deployment, terms);
	const escrow = escrowAddress(deployment.address, terms.seller, terms.sellerNonce);
	const vault = terms.assetKind === "spl" ? vaultAddress(deployment.address, escrow.address) : null;
	if (terms.buyer === "11111111111111111111111111111111" || terms.buyer === escrow.address || terms.buyer === vault?.address) return fail("INVALID_INPUT");
	if (terms.assetKind === "native" && BigInt(terms.amountBaseUnits) > MAX_SAFE_LAMPORTS) return fail("LIMIT_EXCEEDED");
	const bound = deepFreeze({
		binding,
		terms,
		termsHash,
		network,
		deployment,
		asset,
		programDataAddress: programData,
		escrow,
		vault
	});
	BOUND.add(bound);
	return bound;
}
function bindSolanaTrade(registry, binding, terms) {
	try {
		return {
			ok: true,
			value: bindTrade(registry, binding, terms)
		};
	} catch (error) {
		return {
			ok: false,
			error: createCoreError(failureCode(error, "INVALID_INPUT"), {
				operationId: createOperationId(),
				readOnly: true
			})
		};
	}
}
// packages/chain-solana/src/message.ts
/**
* Legacy Solana messages and wire transactions: compile, serialize and strictly parse. Pure: no RPC, no keys.
*
* Wire format, from the Solana docs "Transaction Structure" (solana-foundation/solana-com@14537348,
* apps/docs/content/docs/en/core/transactions/transaction-structure.mdx) and solana-sdk@129a6da7
* (message/src/legacy.rs, message/src/compiled_keys.rs, message/src/compiled_instruction.rs, short-vec/src/lib.rs):
*
*   message     = num_required_signatures u8 ‖ num_readonly_signed u8 ‖ num_readonly_unsigned u8
*                 ‖ compact-u16 n ‖ n × 32-byte account keys ‖ recent_blockhash (32 bytes)
*                 ‖ compact-u16 m ‖ m × (program_id_index u8 ‖ compact-u16 k ‖ k × u8 ‖ compact-u16 d ‖ d bytes)
*   transaction = compact-u16 s ‖ s × 64-byte Ed25519 signatures ‖ message, at most 1232 bytes (PACKET_DATA_SIZE)
*
* Account keys are ordered writable signers, readonly signers, writable non-signers, readonly non-signers, with the
* fee payer first. Flags of a key used twice are OR-ed. Inside each group the keys follow CompiledKeys (a BTreeMap,
* so ascending key bytes), which makes the bytes equal `solana_message::legacy::Message::new(ixs, Some(payer))`.
* The parser applies the legacy `Message::sanitize` rules (signing and readonly-unsigned areas do not overlap, at
* least one writable signer, every index in range, program index never 0) and also refuses duplicate keys,
* non-canonical compact-u16, a versioned prefix and trailing bytes.
*/
/** PACKET_DATA_SIZE: the whole serialized transaction, signatures included. */
const MAX_TRANSACTION_BYTES = 1232;
const MAX_KEYS = 255;
/** compact-u16 (ShortU16): 7 bits per byte, low bits first, continuation bit 0x80, at most 3 bytes. */
function encodeCompactU16(value) {
	if (!Number.isSafeInteger(value) || value < 0 || value > 65535) return fail("INVALID_INPUT");
	const out = [];
	for (let rest = value;; rest >>= 7) {
		if (rest < 128) {
			out.push(rest);
			return Uint8Array.from(out);
		}
		out.push(rest & 127 | 128);
	}
}
/** Canonical decode: no zero continuation byte (alias), no fourth byte, no overflow above 0xffff. */
function decodeCompactU16(bytes, offset) {
	let value = 0;
	for (let index = 0; index < 3; index++) {
		const byte = bytes[offset + index];
		if (byte === void 0) return fail();
		if (byte === 0 && index > 0) return fail();
		value |= (byte & 127) << 7 * index;
		if ((byte & 128) === 0) {
			if (value > 65535) return fail();
			return {
				value,
				next: offset + index + 1
			};
		}
		if (index === 2) return fail();
	}
	return fail();
}
const groupOf = (flags) => (flags.signer ? 0 : 2) + (flags.writable ? 0 : 1);
function compareKeys(a, b) {
	const left = decodeKey(a, "INVALID_INPUT"), right = decodeKey(b, "INVALID_INPUT");
	for (let index = 0; index < 32; index++) if (left[index] !== right[index]) return left[index] - right[index];
	return 0;
}
/** Ordered keys and header for one fee payer and instruction list (CompiledKeys::compile semantics). */
function compileKeys(feePayer, instructions) {
	const flags = /* @__PURE__ */ new Map();
	const add = (key, signer, writable) => {
		decodeKey(key, "INVALID_INPUT");
		const entry = flags.get(key) ?? {
			signer: false,
			writable: false
		};
		flags.set(key, {
			signer: entry.signer || signer,
			writable: entry.writable || writable
		});
	};
	for (const instruction of instructions) {
		add(instruction.programId, false, false);
		for (const account of instruction.accounts) add(account.pubkey, account.isSigner, account.isWritable);
	}
	add(feePayer, true, true);
	const ordered = [feePayer, ...[...flags.entries()].filter(([key]) => key !== feePayer).sort(([a, x], [b, y]) => groupOf(x) - groupOf(y) || compareKeys(a, b)).map(([key]) => key)];
	if (ordered.length > MAX_KEYS) return fail("LIMIT_EXCEEDED");
	const counts = [
		0,
		0,
		0,
		0
	];
	for (const key of ordered) counts[groupOf(flags.get(key))]++;
	return {
		ordered,
		header: Object.freeze({
			numRequiredSignatures: counts[0] + counts[1],
			numReadonlySigned: counts[1],
			numReadonlyUnsigned: counts[3]
		})
	};
}
/** Serializes a legacy message. Throws a fixed-code SolanaFailure on any invalid input. */
function compileLegacyMessage(feePayer, instructions, recentBlockhash) {
	if (instructions.length < 1 || instructions.length > 64) return fail("INVALID_INPUT");
	const { ordered, header } = compileKeys(feePayer, instructions);
	const index = new Map(ordered.map((key, position) => [key, position]));
	const compiled = instructions.map((instruction) => concatBytes([
		Uint8Array.of(index.get(instruction.programId)),
		encodeCompactU16(instruction.accounts.length),
		Uint8Array.from(instruction.accounts, (meta) => index.get(meta.pubkey)),
		encodeCompactU16(instruction.data.length),
		instruction.data
	]));
	const message = concatBytes([
		Uint8Array.of(header.numRequiredSignatures, header.numReadonlySigned, header.numReadonlyUnsigned),
		encodeCompactU16(ordered.length),
		...ordered.map((key) => decodeKey(key, "INVALID_INPUT")),
		decodeKey(recentBlockhash, "INVALID_INPUT"),
		encodeCompactU16(instructions.length),
		...compiled
	]);
	if (transactionLength(header.numRequiredSignatures, message.length) > 1232) return fail("LIMIT_EXCEEDED");
	return message;
}
const transactionLength = (signatures, messageLength) => encodeCompactU16(signatures).length + signatures * 64 + messageLength;
/** Strict legacy parse; see the module comment for the refused forms. */
function parseLegacyMessage(bytes) {
	if (!(bytes instanceof Uint8Array) || bytes.length < 3 || bytes.length > 1232) return fail();
	if ((bytes[0] & 128) !== 0) return fail();
	const header = Object.freeze({
		numRequiredSignatures: bytes[0],
		numReadonlySigned: bytes[1],
		numReadonlyUnsigned: bytes[2]
	});
	const keyCount = decodeCompactU16(bytes, 3);
	let offset = keyCount.next;
	const keys = [];
	for (let index = 0; index < keyCount.value; index++, offset += 32) {
		if (offset + 32 > bytes.length) return fail();
		keys.push(encodeBase58(bytes.subarray(offset, offset + 32)));
	}
	if (offset + 32 > bytes.length) return fail();
	const recentBlockhash = encodeBase58(bytes.subarray(offset, offset + 32));
	offset += 32;
	const count = decodeCompactU16(bytes, offset);
	offset = count.next;
	const instructions = [];
	for (let index = 0; index < count.value; index++) {
		const programIdIndex = bytes[offset];
		if (programIdIndex === void 0) return fail();
		const accountCount = decodeCompactU16(bytes, offset + 1);
		offset = accountCount.next;
		if (offset + accountCount.value > bytes.length) return fail();
		const accounts = Array.from(bytes.subarray(offset, offset + accountCount.value));
		offset += accountCount.value;
		const dataLength = decodeCompactU16(bytes, offset);
		offset = dataLength.next;
		if (offset + dataLength.value > bytes.length) return fail();
		instructions.push(Object.freeze({
			programIdIndex,
			accounts: Object.freeze(accounts),
			data: bytes.slice(offset, offset + dataLength.value)
		}));
		offset += dataLength.value;
	}
	if (offset !== bytes.length) return fail();
	sanitize(header, keys, instructions);
	return Object.freeze({
		header,
		accountKeys: Object.freeze(keys),
		recentBlockhash,
		instructions: Object.freeze(instructions)
	});
}
function sanitize(header, keys, instructions) {
	const { numRequiredSignatures: signers, numReadonlySigned: readonlySigned } = header;
	if (signers + header.numReadonlyUnsigned > keys.length || readonlySigned >= signers) return fail();
	if (new Set(keys).size !== keys.length) return fail();
	for (const instruction of instructions) {
		if (instruction.programIdIndex === 0 || instruction.programIdIndex >= keys.length) return fail();
		if (instruction.accounts.some((index) => index >= keys.length)) return fail();
	}
}
/** Wire transaction with zeroed signature slots, the input the Wallet Standard `signTransaction` expects. */
function unsignedTransaction(message) {
	const signers = parseLegacyMessage(message).header.numRequiredSignatures;
	return concatBytes([
		encodeCompactU16(signers),
		new Uint8Array(signers * 64),
		message
	]);
}
function encodeTransaction(signatures, message) {
	const parsed = parseLegacyMessage(message);
	if (signatures.length !== parsed.header.numRequiredSignatures) return fail("INVALID_INPUT");
	if (signatures.some((signature) => signature.length !== 64)) return fail("INVALID_INPUT");
	return concatBytes([
		encodeCompactU16(signatures.length),
		...signatures,
		message
	]);
}
/** Strict wire decode: signature count equals the header's, the message parses, size at most 1232 bytes. */
function decodeTransaction(wire) {
	if (!(wire instanceof Uint8Array) || wire.length > 1232) return fail();
	const count = decodeCompactU16(wire, 0);
	const start = count.next + count.value * 64;
	if (count.value < 1 || start >= wire.length) return fail();
	const signatures = Array.from({ length: count.value }, (_, index) => wire.slice(count.next + index * 64, count.next + (index + 1) * 64));
	const message = wire.slice(start);
	if (parseLegacyMessage(message).header.numRequiredSignatures !== count.value) return fail();
	return Object.freeze({
		signatures: Object.freeze(signatures),
		message
	});
}
const BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
/** RFC 4648 standard base64 with padding (the inverse of codec.ts `decodeBase64`). */
function encodeBase64(bytes) {
	let out = "";
	for (let index = 0; index < bytes.length; index += 3) {
		const chunk = bytes[index] << 16 | (bytes[index + 1] ?? 0) << 8 | (bytes[index + 2] ?? 0);
		const left = bytes.length - index;
		out += BASE64[chunk >> 18 & 63] + BASE64[chunk >> 12 & 63] + (left > 1 ? BASE64[chunk >> 6 & 63] : "=") + (left > 2 ? BASE64[chunk & 63] : "=");
	}
	return out;
}
// packages/chain-solana/src/auxiliary.ts
/**
* The two non-escrow instructions a payout message may carry. Pure data, frozen like instructions.ts.
*
* - Associated Token Account `CreateIdempotent` (solana-program/associated-token-account@fbf5379e,
*   interface/src/instruction.rs): data `[1]`; accounts funding(w,s), ata(w), wallet, mint, System program, token
*   program. Only the original SPL Token program and the canonical ATA are ever used here.
* - System `Transfer` (solana-sdk@129a6da7, system-interface/src/instruction.rs): bincode u32 LE variant 2 then
*   u64 LE lamports; accounts from(w,s), to(w). Used only to top up a native escrow's rent reserve (D5 "Rent").
*
* Nothing here can build `AdvanceNonceAccount` (variant 4): durable-nonce transactions are refused.
*/
const SYSTEM_TRANSFER = 2;
const meta$1 = (pubkey, isWritable, isSigner = false) => Object.freeze({
	pubkey,
	isSigner,
	isWritable
});
const u32LE = (value) => Uint8Array.of(value & 255, value >> 8 & 255, value >> 16 & 255, value >>> 24);
/** CreateIdempotent for the canonical original-SPL-Token ATA of `owner`; `payer` funds its rent if created. */
function buildCreateAtaIdempotent(payer, owner, mint) {
	const funder = canonicalKey(payer, "INVALID_INPUT"), wallet = canonicalKey(owner, "INVALID_INPUT");
	const tokenMint = canonicalKey(mint, "INVALID_INPUT");
	const ata = associatedTokenAddress(wallet, tokenMint).address;
	return Object.freeze({
		programId: ATA_PROGRAM_ID,
		accounts: Object.freeze([
			meta$1(funder, true, true),
			meta$1(ata, true),
			meta$1(wallet, false),
			meta$1(tokenMint, false),
			meta$1(SYSTEM_PROGRAM_ID, false),
			meta$1(SPL_PROGRAM_ID, false)
		]),
		data: Uint8Array.of(1)
	});
}
/** System transfer of `lamports` (1..u64) from a signer to a different account. */
function buildSystemTransfer(from, to, lamports) {
	const source = canonicalKey(from, "INVALID_INPUT"), target = canonicalKey(to, "INVALID_INPUT");
	if (typeof lamports !== "bigint" || lamports < 1n || source === target) return fail("INVALID_INPUT");
	return Object.freeze({
		programId: SYSTEM_PROGRAM_ID,
		accounts: Object.freeze([meta$1(source, true, true), meta$1(target, true)]),
		data: concatBytes([u32LE(SYSTEM_TRANSFER), u64LE(lamports)])
	});
}
// packages/chain-solana/src/instructions.ts
/**
* Unsigned D5 instruction builders. Pure data: no message, blockhash, fee payer, signature or send. No
* System Program instruction is ever produced, so a durable-nonce advance cannot be smuggled in here.
*/
const DISCRIMINATOR = Object.freeze({
	fundNative: "ecf06fea0be6652b",
	fundSpl: "7eaf579ec83b6a50",
	release: "fdf90fce1c7fc1f1",
	refund: "0260b7fb3fd02e2e",
	payoutNative: "241ed8ee67326263",
	payoutSpl: "890a23c66dc09e25"
});
const discriminator = (value) => Uint8Array.from(value.match(/../g), (pair) => parseInt(pair, 16));
const meta = (pubkey, isWritable, isSigner = false) => Object.freeze({
	pubkey,
	isSigner,
	isWritable
});
function result$1(build) {
	try {
		return {
			ok: true,
			value: build()
		};
	} catch (error) {
		return {
			ok: false,
			error: createCoreError(failureCode(error, "INVALID_INPUT"), {
				operationId: createOperationId(),
				readOnly: true
			})
		};
	}
}
function instruction(trade, accounts, data) {
	const programId = trade.deployment.address;
	return Object.freeze({
		programId,
		accounts: Object.freeze([...accounts]),
		data: Uint8Array.from(data)
	});
}
/** Only branded trades from bindSolanaTrade, of the expected asset kind. */
function branded(trade, kind) {
	if (!isBoundSolanaTrade(trade)) return fail("INVALID_INPUT");
	if (kind !== void 0 && trade.terms.assetKind !== kind) return fail("INVALID_INPUT");
	return trade;
}
/** FundArgs (192 bytes): order_id, buyer, private_agreement_hash, capabilities_hash, seller_nonce, then 4 u64 LE. */
function fundArgs(trade) {
	const terms = trade.terms;
	const u64 = (value) => u64LE(decimalU64(value));
	return concatBytes([
		fromHex32(terms.orderId),
		decodeKey(terms.buyer, "INVALID_INPUT"),
		fromHex32(terms.privateAgreementHash),
		fromHex32(terms.capabilitiesHash),
		fromHex32(terms.sellerNonce),
		u64(terms.revision),
		u64(terms.amountBaseUnits),
		u64(terms.acceptBeforeSeconds),
		u64(terms.escrowExpirySeconds)
	]);
}
function buildFundNative(trade) {
	return result$1(() => {
		const bound = branded(trade, "native");
		return instruction(bound, [
			meta(bound.terms.seller, true, true),
			meta(bound.escrow.address, true),
			meta(bound.terms.buyer, true),
			meta(SYSTEM_PROGRAM_ID, false)
		], concatBytes([discriminator(DISCRIMINATOR.fundNative), fundArgs(bound)]));
	});
}
function buildFundSpl(trade, sellerTokenAccount) {
	return result$1(() => {
		const bound = branded(trade, "spl"), mint = bound.terms.mint, vault = bound.vault.address;
		const source = canonicalKey(sellerTokenAccount, "INVALID_INPUT");
		if (source === bound.escrow.address || source === vault || source === mint) return fail("INVALID_INPUT");
		return instruction(bound, [
			meta(bound.terms.seller, true, true),
			meta(bound.escrow.address, true),
			meta(mint, false),
			meta(source, true),
			meta(vault, true),
			meta(SPL_PROGRAM_ID, false),
			meta(SYSTEM_PROGRAM_ID, false)
		], concatBytes([discriminator(DISCRIMINATOR.fundSpl), fundArgs(bound)]));
	});
}
/** Seller signs read-only; the program requires it to equal the stored seller. */
function buildRelease(trade) {
	return result$1(() => {
		const bound = branded(trade);
		return instruction(bound, [meta(bound.terms.seller, false, true), meta(bound.escrow.address, true)], discriminator(DISCRIMINATOR.release));
	});
}
/** Permissionless after the deadline: only the escrow account. */
function buildRefund(trade) {
	return result$1(() => {
		const bound = branded(trade);
		return instruction(bound, [meta(bound.escrow.address, true)], discriminator(DISCRIMINATOR.refund));
	});
}
/** Recipient follows the terminal state: buyer after release, seller after refund. */
function buildPayout(trade, outcome) {
	return result$1(() => {
		const bound = branded(trade);
		if (outcome !== "released" && outcome !== "refunded") return fail("INVALID_INPUT");
		const recipient = outcome === "released" ? bound.terms.buyer : bound.terms.seller;
		if (bound.terms.assetKind === "native") return instruction(bound, [meta(bound.escrow.address, true), meta(recipient, true)], discriminator(DISCRIMINATOR.payoutNative));
		const mint = bound.terms.mint;
		return instruction(bound, [
			meta(bound.escrow.address, true),
			meta(bound.vault.address, true),
			meta(mint, false),
			meta(associatedTokenAddress(recipient, mint).address, true),
			meta(SPL_PROGRAM_ID, false)
		], discriminator(DISCRIMINATOR.payoutSpl));
	});
}
const ESCROW_DISCRIMINATOR = "1a5ac1dabcfb8bd3";
const STATES$2 = [
	"funded",
	"released",
	"refunded"
];
const ZERO_KEY = /* @__PURE__ */ new Uint8Array(32);
const slice32 = (bytes, offset) => bytes.subarray(offset, offset + 32);
const keyAt$1 = (bytes, offset) => encodeBase58(slice32(bytes, offset));
const exactLength = (bytes, length) => {
	if (bytes.length !== length) fail();
};
/** COption tags are exactly [0,0,0,0] (None) or [1,0,0,0] (Some); the body of None is ignored. */
function optionTag$1(bytes, offset) {
	const tag = readU32(bytes, offset);
	if (tag > 1) return fail();
	return tag === 1;
}
/** ProgramData hash: requires tag 3, option byte 0/1 and a 1..1 MiB region; padding is included. */
function programDataSha256(accountData) {
	const length = accountData.length;
	if (length <= 45 || length > 1048621) return fail();
	if (readU32(accountData, 0) !== 3 || accountData[12] > 1) return fail();
	return hex$1(sha256(accountData.subarray(45)));
}
/** Registry pin from a verifiable build: sha256(elf ‖ zero padding up to the deployed region length). */
function programDataSha256FromElf(elf, programDataLength) {
	if (!Number.isSafeInteger(programDataLength) || elf.length < 1) return fail("INVALID_INPUT");
	const padding = programDataLength - 45 - elf.length;
	if (padding < 0 || programDataLength > 1048621) return fail("INVALID_INPUT");
	return hex$1(sha256.create().update(elf).update(new Uint8Array(padding)).digest());
}
/** Reader view: additionally requires the authority option to be None ([13..45) is never read). */
function decodeProgramData(bytes) {
	const digest = programDataSha256(bytes);
	if (bytes[12] !== 0) return fail();
	return Object.freeze({
		deploySlot: readU64(bytes, 4),
		sha256: digest
	});
}
/** Loader-v3 Program account: tag 2 and the programdata pointer. */
function decodeProgramAccount(bytes) {
	exactLength(bytes, 36);
	if (readU32(bytes, 0) !== 2) return fail();
	return keyAt$1(bytes, 4);
}
function decodeClock(bytes) {
	exactLength(bytes, 40);
	return Object.freeze({
		slot: readU64(bytes, 0),
		unixTimestamp: readI64(bytes, 32)
	});
}
const THRESHOLD_ONE = "000000000000f03f";
const THRESHOLD_TWO = "0000000000000040";
/**
* Rent-exempt minimum of a 222-byte escrow: (128 + 222) * lamportsPerByteYear * threshold. Only the two
* exact f64 thresholds 1.0 and 2.0 are understood (no floats); any other value is unknown (null).
*/
function escrowRentMinimum(bytes) {
	return rentExemptMinimum(bytes, 222);
}
/** The same rule for any account size: (128 + dataLength) * lamportsPerByteYear * threshold, or null. */
function rentExemptMinimum(bytes, dataLength) {
	exactLength(bytes, 17);
	if (!Number.isSafeInteger(dataLength) || dataLength < 0) return fail();
	const lamportsPerByteYear = readU64(bytes, 0), threshold = hex$1(bytes.subarray(8, 16));
	const base = (128n + BigInt(dataLength)) * lamportsPerByteYear;
	if (threshold === THRESHOLD_ONE) return base;
	if (threshold === THRESHOLD_TWO) return 2n * base;
	return null;
}
/** SPL Token account; refuses delegate, close authority, native wrapping and uninitialized state. */
function decodeTokenAccount(bytes) {
	exactLength(bytes, 165);
	const state = bytes[108];
	if (state !== 1 && state !== 2) return fail();
	if (optionTag$1(bytes, 72) || optionTag$1(bytes, 109) || optionTag$1(bytes, 129)) return fail();
	if (readU64(bytes, 121) !== 0n) return fail();
	const amount = readU64(bytes, 64);
	return Object.freeze({
		mint: keyAt$1(bytes, 0),
		owner: keyAt$1(bytes, 32),
		amount,
		frozen: state === 2
	});
}
function decodeMint(bytes) {
	exactLength(bytes, 82);
	optionTag$1(bytes, 0);
	if (bytes[45] !== 1) return fail();
	const freezeAuthority = optionTag$1(bytes, 46) ? keyAt$1(bytes, 50) : null;
	return Object.freeze({
		decimals: bytes[44],
		freezeAuthority
	});
}
/** Structural EscrowV1 decode. Relational checks (PDA bumps, terms) belong to the reader. */
function decodeEscrow(bytes) {
	exactLength(bytes, 222);
	if (hex$1(bytes.subarray(0, 8)) !== ESCROW_DISCRIMINATOR || bytes[8] !== 1) return fail();
	const stateIndex = bytes[11], paid = bytes[12], kind = bytes[13];
	if (stateIndex > 2 || paid > 1 || paid === 1 && stateIndex === 0 || kind !== 0 && kind !== 2) return fail();
	const mint = slice32(bytes, 78), tokenProgram = slice32(bytes, 110), amount = readU64(bytes, 142);
	if (amount < 1n) return fail();
	const zeroAssets = equalBytes(mint, ZERO_KEY) && equalBytes(tokenProgram, ZERO_KEY);
	if (kind === 0 && (!zeroAssets || bytes[10] !== 0)) return fail();
	if (kind === 2 && (keyAt$1(bytes, 110) !== "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" || equalBytes(mint, ZERO_KEY))) return fail();
	return Object.freeze({
		escrowBump: bytes[9],
		vaultBump: bytes[10],
		state: STATES$2[stateIndex],
		paidOut: paid === 1,
		assetKind: kind === 0 ? "native" : "spl",
		seller: keyAt$1(bytes, 14),
		buyer: keyAt$1(bytes, 46),
		mint: kind === 0 ? null : encodeBase58(mint),
		tokenProgram: kind === 0 ? null : SPL_PROGRAM_ID,
		amountBaseUnits: amount.toString(),
		deadlineSeconds: readU64(bytes, 150).toString(),
		termsHash: hex$1(slice32(bytes, 158)),
		sellerNonce: hex$1(slice32(bytes, 190))
	});
}
// packages/chain-solana/src/payout.ts
const STATES$1 = [
	"uninitialized",
	"initialized",
	"frozen"
];
const ABSENT = Object.freeze({ kind: "absent" });
const PREFUNDED = Object.freeze({ kind: "system-prefunded" });
const keyAt = (bytes, offset) => encodeBase58(bytes.subarray(offset, offset + 32));
function optionTag(bytes, offset) {
	const tag = readU32(bytes, offset);
	if (tag > 1) return fail();
	return tag === 1;
}
/** Lenient SPL Token account decode for a destination: delegates, freezes and close authorities are reported. */
function classifyTokenAccount(account) {
	if (account === null) return ABSENT;
	if (account.owner === "11111111111111111111111111111111" && account.dataLength === 0 && !account.executable) return PREFUNDED;
	const bytes = account.data;
	if (account.owner !== "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" || account.executable || account.dataLength !== 165 || bytes === null || bytes.length !== 165) return Object.freeze({
		kind: "foreign",
		programOwner: account.owner
	});
	const state = STATES$1[bytes[108]];
	if (state === void 0) return fail();
	const delegated = optionTag(bytes, 72) || readU64(bytes, 121) !== 0n;
	return Object.freeze({
		kind: "token",
		mint: keyAt(bytes, 0),
		owner: keyAt(bytes, 32),
		amount: readU64(bytes, 64).toString(),
		state,
		delegated,
		native: optionTag(bytes, 109),
		closeAuthority: optionTag(bytes, 129)
	});
}
/** Precedence follows what fails first on chain or matters most to the user; the first match wins. */
function splPlan(recipient, mint, destination, view, custodyBlockedBy, rentLamports) {
	const blocked = (reason) => Object.freeze({
		kind: "blocked",
		destination,
		reason
	});
	if (custodyBlockedBy.includes("vault-frozen")) return blocked("vault-frozen");
	if (view.kind === "absent" || view.kind === "system-prefunded") return Object.freeze({
		kind: "create-ata-idempotent",
		destination,
		owner: recipient,
		mint,
		rentLamports
	});
	if (view.kind === "foreign") return blocked("destination-not-spl-token");
	if (view.state === "uninitialized") return blocked("destination-uninitialized");
	if (view.mint !== mint) return blocked("destination-wrong-mint");
	if (view.owner !== recipient) return blocked("destination-wrong-owner");
	if (view.state === "frozen") return blocked("destination-frozen");
	if (view.native) return blocked("destination-native");
	if (view.delegated) return blocked("destination-delegated");
	return Object.freeze({
		kind: "ready",
		destination
	});
}
/**
* Native payout credits exactly the principal. A recipient left between 0 and its rent-exempt minimum fails the
* transaction (InsufficientFundsForRent), so the plan asks for a top-up in the same payout transaction.
*/
function nativePlan(recipient, principal, wallet, custodyBlockedBy) {
	const blocked = (reason) => Object.freeze({
		kind: "blocked",
		recipient,
		reason
	});
	if (custodyBlockedBy.includes("rent-unknown")) return blocked("rent-unknown");
	if (custodyBlockedBy.includes("rent-shortfall")) return blocked("rent-shortfall");
	if (wallet.executable) return blocked("recipient-executable");
	if (wallet.rentExemptMinimum === null) return blocked("rent-unknown");
	const minimum = BigInt(wallet.rentExemptMinimum), after = BigInt(wallet.lamports) + principal;
	if (after >= minimum) return Object.freeze({
		kind: "ready",
		recipient
	});
	return Object.freeze({
		kind: "rent-top-up",
		recipient,
		lamports: (minimum - after).toString(),
		rentExemptMinimum: minimum.toString()
	});
}
/** Internal entry points for the reader, whose inputs are already validated. */
const payoutPlanners = Object.freeze({
	spl: splPlan,
	native: nativePlan
});
// packages/chain-solana/src/window.ts
/**
* Funding and settlement windows against a finalized chain time (`live.timestampSeconds`). The finalized
* Clock lags the tip, so an open window is necessary but not sufficient. Neither helper reads a wall clock.
*/
const MAX_SUBMIT_MARGIN = 3600n;
const MAX_RELEASE_MARGIN = 604800n;
const invalid$1 = () => ({
	ok: false,
	error: createCoreError("INVALID_INPUT", {
		operationId: createOperationId(),
		readOnly: true
	})
});
function margin(input, maximum) {
	try {
		const value = decimalU64(input);
		return value <= maximum ? value : null;
	} catch {
		return null;
	}
}
function u64(input) {
	try {
		return decimalU64(input);
	} catch {
		return null;
	}
}
/** Program error 6004 (AcceptanceExpired) or 6005 (DeadlineOutOfRange) at one chain time, else open. */
function fundingAt(acceptBefore, expiry, chainTime) {
	if (chainTime > U64_MAX) return "acceptance-expired";
	try {
		checkFundingWindow(acceptBefore, expiry, chainTime.toString());
		return "open";
	} catch (error) {
		return error instanceof TermsError && error.code === "EXPIRED" ? "acceptance-expired" : "deadline-out-of-range";
	}
}
/**
* Open only if funding would pass at both `chainTime` and `chainTime + submitMargin`. The feasible chain times
* form one interval (t < acceptBefore, expiry - 604800 <= t <= expiry - 1800), so the two endpoints suffice.
*/
function fundingWindow(acceptBefore, expiry, chainTime, submitMargin) {
	const now = u64(chainTime), slack = margin(submitMargin, MAX_SUBMIT_MARGIN);
	if (u64(acceptBefore) === null || u64(expiry) === null || now === null || slack === null) return invalid$1();
	const first = fundingAt(acceptBefore, expiry, now);
	return {
		ok: true,
		value: first !== "open" ? first : fundingAt(acceptBefore, expiry, now + slack)
	};
}
/** Program rules: release needs now < deadline (kept `releaseMargin` clear); refund needs now >= deadline. */
function settlementWindow(deadline, chainTime, releaseMargin) {
	const end = u64(deadline), now = u64(chainTime), slack = margin(releaseMargin, MAX_RELEASE_MARGIN);
	if (end === null || now === null || slack === null) return invalid$1();
	return {
		ok: true,
		value: Object.freeze({
			releaseOpen: now + slack < end,
			refundOpen: now >= end
		})
	};
}
const MAX_PERMITS = 64;
const invalid = () => {
	throw new Error("Invalid Solana freeze-authority permits.");
};
function field(entry, name) {
	const descriptor = Object.getOwnPropertyDescriptor(entry, name);
	if (!descriptor || !("value" in descriptor)) return invalid();
	try {
		return canonicalKey(descriptor.value, "INVALID_INPUT");
	} catch {
		return invalid();
	}
}
function copyPermits(input) {
	const permits = /* @__PURE__ */ new Map();
	if (input === void 0) return permits;
	if (!Array.isArray(input) || Object.getPrototypeOf(input) !== Array.prototype) return invalid();
	const lengthField = Object.getOwnPropertyDescriptor(input, "length");
	const length = lengthField && "value" in lengthField ? lengthField.value : void 0;
	if (typeof length !== "number" || length > MAX_PERMITS || Reflect.ownKeys(input).length !== length + 1) return invalid();
	for (let index = 0; index < length; index++) {
		const descriptor = Object.getOwnPropertyDescriptor(input, String(index));
		const entry = descriptor && "value" in descriptor ? descriptor.value : void 0;
		if (typeof entry !== "object" || entry === null || Reflect.ownKeys(entry).length !== 2) return invalid();
		const mint = field(entry, "mint"), freezeAuthority = field(entry, "freezeAuthority");
		if (permits.has(mint)) return invalid();
		permits.set(mint, freezeAuthority);
	}
	return permits;
}
/**
* Validates permits (a dense plain array of at most 64 `{ mint, freezeAuthority }` own data properties with
* canonical keys and unique mints) into a private copy. Accessors are never invoked. Throws a fixed-message
* Error, like the reader's timeout check, so a bad configuration never starts a reader.
*/
function parseFreezeAuthorityPermits(input) {
	try {
		return copyPermits(input);
	} catch {
		return invalid();
	}
}
/**
* Pre-funding admission: no freeze authority is always acceptable (None can never be set again); a mint with one
* is acceptable only when its permit names that exact key, so a rotated freeze authority needs a new owner choice.
*/
function freezeAuthorityPermitted(permits, mint, freezeAuthority) {
	return freezeAuthority === null || permits.get(mint) === freezeAuthority;
}
/** base64 character caps, checked before decoding (ceil(bytes / 3) * 4). */
const CAP = Object.freeze({
	program: 48,
	programData: 1398164,
	clock: 56,
	rent: 24,
	escrow: 296,
	token: 220,
	mint: 112
});
/** MAX_PERMITTED_DATA_LENGTH. A recipient wallet's size comes only via its `space` field; it is never decoded. */
const MAX_ACCOUNT_BYTES = 10485760;
function own$3(input, key) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail();
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field || !("value" in field)) return fail();
		return field.value;
	} catch {
		return fail();
	}
}
function optionalOwn$1(input, key) {
	try {
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field) return void 0;
		if (!("value" in field)) return fail();
		return field.value;
	} catch {
		return fail();
	}
}
/** Dense plain array of at most `maximum` data elements, copied without invoking accessors. */
function ownArray$1(input, maximum) {
	try {
		if (!Array.isArray(input) || Object.getPrototypeOf(input) !== Array.prototype) return fail();
		const lengthField = Object.getOwnPropertyDescriptor(input, "length");
		const length = lengthField && "value" in lengthField ? lengthField.value : void 0;
		if (typeof length !== "number" || !Number.isSafeInteger(length) || length > maximum) return fail();
		if (Reflect.ownKeys(input).length !== length + 1) return fail();
		const copy = [];
		for (let index = 0; index < length; index++) {
			const field = Object.getOwnPropertyDescriptor(input, String(index));
			if (!field || !("value" in field)) return fail();
			copy.push(field.value);
		}
		return copy;
	} catch {
		return fail();
	}
}
function safeInt$1(input, code = "INTEGRITY_FAILURE") {
	if (typeof input !== "number" || !Number.isSafeInteger(input) || input < 0) return fail(code);
	return input;
}
/** `data` must be exactly [string, 'base64'], capped before decoding; `space`, if present, equals the length. */
function readAccount(entry, cap) {
	if (entry === null) return null;
	if (typeof entry !== "object") return fail();
	const owner = canonicalKey(own$3(entry, "owner")), executable = own$3(entry, "executable");
	if (typeof executable !== "boolean") return fail();
	const tuple = ownArray$1(own$3(entry, "data"), 2);
	if (tuple.length !== 2 || tuple[1] !== "base64") return fail();
	const data = decodeBase64(tuple[0], cap);
	const space = optionalOwn$1(entry, "space");
	if (space !== void 0 && space !== data.length) return fail();
	return {
		owner,
		executable,
		data,
		entry
	};
}
function present(entry, cap, owner, executable = false) {
	const account = readAccount(entry, cap);
	if (account === null || account.owner !== owner || account.executable !== executable) return fail();
	return account;
}
/** An uninitialized system account: a pre-init lamport donation leaves exactly this behind. */
const isSystemEmpty = (account) => account.owner === "11111111111111111111111111111111" && account.data.length === 0 && !account.executable;
/** Re-run on every read: nothing about identity is cached that could let a later read skip a check. */
function checkIdentity(ref, accounts, slot) {
	if (decodeProgramAccount(present(accounts[0], CAP.program, LOADER_V3_ID, true).data) !== ref.programDataAddress) return fail();
	const programData = decodeProgramData(present(accounts[1], CAP.programData, LOADER_V3_ID).data);
	const runtime = ref.deployment.runtime;
	if (programData.deploySlot > BigInt(slot) || runtime.kind !== "solana-program") return fail();
	if (programData.sha256 !== runtime.programDataSha256) return fail();
	const clock = decodeClock(present(accounts[2], CAP.clock, SYSVAR_OWNER_ID).data);
	if (clock.slot !== BigInt(slot) || clock.unixTimestamp < 0n) return fail();
	return {
		identity: {
			timestampSeconds: clock.unixTimestamp.toString(),
			programDataSha256: programData.sha256
		},
		deploySlot: programData.deploySlot
	};
}
function block(input, slot) {
	if (input === null) return fail();
	const hash = canonicalKey(own$3(input, "blockhash")), height = safeInt$1(own$3(input, "blockHeight"));
	const parent = safeInt$1(own$3(input, "parentSlot"));
	if (height > slot || !(parent < slot || slot === 0 && parent === 0)) return fail();
	return {
		hash,
		height,
		parent
	};
}
/** Index 3: absent, a pre-init System donation, or a program-owned EscrowV1 bound to these exact terms. */
function classifyEscrow(trade, entry) {
	const account = readAccount(entry, CAP.escrow);
	if (account === null) return {
		occupant: "none",
		escrow: null,
		entry: null
	};
	if (isSystemEmpty(account)) return {
		occupant: "system-prefunded",
		escrow: null,
		entry: null
	};
	if (account.owner !== trade.deployment.address || account.executable) return fail();
	if (account.data.length !== 222) return fail();
	const escrow = decodeEscrow(account.data), terms = trade.terms;
	if (!(escrow.seller === terms.seller && escrow.sellerNonce === terms.sellerNonce) || escrow.escrowBump !== trade.escrow.bump) return fail();
	if (escrow.termsHash !== trade.termsHash) return fail("CONFLICT");
	if (escrow.buyer !== terms.buyer || escrow.assetKind !== terms.assetKind || escrow.mint !== terms.mint || escrow.tokenProgram !== terms.tokenProgram || escrow.amountBaseUnits !== terms.amountBaseUnits || escrow.deadlineSeconds !== terms.escrowExpirySeconds) return fail();
	if (escrow.vaultBump !== (trade.vault?.bump ?? 0)) return fail();
	return {
		occupant: "escrow",
		escrow,
		entry: account.entry
	};
}
/** Native principal stays in the escrow PDA beside its rent reserve and any donated surplus. */
function nativeCustody(escrow, entry, minimum) {
	const lamports = BigInt(safeInt$1(own$3(entry, "lamports")));
	const principal = escrow.paidOut ? 0n : BigInt(escrow.amountBaseUnits);
	if (!escrow.paidOut && lamports <= principal) return fail();
	const blockedBy = [];
	if (minimum === null) blockedBy.push("rent-unknown");
	if (!escrow.paidOut && minimum !== null && lamports - principal < minimum) blockedBy.push("rent-shortfall");
	const spare = minimum === null ? null : lamports - principal - minimum;
	return {
		kind: "native",
		lamports: lamports.toString(),
		principalHeld: principal.toString(),
		rentExemptMinimum: minimum === null ? null : minimum.toString(),
		surplus: spare === null ? null : (spare > 0n ? spare : 0n).toString(),
		payoutBlockedBy: blockedBy
	};
}
/**
* The mint is checked even when no escrow exists (the state in which the app decides to fund): SPL Token owner,
* registry decimals, then the pre-funding freeze-authority policy. Existing validated escrows retain their exits.
* A changed admission permit never vetoes release/refund or an otherwise executable payout after funding.
*/
function splMint(trade, mintEntry, permits, existing) {
	const mint = decodeMint(present(mintEntry, CAP.mint, SPL_PROGRAM_ID).data), address = trade.terms.mint;
	if (mint.decimals !== trade.asset.decimals) return fail();
	if (existing === null && !freezeAuthorityPermitted(permits, address, mint.freezeAuthority)) return fail("UNSUPPORTED_PROVIDER");
	return {
		address,
		decimals: mint.decimals,
		freezeAuthority: mint.freezeAuthority
	};
}
/** SPL principal sits in the vault PDA token account. */
function splCustody(trade, classified, vaultEntry, mint) {
	const escrow = classified.escrow, vaultAddress = trade.vault.address;
	if (escrow === null) {
		const vault = readAccount(vaultEntry, CAP.token);
		if (vault !== null && !isSystemEmpty(vault)) return fail();
		return null;
	}
	const vault = decodeTokenAccount(present(vaultEntry, CAP.token, SPL_PROGRAM_ID).data);
	const principal = escrow.paidOut ? 0n : BigInt(escrow.amountBaseUnits);
	if (vault.mint !== escrow.mint || vault.owner !== trade.escrow.address || vault.amount < principal) return fail();
	const blockedBy = vault.frozen && !escrow.paidOut ? ["vault-frozen"] : [];
	return {
		kind: "spl",
		vault: vaultAddress,
		vaultAmount: vault.amount.toString(),
		principalHeld: principal.toString(),
		surplus: (vault.amount - principal).toString(),
		vaultFrozen: vault.frozen,
		mintDecimals: mint.decimals,
		mintFreezeAuthority: mint.freezeAuthority,
		payoutBlockedBy: blockedBy
	};
}
/**
* A payout recipient may be any account (a native buyer can be a data account of any size), so only its
* metadata is read: `space` is required, the base64 length (with its padding) must encode exactly that many
* bytes, and only a 165-byte SPL Token account is decoded.
*/
function shallowAccount(entry) {
	if (entry === null) return null;
	if (typeof entry !== "object") return fail();
	const owner = canonicalKey(own$3(entry, "owner")), executable = own$3(entry, "executable");
	const lamports = own$3(entry, "lamports"), space = safeInt$1(own$3(entry, "space"));
	if (typeof executable !== "boolean" || typeof lamports !== "number" || !Number.isInteger(lamports) || lamports < 0) return fail();
	const tuple = ownArray$1(own$3(entry, "data"), 2), encoded = tuple[0];
	if (tuple.length !== 2 || tuple[1] !== "base64" || typeof encoded !== "string") return fail();
	const padding = encoded.endsWith("==") ? 2 : encoded.endsWith("=") ? 1 : 0;
	if (space > MAX_ACCOUNT_BYTES || encoded.length % 4 !== 0 || encoded.length / 4 * 3 - padding !== space) return fail();
	return {
		owner,
		executable,
		lamports: Math.min(lamports, Number.MAX_SAFE_INTEGER),
		dataLength: space,
		data: owner === "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" && !executable && space === 165 ? decodeBase64(encoded, CAP.token) : null
	};
}
function walletView(entry, rent) {
	const account = shallowAccount(entry), dataLength = account?.dataLength ?? 0;
	const minimum = rentExemptMinimum(rent, dataLength);
	return {
		lamports: String(account?.lamports ?? 0),
		dataLength,
		executable: account?.executable ?? false,
		rentExemptMinimum: minimum === null ? null : minimum.toString()
	};
}
/** Extra keys for `readPayout`, after the snapshot keys: both parties' payout destinations at the same slot. */
function payoutKeys(trade) {
	const { buyer, seller, mint } = trade.terms;
	if (mint === null) return [buyer, seller];
	return [
		RENT_SYSVAR_ID,
		associatedTokenAddress(buyer, mint).address,
		associatedTokenAddress(seller, mint).address
	];
}
function payoutPlans(trade, snapshot, accounts) {
	const escrow = snapshot.escrow, blockedBy = snapshot.custody?.payoutBlockedBy ?? [];
	if (escrow?.paidOut) return {
		buyer: null,
		seller: null,
		pending: null
	};
	const { buyer: buyerKey, seller: sellerKey, mint } = trade.terms;
	let buyer, seller;
	if (mint === null) {
		const rent = present(accounts[4], CAP.rent, SYSVAR_OWNER_ID).data;
		const principal = BigInt(escrow?.amountBaseUnits ?? trade.terms.amountBaseUnits);
		buyer = payoutPlanners.native(buyerKey, principal, walletView(accounts[5], rent), blockedBy);
		seller = payoutPlanners.native(sellerKey, principal, walletView(accounts[6], rent), blockedBy);
	} else {
		const ataRent = rentExemptMinimum(present(accounts[6], CAP.rent, SYSVAR_OWNER_ID).data, 165);
		const rentLamports = ataRent === null ? null : ataRent.toString();
		const plan = (recipient, index) => payoutPlanners.spl(recipient, mint, associatedTokenAddress(recipient, mint).address, classifyTokenAccount(shallowAccount(accounts[index])), blockedBy, rentLamports);
		buyer = plan(buyerKey, 7);
		seller = plan(sellerKey, 8);
	}
	const pending = escrow?.state === "released" ? buyer : escrow?.state === "refunded" ? seller : null;
	return {
		buyer,
		seller,
		pending
	};
}
function payoutOf(escrow) {
	if (escrow === null || escrow.state === "funded") return "not-applicable";
	return escrow.paidOut ? "complete" : "pending";
}
function counter$1(value) {
	return safeInt$1(value, "INVALID_INPUT");
}
/** A request counter; a getter that throws is the caller's fault (INVALID_INPUT), not a provider failure. */
function requestCounter(read) {
	let value;
	try {
		value = read();
	} catch {
		return fail("INVALID_INPUT");
	}
	return counter$1(value);
}
/** Only snapshots produced by `read()` carry the brand; the settlement planner refuses copies. */
const SNAPSHOTS = /* @__PURE__ */ new WeakSet();
var SolanaChainReader = class {
	#options;
	#timeoutMs;
	#disposed = false;
	#jobs = /* @__PURE__ */ new Set();
	/** Highest finalized slot accepted per network; later reads must not observe an older context. */
	#floors = /* @__PURE__ */ new Map();
	/**
	* ProgramData deploy slot first confirmed per network and program. With no upgrade authority the ProgramData
	* can never be rewritten, so a later read showing another deploy slot is inconsistent and fails. This only
	* adds a refusal; every read still re-checks the whole identity.
	*/
	#deploySlots = /* @__PURE__ */ new Map();
	#permits;
	constructor(options) {
		this.#options = options;
		this.#timeoutMs = options.timeoutMs ?? 1e4;
		if (!Number.isSafeInteger(this.#timeoutMs) || this.#timeoutMs < 1 || this.#timeoutMs > 6e4) throw new Error("Invalid Solana reader timeout.");
		this.#permits = parseFreezeAuthorityPermits(options.freezeAuthorityPermits);
	}
	/** Same job discipline as the EVM reader: a slot is freed only when the physical work settles. */
	#run(signalOf, work) {
		const operationId = createOperationId();
		const failure = (code) => ({
			ok: false,
			error: createCoreError(code, {
				operationId,
				readOnly: true
			})
		});
		if (this.#disposed) return Promise.resolve(failure("CANCELLED"));
		const invalid = () => Promise.resolve(failure("INVALID_INPUT"));
		let external, aborted;
		try {
			const value = signalOf();
			if (value !== void 0 && !(value instanceof AbortSignal)) return invalid();
			external = value;
			aborted = external?.aborted === true;
		} catch {
			return invalid();
		}
		if (aborted) return Promise.resolve(failure("CANCELLED"));
		if (this.#jobs.size >= 4) return Promise.resolve(failure("LIMIT_EXCEEDED"));
		const controller = new AbortController();
		const onExternal = () => controller.abort();
		const detach = () => {
			try {
				external?.removeEventListener("abort", onExternal);
			} catch {}
		};
		this.#jobs.add(controller);
		try {
			external?.addEventListener("abort", onExternal, { once: true });
		} catch {
			detach();
			this.#jobs.delete(controller);
			return invalid();
		}
		let abortCode = "CANCELLED";
		const timer = setTimeout(() => {
			abortCode = "TIMEOUT";
			controller.abort();
		}, this.#timeoutMs);
		const guard = () => {
			if (this.#disposed || controller.signal.aborted) fail(abortCode);
		};
		const context = {
			signal: controller.signal,
			guard,
			call: async (method, params) => {
				guard();
				let boxed;
				try {
					boxed = { value: await this.#options.rpc.request({
						method,
						params,
						signal: controller.signal
					}) };
				} catch {
					guard();
					return fail("UNAVAILABLE");
				}
				guard();
				return boxed;
			}
		};
		let onAbort;
		const cancelled = new Promise((resolve) => {
			onAbort = () => resolve(failure(abortCode));
			controller.signal.addEventListener("abort", onAbort, { once: true });
		});
		const physical = Promise.resolve().then(() => {
			guard();
			return work(context);
		}).then((value) => {
			guard();
			return {
				ok: true,
				value
			};
		}).catch((error) => failure(failureCode(error, "UNAVAILABLE"))).finally(() => {
			this.#jobs.delete(controller);
			clearTimeout(timer);
			detach();
		});
		return Promise.race([physical, cancelled]).finally(() => {
			controller.signal.removeEventListener("abort", onAbort);
			detach();
		});
	}
	/** Steps 1-2 plus identity: genesis, one finalized getMultipleAccounts at slot S >= floor. */
	async #anchor(ref, extraKeys, context) {
		if ((await context.call("getGenesisHash", [])).value !== ref.network.genesisHash) return fail("WRONG_CHAIN");
		const floor = this.#floors.get(ref.network.id);
		const config = floor === void 0 ? {
			commitment: "finalized",
			encoding: "base64"
		} : {
			commitment: "finalized",
			encoding: "base64",
			minContextSlot: floor
		};
		const keys = [
			ref.deployment.address,
			ref.programDataAddress,
			CLOCK_SYSVAR_ID,
			...extraKeys
		];
		const response = (await context.call("getMultipleAccounts", [keys, config])).value;
		const slot = safeInt$1(own$3(own$3(response, "context"), "slot"));
		if (floor !== void 0 && slot < floor) return fail();
		const accounts = ownArray$1(own$3(response, "value"), keys.length);
		if (accounts.length !== keys.length) return fail();
		return {
			slot,
			accounts,
			...checkIdentity(ref, accounts, slot)
		};
	}
	/** Steps 3-5: the block at S twice, then the genesis again; only then is the floor raised. */
	async #confirm(ref, anchored, context) {
		const params = [anchored.slot, {
			commitment: "finalized",
			transactionDetails: "none",
			rewards: false
		}];
		const first = block((await context.call("getBlock", params)).value, anchored.slot);
		const second = block((await context.call("getBlock", params)).value, anchored.slot);
		if (first.hash !== second.hash || first.height !== second.height || first.parent !== second.parent) return fail();
		if ((await context.call("getGenesisHash", [])).value !== ref.network.genesisHash) return fail();
		context.guard();
		const program = `${ref.network.id}:${ref.deployment.address}`, pinned = this.#deploySlots.get(program);
		if (pinned !== void 0 && pinned !== anchored.deploySlot) return fail();
		this.#deploySlots.set(program, anchored.deploySlot);
		this.#floors.set(ref.network.id, Math.max(this.#floors.get(ref.network.id) ?? 0, anchored.slot));
		return {
			height: String(anchored.slot),
			hash: first.hash,
			blockHeight: String(first.height),
			...anchored.identity
		};
	}
	validateLive(networkId, deploymentId, signal) {
		return this.#run(() => signal, async (context) => {
			const ref = resolveDeployment(this.#options.registry, networkId, deploymentId);
			return deepFreeze(await this.#confirm(ref, await this.#anchor(ref, [], context), context));
		});
	}
	/** One anchored read; `payout` appends both parties' payout destinations to the same getMultipleAccounts. */
	async #observe(binding, request, terms, context, payout) {
		const generation = requestCounter(() => request.generation);
		const requestSequence = requestCounter(() => request.requestSequence);
		const trade = bindTrade(this.#options.registry, binding, terms);
		const native = trade.terms.assetKind === "native";
		const extra = native ? [trade.escrow.address, RENT_SYSVAR_ID] : [
			trade.escrow.address,
			trade.vault.address,
			trade.terms.mint
		];
		const anchored = await this.#anchor(trade, payout ? [...extra, ...payoutKeys(trade)] : extra, context);
		const classified = classifyEscrow(trade, anchored.accounts[3]);
		let custody, mint = null;
		if (native) {
			const minimum = escrowRentMinimum(present(anchored.accounts[4], CAP.rent, SYSVAR_OWNER_ID).data);
			custody = classified.escrow === null ? null : nativeCustody(classified.escrow, classified.entry, minimum);
		} else {
			mint = splMint(trade, anchored.accounts[5], this.#permits, classified.escrow);
			custody = splCustody(trade, classified, anchored.accounts[4], mint);
		}
		const live = await this.#confirm(trade, anchored, context);
		const observedAt = counter$1((this.#options.now ?? Date.now)());
		return {
			trade,
			snapshot: {
				observation: {
					binding: trade.binding,
					generation,
					requestSequence,
					anchor: {
						height: live.height,
						hash: live.hash
					},
					state: classified.escrow?.state ?? "absent",
					finality: "finalized",
					observedAt
				},
				live,
				escrowAddress: trade.escrow.address,
				occupant: classified.occupant,
				escrow: classified.escrow,
				payout: payoutOf(classified.escrow),
				custody,
				mint
			},
			accounts: anchored.accounts
		};
	}
	read(binding, request, terms) {
		return this.#run(() => request.signal, async (context) => {
			const snapshot = deepFreeze((await this.#observe(binding, request, terms, context, false)).snapshot);
			SNAPSHOTS.add(snapshot);
			return snapshot;
		});
	}
	/**
	* The snapshot plus payout plans, all at slot S: 2 more keys for native (buyer, seller wallets), 3 for SPL
	* (Rent sysvar, buyer and seller canonical ATAs). The plans are advisory; the program enforces the rules.
	*/
	readPayout(binding, request, terms) {
		return this.#run(() => request.signal, async (context) => {
			const { trade, snapshot, accounts } = await this.#observe(binding, request, terms, context, true);
			const result = deepFreeze({
				snapshot,
				...payoutPlans(trade, snapshot, accounts)
			});
			SNAPSHOTS.add(snapshot);
			return result;
		});
	}
	/**
	* G08 port: the ChainObservation alone. A frozen SPL vault is reported like any other funded trade (review
	* C-L3): `release` and `refund` are state-only and still succeed, and only the payout waits for a thaw. The
	* flag is `read(…).custody.vaultFrozen` and `payoutBlockedBy` (`'vault-frozen'`); readPayout plans with it.
	*/
	async readValidated(binding, request, terms) {
		const result = await this.read(binding, request, terms);
		return result.ok ? {
			ok: true,
			value: result.value.observation
		} : result;
	}
	dispose() {
		if (this.#disposed) return;
		this.#disposed = true;
		for (const controller of this.#jobs) controller.abort();
	}
};
// packages/chain-solana/src/plan.ts
/**
* C-L2 message plans: the only way this package turns escrow instructions into a message.
*
* Integration review C-L2 overrides the D5 packet's "release and payout in one transaction" for the client: a
* failed payout leg (frozen destination, rent) would roll back the release with it. So a message carries exactly
* one escrow instruction. `fund`, `release` and `refund` messages hold that instruction alone; a payout message
* is `[CreateIdempotent ATA]? ‖ [System transfer rent top-up]? ‖ payout_*` and is planned only from a FINALIZED
* reader snapshot that shows `Released`/`Refunded` and an unpaid principal. There is no API that takes an
* instruction list, and `verifyPlanMessage` rebuilds the expected bytes and refuses anything else.
*/
const PLANS = /* @__PURE__ */ new WeakSet();
const TRUSTED = /* @__PURE__ */ new WeakSet();
const isSolanaMessagePlan = (value) => typeof value === "object" && value !== null && PLANS.has(value);
const isTrustedSnapshot = (value) => typeof value === "object" && value !== null && TRUSTED.has(value);
const failure$2 = (code) => ({
	ok: false,
	error: createCoreError(code, {
		operationId: createOperationId(),
		readOnly: true
	})
});
function result(work) {
	try {
		return {
			ok: true,
			value: work()
		};
	} catch (error) {
		return failure$2(failureCode(error, "INVALID_INPUT"));
	}
}
const value$1 = (built) => built.ok ? built.value : fail(built.error.code);
/**
* A finalized read through a genuine `SolanaChainReader` (the prototype method, so a look-alike object or an own
* `read` property cannot inject a snapshot). Only snapshots returned here can be planned against.
*/
async function readTrustedSnapshot(reader, trade, request) {
	if (!isBoundSolanaTrade(trade)) return failure$2("INVALID_INPUT");
	let read;
	try {
		read = await SolanaChainReader.prototype.read.call(reader, trade.binding, request, trade.terms);
	} catch {
		return failure$2("INVALID_INPUT");
	}
	if (read.ok) TRUSTED.add(read.value);
	return read;
}
function roleKey(trade, role) {
	if (role === "seller") return trade.terms.seller;
	if (role === "buyer") return trade.terms.buyer;
	return fail("INVALID_INPUT");
}
/** Strict margins: exactly the two keys, as u64 decimal strings (the window helpers bound them). */
function parseMargins(input) {
	if (typeof input !== "object" || input === null || Array.isArray(input)) return fail("INVALID_INPUT");
	if (Reflect.ownKeys(input).length !== 2) return fail("INVALID_INPUT");
	const read = (key) => {
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field || !("value" in field)) return fail("INVALID_INPUT");
		decimalU64(field.value);
		return field.value;
	};
	return Object.freeze({
		submitMarginSeconds: read("submitMarginSeconds"),
		releaseMarginSeconds: read("releaseMarginSeconds")
	});
}
/** Snapshot of exactly this trade, read through `readTrustedSnapshot`, at finalized commitment. */
function checkedSnapshot(trade, snapshot) {
	if (!isBoundSolanaTrade(trade) || !isTrustedSnapshot(snapshot)) return fail("INVALID_INPUT");
	const binding = snapshot.observation.binding;
	if (snapshot.observation.finality !== "finalized" || snapshot.escrowAddress !== trade.escrow.address || binding.tradeId !== trade.binding.tradeId || binding.networkId !== trade.binding.networkId || binding.deploymentId !== trade.binding.deploymentId) return fail("INVALID_INPUT");
	return snapshot;
}
function payer(trade, role, allowed) {
	if (!allowed.includes(role)) return fail("UNAUTHORIZED");
	return roleKey(trade, role);
}
/** Instructions for one shape. Every message this package compiles comes from here. */
function shapeInstructions(trade, feePayer, shape) {
	switch (shape.action) {
		case "fund": return [trade.terms.assetKind === "native" ? value$1(buildFundNative(trade)) : value$1(buildFundSpl(trade, shape.sellerTokenAccount ?? fail("INVALID_INPUT")))];
		case "release": return [value$1(buildRelease(trade))];
		case "refund": return [value$1(buildRefund(trade))];
		case "payout": {
			const out = [];
			const recipient = shape.outcome === "released" ? trade.terms.buyer : trade.terms.seller;
			if (shape.createAta) {
				if (trade.terms.assetKind !== "spl") return fail("INVALID_INPUT");
				out.push(buildCreateAtaIdempotent(feePayer, recipient, trade.terms.mint));
			}
			if (shape.rentTopUpLamports !== null) {
				if (trade.terms.assetKind !== "native") return fail("INVALID_INPUT");
				out.push(buildSystemTransfer(feePayer, trade.escrow.address, decimalU64(shape.rentTopUpLamports)));
			}
			out.push(value$1(buildPayout(trade, shape.outcome)));
			return out;
		}
		default: return fail("INVALID_INPUT");
	}
}
function makePlan(trade, snapshot, role, feePayer, shape, expectedEscrowState) {
	const plan = Object.freeze({
		trade,
		action: shape.action,
		role,
		feePayer,
		shape: Object.freeze({ ...shape }),
		expectedEscrowState,
		instructions: Object.freeze(shapeInstructions(trade, feePayer, shape)),
		snapshotSlot: snapshot.live.height,
		snapshotBlockHeight: snapshot.live.blockHeight
	});
	PLANS.add(plan);
	return plan;
}
/** Seller funds an absent escrow while the funding window stays open for `submitMarginSeconds`. */
function planFund(trade, snapshot, role, margins, options = {}) {
	return result(() => {
		const read = checkedSnapshot(trade, snapshot), limits = parseMargins(margins);
		const feePayer = payer(trade, role, ["seller"]);
		if (read.escrow !== null || read.occupant === "escrow") return fail("CONFLICT");
		const terms = trade.terms;
		if (value$1(fundingWindow(terms.acceptBeforeSeconds, terms.escrowExpirySeconds, read.live.timestampSeconds, limits.submitMarginSeconds)) !== "open") return fail("EXPIRED");
		return makePlan(trade, read, role, feePayer, {
			action: "fund",
			sellerTokenAccount: terms.assetKind === "spl" ? options.sellerTokenAccount ?? associatedTokenAddress(terms.seller, terms.mint).address : null
		}, "absent");
	});
}
/** Seller releases a `Funded` escrow strictly before `deadline - releaseMarginSeconds` (finalized Clock). */
function planRelease(trade, snapshot, role, margins) {
	return result(() => {
		const read = checkedSnapshot(trade, snapshot), limits = parseMargins(margins);
		const feePayer = payer(trade, role, ["seller"]);
		if (read.escrow?.state !== "funded") return fail("CONFLICT");
		if (!value$1(settlementWindow(read.escrow.deadlineSeconds, read.live.timestampSeconds, limits.releaseMarginSeconds)).releaseOpen) return fail("EXPIRED");
		return makePlan(trade, read, role, feePayer, { action: "release" }, "funded");
	});
}
/** Seller refunds a `Funded` escrow once the finalized Clock has reached the deadline. */
function planRefund(trade, snapshot, role, margins) {
	return result(() => {
		const read = checkedSnapshot(trade, snapshot), limits = parseMargins(margins);
		const feePayer = payer(trade, role, ["seller"]);
		if (read.escrow?.state !== "funded") return fail("CONFLICT");
		if (!value$1(settlementWindow(read.escrow.deadlineSeconds, read.live.timestampSeconds, limits.releaseMarginSeconds)).refundOpen) return fail("EXPIRED");
		return makePlan(trade, read, role, feePayer, { action: "refund" }, "funded");
	});
}
/** Native rent shortfall the payout needs topped up, or null; refused above the payer's limit. */
function rentTopUp(snapshot, maxTopUp) {
	const custody = snapshot.custody;
	if (custody?.kind !== "native" || !custody.payoutBlockedBy.includes("rent-shortfall")) return null;
	const shortfall = BigInt(custody.rentExemptMinimum) - (BigInt(custody.lamports) - BigInt(custody.principalHeld));
	if (shortfall < 1n) return fail("INTEGRITY_FAILURE");
	if (shortfall > maxTopUp) return fail("LIMIT_EXCEEDED");
	return shortfall.toString();
}
/** Anyone in the trade pays out after a FINALIZED `Released`/`Refunded` read with the principal unpaid. */
function planPayout(trade, snapshot, role, options = {}) {
	return result(() => {
		const read = checkedSnapshot(trade, snapshot), feePayer = payer(trade, role, ["seller", "buyer"]);
		const state = read.escrow?.state;
		if (state !== "released" && state !== "refunded" || read.escrow.paidOut || read.payout !== "pending") return fail("CONFLICT");
		if (read.custody?.kind === "spl" && read.custody.vaultFrozen) return fail("CONFLICT");
		const spl = trade.terms.assetKind === "spl";
		return makePlan(trade, read, role, feePayer, {
			action: "payout",
			outcome: state,
			createAta: spl && options.createAta !== false,
			rentTopUpLamports: spl ? null : rentTopUp(read, decimalU64(options.maxRentTopUpLamports ?? "0"))
		}, state);
	});
}
/** Legacy message bytes of a plan; re-checks the plan brand. */
function compilePlan(plan, recentBlockhash) {
	if (!isSolanaMessagePlan(plan)) return fail("INVALID_INPUT");
	return compileLegacyMessage(plan.feePayer, plan.instructions, recentBlockhash);
}
/** Reads the variable parts back from a message, then requires byte equality with the rebuilt message. */
function shapeOf(trade, action, expected, message) {
	const parsed = parseLegacyMessage(message), keys = parsed.accountKeys;
	const programs = parsed.instructions.map((instruction) => keys[instruction.programIdIndex]);
	if (action === "fund") {
		const fund = parsed.instructions[0];
		return {
			action,
			sellerTokenAccount: trade.terms.assetKind === "spl" && fund ? keys[fund.accounts[3] ?? 0] ?? null : null
		};
	}
	if (action === "release" || action === "refund") return { action };
	if (expected !== "released" && expected !== "refunded") return fail("INVALID_INPUT");
	const createAta = programs[0] === ATA_PROGRAM_ID;
	const transfer = parsed.instructions.find((_, index) => programs[index] === SYSTEM_PROGRAM_ID);
	return {
		action,
		outcome: expected,
		createAta,
		rentTopUpLamports: transfer && transfer.data.length === 12 ? readU64(transfer.data, 4).toString() : null
	};
}
/**
* Throws unless `message` is exactly what this package would compile for (trade, action, fee payer, blockhash):
* one escrow instruction, never a state instruction beside a payout, no foreign or durable-nonce instruction.
*/
function verifyPlanMessage(trade, action, expected, feePayer, message) {
	if (!isBoundSolanaTrade(trade)) return fail("INVALID_INPUT");
	const parsed = parseLegacyMessage(message);
	if (parsed.accountKeys[0] !== feePayer || parsed.header.numRequiredSignatures !== 1) return fail("INVALID_INPUT");
	let shape, rebuilt;
	try {
		shape = shapeOf(trade, action, expected, message);
		rebuilt = compileLegacyMessage(feePayer, shapeInstructions(trade, feePayer, shape), parsed.recentBlockhash);
	} catch {
		return fail("INVALID_INPUT");
	}
	if (!equalBytes(rebuilt, message)) return fail("INVALID_INPUT");
	return shape;
}
// packages/chain-solana/src/wallet.ts
/**
* Wallet permission port, modelled on the Wallet Standard (`standard:connect` from wallet-standard/wallet-standard
* @c49b56d6 packages/core/features/src/connect.ts; `solana:signTransaction` from anza-xyz/wallet-standard@c4d06f9f
* packages/core/features/src/signTransaction.ts). The port is injected; this module never looks for a wallet.
*
* - `connectWalletRole` is an explicit, user-triggered `connect()` (no `silent`). The account used must equal the
*   stored key of the role (seller or buyer), its `publicKey` bytes must match its address, and it must list the
*   configured chain and `solana:signTransaction`.
* - Sign-only: `signTransaction` returns signed bytes, so the signature (the transaction id) is known and durably
*   journaled before this client broadcasts. `solana:signAndSendTransaction` is deliberately not used.
* - The returned wire transaction must carry exactly one signature over exactly the message we built (so no fee
*   payer, instruction, account or blockhash substitution), and that signature must verify with Ed25519 (strict
*   RFC 8032 verification, `zip215: false`) for the session's key.
*/
const STANDARD_CONNECT = "standard:connect";
const SOLANA_SIGN_TRANSACTION = "solana:signTransaction";
const SESSIONS = /* @__PURE__ */ new WeakMap();
const CHAIN$1 = /^solana:[a-z0-9-]{1,32}$/;
function own$2(input, key) {
	try {
		if (typeof input !== "object" || input === null) return fail();
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field || !("value" in field)) return fail();
		return field.value;
	} catch {
		return fail();
	}
}
function strings(input, maximum) {
	if (!Array.isArray(input) || input.length > maximum) return fail();
	const out = [];
	for (let index = 0; index < input.length; index++) {
		const entry = own$2(input, String(index));
		if (typeof entry !== "string" || entry.length > 128) return fail();
		out.push(entry);
	}
	return out;
}
function bytesOf(input, maximum) {
	if (!(input instanceof Uint8Array) || input.length > maximum) return fail();
	return Uint8Array.from(input);
}
/** Strict canonical base58 of exactly 64 bytes (a transaction signature). */
function decodeSignature(input) {
	if (typeof input !== "string" || input.length < 64 || input.length > 88) return fail("INVALID_INPUT");
	let value = 0n;
	const alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
	for (const character of input) {
		const digit = alphabet.indexOf(character);
		if (digit < 0) return fail("INVALID_INPUT");
		value = value * 58n + BigInt(digit);
	}
	const out = /* @__PURE__ */ new Uint8Array(64);
	for (let index = 63; index >= 0; index--, value >>= 8n) out[index] = Number(value & 255n);
	if (value !== 0n || encodeBase58(out) !== input) return fail("INVALID_INPUT");
	return out;
}
/** Strict Ed25519 verification of a base58 signature over `message` for a base58 key. Never throws. */
function verifySignature(signature, message, key) {
	try {
		const bytes = decodeSignature(signature);
		if (bytes.every((byte) => byte === 0)) return false;
		return ed25519.verify(bytes, message, decodeKey(key), { zip215: false });
	} catch {
		return false;
	}
}
function account(entry, address, chain) {
	if (own$2(entry, "address") !== address) return null;
	if (!equalBytes(bytesOf(own$2(entry, "publicKey"), 32), decodeKey(address))) return fail("INTEGRITY_FAILURE");
	const chains = strings(own$2(entry, "chains"), 16), features = strings(own$2(entry, "features"), 64);
	if (!chains.includes(chain) || !features.includes("solana:signTransaction")) return fail("UNSUPPORTED_PROVIDER");
	return entry;
}
/** A Wallet Standard feature method; a wallet without it (or with accessors there) is unsupported. */
function feature(wallet, name, method) {
	let entry, call;
	try {
		entry = own$2(own$2(wallet, "features"), name);
		call = own$2(entry, method);
	} catch {
		return fail("UNSUPPORTED_PROVIDER");
	}
	if (typeof call !== "function") return fail("UNSUPPORTED_PROVIDER");
	return (...args) => Promise.resolve(Reflect.apply(call, entry, args));
}
const failure$1 = (code) => ({
	ok: false,
	error: createCoreError(code, {
		operationId: createOperationId(),
		readOnly: true
	})
});
/** Wallet errors are the wallet's claim; only their numeric/string code is read (4001 => USER_REJECTED). */
function walletError(error) {
	const code = failureCode(error, normalizeError(error, {
		operationId: createOperationId(),
		phase: "prepare"
	}).code);
	return failure$1(code);
}
/** Explicit connect for one role of one trade; refuses any account but the role's stored key. */
async function connectWalletRole(wallet, trade, role, chain) {
	try {
		if (!isBoundSolanaTrade(trade) || typeof chain !== "string" || !CHAIN$1.test(chain)) return failure$1("INVALID_INPUT");
		const address = roleKey(trade, role), connect = feature(wallet, STANDARD_CONNECT, "connect");
		feature(wallet, SOLANA_SIGN_TRANSACTION, "signTransaction");
		let output;
		try {
			output = await connect();
		} catch (error) {
			return walletError(error);
		}
		const accounts = own$2(output, "accounts");
		if (!Array.isArray(accounts) || accounts.length > 16) return failure$1("INTEGRITY_FAILURE");
		let chosen = null;
		for (let index = 0; index < accounts.length && chosen === null; index++) chosen = account(own$2(accounts, String(index)), address, chain);
		if (chosen === null) return failure$1("UNAUTHORIZED");
		const session = Object.freeze({
			role,
			address,
			chain,
			tradeId: trade.binding.tradeId
		});
		SESSIONS.set(session, {
			wallet,
			account: chosen
		});
		return {
			ok: true,
			value: session
		};
	} catch (error) {
		return failure$1(failureCode(error, "INTEGRITY_FAILURE"));
	}
}
const isWalletSession = (value) => typeof value === "object" && value !== null && SESSIONS.has(value);
/** Validates wallet output: one signature, our exact message bytes, a valid signature by the session key. */
function checkSignedTransaction(output, message, signer) {
	if (!Array.isArray(output) || output.length !== 1) return fail("INTEGRITY_FAILURE");
	const wire = bytesOf(own$2(own$2(output, "0"), "signedTransaction"), 1232);
	let decoded;
	try {
		decoded = decodeTransaction(wire);
	} catch {
		return fail("INTEGRITY_FAILURE");
	}
	if (decoded.signatures.length !== 1 || !equalBytes(decoded.message, message)) return fail("INTEGRITY_FAILURE");
	const signature = encodeBase58(decoded.signatures[0]);
	if (!verifySignature(signature, message, signer)) return fail("INTEGRITY_FAILURE");
	return Object.freeze({
		signature,
		wire
	});
}
/** One `signTransaction` call for our unsigned wire transaction; the wallet must not change a byte of the message. */
async function signWithWallet(session, message, assertActive) {
	try {
		const state = SESSIONS.get(session);
		if (!state) return failure$1("UNAUTHORIZED");
		assertActive?.();
		const sign = feature(state.wallet, SOLANA_SIGN_TRANSACTION, "signTransaction");
		const input = {
			account: state.account,
			transaction: unsignedTransaction(message),
			chain: session.chain
		};
		assertActive?.();
		let output;
		try {
			output = await sign(input);
		} catch (error) {
			return walletError(error);
		}
		return {
			ok: true,
			value: checkSignedTransaction(output, message, session.address)
		};
	} catch (error) {
		return failure$1(failureCode(error, "INTEGRITY_FAILURE"));
	}
}
// packages/chain-solana/src/intent.ts
/**
* Solana intent record: the journal entry for one signed escrow message, kept in the encrypted vault through an
* injected journal port. Restored or imported records are untrusted input: `parseSolanaIntent` checks every field
* and invariant, and `verifyIntentForTrade` binds a record to one trade, registry deployment and exact message.
*
* States (D9 semantics, Solana-native):
*   prepared  message built and journaled; nothing signed yet (signature null)
*   signed    wallet output validated; signature (= transaction id) known; not handed to any RPC by this client
*   sendMarked  durable send marker written (CAS, before the broadcast); never cleared
*   sent      the RPC accepted the broadcast and answered this signature (not evidence of landing)
*   unknown   the broadcast call threw, timed out or answered something else; outcome uncertain
*   finalized landed at finalized commitment without error (corroborated by a finalized escrow read)
*   failed    landed at finalized commitment with an error (`outcome.err`)
*   dropped   finalized block height > lastValidBlockHeight and no status: it can never land
*   cancelled never marked and known not sent by this profile (local cancel before the marker)
*/
const SOLANA_INTENT_FORMAT = "p2p-offramp/solana-intent/v1";
const TERMINAL_STATES = Object.freeze([
	"finalized",
	"failed",
	"dropped",
	"cancelled"
]);
/** Origin of a record imported from a format without provenance; never a real profile id. */
const UNKNOWN_ORIGIN = "0".repeat(32);
/** Allowed state changes; everything else in a record is immutable except as `transitionIntent` permits. */
const SOLANA_TRANSITIONS = Object.freeze({
	prepared: Object.freeze([
		"signed",
		"cancelled",
		"dropped"
	]),
	signed: Object.freeze([
		"sendMarked",
		"cancelled",
		"finalized",
		"failed",
		"dropped"
	]),
	sendMarked: Object.freeze([
		"sent",
		"unknown",
		"finalized",
		"failed",
		"dropped"
	]),
	sent: Object.freeze([
		"finalized",
		"failed",
		"dropped"
	]),
	unknown: Object.freeze([
		"finalized",
		"failed",
		"dropped"
	]),
	finalized: Object.freeze([]),
	failed: Object.freeze([]),
	dropped: Object.freeze([]),
	cancelled: Object.freeze([])
});
const STATES = Object.keys(SOLANA_TRANSITIONS);
const KEYS = Object.freeze([
	"format",
	"intentId",
	"binding",
	"genesisHash",
	"programId",
	"programDataSha256",
	"escrow",
	"action",
	"role",
	"feePayer",
	"expectedEscrowState",
	"message",
	"blockhash",
	"blockhashSlot",
	"lastValidBlockHeight",
	"signature",
	"state",
	"sendMarkedAt",
	"outcome",
	"replacementOf",
	"originProfileId",
	"createdAt",
	"updatedAt"
]);
const EXPECTED = Object.freeze({
	fund: ["absent"],
	release: ["funded"],
	refund: ["funded"],
	payout: ["released", "refunded"]
});
const ROLES = Object.freeze({
	fund: ["seller"],
	release: ["seller"],
	refund: ["seller"],
	payout: ["seller", "buyer"]
});
/** Compact transaction error label written by `summarizeTransactionError` (submit.ts). */
const ERROR_LABEL = /^[A-Za-z]{1,64}(?::[0-9]{1,3}:(?:Custom:[0-9]{1,10}|[A-Za-z]{1,64}))?$/;
const MAX_MESSAGE_BASE64 = Math.ceil(MAX_TRANSACTION_BYTES / 3) * 4;
/** Exactly `keys` as own data properties of a plain object, copied without invoking accessors. */
function exactData(input, keys) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail("INVALID_INPUT");
		const prototype = Object.getPrototypeOf(input);
		if (prototype !== Object.prototype && prototype !== null) return fail("INVALID_INPUT");
		const own = Reflect.ownKeys(input);
		if (own.length !== keys.length || own.some((key) => typeof key !== "string" || !keys.includes(key))) return fail("INVALID_INPUT");
		const copy = Object.create(null);
		for (const key of keys) {
			const field = Object.getOwnPropertyDescriptor(input, key);
			if (!field || !("value" in field)) return fail("INVALID_INPUT");
			copy[key] = field.value;
		}
		return copy;
	} catch {
		return fail("INVALID_INPUT");
	}
}
function choice(input, allowed) {
	if (typeof input !== "string" || !allowed.includes(input)) return fail("INVALID_INPUT");
	return input;
}
function counter(input) {
	if (typeof input !== "number" || !Number.isSafeInteger(input) || input < 0) return fail("INVALID_INPUT");
	return input;
}
function decimal(input) {
	decimalU64(input);
	return input;
}
function intentId(input) {
	try {
		return parseIntentId(input);
	} catch {
		return fail("INVALID_INPUT");
	}
}
function hash64(input) {
	if (typeof input !== "string" || !/^[0-9a-f]{64}$/.test(input)) return fail("INVALID_INPUT");
	return input;
}
function outcomeOf(input) {
	if (input === null) return null;
	const raw = exactData(input, ["slot", "err"]);
	if (raw.err !== null && (typeof raw.err !== "string" || !ERROR_LABEL.test(raw.err))) return fail("INVALID_INPUT");
	return Object.freeze({
		slot: decimal(raw.slot),
		err: raw.err
	});
}
function messageBytes(input) {
	try {
		return decodeBase64(input, MAX_MESSAGE_BASE64);
	} catch {
		return fail("INVALID_INPUT");
	}
}
/** Per-state invariants of signature, marker and outcome. */
function checkState(record) {
	const { state, signature, sendMarkedAt, outcome } = record;
	const signed = signature !== null, marked = sendMarkedAt !== null;
	if (!{
		prepared: !signed && !marked && outcome === null,
		signed: signed && !marked && outcome === null,
		sendMarked: signed && marked && outcome === null,
		sent: signed && marked && outcome === null,
		unknown: signed && marked && outcome === null,
		finalized: signed && outcome !== null && outcome.err === null,
		failed: signed && outcome !== null && outcome.err !== null,
		dropped: outcome === null,
		cancelled: !marked && outcome === null
	}[state]) return fail("INVALID_INPUT");
}
/** Structural and internal validation of one stored record (no registry or trade needed). */
function parseSolanaIntent(input) {
	const raw = exactData(input, KEYS);
	if (raw.format !== "p2p-offramp/solana-intent/v1") return fail("UNSUPPORTED_VERSION");
	let binding;
	try {
		binding = parseSolanaBinding(parseTradeBinding(raw.binding));
	} catch {
		return fail("INVALID_INPUT");
	}
	const action = choice(raw.action, [
		"fund",
		"release",
		"refund",
		"payout"
	]);
	const role = choice(raw.role, ROLES[action]);
	const expectedEscrowState = choice(raw.expectedEscrowState, EXPECTED[action]);
	const record = Object.freeze({
		format: SOLANA_INTENT_FORMAT,
		intentId: intentId(raw.intentId),
		binding,
		genesisHash: canonicalKey(raw.genesisHash, "INVALID_INPUT"),
		programId: canonicalKey(raw.programId, "INVALID_INPUT"),
		programDataSha256: hash64(raw.programDataSha256),
		escrow: canonicalKey(raw.escrow, "INVALID_INPUT"),
		action,
		role,
		feePayer: canonicalKey(raw.feePayer, "INVALID_INPUT"),
		expectedEscrowState,
		message: raw.message,
		blockhash: canonicalKey(raw.blockhash, "INVALID_INPUT"),
		blockhashSlot: decimal(raw.blockhashSlot),
		lastValidBlockHeight: decimal(raw.lastValidBlockHeight),
		signature: raw.signature === null ? null : encodeBase58(decodeSignature(raw.signature)),
		state: choice(raw.state, STATES),
		sendMarkedAt: raw.sendMarkedAt === null ? null : counter(raw.sendMarkedAt),
		outcome: outcomeOf(raw.outcome),
		replacementOf: raw.replacementOf === null ? null : intentId(raw.replacementOf),
		originProfileId: typeof raw.originProfileId === "string" && /^[0-9a-f]{32}$/.test(raw.originProfileId) ? raw.originProfileId : fail("INVALID_INPUT"),
		createdAt: counter(raw.createdAt),
		updatedAt: counter(raw.updatedAt)
	});
	if (record.signature !== raw.signature || record.replacementOf === record.intentId) return fail("INVALID_INPUT");
	if (record.updatedAt < record.createdAt) return fail("INVALID_INPUT");
	if (record.sendMarkedAt !== null && (record.sendMarkedAt < record.createdAt || record.sendMarkedAt > record.updatedAt)) return fail("INVALID_INPUT");
	checkState(record);
	const message = messageBytes(record.message);
	let parsed;
	try {
		parsed = parseLegacyMessage(message);
	} catch {
		return fail("INVALID_INPUT");
	}
	if (parsed.accountKeys[0] !== record.feePayer || parsed.recentBlockhash !== record.blockhash || parsed.header.numRequiredSignatures !== 1) return fail("INVALID_INPUT");
	if (record.signature !== null && !verifySignature(record.signature, message, record.feePayer)) return fail("INTEGRITY_FAILURE");
	return record;
}
/** Binds a parsed record to one trade: network, genesis, program, ProgramData pin, escrow, role and exact bytes. */
function verifyIntentForTrade(record, trade) {
	const binding = trade.binding;
	if (record.binding.networkId !== binding.networkId || record.binding.deploymentId !== binding.deploymentId || record.binding.tradeId !== binding.tradeId) return fail("CONFLICT");
	if (record.genesisHash !== trade.network.genesisHash || record.programId !== trade.deployment.address) return fail("WRONG_CHAIN");
	const runtime = trade.deployment.runtime;
	if (runtime.kind !== "solana-program" || record.programDataSha256 !== runtime.programDataSha256) return fail("WRONG_CHAIN");
	if (record.escrow !== trade.escrow.address || record.feePayer !== roleKey(trade, record.role)) return fail("INTEGRITY_FAILURE");
	verifyPlanMessage(trade, record.action, record.expectedEscrowState, record.feePayer, messageBytes(record.message));
}
const isTerminal = (record) => TERMINAL_STATES.includes(record.state);
/**
* The next record for one transition. Only `state`, `updatedAt` (never backwards) and, once each, `signature`
* (prepared -> signed), `sendMarkedAt` (signed -> sendMarked) and `outcome` (to finalized/failed) may change.
*/
function transitionIntent(current, state, now, changes = {}) {
	if (!SOLANA_TRANSITIONS[current.state].includes(state)) return fail("CONFLICT");
	const updatedAt = Math.max(counter(now), current.updatedAt);
	const signature = changes.signature ?? current.signature;
	if (changes.signature !== void 0 && (current.state !== "prepared" || state !== "signed")) return fail("CONFLICT");
	const sendMarkedAt = state === "sendMarked" ? updatedAt : current.sendMarkedAt;
	const outcome = changes.outcome ?? current.outcome;
	return parseSolanaIntent({
		...current,
		binding: { ...current.binding },
		state,
		signature,
		sendMarkedAt,
		outcome: outcome === null ? null : { ...outcome },
		updatedAt
	});
}
const CODES = [
	"INVALID_INPUT",
	"UNSUPPORTED_VERSION",
	"UNSUPPORTED_PROVIDER",
	"WRONG_CHAIN",
	"UNAUTHORIZED",
	"USER_REJECTED",
	"LOCKED",
	"CONFLICT",
	"UNAVAILABLE",
	"TIMEOUT",
	"CANCELLED",
	"LIMIT_EXCEEDED",
	"INTEGRITY_FAILURE",
	"BROADCAST_UNKNOWN",
	"EXPIRED"
];
const UNCERTAIN = [
	"UNAVAILABLE",
	"TIMEOUT",
	"CANCELLED",
	"BROADCAST_UNKNOWN"
];
/** Raised when a journal write may or may not have committed. */
var UncertainWrite = class extends SolanaFailure {
	constructor() {
		super("UNAVAILABLE");
		this.name = "UncertainWrite";
	}
};
function own$1(input, key) {
	try {
		if (typeof input !== "object" || input === null) return fail();
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field || !("value" in field)) return fail();
		return field.value;
	} catch {
		return fail();
	}
}
/** A CoreResult from injected code, read through own data properties; foreign error detail is dropped. */
function portValue(result) {
	const ok = own$1(result, "ok");
	if (ok === true) return own$1(result, "value");
	if (ok !== false) return fail();
	const code = own$1(own$1(result, "error"), "code");
	return fail(CODES.includes(code) ? code : "UNAVAILABLE");
}
function revisionOf(input) {
	if (typeof input !== "number" || !Number.isSafeInteger(input) || input < 0) return fail();
	return input;
}
function checkedProfileId(journal) {
	let id;
	try {
		id = journal.profileId();
	} catch {
		return fail("LOCKED");
	}
	if (typeof id !== "string" || !/^[0-9a-f]{32}$/.test(id) || id === UNKNOWN_ORIGIN) return fail("LOCKED");
	return id;
}
/** Reads, validates and binds every record of one trade; duplicates or foreign records fail closed. */
async function loadIntents(journal, trade, signal) {
	let raw;
	try {
		raw = portValue(await journal.read(trade.binding, signal));
	} catch (error) {
		if (error instanceof SolanaFailure) throw error;
		return fail("UNAVAILABLE");
	}
	const revision = revisionOf(own$1(raw, "revision")), list = own$1(raw, "records");
	if (!Array.isArray(list) || list.length > 32) return fail("INTEGRITY_FAILURE");
	const records = [], ids = /* @__PURE__ */ new Set();
	for (let index = 0; index < list.length; index++) {
		let record;
		try {
			record = parseSolanaIntent(own$1(list, String(index)));
		} catch (error) {
			return fail(error instanceof SolanaFailure && error.code === "UNSUPPORTED_VERSION" ? "UNSUPPORTED_VERSION" : "INTEGRITY_FAILURE");
		}
		verifyIntentForTrade(record, trade);
		if (ids.has(record.intentId)) return fail("INTEGRITY_FAILURE");
		ids.add(record.intentId);
		records.push(record);
	}
	return Object.freeze({
		revision,
		records: Object.freeze(records)
	});
}
/** One CAS write. CONFLICT means another writer won; an `UncertainWrite` means the outcome is unknown. */
async function storeIntent(journal, trade, expectedRevision, record, signal) {
	let raw;
	try {
		raw = await journal.write(trade.binding, expectedRevision, record, signal);
	} catch {
		throw new UncertainWrite();
	}
	let next;
	try {
		next = revisionOf(portValue(raw));
	} catch (error) {
		const code = error instanceof SolanaFailure ? error.code : "UNAVAILABLE";
		if (UNCERTAIN.includes(code)) throw new UncertainWrite();
		throw error;
	}
	if (next <= expectedRevision) return fail("INTEGRITY_FAILURE");
	return next;
}
/**
* A new intent may join a trade only when every stored record is terminal. A rebuild after a definitive drop must
* name the dropped intent of the same action (`replacementOf`), and each dropped intent has at most one successor.
*/
function admitIntent(records, next) {
	if (records.length >= 32) return fail("LIMIT_EXCEEDED");
	if (records.some((record) => !isTerminal(record) || record.intentId === next.intentId)) return fail("CONFLICT");
	const latest = records.filter((record) => record.action === next.action).sort((a, b) => a.createdAt - b.createdAt).at(-1);
	const successors = new Set(records.map((record) => record.replacementOf).filter((id) => id !== null));
	if (next.replacementOf !== null) {
		const original = records.find((record) => record.intentId === next.replacementOf);
		if (!original || original.state !== "dropped" || original.action !== next.action || successors.has(original.intentId)) return fail("CONFLICT");
	} else if (latest?.state === "dropped" && !successors.has(latest.intentId)) return fail("CONFLICT");
}
/** The one sendTransaction configuration this client uses. */
const SEND_CONFIG = Object.freeze({
	encoding: "base64",
	skipPreflight: true,
	maxRetries: 0
});
/** One RPC request with a timeout; the result is boxed so no `then` of provider data is ever looked up. */
async function call(context, method, params, signal) {
	if (signal?.aborted) return fail("CANCELLED");
	const controller = new AbortController();
	let timer, onAbort;
	const stop = new Promise((resolve) => {
		timer = setTimeout(() => {
			resolve({ stop: "TIMEOUT" });
			controller.abort();
		}, context.timeoutMs);
		onAbort = () => {
			resolve({ stop: "CANCELLED" });
			controller.abort();
		};
		signal?.addEventListener("abort", onAbort, { once: true });
	});
	const physical = Promise.resolve().then(() => {
		context.assertActive?.();
		const rpc = context.rpc, request = rpc.request;
		context.assertActive?.();
		return Reflect.apply(request, rpc, [{
			method,
			params,
			signal: controller.signal
		}]);
	}).then((value) => ({ boxed: { value } }), () => ({ stop: "UNAVAILABLE" }));
	try {
		const raced = await Promise.race([physical, stop]);
		if ("stop" in raced) return fail(raced.stop);
		return raced.boxed;
	} finally {
		clearTimeout(timer);
		if (onAbort) signal?.removeEventListener("abort", onAbort);
	}
}
function own(input, key) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail();
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field || !("value" in field)) return fail();
		return field.value;
	} catch {
		return fail();
	}
}
function optionalOwn(input, key) {
	try {
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field) return void 0;
		return "value" in field ? field.value : fail();
	} catch {
		return fail();
	}
}
/** Plain dense array of at most `maximum` data elements. */
function ownArray(input, maximum) {
	try {
		if (!Array.isArray(input) || Object.getPrototypeOf(input) !== Array.prototype) return fail();
		const length = Object.getOwnPropertyDescriptor(input, "length")?.value;
		if (typeof length !== "number" || length > maximum || Reflect.ownKeys(input).length !== length + 1) return fail();
		return Array.from({ length }, (_, index) => {
			const field = Object.getOwnPropertyDescriptor(input, String(index));
			return field && "value" in field ? field.value : fail();
		});
	} catch {
		return fail();
	}
}
function safeInt(input) {
	if (typeof input !== "number" || !Number.isSafeInteger(input) || input < 0) return fail();
	return input;
}
function clockNow(context) {
	let now;
	try {
		now = context.clock.now();
	} catch {
		return fail("INVALID_INPUT");
	}
	if (typeof now !== "number" || !Number.isSafeInteger(now) || now < 0) return fail("INVALID_INPUT");
	return now;
}
function newIntentId(context) {
	let bytes;
	try {
		bytes = context.random(32);
	} catch {
		return fail("UNAVAILABLE");
	}
	if (!(bytes instanceof Uint8Array) || bytes.length !== 32 || bytes.every((byte) => byte === 0)) return fail();
	return encodeBase64(bytes).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}
function raiseFloor(context, binding, height) {
	if (height < (context.floors.get(binding.networkId) ?? 0)) return fail("INTEGRITY_FAILURE");
	context.floors.set(binding.networkId, height);
}
const NAME = /^[A-Za-z]{1,64}$/;
/** Compact label for a TransactionError (`InstructionError:<i>:Custom:<n>`, `<Name>`, or `Unrecognized`). */
function summarizeTransactionError(err) {
	try {
		if (typeof err === "string") return NAME.test(err) ? err : "Unrecognized";
		if (typeof err !== "object" || err === null || Array.isArray(err)) return "Unrecognized";
		const keys = Reflect.ownKeys(err), name = keys[0];
		if (keys.length !== 1 || typeof name !== "string" || !NAME.test(name)) return "Unrecognized";
		if (name !== "InstructionError") return name;
		const pair = ownArray(own(err, name), 2), index = pair[0], inner = pair[1];
		if (pair.length !== 2 || typeof index !== "number" || !Number.isInteger(index) || index < 0 || index > 255) return "Unrecognized";
		if (typeof inner === "string") return `InstructionError:${index}:${NAME.test(inner) ? inner : "Unrecognized"}`;
		const innerKeys = typeof inner === "object" && inner !== null ? Reflect.ownKeys(inner) : [];
		const custom = innerKeys.length === 1 && innerKeys[0] === "Custom" ? own(inner, "Custom") : void 0;
		if (typeof custom === "number" && Number.isInteger(custom) && custom >= 0 && custom <= 4294967295) return `InstructionError:${index}:Custom:${custom}`;
		return `InstructionError:${index}:Unrecognized`;
	} catch {
		return "Unrecognized";
	}
}
/**
* Finalized blockhash for a new message. getLatestBlockhash(finalized) must agree with getBlock at its context
* slot (same blockhash, lastValidBlockHeight = blockHeight + 150), be no older than the plan's snapshot, and the
* genesis hash must still match the registry.
*/
async function anchorBlockhash(context, trade, plan, signal) {
	const latest = (await call(context, "getLatestBlockhash", [{ commitment: "finalized" }], signal)).value;
	const slot = safeInt(own(own(latest, "context"), "slot")), value = own(latest, "value");
	const blockhash = canonicalKey(own(value, "blockhash")), lastValid = safeInt(own(value, "lastValidBlockHeight"));
	if (slot < Number(plan.snapshotSlot)) return fail();
	const block = (await call(context, "getBlock", [slot, {
		commitment: "finalized",
		transactionDetails: "none",
		rewards: false
	}], signal)).value;
	const height = safeInt(own(block, "blockHeight"));
	if (canonicalKey(own(block, "blockhash")) !== blockhash || height + 150 !== lastValid) return fail();
	if (height < Number(plan.snapshotBlockHeight)) return fail();
	if ((await call(context, "getGenesisHash", [], signal)).value !== trade.network.genesisHash) return fail("WRONG_CHAIN");
	raiseFloor(context, trade.binding, height);
	return {
		blockhash,
		slot,
		lastValidBlockHeight: lastValid
	};
}
/** Journals a `prepared` intent for a plan after the admission rule; nothing is signed yet. */
async function prepareIntent(context, trade, plan, replacementOf, signal) {
	const profile = checkedProfileId(context.journal);
	const loaded = await loadIntents(context.journal, trade, signal);
	const anchor = await anchorBlockhash(context, trade, plan, signal);
	const message = compilePlan(plan, anchor.blockhash), now = clockNow(context);
	const runtime = trade.deployment.runtime;
	if (runtime.kind !== "solana-program") return fail("UNSUPPORTED_PROVIDER");
	const record = parseSolanaIntent({
		format: SOLANA_INTENT_FORMAT,
		intentId: newIntentId(context),
		binding: { ...trade.binding },
		genesisHash: trade.network.genesisHash,
		programId: trade.deployment.address,
		programDataSha256: runtime.programDataSha256,
		escrow: trade.escrow.address,
		action: plan.action,
		role: plan.role,
		feePayer: plan.feePayer,
		expectedEscrowState: plan.expectedEscrowState,
		message: encodeBase64(message),
		blockhash: anchor.blockhash,
		blockhashSlot: String(anchor.slot),
		lastValidBlockHeight: String(anchor.lastValidBlockHeight),
		signature: null,
		state: "prepared",
		sendMarkedAt: null,
		outcome: null,
		replacementOf,
		originProfileId: profile,
		createdAt: now,
		updatedAt: now
	});
	verifyIntentForTrade(record, trade);
	admitIntent(loaded.records, record);
	context.assertActive?.();
	if (checkedProfileId(context.journal) !== profile) return fail("LOCKED");
	return {
		record,
		revision: await storeIntent(context.journal, trade, loaded.revision, record, signal)
	};
}
/**
* Validity of the ORIGINAL reviewed blockhash; this never requests a replacement blockhash or edits a message.
* Bracket the fresh finalized height and processed validity with genesis checks, and reject stale contexts.
*/
async function recheckPreparedBlockhash(context, trade, record, plan) {
	if (record.state !== "prepared" && record.state !== "signed" || record.sendMarkedAt !== null) return fail("CONFLICT");
	const genesis = async () => {
		if ((await call(context, "getGenesisHash", [])).value !== trade.network.genesisHash) return fail("WRONG_CHAIN");
	};
	await genesis();
	const height = safeInt((await call(context, "getBlockHeight", [{ commitment: "finalized" }])).value);
	if (height < Number(record.lastValidBlockHeight) - 150 || height < Number(plan.snapshotBlockHeight) || height < (context.floors.get(trade.binding.networkId) ?? 0)) return fail("INTEGRITY_FAILURE");
	if (height > Number(record.lastValidBlockHeight)) return fail("EXPIRED");
	const minimumSlot = Math.max(Number(record.blockhashSlot), Number(plan.snapshotSlot));
	const validity = (await call(context, "isBlockhashValid", [record.blockhash, {
		commitment: "processed",
		minContextSlot: minimumSlot
	}])).value;
	if (safeInt(own(own(validity, "context"), "slot")) < minimumSlot) return fail("INTEGRITY_FAILURE");
	const valid = own(validity, "value");
	if (typeof valid !== "boolean") return fail("INTEGRITY_FAILURE");
	await genesis();
	if (!valid) return fail("EXPIRED");
	context.assertActive?.();
	raiseFloor(context, trade.binding, height);
}
const MESSAGE_BASE64_CAP = Math.ceil(MAX_TRANSACTION_BYTES / 3) * 4;
const messageOf = (record) => decodeBase64(record.message, MESSAGE_BASE64_CAP);
/** Wallet signature for a `prepared` intent of this session, then the CAS to `signed`. */
async function signIntent(context, trade, stored, session) {
	const { record } = stored;
	if (record.state !== "prepared" || session.address !== record.feePayer || session.role !== record.role || session.tradeId !== trade.binding.tradeId) return fail("UNAUTHORIZED");
	const result = await signWithWallet(session, messageOf(record), context.assertActive);
	if (!result.ok) return fail(result.error.code);
	context.assertActive?.();
	const next = transitionIntent(record, "signed", clockNow(context), { signature: result.value.signature });
	return {
		record: next,
		revision: await storeIntent(context.journal, trade, stored.revision, next),
		signed: result.value
	};
}
/**
* Writes the durable marker, then sends exactly once. If the marker write fails or its outcome is unknown,
* nothing is sent (UNAVAILABLE; the stored record is `signed` or `sendMarked` and reconciles like any other).
* After the marker every send outcome is recorded as `sent` or `unknown`.
*/
async function markAndSend(context, trade, stored, signed) {
	const { record } = stored;
	if (record.state !== "signed" || record.signature !== signed.signature) return fail("CONFLICT");
	context.assertActive?.();
	const marked = transitionIntent(record, "sendMarked", clockNow(context));
	let revision;
	try {
		revision = await storeIntent(context.journal, trade, stored.revision, marked);
	} catch (error) {
		if (error instanceof UncertainWrite) return fail("UNAVAILABLE");
		throw error;
	}
	context.assertActive?.();
	let state = "unknown";
	try {
		if ((await call(context, "sendTransaction", [encodeBase64(signed.wire), SEND_CONFIG])).value === signed.signature) state = "sent";
	} catch {
		state = "unknown";
	}
	let after;
	try {
		after = transitionIntent(marked, state, clockNow(context));
		return {
			record: after,
			revision: await storeIntent(context.journal, trade, revision, after)
		};
	} catch {
		return {
			record: marked,
			revision
		};
	}
}
async function signatureStatus(context, record, signal, minimumSlot = Number(record.blockhashSlot)) {
	const raw = (await call(context, "getSignatureStatuses", [[record.signature], { searchTransactionHistory: true }], signal)).value;
	const contextSlot = safeInt(own(own(raw, "context"), "slot")), list = ownArray(own(raw, "value"), 1);
	if (list.length !== 1 || contextSlot < minimumSlot) return fail();
	const entry = list[0];
	if (entry === null) return null;
	const slot = safeInt(own(entry, "slot")), confirmations = own(entry, "confirmations");
	const level = optionalOwn(entry, "confirmationStatus");
	if (level !== "processed" && level !== "confirmed" && level !== "finalized") return fail();
	if (confirmations !== null) safeInt(confirmations);
	if (slot > contextSlot || slot <= Number(record.blockhashSlot)) return fail();
	if (level === "finalized" !== (confirmations === null)) return fail();
	return {
		finalized: level === "finalized",
		slot,
		err: own(entry, "err") === null ? null : summarizeTransactionError(own(entry, "err"))
	};
}
const fromStatus = (status) => status.finalized ? {
	kind: "landed",
	slot: String(status.slot),
	err: status.err
} : { kind: "open" };
/** Collects evidence without mutating the network height floor before its final identity check. */
async function observeEvidence(context, record, signal) {
	if (record.signature !== null) {
		const status = await signatureStatus(context, record, signal);
		if (status !== null) return {
			observation: fromStatus(status),
			height: null
		};
	}
	const height = safeInt((await call(context, "getBlockHeight", [{ commitment: "finalized" }], signal)).value);
	if (height < (context.floors.get(record.binding.networkId) ?? 0)) return fail("INTEGRITY_FAILURE");
	let evidenceHeight = height;
	const observed = (observation) => ({
		observation,
		height: evidenceHeight
	});
	if (BigInt(height) <= BigInt(record.lastValidBlockHeight)) return observed({ kind: "open" });
	const finalized = (await call(context, "isBlockhashValid", [record.blockhash, {
		commitment: "finalized",
		minContextSlot: Number(record.blockhashSlot)
	}], signal)).value;
	const finalizedSlot = safeInt(own(own(finalized, "context"), "slot"));
	if (finalizedSlot < Number(record.blockhashSlot) || own(finalized, "value") !== false) return fail();
	const block = (await call(context, "getBlock", [finalizedSlot, {
		commitment: "finalized",
		transactionDetails: "none",
		rewards: false
	}], signal)).value;
	evidenceHeight = safeInt(own(block, "blockHeight"));
	if (evidenceHeight < height || BigInt(evidenceHeight) <= BigInt(record.lastValidBlockHeight)) return fail();
	const validity = (await call(context, "isBlockhashValid", [record.blockhash, {
		commitment: "processed",
		minContextSlot: finalizedSlot
	}], signal)).value;
	if (safeInt(own(own(validity, "context"), "slot")) < finalizedSlot) return fail();
	if (own(validity, "value") !== false) return fail();
	if (safeInt((await call(context, "getFirstAvailableBlock", [], signal)).value) > Number(record.blockhashSlot)) return observed({ kind: "open" });
	if (record.signature !== null) {
		const status = await signatureStatus(context, record, signal, finalizedSlot);
		if (status !== null) return observed(fromStatus(status));
	}
	return observed({ kind: "dropped" });
}
/**
* Native reconciliation never sends. Genesis brackets every observation, including absence and failed statuses:
* switching networks must not turn uncertainty into a terminal record or poison the correct network's floor.
*/
async function observeIntent(context, trade, record, signal) {
	const identity = async () => {
		if ((await call(context, "getGenesisHash", [], signal)).value !== trade.network.genesisHash) fail("WRONG_CHAIN");
	};
	await identity();
	let evidence;
	try {
		evidence = await observeEvidence(context, record, signal);
	} catch (error) {
		await identity();
		throw error;
	}
	await identity();
	if (evidence.height !== null) raiseFloor(context, trade.binding, evidence.height);
	return evidence.observation;
}
/** CAS write of a terminal observation; an open observation changes nothing. */
async function applyObservation(context, trade, stored, observation) {
	if (observation.kind === "open") return stored;
	const now = clockNow(context);
	const next = observation.kind === "dropped" ? transitionIntent(stored.record, "dropped", now) : transitionIntent(stored.record, observation.err === null ? "finalized" : "failed", now, { outcome: {
		slot: observation.slot,
		err: observation.err
	} });
	return {
		record: next,
		revision: await storeIntent(context.journal, trade, stored.revision, next)
	};
}
/** Local cancel of a never-marked intent this profile wrote. */
async function cancelIntent(context, trade, stored) {
	const { record } = stored;
	if (record.state !== "prepared" && record.state !== "signed" || record.sendMarkedAt !== null || record.originProfileId !== checkedProfileId(context.journal)) return fail("CONFLICT");
	const next = transitionIntent(record, "cancelled", clockNow(context));
	return {
		record: next,
		revision: await storeIntent(context.journal, trade, stored.revision, next)
	};
}
// packages/chain-solana/src/compose.ts
/**
* Composition entry point for the Solana escrow client; wallet, RPC and encrypted journal are injected.
*
*   const client = createSolanaEscrowClient({ rpc, wallet, journal, registry, clock, margins, walletChain });
*   const trade = client.bind(binding, terms);              // G16 terms bound to one registry deployment
*   const seller = await client.connect(trade, 'seller');   // explicit, user-triggered wallet connect
*   const review = await client.prepare(trade, seller, 'release'); // journal exact bytes, no wallet prompt
*   await client.confirm(review.value, seller);             // explicit review confirmation, one-shot capability
*   await client.reconcile(trade);                          // poll until the intent is terminal
*   await client.payout(trade, seller);                     // only after a finalized Released/Refunded read
*
* Every action reads a fresh finalized snapshot, plans against it, journals `prepared`, has the wallet sign,
* journals the signature and the durable marker, then sends once. `recover` runs at startup: it cancels this
* profile's never-marked preparations and reconciles everything else from chain state. Nothing ever resends.
* `margins` are required: the default policy is chosen elsewhere, never here. A host MUST dispose this client
* synchronously on wallet account/chain/disconnect changes; Wallet Standard sessions cannot observe them here.
* A pending physical wallet prompt keeps its serial slot until it settles, even after cancellation/disposal.
*/
const failure = (code) => ({
	ok: false,
	error: createCoreError(code, {
		operationId: createOperationId(),
		readOnly: false
	})
});
const value = (result) => result.ok ? result.value : fail(result.error.code);
const codeOf = (error) => error instanceof UncertainWrite ? "UNAVAILABLE" : error instanceof SolanaFailure ? error.code : "UNAVAILABLE";
const isLocalPreMarker = (record, profile) => (record.state === "prepared" || record.state === "signed") && record.sendMarkedAt === null && record.originProfileId === profile;
/** Capture user review options before the first await; no provider getter or later mutation can change them. */
function reviewOptions(input) {
	let raw;
	try {
		const keys = Reflect.ownKeys(input);
		if (keys.some((key) => typeof key !== "string" || ![
			"createAta",
			"maxRentTopUpLamports",
			"rebuildOf"
		].includes(key))) return fail("INVALID_INPUT");
		raw = exactData(input, keys);
	} catch {
		return fail("INVALID_INPUT");
	}
	const copy = {};
	if (raw.createAta !== void 0) {
		if (typeof raw.createAta !== "boolean") return fail("INVALID_INPUT");
		copy.createAta = raw.createAta;
	}
	if (raw.maxRentTopUpLamports !== void 0) {
		decimalU64(raw.maxRentTopUpLamports);
		copy.maxRentTopUpLamports = raw.maxRentTopUpLamports;
	}
	if (raw.rebuildOf !== void 0) {
		if (typeof raw.rebuildOf !== "string") return fail("INVALID_INPUT");
		copy.rebuildOf = raw.rebuildOf;
	}
	return Object.freeze(copy);
}
/** Capture the funding source and replacement identity before enqueueing any asynchronous work. */
function fundingReviewOptions(input) {
	try {
		const keys = Reflect.ownKeys(input);
		if (keys.length > 2 || keys.some((key) => typeof key !== "string" || !["sellerTokenAccount", "rebuildOf"].includes(key))) return fail("INVALID_INPUT");
		const raw = exactData(input, keys);
		const copy = {};
		if (raw.sellerTokenAccount !== void 0) copy.sellerTokenAccount = canonicalKey(raw.sellerTokenAccount, "INVALID_INPUT");
		if (raw.rebuildOf !== void 0) copy.rebuildOf = parseIntentId(raw.rebuildOf);
		return Object.freeze(copy);
	} catch {
		return fail("INVALID_INPUT");
	}
}
/** Ignore only fields a legitimate intent transition can change; all reviewed identity/bytes stay exact. */
function samePreparation(first, second) {
	const original = (record) => ({
		...record,
		state: "prepared",
		signature: null,
		sendMarkedAt: null,
		outcome: null,
		updatedAt: record.createdAt
	});
	return JSON.stringify(original(first)) === JSON.stringify(original(second));
}
/** The finalized effect a successful intent must have left (corroborates a "finalized, no error" status). */
function effectVisible(record, snapshot) {
	const escrow = snapshot.escrow;
	if (escrow === null) return false;
	if (record.action === "fund") return true;
	if (record.action === "release") return escrow.state === "released";
	if (record.action === "refund") return escrow.state === "refunded";
	return escrow.paidOut && escrow.state === record.expectedEscrowState;
}
function createSolanaEscrowClient(options) {
	const { rpc, wallet, journal, registry, clock, walletChain } = options;
	const margins = parseMargins(options.margins);
	const timeoutMs = options.timeoutMs ?? 1e4;
	if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 6e4) fail("INVALID_INPUT");
	const random = options.random ?? ((length) => crypto.getRandomValues(new Uint8Array(length)));
	const reader = new SolanaChainReader({
		rpc,
		registry,
		timeoutMs,
		now: () => clock.now(),
		freezeAuthorityPermits: options.freezeAuthorityPermits ?? []
	});
	let disposed = false, sequence = 0;
	const assertActive = () => {
		if (disposed) fail("CANCELLED");
		checkedProfileId(journal);
	};
	const context = {
		rpc,
		journal,
		clock,
		random,
		timeoutMs,
		floors: /* @__PURE__ */ new Map(),
		assertActive
	};
	const locks = /* @__PURE__ */ new Map();
	const sessions = /* @__PURE__ */ new WeakMap();
	const preparations = /* @__PURE__ */ new WeakMap();
	/** One operation per trade at a time in this instance; other tabs are fenced by the journal CAS. */
	function serialized(trade, work) {
		if (disposed) return Promise.resolve(failure("CANCELLED"));
		if (!isBoundSolanaTrade(trade)) return Promise.resolve(failure("INVALID_INPUT"));
		const key = `${trade.binding.networkId}:${trade.binding.deploymentId}:${trade.binding.tradeId}`;
		const run = (locks.get(key) ?? Promise.resolve()).then(async () => {
			if (disposed) return failure("CANCELLED");
			try {
				return {
					ok: true,
					value: await work()
				};
			} catch (error) {
				return failure(codeOf(error));
			}
		});
		locks.set(key, run.then(() => void 0));
		return run;
	}
	const request = () => ({
		generation: 0,
		requestSequence: ++sequence,
		signal: new AbortController().signal
	});
	const read = async (trade) => value(await readTrustedSnapshot(reader, trade, request()));
	async function cancelLocal(trade, original) {
		try {
			if (checkedProfileId(journal) !== original.originProfileId) return;
			const loaded = await loadIntents(journal, trade);
			const record = loaded.records.find((entry) => entry.intentId === original.intentId);
			if (record && samePreparation(record, original) && isLocalPreMarker(record, checkedProfileId(journal))) await cancelIntent(context, trade, {
				record,
				revision: loaded.revision
			});
		} catch {}
	}
	function checkSession(trade, session, own = false) {
		if (!isWalletSession(session) || session.tradeId !== trade.binding.tradeId) return fail("UNAUTHORIZED");
		if (session.chain !== walletChain) return fail("WRONG_CHAIN");
		if (own) {
			const connected = sessions.get(session);
			if (!connected || connected.binding.networkId !== trade.binding.networkId || connected.binding.deploymentId !== trade.binding.deploymentId || connected.binding.tradeId !== trade.binding.tradeId) return fail("UNAUTHORIZED");
			if (connected.profileId !== checkedProfileId(journal)) return fail("LOCKED");
		}
	}
	async function submitPrepared(trade, session, original, active, revalidate) {
		let stored = original, signed;
		try {
			active.assertActive?.();
			if (revalidate) stored = await revalidate(stored);
			active.assertActive?.();
			const result = await signIntent(active, trade, stored, session);
			stored = result;
			signed = result.signed;
			active.assertActive?.();
			if (revalidate) stored = await revalidate(stored);
			active.assertActive?.();
		} catch (error) {
			await cancelLocal(trade, original.record);
			throw error;
		}
		stored = await markAndSend(active, trade, stored, signed);
		return Object.freeze({
			intentId: stored.record.intentId,
			signature: signed.signature,
			state: stored.record.state
		});
	}
	async function act(trade, session, rebuildOf, plan) {
		checkSession(trade, session);
		const planned = value(plan(await read(trade)));
		if (planned.role !== session.role || planned.feePayer !== session.address) return fail("UNAUTHORIZED");
		const stored = await prepareIntent(context, trade, planned, rebuildOf ?? null);
		return submitPrepared(trade, session, stored, {
			...context,
			assertActive: () => {
				assertActive();
				if (checkedProfileId(journal) !== stored.record.originProfileId) fail("LOCKED");
			}
		});
	}
	async function prepareReview(trade, session, action, extra) {
		assertActive();
		checkSession(trade, session, true);
		const profile = checkedProfileId(journal);
		let preparation;
		const active = {
			...context,
			assertActive: () => {
				assertActive();
				if (checkedProfileId(journal) !== profile) fail("LOCKED");
				if (preparation?.revoked) fail("CANCELLED");
				checkSession(trade, session, true);
			}
		};
		const plan = (snapshot) => action === "fund" ? planFund(trade, snapshot, session.role, margins, extra) : action === "release" ? planRelease(trade, snapshot, session.role, margins) : action === "refund" ? planRefund(trade, snapshot, session.role, margins) : planPayout(trade, snapshot, session.role, extra);
		const planned = value(plan(await read(trade)));
		active.assertActive?.();
		if (planned.role !== session.role || planned.feePayer !== session.address) return fail("UNAUTHORIZED");
		const stored = await prepareIntent(active, trade, planned, extra.rebuildOf ?? null);
		try {
			active.assertActive?.();
		} catch (error) {
			await cancelLocal(trade, stored.record);
			throw error;
		}
		preparation = {
			trade,
			session,
			stored,
			plan,
			context: active,
			status: "prepared",
			revoked: false
		};
		const record = stored.record;
		const view = Object.freeze({
			intentId: record.intentId,
			action,
			role: record.role,
			feePayer: record.feePayer,
			binding: Object.freeze({ ...record.binding }),
			programId: record.programId,
			escrow: record.escrow,
			expectedEscrowState: record.expectedEscrowState,
			message: record.message,
			blockhash: record.blockhash,
			lastValidBlockHeight: record.lastValidBlockHeight,
			shape: Object.freeze({ ...planned.shape })
		});
		preparations.set(view, preparation);
		return view;
	}
	async function revalidateReview(preparation, stored) {
		const { trade, context: active } = preparation;
		active.assertActive?.();
		const loaded = await loadIntents(journal, trade);
		active.assertActive?.();
		const record = loaded.records.find((entry) => entry.intentId === stored.record.intentId);
		if (!record || !samePreparation(record, preparation.stored.record)) return fail("INTEGRITY_FAILURE");
		if (record.state !== stored.record.state || record.signature !== stored.record.signature || !isLocalPreMarker(record, preparation.stored.record.originProfileId)) return fail("CONFLICT");
		const planned = value(preparation.plan(await read(trade)));
		active.assertActive?.();
		if (planned.role !== record.role || planned.feePayer !== record.feePayer || planned.action !== record.action || planned.expectedEscrowState !== record.expectedEscrowState || encodeBase64(compilePlan(planned, record.blockhash)) !== record.message) return fail("CONFLICT");
		await recheckPreparedBlockhash(active, trade, record, planned);
		active.assertActive?.();
		return {
			record,
			revision: loaded.revision
		};
	}
	function confirm(prepared, session) {
		const preparation = preparations.get(prepared);
		if (!preparation) return Promise.resolve(failure("UNAUTHORIZED"));
		if (preparation.status !== "prepared" || preparation.revoked) return Promise.resolve(failure("CONFLICT"));
		preparation.status = "confirming";
		return serialized(preparation.trade, async () => {
			try {
				return await submitPrepared(preparation.trade, preparation.session, preparation.stored, preparation.context, (stored) => {
					if (session !== preparation.session) return Promise.reject(new SolanaFailure("UNAUTHORIZED"));
					return revalidateReview(preparation, stored);
				});
			} finally {
				preparation.status = "consumed";
			}
		});
	}
	function cancel(prepared) {
		const preparation = preparations.get(prepared);
		if (!preparation) return Promise.resolve(failure("UNAUTHORIZED"));
		if (preparation.status === "consumed" || preparation.revoked) return Promise.resolve(failure("CONFLICT"));
		preparation.revoked = true;
		return serialized(preparation.trade, async () => {
			try {
				assertActive();
				const original = preparation.stored.record;
				if (checkedProfileId(journal) !== original.originProfileId) return fail("LOCKED");
				const loaded = await loadIntents(journal, preparation.trade);
				const record = loaded.records.find((entry) => entry.intentId === original.intentId);
				if (!record || !samePreparation(record, original)) return fail("INTEGRITY_FAILURE");
				if (checkedProfileId(journal) !== original.originProfileId) return fail("LOCKED");
				if (record.state === "cancelled") return;
				if (!isLocalPreMarker(record, original.originProfileId)) return fail("CONFLICT");
				await cancelIntent(context, preparation.trade, {
					record,
					revision: loaded.revision
				});
			} finally {
				preparation.status = "consumed";
			}
		});
	}
	async function reconcileAll(trade) {
		const profile = checkedProfileId(journal);
		let loaded = await loadIntents(journal, trade), revision = loaded.revision;
		for (const record of loaded.records) {
			if (isTerminal(record) || isLocalPreMarker(record, profile)) continue;
			const observation = await observeIntent(context, trade, record);
			if (observation.kind === "landed" && observation.err === null) {
				const snapshot = await read(trade);
				if (BigInt(snapshot.live.height) < BigInt(observation.slot)) continue;
				if (!effectVisible(record, snapshot)) return fail("INTEGRITY_FAILURE");
			}
			revision = (await applyObservation(context, trade, {
				record,
				revision
			}, observation)).revision;
		}
		loaded = await loadIntents(journal, trade);
		return loaded.records;
	}
	return Object.freeze({
		bind: (binding, terms) => bindSolanaTrade(registry, binding, terms),
		connect: async (trade, role) => {
			try {
				assertActive();
				const profileId = checkedProfileId(journal);
				const result = await connectWalletRole(wallet, trade, role, walletChain);
				assertActive();
				if (checkedProfileId(journal) !== profileId) return failure("LOCKED");
				if (result.ok) sessions.set(result.value, {
					binding: trade.binding,
					profileId
				});
				return result;
			} catch (error) {
				return failure(codeOf(error));
			}
		},
		read: (trade) => serialized(trade, () => read(trade)),
		prepare: (trade, session, action, extra = {}) => {
			try {
				if (action !== "release" && action !== "refund" && action !== "payout") return Promise.resolve(failure("INVALID_INPUT"));
				const captured = reviewOptions(extra);
				return serialized(trade, () => prepareReview(trade, session, action, captured));
			} catch (error) {
				return Promise.resolve(failure(codeOf(error)));
			}
		},
		prepareFunding: (trade, session, extra = {}) => {
			try {
				const captured = fundingReviewOptions(extra);
				return serialized(trade, () => prepareReview(trade, session, "fund", captured));
			} catch (error) {
				return Promise.resolve(failure(codeOf(error)));
			}
		},
		confirm,
		cancel,
		fund: (trade, session, extra = {}) => serialized(trade, () => act(trade, session, extra.rebuildOf, (snapshot) => planFund(trade, snapshot, session.role, margins, extra))),
		release: (trade, session, extra = {}) => serialized(trade, () => act(trade, session, extra.rebuildOf, (snapshot) => planRelease(trade, snapshot, session.role, margins))),
		refund: (trade, session, extra = {}) => serialized(trade, () => act(trade, session, extra.rebuildOf, (snapshot) => planRefund(trade, snapshot, session.role, margins))),
		payout: (trade, session, extra = {}) => serialized(trade, () => act(trade, session, extra.rebuildOf, (snapshot) => planPayout(trade, snapshot, session.role, extra))),
		reconcile: (trade) => serialized(trade, () => reconcileAll(trade)),
		recover: (trade) => serialized(trade, async () => {
			const profile = checkedProfileId(journal), loaded = await loadIntents(journal, trade);
			let revision = loaded.revision;
			for (const record of loaded.records) {
				if (!isLocalPreMarker(record, profile)) continue;
				revision = (await cancelIntent(context, trade, {
					record,
					revision
				})).revision;
			}
			return reconcileAll(trade);
		}),
		intents: (trade) => serialized(trade, async () => (await loadIntents(journal, trade)).records),
		dispose: () => {
			if (!disposed) {
				disposed = true;
				reader.dispose();
			}
		}
	});
}
// contracts/solana/localnet/client-run.mjs
const HERE = dirname(fileURLToPath(import.meta.url));
const SOLANA_DIR = resolve(HERE, "..");
const ALLOWED_ROOTS = [resolve(SOLANA_DIR, "../.."), tmpdir()];
const SO_PATH = join(SOLANA_DIR, "target/deploy/basic_escrow.so");
const OFFSET = Number(process.env.SOLANA_LOCALNET_PORT_OFFSET ?? 400);
if (!Number.isInteger(OFFSET) || OFFSET < 0 || OFFSET > 1e3) throw new Error("SOLANA_LOCALNET_PORT_OFFSET: 0..1000");
const PORTS = {
	rpc: 18899 + OFFSET,
	faucet: 19900 + OFFSET,
	gossip: 18001 + OFFSET,
	dynamic: `${18002 + OFFSET}-${18030 + OFFSET}`
};
const RPC_URL = `http://127.0.0.1:${PORTS.rpc}`;
const WORKDIR = confinedPath(process.env.SOLANA_LOCALNET_DIR ?? mkdtempSync(join(tmpdir(), "p2p-offramp-client-")), ALLOWED_ROOTS);
const SKIP_REFUND = process.env.SOLANA_CLIENT_SKIP_REFUND === "1";
const COMPILED_GENESIS = base58Encode(utf8$1(GENESIS_HASH_ASCII));
const CHAIN = "solana:localnet";
const MARGINS = {
	submitMarginSeconds: "60",
	releaseMarginSeconds: "600"
};
const REFUND_MARGINS = {
	submitMarginSeconds: "10",
	releaseMarginSeconds: "600"
};
const AMOUNTS = {
	native: 4e8,
	spl: 25e6,
	splMinted: 1e8,
	refund: 3e8
};
const DESTINATION_FROZEN = "InstructionError:1:Custom:6016";
const rpc = new Rpc(RPC_URL);
const t0 = Date.now();
const summary = {
	ok: false,
	startedAt: new Date(t0).toISOString(),
	workdir: WORKDIR,
	rpc: RPC_URL,
	validator: {},
	program: {},
	flows: {},
	sendCounts: {},
	cliDecode: null,
	checks: [],
	deviations: ["getGenesisHash answered with the compiled synthetic genesis constant (localnet-only shim; see header)"],
	error: null
};
const keys = {};
let validator = null;
const log = (...a) => console.error(`[${(/* @__PURE__ */ new Date()).toISOString()}]`, ...a);
function check(name, ok, detail) {
	summary.checks.push({
		name,
		ok: Boolean(ok),
		detail: detail ?? null
	});
	log(`${ok ? "PASS" : "FAIL"} ${name}${detail === void 0 ? "" : " " + JSON.stringify(detail)}`);
	return Boolean(ok);
}
function must(name, ok, detail) {
	if (!check(name, ok, detail)) throw new Error(`fatal expectation failed: ${name}`);
}
const eq = (name, actual, expected) => check(name, actual === expected, {
	actual,
	expected
});
const unwrap = (label, result) => {
	if (!result.ok) throw new Error(`${label}: ${result.error.code}`);
	return result.value;
};
function run(cmd, args, { allowFail = false, timeoutMs = 18e4 } = {}) {
	log(`$ ${cmd} ${args.join(" ")}`);
	const r = spawnSync(resolveTool(cmd), args, {
		encoding: "utf8",
		timeout: timeoutMs,
		maxBuffer: 16777216
	});
	if (r.error) throw new Error(`${cmd}: ${r.error.message}`);
	const res = {
		status: r.status,
		stdout: (r.stdout ?? "").trim(),
		stderr: (r.stderr ?? "").trim()
	};
	if (!allowFail && r.status !== 0) throw new Error(`${cmd} ${args[0]} exited ${r.status}: ${res.stderr || res.stdout}`);
	return res;
}
const cli = (args, opts) => run("solana", [
	...args,
	"--url",
	RPC_URL,
	"--keypair",
	keys.payerPath,
	"--commitment",
	"confirmed"
], opts);
function killValidatorSync() {
	if (validator && validator.exitCode === null && validator.signalCode === null) validator.kill("SIGKILL");
}
process.on("exit", killValidatorSync);
for (const sig of [
	"SIGINT",
	"SIGTERM",
	"SIGHUP"
]) process.on(sig, () => {
	killValidatorSync();
	process.exit(1);
});
async function startValidator() {
	const dir = join(WORKDIR, "accounts");
	mkdirSync(dir, { recursive: true });
	const mintFiles = [[OPEN_MINT, null], [FREEZABLE_MINT, keys.mintAuthority.address]].map(([mint, freeze], i) => {
		const path = join(dir, `mint-${i}.json`);
		writeFileSync(path, JSON.stringify(mintAccountFile(mint, {
			mintAuthority: keys.mintAuthority.address,
			freezeAuthority: freeze,
			decimals: 6,
			lamports: 1461600
		})));
		return path;
	});
	const args = [
		"--ledger",
		join(WORKDIR, "ledger"),
		"--reset",
		"--quiet",
		"--bind-address",
		"127.0.0.1",
		"--rpc-port",
		String(PORTS.rpc),
		"--faucet-port",
		String(PORTS.faucet),
		"--gossip-port",
		String(PORTS.gossip),
		"--dynamic-port-range",
		PORTS.dynamic,
		"--mint",
		keys.payer.address,
		"--upgradeable-program",
		PROGRAM_ID,
		SO_PATH,
		keys.authority.address,
		...mintFiles.flatMap((f) => [
			"--account",
			"-",
			f
		])
	];
	const out = openSync(join(WORKDIR, "validator.out"), "w");
	log(`$ solana-test-validator ${args.join(" ")}`);
	validator = spawn(resolveTool("solana-test-validator"), args, { stdio: [
		"ignore",
		out,
		out
	] });
	closeSync(out);
	const started = Date.now();
	for (;;) {
		if (validator.exitCode !== null) throw new Error(`validator exited early (${validator.exitCode})`);
		try {
			if (await rpc.call("getHealth") === "ok" && await rpc.call("getSlot", [{ commitment: "finalized" }]) > 0) break;
		} catch {}
		if (Date.now() - started > 9e4) throw new Error("validator not healthy within 90 s");
		await sleep(500);
	}
	const version = await rpc.call("getVersion");
	must("validator reports solana-core 4.1.2", version["solana-core"] === "4.1.2", version);
	summary.validator = {
		version,
		realGenesisHash: await rpc.call("getGenesisHash")
	};
}
async function finalizeProgram() {
	cli([
		"program",
		"set-upgrade-authority",
		PROGRAM_ID,
		"--final",
		"--upgrade-authority",
		keys.authorityPath
	]);
	const pd = programDataAddress$1(PROGRAM_ID), stop = Date.now() + 12e4;
	for (;;) {
		const acc = await getAccount(rpc, pd, "finalized");
		if (acc && decodeProgramDataHeader(acc.data).upgradeAuthority === null) {
			summary.program = {
				id: PROGRAM_ID,
				programData: pd,
				length: acc.data.length
			};
			return acc.data.length;
		}
		if (Date.now() > stop) throw new Error("upgrade authority still set at finalized");
		await sleep(1e3);
	}
}
const sendLog = [];
const signLog = [];
const rpcPort = { async request({ method, params = [], signal }) {
	if (method === "getGenesisHash") return COMPILED_GENESIS;
	if (method === "sendTransaction") sendLog.push(params[0]);
	const json = await (await fetch(RPC_URL, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify({
			jsonrpc: "2.0",
			id: 1,
			method,
			params
		}),
		signal
	})).json();
	if (json.error) throw new Error(`rpc ${method} error ${json.error.code}`);
	return json.result;
} };
function keypairWallet(pairs) {
	const accounts = pairs.map((p) => ({
		address: p.address,
		publicKey: p.publicKey,
		chains: [CHAIN],
		features: ["standard:connect", "solana:signTransaction"]
	}));
	return { features: {
		"standard:connect": {
			version: "1.0.0",
			connect: async () => ({ accounts })
		},
		"solana:signTransaction": {
			version: "1.0.0",
			supportedTransactionVersions: ["legacy"],
			async signTransaction(input) {
				const wire = input.transaction, message = wire.slice(1 + 64 * wire[0]);
				signLog.push({
					address: input.account.address,
					message: encodeBase64(message)
				});
				const pair = pairs.find((p) => p.address === input.account.address);
				return [{ signedTransaction: Uint8Array.from([
					1,
					...ed25519.sign(message, pair.seed),
					...message
				]) }];
			}
		}
	} };
}
function casJournal(profileId, initial = /* @__PURE__ */ new Map()) {
	let store = initial;
	const hooks = {};
	const keyOf = (b) => `${b.networkId}|${b.deploymentId}|${b.tradeId}`;
	const entry = (b) => store.get(keyOf(b)) ?? {
		revision: 0,
		records: /* @__PURE__ */ new Map()
	};
	return {
		hooks,
		backup: () => structuredClone(store),
		journal: {
			profileId: () => profileId,
			async read(binding) {
				const e = entry(binding);
				return {
					ok: true,
					value: {
						revision: e.revision,
						records: [...e.records.values()].map((r) => structuredClone(r))
					}
				};
			},
			async write(binding, expected, record) {
				const e = entry(binding);
				if (e.revision !== expected) return {
					ok: false,
					error: { code: "CONFLICT" }
				};
				e.records.set(record.intentId, structuredClone(record));
				e.revision++;
				store.set(keyOf(binding), e);
				if (hooks.after?.(record) === "crash") throw new Error("simulated crash after commit");
				return {
					ok: true,
					value: e.revision
				};
			}
		}
	};
}
function registry() {
	const network = {
		id: "solana-localnet",
		chain: "solana",
		chainIdentity: COMPILED_GENESIS,
		genesisHash: COMPILED_GENESIS,
		endpoints: [],
		finality: {
			kind: "solana-commitment",
			commitment: "finalized"
		},
		environment: "local",
		deployments: [],
		assets: [
			{
				id: "sol",
				kind: "native",
				address: null,
				decimals: 9,
				transferPolicy: "exact-transfer"
			},
			{
				id: "usd6",
				kind: "spl",
				address: OPEN_MINT,
				decimals: 6,
				transferPolicy: "exact-transfer"
			},
			{
				id: "usd6f",
				kind: "spl",
				address: FREEZABLE_MINT,
				decimals: 6,
				transferPolicy: "exact-transfer"
			}
		]
	};
	const deployment = {
		id: "escrow-v1",
		address: PROGRAM_ID,
		protocolVersion: 1,
		artifactSha256: "0".repeat(64),
		runtime: {
			kind: "solana-program",
			programDataSha256: summary.program.pin,
			upgradeAuthority: null
		},
		supportedAssetIds: [
			"sol",
			"usd6",
			"usd6f"
		]
	};
	return {
		network: (id) => id === network.id ? network : null,
		deployment: (n, id) => n === network.id && id === deployment.id ? deployment : null
	};
}
function makeClient(journal, margins = MARGINS) {
	return createSolanaEscrowClient({
		rpc: rpcPort,
		wallet: keypairWallet([
			keys.seller,
			keys.buyer,
			keys.refundSeller
		]),
		journal,
		registry: registry(),
		clock: { now: () => Date.now() },
		margins,
		walletChain: CHAIN,
		freezeAuthorityPermits: [{
			mint: FREEZABLE_MINT,
			freezeAuthority: keys.mintAuthority.address
		}],
		random: (n) => Uint8Array.from(randomBytes(n)),
		timeoutMs: 15e3
	});
}
const hex = (bytes) => Buffer.from(bytes).toString("hex");
async function newTerms(seller, buyer, { mint = null, amount, expiryOffset }) {
	const clock = await readClock(rpc, "processed");
	return {
		genesisHash: COMPILED_GENESIS,
		programId: PROGRAM_ID,
		orderId: hex(randomBytes(32)),
		seller,
		buyer,
		assetKind: mint ? "spl" : "native",
		mint,
		tokenProgram: mint ? SPL_PROGRAM_ID$1 : null,
		privateAgreementHash: hex(sha256$1(utf8$1(`agreement-${Date.now()}`))),
		capabilitiesHash: hex(sha256$1(Uint8Array.of(0))),
		sellerNonce: hex(randomBytes(32)),
		revision: "1",
		amountBaseUnits: String(amount),
		acceptBeforeSeconds: String(clock.unixTimestamp + 600),
		escrowExpirySeconds: String(clock.unixTimestamp + expiryOffset)
	};
}
const bindingOf = (terms) => ({
	chain: "solana",
	networkId: "solana-localnet",
	deploymentId: "escrow-v1",
	tradeId: hex(sha256$1(encodeSolanaTerms(terms)))
});
/** Polls reconcile until the intent is terminal. */
async function settle(client, trade, intentId, label, timeoutMs = 18e4) {
	const stop = Date.now() + timeoutMs;
	for (;;) {
		const record = unwrap(`${label} reconcile`, await client.reconcile(trade)).find((r) => r.intentId === intentId);
		if ([
			"finalized",
			"failed",
			"dropped",
			"cancelled"
		].includes(record.state)) {
			log(`${label}: ${record.state} ${JSON.stringify(record.outcome)}`);
			return record;
		}
		if (Date.now() > stop) throw new Error(`${label}: not terminal after ${timeoutMs} ms (${record.state})`);
		await sleep(1500);
	}
}
async function act(client, trade, label, call) {
	const submission = unwrap(label, await call());
	eq(`${label}: send answered with the journaled signature`, submission.state, "sent");
	return {
		submission,
		record: await settle(client, trade, submission.intentId, label)
	};
}
const snapshot = async (client, trade, label) => unwrap(`${label} read`, await client.read(trade));
const sendsFor = (signature) => sendLog.filter((w) => base58Encode(Buffer.from(w, "base64").subarray(1, 65)) === signature).length;
/** Reviews one funding message before confirming it through the existing finalized reconciliation path. */
async function reviewedFund(client, trade, session, label, sellerTokenAccount = null) {
	const signsBefore = signLog.length, sendsBefore = sendLog.length;
	const options = sellerTokenAccount === null ? void 0 : { sellerTokenAccount };
	const prepared = unwrap(`${label} prepare`, await client.prepareFunding(trade, session, options));
	must(`${label}: preparation never signs or sends`, signLog.length === signsBefore && sendLog.length === sendsBefore);
	must(`${label}: reviewed data is immutable`, Object.isFrozen(prepared) && Object.isFrozen(prepared.binding) && Object.isFrozen(prepared.shape));
	must(`${label}: review binds seller funding to this absent escrow`, prepared.action === "fund" && prepared.role === "seller" && prepared.feePayer === session.address && prepared.programId === trade.terms.programId && prepared.escrow === trade.escrow.address && prepared.expectedEscrowState === "absent" && isDeepStrictEqual(prepared.binding, trade.binding));
	const shape = {
		action: "fund",
		sellerTokenAccount
	};
	must(`${label}: review names the exact funding source`, isDeepStrictEqual(prepared.shape, shape));
	const message = Uint8Array.from(Buffer.from(prepared.message, "base64"));
	must(`${label}: reviewed bytes encode the exact funding source and original blockhash`, isDeepStrictEqual(verifyPlanMessage(trade, "fund", "absent", session.address, message), shape) && parseLegacyMessage(message).recentBlockhash === prepared.blockhash && encodeBase64(message) === prepared.message);
	const records = unwrap(`${label} prepared journal`, await client.intents(trade));
	must(`${label}: preparation durably journals one reviewed intent`, records.length === 1 && records[0].intentId === prepared.intentId);
	const record = records[0];
	must(`${label}: durable intent is prepared without a signature, send marker or outcome`, record.state === "prepared" && record.signature === null && record.sendMarkedAt === null && record.outcome === null);
	const reviewFields = [
		"intentId",
		"action",
		"role",
		"feePayer",
		"programId",
		"escrow",
		"expectedEscrowState",
		"message",
		"blockhash",
		"lastValidBlockHeight"
	];
	const matchesReview = (value) => reviewFields.every((field) => value[field] === prepared[field]) && isDeepStrictEqual(value.binding, prepared.binding);
	must(`${label}: durable intent exactly matches the reviewed data`, matchesReview(record));
	must(`${label}: preparation remains unsigned and unsent before confirmation`, signLog.length === signsBefore && sendLog.length === sendsBefore);
	const funded = await act(client, trade, label, () => client.confirm(prepared, session));
	must(`${label}: confirmation preserves the same intent and reviewed message`, funded.submission.intentId === prepared.intentId && matchesReview(funded.record));
	const signs = signLog.slice(signsBefore), sends = sendLog.slice(sendsBefore);
	must(`${label}: confirmation signs once with the reviewed seller and message`, signs.length === 1 && signs[0].address === prepared.feePayer && signs[0].message === prepared.message);
	must(`${label}: confirmation sends the reviewed intent once`, sends.length === 1 && sendsFor(funded.submission.signature) === 1);
	const sentWire = Uint8Array.from(Buffer.from(sends[0], "base64"));
	must(`${label}: broadcast contains the exact reviewed message`, sentWire[0] === 1 && encodeBase64(sentWire.slice(65)) === prepared.message);
	return funded;
}
async function nativeFlow() {
	const client = makeClient(casJournal("1".repeat(32)).journal);
	const terms = await newTerms(keys.seller.address, keys.buyer.address, {
		amount: AMOUNTS.native,
		expiryOffset: 3600
	});
	const trade = unwrap("bind", client.bind(bindingOf(terms), terms));
	const seller = unwrap("connect seller", await client.connect(trade, "seller"));
	const fund = await reviewedFund(client, trade, seller, "native fund");
	eq("native fund finalized", fund.record.state, "finalized");
	eq("native: escrow Funded at finalized", (await snapshot(client, trade, "native")).escrow.state, "funded");
	const release = await act(client, trade, "native release", () => client.release(trade, seller));
	eq("native release finalized", release.record.state, "finalized");
	const released = await snapshot(client, trade, "native");
	check("native: Released, unpaid, after a release-only message", released.escrow.state === "released" && !released.escrow.paidOut, released.escrow);
	const buyerBefore = await getBalance(rpc, keys.buyer.address);
	const payout = await act(client, trade, "native payout", () => client.payout(trade, seller));
	eq("native payout finalized", payout.record.state, "finalized");
	eq("native: buyer credited exactly the amount", await getBalance(rpc, keys.buyer.address) - buyerBefore, AMOUNTS.native);
	eq("native: paid out at finalized", (await snapshot(client, trade, "native")).escrow.paidOut, true);
	for (const step of [
		fund,
		release,
		payout
	]) eq("native: one sendTransaction per intent", sendsFor(step.submission.signature), 1);
	cliDecode(fund.submission.signature);
	summary.flows.native = {
		escrow: trade.escrow.address,
		fund: fund.record.outcome,
		release: release.record.outcome,
		payout: payout.record.outcome
	};
}
/** `solana decode-transaction` of one of our signed wire transactions: same keys, header and a passing sigverify. */
function cliDecode(signature) {
	const wire = sendLog.find((w) => base58Encode(Buffer.from(w, "base64").subarray(1, 65)) === signature);
	const out = JSON.parse(run("solana", [
		"decode-transaction",
		wire,
		"base64",
		"--output",
		"json"
	]).stdout);
	const message = parseLegacyMessage(Uint8Array.from(Buffer.from(wire, "base64").subarray(65)));
	const decoded = out.transaction.message;
	eq("CLI decode: sigverify pass", JSON.stringify(out.sigverifyStatus), JSON.stringify(["pass"]));
	eq("CLI decode: account keys equal ours", JSON.stringify(decoded.accountKeys), JSON.stringify(message.accountKeys));
	eq("CLI decode: header equal ours", JSON.stringify([
		decoded.header.numRequiredSignatures,
		decoded.header.numReadonlySignedAccounts,
		decoded.header.numReadonlyUnsignedAccounts
	]), JSON.stringify([
		message.header.numRequiredSignatures,
		message.header.numReadonlySigned,
		message.header.numReadonlyUnsigned
	]));
	summary.cliDecode = {
		signature,
		sigverifyStatus: out.sigverifyStatus,
		accountKeys: decoded.accountKeys.length
	};
}
const tokenIx = (index, account, authority) => ({
	programId: SPL_PROGRAM_ID$1,
	keys: [
		meta$2(account, false, true),
		meta$2(FREEZABLE_MINT, false, false),
		meta$2(authority, true, false)
	],
	data: Uint8Array.of(index)
});
async function tokenAmount(address) {
	const acc = await getAccount(rpc, address, "finalized");
	return acc ? decodeTokenAccount$1(acc.data) : null;
}
async function splHazardFlow() {
	const seller = keys.seller.address, buyer = keys.buyer.address, mint = FREEZABLE_MINT;
	const sellerAta = createAtaIdempotentIx(seller, seller, mint), buyerAta = createAtaIdempotentIx(seller, buyer, mint);
	await sendFinal("spl setup: ATAs, mint_to, freeze buyer ATA", keys.seller, [
		sellerAta.ix,
		buyerAta.ix,
		{ ...mintToIx(mint, sellerAta.ata, keys.mintAuthority.address, AMOUNTS.splMinted) },
		tokenIx(10, buyerAta.ata, keys.mintAuthority.address)
	], [keys.seller, keys.mintAuthority]);
	eq("spl: buyer ATA frozen", (await tokenAmount(buyerAta.ata)).state, 2);
	const client = makeClient(casJournal("2".repeat(32)).journal);
	const terms = await newTerms(seller, buyer, {
		mint,
		amount: AMOUNTS.spl,
		expiryOffset: 3600
	});
	const trade = unwrap("bind spl", client.bind(bindingOf(terms), terms));
	const session = unwrap("connect seller", await client.connect(trade, "seller"));
	const fund = await reviewedFund(client, trade, session, "spl fund", sellerAta.ata);
	eq("spl fund finalized", fund.record.state, "finalized");
	const latest = (await rpc.call("getLatestBlockhash", [{ commitment: "finalized" }])).value;
	const message = compileLegacyMessage(seller, [unwrap("release ix", buildRelease(trade)), unwrap("payout ix", buildPayout(trade, "released"))], latest.blockhash);
	let refused = null;
	try {
		verifyPlanMessage(trade, "payout", "released", seller, message);
	} catch (error) {
		refused = error.code;
	}
	eq("client refuses the bundled [release, payout_spl] message (C-L2)", refused, "INVALID_INPUT");
	const wire = encodeTransaction([ed25519.sign(message, keys.seller.seed)], message);
	const signature = await rpc.call("sendTransaction", [encodeBase64(wire), {
		encoding: "base64",
		skipPreflight: true,
		maxRetries: 0
	}]);
	const status = await waitForSignature(rpc, signature, "finalized", 12e4);
	eq("hazard: bundled tx fails on the payout leg (DestinationFrozen 6016)", JSON.stringify(status.err), JSON.stringify({ InstructionError: [1, { Custom: 6016 }] }));
	eq("hazard: release rolled back, escrow still Funded", (await snapshot(client, trade, "hazard")).escrow.state, "funded");
	const release = await act(client, trade, "spl release", () => client.release(trade, session));
	eq("spl release finalized", release.record.state, "finalized");
	const failedPayout = await act(client, trade, "spl payout (frozen)", () => client.payout(trade, session));
	eq("spl payout to frozen ATA recorded failed", failedPayout.record.state, "failed");
	eq("spl payout failure label", failedPayout.record.outcome?.err, DESTINATION_FROZEN);
	const after = await snapshot(client, trade, "after failed payout");
	check("spl: escrow stays Released and unpaid after the failed payout", after.escrow.state === "released" && !after.escrow.paidOut && after.payout === "pending", after.escrow);
	await sendFinal("thaw buyer ATA", keys.seller, [tokenIx(11, buyerAta.ata, keys.mintAuthority.address)], [keys.seller, keys.mintAuthority]);
	const retry = await act(client, trade, "spl payout retry", () => client.payout(trade, session));
	eq("spl payout retry finalized", retry.record.state, "finalized");
	eq("spl: buyer ATA holds the amount", (await tokenAmount(buyerAta.ata)).amount, String(AMOUNTS.spl));
	eq("spl: paid out at finalized", (await snapshot(client, trade, "spl")).escrow.paidOut, true);
	summary.flows.splHazard = {
		escrow: trade.escrow.address,
		hazardSignature: signature,
		hazardErr: status.err,
		release: release.record.outcome,
		failedPayout: failedPayout.record.outcome,
		retry: retry.record.outcome
	};
}
async function sendFinal(label, feePayer, instructions, signers) {
	const res = await sendTx(rpc, {
		feePayer,
		instructions,
		signers
	});
	const st = await waitForSignature(rpc, res.signature, "finalized", 12e4);
	must(`${label}: finalized without error`, st.err === null, st.err);
}
async function crashFlow() {
	const store = casJournal("3".repeat(32));
	let client = makeClient(store.journal);
	const terms = await newTerms(keys.seller.address, keys.buyer.address, {
		amount: AMOUNTS.native,
		expiryOffset: 3600
	});
	const trade = unwrap("bind crash", client.bind(bindingOf(terms), terms));
	let session = unwrap("connect", await client.connect(trade, "seller"));
	await act(client, trade, "crash fund", () => client.fund(trade, session));
	store.hooks.after = (record) => record.state === "sendMarked" ? "crash" : void 0;
	const sendsBefore = sendLog.length;
	const crashed = await client.release(trade, session);
	store.hooks.after = void 0;
	eq("crash: release reports UNAVAILABLE after a crash at the marker", crashed.ok ? "ok" : crashed.error.code, "UNAVAILABLE");
	eq("crash: nothing was sent", sendLog.length, sendsBefore);
	client.dispose();
	client = makeClient(store.journal);
	session = unwrap("reconnect", await client.connect(trade, "seller"));
	const marked = unwrap("recover", await client.recover(trade)).find((r) => r.action === "release");
	eq("crash: marked intent not cancelled on recover", marked.state, "sendMarked");
	const conflict = await client.release(trade, session);
	eq("crash: a new release is refused while the marked one is open", conflict.ok ? "ok" : conflict.error.code, "CONFLICT");
	const dropped = await settle(client, trade, marked.intentId, "crash marked release", 3e5);
	eq("crash: marked intent dropped after finalized expiry", dropped.state, "dropped");
	eq("crash: never sent at any point", sendLog.length, sendsBefore);
	const implicit = await client.release(trade, session);
	eq("crash: rebuild must name the dropped intent", implicit.ok ? "ok" : implicit.error.code, "CONFLICT");
	const rebuilt = await act(client, trade, "crash rebuild release", () => client.release(trade, session, { rebuildOf: marked.intentId }));
	eq("crash: explicit rebuild finalized", rebuilt.record.state, "finalized");
	eq("crash: rebuild uses a new blockhash", rebuilt.record.blockhash !== marked.blockhash, true);
	const payout = unwrap("crash payout", await client.payout(trade, session));
	const backup = store.backup();
	const sendsAfterPayout = sendLog.length;
	client.dispose();
	const restored = makeClient(casJournal("4".repeat(32), backup).journal);
	check("restore: marked payout kept, not cancelled", unwrap("recover restored", await restored.recover(trade)).find((r) => r.intentId === payout.intentId).state !== "cancelled");
	const settled = await settle(restored, trade, payout.intentId, "restored payout");
	eq("restore: payout reconciled finalized from chain state", settled.state, "finalized");
	eq("restore: no resend", sendLog.length, sendsAfterPayout);
	eq("restore: paid out", (await snapshot(restored, trade, "restored")).escrow.paidOut, true);
	summary.flows.crash = {
		escrow: trade.escrow.address,
		droppedIntent: marked.intentId,
		droppedLastValidBlockHeight: marked.lastValidBlockHeight,
		rebuild: rebuilt.record.outcome,
		payout: settled.outcome
	};
}
async function refundStart() {
	const client = makeClient(casJournal("5".repeat(32)).journal, REFUND_MARGINS);
	const terms = await newTerms(keys.refundSeller.address, keys.buyer.address, {
		amount: AMOUNTS.refund,
		expiryOffset: 1815
	});
	const trade = unwrap("bind refund", client.bind(bindingOf(terms), terms));
	const session = unwrap("connect refund seller", await client.connect(trade, "seller"));
	const fund = await act(client, trade, "refund fund", () => client.fund(trade, session));
	eq("refund trade funded", fund.record.state, "finalized");
	const early = await client.refund(trade, session);
	eq("refund: client refuses before the finalized Clock reaches the deadline", early.ok ? "ok" : early.error.code, "EXPIRED");
	return {
		client,
		trade,
		session,
		terms,
		fundedAt: Date.now()
	};
}
async function refundFinish({ client, trade, session, terms, fundedAt }) {
	const deadline = Number(terms.escrowExpirySeconds), stop = Date.now() + 3e6;
	for (;;) {
		const snap = await snapshot(client, trade, "refund wait");
		if (Number(snap.live.timestampSeconds) >= deadline) break;
		if (Date.now() > stop) throw new Error("refund: deadline never reached");
		log(`refund: finalized clock ${snap.live.timestampSeconds}, deadline ${deadline}`);
		await sleep(2e4);
	}
	const refund = await act(client, trade, "refund", () => client.refund(trade, session));
	eq("refund finalized", refund.record.state, "finalized");
	eq("refund: escrow Refunded", (await snapshot(client, trade, "refund")).escrow.state, "refunded");
	const lamportsBefore = (await getAccount(rpc, trade.escrow.address, "finalized")).lamports;
	const payout = await act(client, trade, "refund payout", () => client.payout(trade, session));
	eq("refund payout finalized", payout.record.state, "finalized");
	eq("refund: escrow released exactly the amount", lamportsBefore - (await getAccount(rpc, trade.escrow.address, "finalized")).lamports, AMOUNTS.refund);
	summary.flows.refund = {
		escrow: trade.escrow.address,
		deadline,
		waitedSeconds: Math.round((Date.now() - fundedAt) / 1e3),
		refund: refund.record.outcome,
		payout: payout.record.outcome
	};
}
async function main() {
	must("program .so exists (cargo build-sbf)", existsSync(SO_PATH), SO_PATH);
	const so = new Uint8Array(readFileSync(SO_PATH));
	const tv = run("solana-test-validator", ["--version"]).stdout;
	must("solana-test-validator is pinned Agave 4.1.2", tv.includes("4.1.2 "), tv);
	mkdirSync(join(WORKDIR, "keys"), { recursive: true });
	for (const name of ["payer", "authority"]) {
		const path = join(WORKDIR, "keys", `${name}.json`);
		run("solana-keygen", [
			"new",
			"--no-bip39-passphrase",
			"-s",
			"--force",
			"-o",
			path
		]);
		keys[name] = loadKeypairFile(path);
		keys[`${name}Path`] = path;
	}
	for (const name of [
		"seller",
		"refundSeller",
		"buyer",
		"mintAuthority"
	]) keys[name] = generateKeypair();
	await startValidator();
	const length = await finalizeProgram();
	summary.program.pin = programDataSha256FromElf(so, length);
	await sendFinal("wallet funding", keys.payer, [transferIx(keys.payer.address, keys.seller.address, 1e10), transferIx(keys.payer.address, keys.refundSeller.address, 2e9)], [keys.payer]);
	const refund = await refundStart();
	await nativeFlow();
	await splHazardFlow();
	await crashFlow();
	if (SKIP_REFUND) check("refund flow executed (skipped by SOLANA_CLIENT_SKIP_REFUND)", false);
	else await refundFinish(refund);
	summary.sendCounts = { sendTransaction: sendLog.length };
}
try {
	await main();
} catch (e) {
	summary.error = e.stack ?? String(e);
	log(`ERROR ${summary.error}`);
}
killValidatorSync();
summary.durationSeconds = Math.round((Date.now() - t0) / 1e3);
summary.ok = summary.error === null && summary.checks.length > 0 && summary.checks.every((c) => c.ok);
summary.finishedAt = (/* @__PURE__ */ new Date()).toISOString();
const out = JSON.stringify(summary, null, 2);
writeFileSync(join(WORKDIR, "client-summary.json"), out + "\n");
console.log(out);
process.exitCode = summary.ok ? 0 : 1;
export {};
