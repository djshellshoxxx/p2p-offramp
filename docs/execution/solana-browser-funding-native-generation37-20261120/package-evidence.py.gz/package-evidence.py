from pathlib import Path
import hashlib,gzip,json,os,subprocess,tempfile,datetime
repo=Path('/workspace/scratch/dcf03ef9bee8/p2p-browser-funding-native-g37'); raw=repo.parent/'g37-browser-funding-native'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,env=None):return subprocess.check_output(['git',*a],cwd=repo,env=env)
def source_entries(rev):
 return {r.split(b'\t',1)[1].decode():r.split(b'\t',1)[0].decode() for r in git('ls-tree','-r','-z',rev).split(b'\0') if r and not r.split(b'\t',1)[1].startswith(b'docs/')}
component=json.loads((raw/'source.json').read_text());combined=json.loads((raw/'combined-source.json').read_text())
assert git('status','--porcelain')==b''
assert git('rev-parse','HEAD').decode().strip()==combined['source']
assert git('rev-parse','HEAD^{tree}').decode().strip()==combined['tree']
for p,h in component['paths'].items():assert sha(git('show',combined['source']+':'+p))==h
checks=[]
for path in sorted(raw.glob('[0-9][0-9]-*.json')):
 item=json.loads(path.read_text());log=Path(item['log']).read_bytes()
 assert len(log)==item['bytes'] and sha(log)==item['sha256'] and item['unchangedDuringExecution'] is True
 for side in ['before','after']:
  snap=item[side];patch=Path(snap['patch']).read_bytes();assert len(patch)==snap['patchBytes'] and sha(patch)==snap['patchSha256']
  with tempfile.TemporaryDirectory(prefix='g37-native-tree-') as td:
   env={**os.environ,'GIT_INDEX_FILE':str(Path(td)/'index')}
   subprocess.run(['git','read-tree',snap['head']],cwd=repo,env=env,check=True)
   if patch:subprocess.run(['git','apply','--cached','--binary','--whitespace=error-all','-'],input=patch,cwd=repo,env=env,check=True)
   assert git('write-tree',env=env).decode().strip()==snap['executionTree']
 checks.append(item)
assert checks[0]['counts']=={'tests':10,'pass':2,'fail':8,'cancelled':0,'skipped':0,'todo':0}
assert all(c['exitCode']==0 for c in checks[1:])
compilation=json.loads((raw/'06-build-only-driver.log').read_text())
assert compilation['nativeBrowserExecuted'] is False and compilation['nativeValidatorExecuted'] is False and compilation['compiledOutputExecuted'] is False
assert compilation['warnings']==[]
for item in compilation['inputs']:
 if not item.get('virtual'):assert sha(git('show',combined['source']+':'+item['path']))==item['sha256']
for item in compilation['outputs']:
 data=(raw/item['file']).read_bytes();decoded=gzip.decompress(data)
 assert len(data)==item['compressedBytes'] and sha(data)==item['compressedSha256']
 assert len(decoded)==item['rawBytes'] and sha(decoded)==item['rawSha256'] and data[4:8]==b'\0'*4
out=repo/'docs/execution/solana-browser-funding-native-generation37-20261120';assert not out.exists();out.mkdir(parents=True)
artifacts=[]
for path in sorted(raw.iterdir()):
 if not path.is_file() or path.name in ['packaged-summary.json','report.md']:continue
 data=path.read_bytes()
 if path.name.endswith('.gz'):decoded=gzip.decompress(data);target=out/path.name;compressed=data
 else:decoded=data;target=out/(path.name+'.gz');compressed=gzip.compress(data,mtime=0)
 assert compressed[4:8]==b'\0'*4 and gzip.decompress(compressed)==decoded
 target.write_bytes(compressed)
 artifacts.append(dict(path=str(target.relative_to(repo)),originalPath=str(path),rawBytes=len(decoded),rawSha256=sha(decoded),compressedBytes=len(compressed),compressedSha256=sha(compressed),gzipMtime=0))
receipt=dict(schema='p2p-offramp.solana-browser-funding-native-generation37.v1',createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),component=component,combined=combined,commands=checks,compilation=compilation,artifacts=artifacts,nonDocumentationEntries=len(source_entries('HEAD')),ReleaseEnabled=0,nativeBrowserExecuted=False,nativeValidatorExecuted=False)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
report=repo/'docs/engineering/SOLANA_BROWSER_FUNDING_NATIVE_COMPANION_GENERATION37_20261120.md';assert not report.exists();report.write_bytes((raw/'report.md').read_bytes())
subprocess.run(['git','diff','--check','8e836baa877b676a863c877003e277b638fc5061'],cwd=repo,check=True)
print(json.dumps(dict(artifacts=len(artifacts),commands=len(checks),capturedExecutionTrees=len(checks)*2,source=combined['source'],tree=combined['tree'],nonDocumentationEntries=len(source_entries('HEAD'))),indent=2))
