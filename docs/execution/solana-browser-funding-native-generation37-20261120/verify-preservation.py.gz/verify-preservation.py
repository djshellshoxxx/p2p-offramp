import pathlib,subprocess,hashlib,json
repo=pathlib.Path('/workspace/scratch/dcf03ef9bee8/p2p-browser-funding-native-g37')
base='b785a01ffc54a75d497641d0e758d077adff41d0'
sha=lambda b:hashlib.sha256(b).hexdigest()
def original(path):return subprocess.check_output(['git','show',base+':'+path],cwd=repo).decode()
helper='scripts/lib/solana-localnet-send-evidence.mjs'
before=original(helper); after=(repo/helper).read_text()
legacy=before[before.index('export function assertSolanaSendMarked'):]
assert after[after.index('export function assertSolanaSendMarked'):].split('\n/** Separate fixed funding proof.')[0]==legacy
readers=before[before.index('export function readSolanaVaultRecords'):before.index('export function assertSolanaSendMarked')]
assert after[after.index('export function readSolanaVaultRecords'):after.index('export function assertSolanaSendMarked')]==readers
path='scripts/test-solana-localnet-browser.mjs'; old=original(path); new=(repo/path).read_text(); normalized=new
start=normalized.index('  // Fund immediately:');end=normalized.index("  for (const name of ['release', 'rebuild', 'refund'])",start)
funding=new[start:end];normalized=normalized[:start]+normalized[end:]
replacements=[
("import { readClock, getBalance, getAccount, decodeEscrow }", "import { readClock, getBalance }"),
("const stored = await fixture.vault(); assert.equal(stored.documents.length, 1 + 3, 'one promoted funding recovery plus three original funded receipts');", "const stored = await fixture.vault(); assert.equal(stored.documents.length, 3);"),
("assert.equal(fixture.walletConnects, 1); assert.equal(fixture.prompts.length, 1 + 0); assert.equal(chain.summary.appSends.length, 1 + 0);", "assert.equal(fixture.walletConnects, 0); assert.equal(fixture.prompts.length, 0); assert.equal(chain.summary.appSends.length, 0);"),
("  await until(async () => {\n    const intents = (await fixture.vault()).intents.filter(r => r.binding.tradeId === ids.release);\n    return intents.length === 1 && intents.every(r => r.state === 'cancelled');\n  }, 'durable pre-sign cancellation'); await idle();", "  await until(async () => (await fixture.vault()).intents.every(r => r.state === 'cancelled'), 'durable pre-sign cancellation'); await idle();"),
("  assert.equal(await card(ids.absent).count(), 1, 'restore retains the already finalized funding recovery');\n  assert.equal(await card(ids.absent).getAttribute('data-chain-state'), 'funded');\n  assert.equal(restored.intents.find(r => r.intentId === fundingSend.intentId).originProfileId, originalProfile);", "  assert.equal(await card(ids.absent).count(), 0, 'restore never promotes an unfunded proposal to recovery');"),
("  assert.equal(fixture.prompts.length, 1 + 8, 'one funding prompt plus the original revoked prompt and seven exit confirmations');", "  assert.equal(fixture.prompts.length, 8, 'one revoked prompt plus seven separately confirmed transaction messages');"),
]
for a,b in replacements:
 assert normalized.count(a)==1,a
 normalized=normalized.replace(a,b)
for line in [
 "  assert.equal(chain.summary.appSends.filter(r => r.action === 'fund').length, 1);\n",
 "  assert.equal(chain.summary.appSends.filter(r => ['release', 'refund', 'payout'].includes(r.action)).length, 7);\n",
 "  assert.equal(fixture.prompts.filter(r => r.action === 'fund').length, 1);\n",
 "  assert.equal(fixture.prompts.filter(r => ['release', 'refund', 'payout'].includes(r.action)).length, 8);\n",
]:
 assert normalized.count(line)==1,line
 normalized=normalized.replace(line,'')
for n in [0,2,3,5,7]: normalized=normalized.replace(f'chain.summary.appSends.length, 1 + {n}',f'chain.summary.appSends.length, {n}')
normalized=normalized.replace('fixture.prompts.length, 1 + 0','fixture.prompts.length, 0')
normalized=normalized.replace('new Set(chain.summary.appSends.map(r => r.signature)).size, 1 + 7','new Set(chain.summary.appSends.map(r => r.signature)).size, 7')
assert normalized==old, 'only explicit new-funding accounting and scoped legacy assertions may differ outside the additive journey'
fixture='scripts/lib/solana-localnet-fixture.mjs';assert (repo/fixture).read_text()==original(fixture)
assert "'finalized funding marker and promoted recovery', 150000, 1000" in funding
assert new.index('a saved proposal is not a funded recovery card')<new.index('  // Fund immediately:')<new.index("  for (const name of ['release', 'rebuild', 'refund'])")
paths=['scripts/test-solana-localnet-browser.mjs','scripts/lib/solana-localnet-browser-fixture.mjs',helper,'apps/web/test/solana-localnet-funding-send-evidence.test.mjs']
for p in paths:subprocess.run(['node','--check',p],cwd=repo,check=True)
subprocess.run(['git','diff','--check','8e836baa877b676a863c877003e277b638fc5061'],cwd=repo,check=True)
print(json.dumps({'check':'legacy verifier and financial journey preservation; source syntax; full main whitespace','baseline':base,'legacyExitVerifierBytes':len(legacy.encode()),'legacyExitVerifierSha256':sha(legacy.encode()),'bothLegacyReadersBytes':len(readers.encode()),'bothLegacyReadersSha256':sha(readers.encode()),'existingDriverRecoveredExactly':True,'existingDriverBytes':len(old.encode()),'existingDriverSha256':sha(old.encode()),'additiveFundingJourneyLines':len(funding.splitlines()),'originalExitSends':7,'newFundingSends':1,'newTotalSends':8,'originalPromptsIncludingRevoked':8,'newFundingPrompts':1,'newTotalPrompts':9,'fixtureSourceUnchanged':True,'syntaxPaths':paths,'nativeBrowserExecuted':False,'nativeValidatorExecuted':False,'ReleaseEnabled':0},indent=2))
