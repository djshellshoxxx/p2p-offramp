import sys,json,pathlib,subprocess,os,tempfile,hashlib,datetime,re
repo=pathlib.Path('/workspace/scratch/dcf03ef9bee8/p2p-browser-funding-native-g37')
out=pathlib.Path('/workspace/scratch/dcf03ef9bee8/g37-browser-funding-native')
name=sys.argv[1]; command=sys.argv[2:]
assert command and not (out/(name+'.json')).exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,env=None):return subprocess.check_output(['git',*a],cwd=repo,env=env)
def snap(suffix):
 base=git('rev-parse','HEAD').decode().strip()
 with tempfile.TemporaryDirectory(prefix='g37-native-index-') as td:
  env={**os.environ,'GIT_INDEX_FILE':str(pathlib.Path(td)/'index')}
  subprocess.run(['git','read-tree',base],cwd=repo,env=env,check=True)
  subprocess.run(['git','add','-A'],cwd=repo,env=env,check=True)
  tree=git('write-tree',env=env).decode().strip()
  patch=git('diff','--binary','--cached',base,env=env)
 path=out/(name+suffix+'.patch'); path.write_bytes(patch)
 return {'head':base,'headTree':git('rev-parse',base+'^{tree}').decode().strip(),'executionTree':tree,'clean':not patch,'patch':str(path),'patchBytes':len(patch),'patchSha256':sha(patch)}
record={'name':name,'command':command,'cwd':str(repo),'before':snap(''),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (out/(name+'.log')).open('wb') as log:r=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
record['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['exitCode']=r.returncode;record['after']=snap('.after')
raw=(out/(name+'.log')).read_bytes();record.update(log=str(out/(name+'.log')),bytes=len(raw),sha256=sha(raw))
record['counts']={k:int(v) for k,v in re.findall(rb'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',raw,re.M)}
record['counts']={k.decode() if isinstance(k,bytes) else k:v for k,v in record['counts'].items()}
record['unchangedDuringExecution']=record['before']=={**record['after'],'patch':record['before']['patch']}
(out/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2));print(raw.decode(errors='replace')[-1800:])
sys.exit(r.returncode)
