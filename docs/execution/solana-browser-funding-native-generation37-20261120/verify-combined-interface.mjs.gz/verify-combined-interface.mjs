import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
const base = process.cwd(), file = path => readFileSync(resolve(base, path), 'utf8');
const { parseSolanaCommand } = await import(resolve(base, 'apps/web/src/solana-localnet/validation.ts'));
const proposalId = '12'.repeat(16);
for (const input of [{ type: 'funding.wallet.connect', proposalId }, { type: 'funding.prepare', proposalId },
  { type: 'funding.prepare', proposalId, rebuildOf: 'original-intent' }]) assert.deepEqual(parseSolanaCommand(input), input);
assert.throws(() => parseSolanaCommand({ type: 'review.prepare', tradeId: '12'.repeat(32), action: 'fund' }));
const ui = file('apps/web/src/solana-localnet/SolanaLocalnetRoot.tsx'), controller = file('apps/web/src/solana-localnet/controller.ts');
for (const required of ['data-proposal-id={proposal.id}', 'data-proposal-state={proposal.state}', 'data-wallet-connected={String(proposal.walletConnected)}',
  '>Connect seller wallet</button>', '>Review funding</button>', '>Review new funding after this definitive drop</button>',
  '>Confirm and sign in wallet</button>', '>Cancel transaction review</button>', '>Export public recovery JSON</button>']) assert.ok(ui.includes(required), required);
for (const label of ['Network genesis', 'Immutable program', 'ProgramData SHA-256', 'Terms SHA-256', 'Fee payer', 'Message (base64)',
  'Acceptance deadline (chain seconds)', 'Escrow expiry (chain seconds)', 'Network fee (lamports)', 'Escrow rent (lamports)',
  'Total debit (lamports)', 'Peer acceptance']) assert.ok(controller.includes(`['${label}',`), label);
for (const label of ['Network fee (lamports)', 'Escrow rent (lamports)', 'Total debit (lamports)']) assert.ok(controller.includes(`['${label}', 'Unknown']`));
assert.ok(controller.includes("['Peer acceptance', 'Not established']"));
console.log(JSON.stringify({ check: 'Combined native-driver command and static selector/field compatibility',
  commands: ['funding.wallet.connect', 'funding.prepare', 'funding.prepare with explicit rebuildOf'], exitReviewRefusesFunding: true,
  selectors: 9, reviewLabels: 12, unknownCosts: 3, peerAcceptanceEstablished: false,
  uiSha256: createHash('sha256').update(ui).digest('hex'), controllerSha256: createHash('sha256').update(controller).digest('hex'),
  limits: 'Validates exact command parsing and source selector/field presence. Does not execute the DOM, Worker, browser or validator.',
  nativeBrowserExecuted: false, nativeValidatorExecuted: false, ReleaseEnabled: 0 }, null, 2));
