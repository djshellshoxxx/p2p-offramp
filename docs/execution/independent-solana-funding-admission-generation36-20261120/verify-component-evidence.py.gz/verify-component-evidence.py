import datetime
import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path('/workspace/scratch/dcf03ef9bee8')
REPO = ROOT / 'p2p-funding-admission-review-g36'
OUT = ROOT / 'g36-admission-review'
BASE = 'ea3ee7f5b5d36456616bd9fef893257327560a10'
AUTHOR = '3283940bae1a2d4e7baabed66878ecb5d977bfb1'
DRIVER = 'd36be3c5348b94d39836b73a3e0b9e864ff0a669'


def git(*args, data=None, env=None):
    return subprocess.check_output(['git', *args], cwd=REPO, input=data, env=env)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def counts(data):
    return {k: int(v) for k, v in re.findall(
        r'^[#ℹ]\s+(tests|pass|fail|cancelled|skipped|todo)\s+(\d+)',
        data.decode('utf-8', errors='replace'), re.M)}


def entries(ref):
    return {p: head for line in git('ls-tree', '-r', ref).decode().splitlines()
            for head, p in [line.split('\t', 1)] if not p.startswith('docs/')}


def reconstruct(base, patch):
    with tempfile.TemporaryDirectory(prefix='evidence-index-', dir=OUT) as tmp:
        env = dict(os.environ, GIT_INDEX_FILE=str(Path(tmp) / 'index'))
        git('read-tree', base, env=env)
        if patch:
            git('apply', '--cached', '--binary', '-', data=patch, env=env)
        return git('write-tree', env=env).decode().strip()


specs = [
    ('author', '1d14b1a32f74869d1dae7b1e65e9ef9f0a62408c', AUTHOR,
     'docs/execution/solana-funding-admission-generation36-20261120/receipt.json', 27, 1037),
    ('driver', '2e07fe01926275c4c5fe888bde2225791fe44163', DRIVER,
     'docs/execution/solana-funding-admission-browser-generation36-20261120/receipt.json', 42, 1038),
]
result = {
    'schema': 'p2p-offramp.g36-independent-component-evidence-verification.v1',
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewSource': DRIVER, 'reviewTree': git('rev-parse', DRIVER + '^{tree}').decode().strip(),
    'components': [], 'nativeExecuted': False, 'ReleaseEnabled': 0,
}
for name, ref, source, path, doc_count, non_doc_count in specs:
    raw_receipt = git('show', ref + ':' + path)
    receipt = json.loads(raw_receipt)
    assert receipt['source'] == source
    assert receipt['tree'] == git('rev-parse', source + '^{tree}').decode().strip()
    assert git('rev-parse', ref + '^').decode().strip() == source
    changed = git('diff', '--name-only', source, ref).decode().splitlines()
    assert len(changed) == doc_count and all(p.startswith('docs/') for p in changed)
    assert entries(source) == entries(ref)
    assert len(entries(source)) == non_doc_count
    actual_paths = git('diff', '--name-only', source + '^', source).decode().splitlines()
    assert actual_paths == receipt['changedPaths']
    originals, by_stored, artifact_results = {}, {}, []
    for a in receipt['artifacts']:
        compressed = git('show', ref + ':' + a['storedPath'])
        decoded = gzip.decompress(compressed)
        assert len(compressed) == a['compressedBytes'] and digest(compressed) == a['compressedSha256']
        assert len(decoded) == a['decodedBytes'] and digest(decoded) == a['decodedSha256']
        assert int.from_bytes(compressed[4:8], 'little') == 0
        # Python-created bundles are byte reproducible here. The three original
        # Node gzip outputs retain their own exact original compressed bytes.
        node_gzip = a.get('producer') == 'retained original Node gzip'
        if not node_gzip:
            assert gzip.compress(decoded, mtime=0) == compressed
        original_path = Path(a['originalPath'])
        assert original_path.exists(), a['originalPath']
        assert original_path.read_bytes() == (compressed if node_gzip else decoded), a['originalPath']
        assert a['originalPath'] not in originals and a['storedPath'] not in by_stored
        originals[a['originalPath']] = decoded
        by_stored[a['storedPath']] = decoded
        artifact_results.append({**a, 'verified': True, 'originalBytesPreserved': True, 'gzipMtime': 0})
    commands = receipt.get('commands', receipt.get('executions'))
    snapshots = []
    snapshot_path = receipt.get('executionSnapshotVerification', str(Path(path).parent / 'execution-snapshot-verification.json'))
    snapshot_receipt = json.loads(git('show', ref + ':' + snapshot_path))
    snapshot_claims = {x['name']: x for x in snapshot_receipt.get('snapshots', snapshot_receipt.get('executions'))}
    for command in commands:
        original_receipt_path = str(Path(command['log']).with_suffix('.json'))
        original_receipt = json.loads(originals[original_receipt_path])
        for k, v in original_receipt.items():
            assert command[k] == v, (name, command['name'], k)
        log, patch = originals[command['log']], originals[command['patch']]
        assert len(log) == command['bytes'] and digest(log) == command['sha256']
        assert digest(patch) == command['patchSha256']
        assert counts(log) == command['counts'], (name, command['name'])
        assert command['completedAt'] >= command['startedAt']
        head = command.get('head', command.get('source'))
        tree = reconstruct(head, patch)
        assert tree == command['executionTree'], (name, command['name'], tree)
        claim = snapshot_claims[command['name']]
        assert claim['executionTree'] == tree and claim['patchSha256'] == digest(patch)
        if 'executionTreeAfter' in command:
            assert command['executionTreeAfter'] == tree and command['unchangedExecutionTree']
        snapshots.append({'name': command['name'], 'head': head, 'executionTree': tree,
                          'patchSha256': digest(patch), 'logSha256': digest(log),
                          'counts': counts(log), 'exitCode': command['exitCode'],
                          'exactReconstruction': True,
                          'matchesFrozenSource': tree == receipt['tree']})
    component = {'name': name, 'source': source, 'tree': receipt['tree'],
                 'evidenceCommit': ref, 'evidenceTree': git('rev-parse', ref + '^{tree}').decode().strip(),
                 'receiptPath': path, 'receiptSha256': digest(raw_receipt),
                 'documentationOnlyPaths': len(changed), 'nonDocumentationEntries': non_doc_count,
                 'changedPaths': actual_paths, 'artifacts': artifact_results, 'snapshots': snapshots}
    if name == 'author':
        for p, blob in receipt['sourceBlobs'].items():
            assert git('ls-tree', source, '--', p).decode().split('\t')[0] == blob['gitEntry']
            assert digest(git('show', source + ':' + p)) == blob['sha256']
        component['sourceBlobsVerified'] = len(receipt['sourceBlobs'])
        frozen = next(raw for p, raw in originals.items() if p.endswith('/frozen-source.patch'))
        assert reconstruct(BASE, frozen) == receipt['tree']
    else:
        compilation = receipt['compilation']
        assert compilation['inputCount'] == len(compilation['inputs']) == 70
        assert len({x['path'] for x in compilation['inputs']}) == 70
        for entry in compilation['inputs']:
            assert digest(git('show', source + ':' + entry['path'])) == entry['sha256']
        assert not compilation['warnings']
        assert len(compilation['outputs']) == 3
        for entry in compilation['outputs']:
            stored = str(Path(path).parent / entry['file'])
            raw = by_stored[stored]
            compressed = git('show', ref + ':' + stored)
            assert len(raw) == entry['rawBytes'] and digest(raw) == entry['rawSha256']
            assert len(compressed) == entry['compressedBytes'] and digest(compressed) == entry['compressedSha256']
            assert entry['gzipMtime'] == 0
        assert sum(x['rawBytes'] for x in compilation['outputs']) == 417221
        compile_log = next(originals[x['log']] for x in commands if x['name'] == '07-build-only-driver')
        assert json.loads(compile_log) == compilation
        component['compilation'] = {'inputsVerified': 70, 'outputsVerified': 3,
                                    'rawBytes': 417221, 'warnings': 0,
                                    'outputNeverEvaluatedClaim': True}
        for flag in ['nativeBrowserExecuted', 'nativeValidatorExecuted', 'compiledOutputExecuted']:
            assert receipt[flag] is False and compilation[flag] is False
        assert receipt['ReleaseEnabled'] == compilation['ReleaseEnabled'] == 0
        versions = receipt['verifierVersions']['executions']
        version_bytes = {}
        for run, version in versions.items():
            raw = by_stored[str(Path(path).parent / (version['file'] + '.gz'))]
            assert digest(raw) == version['sha256']
            version_bytes[run] = raw
        old = version_bytes['04-original-financial-source-preservation'].decode().splitlines(keepends=True)
        new = version_bytes['08-final-source-preservation'].decode().splitlines(keepends=True)
        added = [line[1:] for line in difflib.ndiff(old, new) if line.startswith('+ ')]
        # Both retained scripts differ only by five additive selector-check lines.
        assert not [line for line in difflib.ndiff(old, new) if line.startswith('- ')]
        assert len(added) == 5
        assert 'currentUISelectorsVerified' in ''.join(added)
        component['externalVerifierVersions'] = {'mappingVerified': True, 'additiveLines': 5,
                                                'earlierVersionReconstructedByAuthor': True,
                                                'historicalExternalScriptCaptureClaimed': False}
        frozen = next(raw for p, raw in originals.items() if p.endswith('/frozen-companion-source.patch'))
        assert reconstruct(AUTHOR, frozen) == receipt['tree']
    result['components'].append(component)

own = []
for name in ['01-independent-selection', '02-ui-typecheck', '03-boundaries']:
    rec = json.loads((OUT / (name + '.json')).read_text())
    assert rec['source'] == rec['finalSource'] == DRIVER
    assert rec['tree'] == rec['finalTree'] == result['reviewTree']
    assert rec['exitCode'] == 0 and rec['exactSourceUnchanged']
    assert not rec['initialStatus'] and not rec['finalStatus']
    for field in ['log', 'probes']:
        data = Path(rec[field]['path']).read_bytes()
        assert len(data) == rec[field]['bytes'] and digest(data) == rec[field]['sha256']
    assert counts(Path(rec['log']['path']).read_bytes()) == rec['counts']
    own.append({'name': name, 'source': DRIVER, 'tree': rec['tree'],
                'counts': rec['counts'], 'exitCode': 0, 'originalReceiptPreserved': True,
                'logSha256': rec['log']['sha256'], 'probesSha256': rec['probes']['sha256']})
assert own[0]['counts'] == {'tests': 168, 'pass': 168, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}
result.update(ownExecutions=own, artifactsVerified=sum(len(c['artifacts']) for c in result['components']),
              executionTreesReconstructed=sum(len(c['snapshots']) for c in result['components']),
              completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(), allVerified=True)
assert result['artifactsVerified'] == 63 and result['executionTreesReconstructed'] == 16
(OUT / 'component-evidence-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['reviewSource', 'reviewTree', 'artifactsVerified',
                                       'executionTreesReconstructed', 'completedAt', 'allVerified']}, indent=2))
