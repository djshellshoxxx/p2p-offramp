import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

root = Path('/workspace/scratch/dcf03ef9bee8')
repo = root / 'p2p-funding-admission-review-g36'
output = root / 'g36-admission-review'
name, command = sys.argv[1], sys.argv[2:]
assert name and command
log, receipt_path = output / (name + '.log'), output / (name + '.json')
assert not log.exists() and not receipt_path.exists(), 'Refusing to overwrite prior execution evidence'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


source = git('rev-parse', 'HEAD').decode().strip()
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
status = git('status', '--porcelain').decode()
assert not status, 'Review execution requires an exact committed source'
probes = output / 'independent-probes.test.mjs'
probe_snapshot = output / (name + '.probes.mjs')
probe_snapshot.write_bytes(probes.read_bytes())
source_receipt = json.loads((output / 'review-source.json').read_text())
receipt = {
    'schema': 'p2p-offramp.generation36-independent-execution.v1',
    'name': name, 'command': command, 'cwd': str(repo), 'source': source, 'tree': tree,
    'sourceMapping': source_receipt, 'startedAt': stamp(), 'initialStatus': status,
    'probes': {'path': str(probe_snapshot), 'bytes': probe_snapshot.stat().st_size,
               'sha256': hashlib.sha256(probe_snapshot.read_bytes()).hexdigest()},
}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
env = dict(os.environ)
env['PATH'] = str(repo / 'node_modules/.bin') + os.pathsep + env['PATH']
with log.open('xb') as stream:
    result = subprocess.run(command, cwd=repo, env=env, stdout=stream, stderr=subprocess.STDOUT)
data = log.read_bytes()
text = data.decode('utf-8', errors='replace')
counts = {}
for line in text.splitlines():
    match = re.match(r'^[#ℹ]\s+(tests|pass|fail|cancelled|skipped|todo)\s+(\d+)', line)
    if match:
        counts[match[1]] = int(match[2])
receipt.update(completedAt=stamp(), exitCode=result.returncode, counts=counts,
               log={'path': str(log), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()},
               finalSource=git('rev-parse', 'HEAD').decode().strip(),
               finalTree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
               finalStatus=git('status', '--porcelain').decode())
receipt['exactSourceUnchanged'] = receipt['source'] == receipt['finalSource'] and receipt['tree'] == receipt['finalTree'] and not receipt['finalStatus']
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ['name', 'source', 'tree', 'completedAt', 'exitCode', 'counts', 'log', 'exactSourceUnchanged']}))
assert receipt['exactSourceUnchanged']
sys.exit(result.returncode)
