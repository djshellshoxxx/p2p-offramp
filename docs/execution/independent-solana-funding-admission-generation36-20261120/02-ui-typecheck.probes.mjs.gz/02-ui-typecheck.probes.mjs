import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const repo = new URL('../p2p-funding-admission-review-g36/', import.meta.url);
const load = path => import(new URL(path, repo));
const [controllerModule, configModule, configFixture, nativeFixture, codec, schemas, storage, vaultCrypto, vaultStore, recovery] = await Promise.all([
  load('apps/web/src/solana-localnet/controller.ts'),
  load('apps/web/src/solana-localnet/config.ts'),
  load('apps/web/test/solana-localnet-support.mjs'),
  load('packages/chain-solana/test/lifecycle-support.mjs'),
  load('apps/web/src/solana-localnet/funding-proposal.ts'),
  load('packages/schemas/index.ts'),
  load('packages/storage/index.ts'),
  load('packages/storage/src/vault-crypto.ts'),
  load('packages/storage/src/idb-vault-store.ts'),
  load('packages/chain-solana/src/recovery.ts'),
]);
const { SolanaRecoveryController } = controllerModule;
const { parseSolanaLocalnetConfig, solanaLocalnetConfigDocument } = configModule;
const { createSolanaFundingProposalRecord, SOLANA_FUNDING_PROPOSAL_FORMAT } = codec;
const { encodeBase64url, decodeBase64url } = schemas;
const PASS = 'synthetic independent G36 profile passphrase';
const DEST = 'synthetic independent G36 restored passphrase';
const RECOVERY = 'p2p-offramp/solana-local-recovery/v1';
const encode = value => new TextEncoder().encode(JSON.stringify(value));
const hash = value => createHash('sha256').update(value).digest('hex');
const publicDocument = terms => ({ format: SOLANA_FUNDING_PROPOSAL_FORMAT, terms });
const publicText = terms => JSON.stringify(publicDocument(terms));
const freshTerms = (terms, label) => ({ ...terms, sellerNonce: hash('G36 independent nonce ' + label), orderId: hash('G36 independent order ' + label) });
const success = result => { assert.equal(result.ok, true, JSON.stringify(result)); return result; };
const value = result => success(result).value;
const deferred = () => { let resolve; const promise = new Promise(done => { resolve = done; }); return { promise, resolve }; };

function memoryStore() {
  const rows = new Map(), commits = [];
  return {
    rows, commits, beforeCommit: null,
    async get(id) { return structuredClone(rows.get(id)); },
    async add(row, options) { options?.assertCurrent?.(); assert.equal(rows.has(row.profileId), false); rows.set(row.profileId, structuredClone(row)); },
    async compareAndSwap(before, after, options) {
      await this.beforeCommit?.(before, after, options);
      options?.assertCurrent?.();
      if (options?.signal?.aborted) throw new vaultStore.VaultStorageError('CANCELLED');
      if (JSON.stringify(rows.get(before.profileId)) !== JSON.stringify(before)) throw new vaultStore.VaultStorageError('CONFLICT');
      rows.set(after.profileId, structuredClone(after)); commits.push({ before: before.revision, after: after.revision });
    },
    async addWithSource(before, after, options) { assert.deepEqual(rows.get(before.profileId), before); await this.add(after, options); },
    async listProfileIds() { return { profileIds: [...rows.keys()].sort(), truncated: false }; },
    subscribeInvalidation() { return () => {}; },
  };
}
async function installed(env, change = () => {}) {
  return parseSolanaLocalnetConfig(solanaLocalnetConfigDocument(configFixture.configOption(network => {
    network.genesisHash = network.chainIdentity = env.terms.genesisHash;
    network.deployments[0].artifactSha256 = env.trade.deployment.artifactSha256;
    network.deployments[0].runtime.programDataSha256 = env.trade.deployment.runtime.programDataSha256;
    change(network);
  })));
}
function recoveryRecord(document, profileId) {
  return { id: hash(RECOVERY + '\0' + document.termsHash).slice(0, 32), kind: 'trade', schemaVersion: 1,
    payload: encodeBase64url(encode({ format: RECOVERY, document, role: 'seller', originProfileId: profileId })) };
}
async function fixture(t, seed = async () => []) {
  const env = nativeFixture.setupClient(), config = await installed(env), store = memoryStore();
  const vault = new storage.EncryptedVaultService(store, crypto, { lifecycle: false });
  const session = value(await vault.create(PASS));
  const document = value(recovery.createRecoveryDocument(env.trade));
  const context = { env, config, store, vault, session, document };
  const seeded = await seed(context);
  if (seeded.length) value(await vault.commit(session.sessionId, session.revision, seeded.map(record => ({ op: 'put', record }))));
  vault.lockAll();
  const controller = new SolanaRecoveryController(config, env.walletFake.wallet, env.cluster.rpc, { store });
  t.after(() => { controller.dispose(); vault.dispose(); env.client.dispose(); });
  const opened = success(await controller.dispatch({ type: 'profile.unlock', profileId: session.profileId, passphrase: PASS }));
  const inspect = async (profileId = session.profileId, passphrase = PASS) => {
    const opened = await vaultCrypto.openEnvelope(store.rows.get(profileId), passphrase, crypto);
    try { return structuredClone(opened.snapshot); } finally { vaultCrypto.disposeMaterial(opened.material); }
  };
  return { ...context, controller, opened, seeded, inspect,
    save: terms => controller.dispatch({ type: 'funding.proposal.import', text: publicText(terms) }),
  };
}

test('independent: eight explicit saves and a full-capacity duplicate never touch native authority', async t => {
  const f = await fixture(t), proposals = Array.from({ length: 8 }, (_, i) => freshTerms(f.env.terms, 'quota-' + i));
  const start = f.store.commits.length;
  for (const terms of proposals) success(await f.save(terms));
  assert.equal(f.store.commits.length - start, 8);
  assert.deepEqual(f.controller.snapshot().tradeCapacity, { used: 8, limit: 8 });
  const retained = await f.inspect(), before = structuredClone(f.store.rows.get(f.session.profileId));
  const reversed = { terms: Object.fromEntries(Object.entries(proposals[0]).reverse()), format: SOLANA_FUNDING_PROPOSAL_FORMAT };
  success(await f.controller.dispatch({ type: 'funding.proposal.import', text: ' \n' + JSON.stringify(reversed, null, 2) }));
  assert.deepEqual(f.store.rows.get(f.session.profileId), before);
  assert.deepEqual(await f.inspect(), retained);
  assert.equal((await f.save(freshTerms(f.env.terms, 'quota-overflow'))).code, 'LIMIT_EXCEEDED');
  const snapshot = f.controller.snapshot();
  assert.equal(snapshot.proposals.length, 8); assert.deepEqual(snapshot.trades, []);
  assert.equal(snapshot.wallet, null); assert.equal(snapshot.review, null);
  assert.equal((await f.controller.dispatch({ type: 'review.prepare', tradeId: snapshot.proposals[0].binding.tradeId, action: 'fund' })).code, 'UNSUPPORTED_COMMAND');
  assert.equal(f.env.cluster.calls.length, 0); assert.equal(f.env.walletFake.calls.connect, 0);
  assert.equal(f.env.walletFake.calls.sign.length, 0); assert.equal(f.env.cluster.sent.length, 0);
});

test('independent: a restored duplicate preserves exact historical payload despite installed configuration changes', async t => {
  let original;
  const f = await fixture(t, async ({ env, session }) => {
    const old = await installed(env, network => { network.endpoints[0].id = 'historical-endpoint-name'; });
    original = (await createSolanaFundingProposalRecord(encode(publicDocument(env.terms)), old, session.profileId)).record;
    original = { ...original, payload: encodeBase64url(new TextEncoder().encode(new TextDecoder().decode(decodeBase64url(original.payload, 1, 8192)) + '\n ')) };
    return [original];
  });
  assert.equal(f.opened.snapshot.proposals[0].bindingStatus, 'configuration-mismatch');
  assert.equal(f.opened.snapshot.proposals[0].escrow, null);
  const exported = success(await f.controller.dispatch({ type: 'backup.export' })).backupBytes;
  success(await f.controller.dispatch({ type: 'profile.lock' }));
  const restored = success(await f.controller.dispatch({ type: 'backup.restore', bytes: exported, sourcePassphrase: PASS, destinationPassphrase: DEST }));
  assert.notEqual(restored.snapshot.profileId, f.session.profileId);
  assert.equal(restored.snapshot.proposals[0].restored, true);
  assert.equal(restored.snapshot.proposals[0].bindingStatus, 'configuration-mismatch');
  const before = structuredClone(f.store.rows.get(restored.snapshot.profileId)), commits = f.store.commits.length;
  success(await f.save(f.env.terms));
  assert.equal(f.store.commits.length, commits); assert.deepEqual(f.store.rows.get(restored.snapshot.profileId), before);
  const records = (await f.inspect(restored.snapshot.profileId, DEST)).records;
  assert.deepEqual(records.find(record => record.id === original.id), original);
  assert.equal((await codec.decodeSolanaFundingProposalRecord(original)).originProfileId, f.session.profileId);
  assert.equal(f.env.cluster.calls.length, 0); assert.equal(f.env.walletFake.calls.connect, 0);
});

test('independent: historical registry IDs cannot disguise a retained same-escrow reservation', async t => {
  const f = await fixture(t, async ({ env, session }) => {
    const old = await installed(env, network => { network.id = 'historical-network-id'; network.deployments[0].id = 'historical-deployment-id'; });
    return [(await createSolanaFundingProposalRecord(encode(publicDocument(env.terms)), old, session.profileId)).record];
  });
  assert.equal(f.opened.snapshot.proposals[0].bindingStatus, 'configuration-mismatch');
  const before = structuredClone(f.store.rows.get(f.session.profileId)), commits = f.store.commits.length;
  const result = await f.save(f.env.terms);
  assert.equal(result.ok, false); assert.equal(result.code, 'CONFLICT');
  assert.equal(f.store.commits.length, commits); assert.deepEqual(f.store.rows.get(f.session.profileId), before);
  assert.equal((await f.inspect()).records.length, 1);
  assert.equal(f.env.cluster.calls.length, 0); assert.equal(f.env.walletFake.calls.connect, 0);
});

test('independent: an unfunded conflicting proposal cannot veto a real funded recovery import', async t => {
  const f = await fixture(t, async ({ env, config, session }) => {
    const changed = { ...env.terms, amountBaseUnits: (BigInt(env.terms.amountBaseUnits) + 1n).toString() };
    return [(await createSolanaFundingProposalRecord(encode(publicDocument(changed)), config, session.profileId)).record];
  });
  assert.equal(f.env.cluster.calls.length, 0);
  const imported = success(await f.controller.dispatch({ type: 'recovery.import', text: JSON.stringify(f.document), role: 'seller' }));
  assert.deepEqual(imported.snapshot.tradeCapacity, { used: 2, limit: 8 });
  assert.equal(imported.snapshot.trades[0].state, 'funded'); assert.equal(imported.snapshot.proposals[0].escrowConflict, true);
  assert.equal(imported.snapshot.proposals[0].recoveryRetained, false, 'different bindings remain distinct');
  const proposalOnly = await f.controller.dispatch({ type: 'wallet.connect', tradeId: imported.snapshot.proposals[0].binding.tradeId });
  assert.equal(proposalOnly.code, 'TRADE_NOT_FOUND');
  const exported = success(await f.controller.dispatch({ type: 'recovery.export', tradeId: f.document.termsHash }));
  assert.deepEqual(JSON.parse(exported.recoveryJson), f.document);
  assert.equal(f.env.walletFake.calls.connect, 0); assert.equal(f.env.walletFake.calls.sign.length, 0); assert.equal(f.env.cluster.sent.length, 0);
});

test('independent: mixed-version overflow stays readable and preserves existing funded exit review', async t => {
  const f = await fixture(t, async ({ env, config, session, document }) => {
    const records = [recoveryRecord(document, session.profileId)];
    for (const terms of [env.terms, ...Array.from({ length: 8 }, (_, i) => freshTerms(env.terms, 'legacy-' + i))]) {
      records.push((await createSolanaFundingProposalRecord(encode(publicDocument(terms)), config, session.profileId)).record);
    }
    return records;
  });
  assert.equal(f.opened.snapshot.proposals.length, 9); assert.equal(f.opened.snapshot.trades.length, 1);
  assert.deepEqual(f.opened.snapshot.tradeCapacity, { used: 9, limit: 8 });
  const paired = f.opened.snapshot.proposals.find(p => p.binding.tradeId === f.document.termsHash);
  assert.equal(paired.recoveryRetained, true); assert.equal(paired.escrowConflict, false);
  const writes = f.store.commits.length;
  assert.equal((await f.save(freshTerms(f.env.terms, 'legacy-extra'))).code, 'LIMIT_EXCEEDED');
  assert.equal(f.store.commits.length, writes); assert.equal(f.controller.snapshot().profileId, f.session.profileId);
  success(await f.controller.dispatch({ type: 'wallet.connect', tradeId: f.document.termsHash }));
  const review = success(await f.controller.dispatch({ type: 'review.prepare', tradeId: f.document.termsHash, action: 'release', fiatReceiptConfirmed: true }));
  assert.equal(review.snapshot.review.action, 'release');
  success(await f.controller.dispatch({ type: 'review.cancel' }));
  assert.equal(f.env.walletFake.calls.sign.length, 0); assert.equal(f.env.cluster.sent.length, 0);
});

test('independent: proposal admission cannot overwrite another private record kind at its ID', async t => {
  const f = await fixture(t, async ({ env, config, session }) => {
    const candidate = await createSolanaFundingProposalRecord(encode(publicDocument(env.terms)), config, session.profileId);
    return [{ id: candidate.record.id, kind: 'preference', schemaVersion: 1, payload: encodeBase64url(encode({ ordinary: 'retained private preference' })) }];
  });
  assert.deepEqual(f.opened.snapshot.proposals, []);
  const before = structuredClone(f.store.rows.get(f.session.profileId)), writes = f.store.commits.length;
  const result = await f.save(f.env.terms);
  assert.equal(result.ok, false); assert.equal(result.code, 'CONFLICT');
  assert.equal(f.store.commits.length, writes); assert.deepEqual(f.store.rows.get(f.session.profileId), before);
  assert.equal((await f.inspect()).records[0].kind, 'preference');
});

for (const interruption of ['profile lock', 'wallet change']) {
  test(`independent: ${interruption} during terms hashing retires the pending admission`, { timeout: 10000 }, async t => {
    const f = await fixture(t), entered = deferred(), release = deferred();
    const descriptor = Object.getOwnPropertyDescriptor(crypto.subtle, 'digest'), original = crypto.subtle.digest.bind(crypto.subtle);
    let held = false;
    Object.defineProperty(crypto.subtle, 'digest', { configurable: true, writable: true, async value(...args) {
      if (!held && args[0] === 'SHA-256') { held = true; entered.resolve(); await release.promise; }
      return original(...args);
    } });
    const restore = () => descriptor ? Object.defineProperty(crypto.subtle, 'digest', descriptor) : Reflect.deleteProperty(crypto.subtle, 'digest');
    t.after(() => { release.resolve(); restore(); });
    const before = structuredClone(f.store.rows.get(f.session.profileId)), pending = f.save(f.env.terms);
    await Promise.race([entered.promise, pending.then(() => { throw Error('Admission settled before the held boundary'); })]);
    if (interruption === 'profile lock') success(await f.controller.dispatch({ type: 'profile.lock' }));
    else f.controller.walletChanged();
    release.resolve(); const result = await pending; restore();
    assert.equal(result.ok, false); assert.equal(result.code, 'LOCKED');
    assert.deepEqual(f.store.rows.get(f.session.profileId), before); assert.equal(f.store.commits.length, 0);
    assert.equal(f.env.cluster.calls.length, 0); assert.equal(f.env.walletFake.calls.connect, 0);
    assert.deepEqual(f.controller.snapshot().proposals, []);
  });
}

test('independent: lock at the atomic write boundary leaves the encrypted row unchanged', { timeout: 10000 }, async t => {
  const f = await fixture(t), entered = deferred(), release = deferred();
  f.store.beforeCommit = async () => { entered.resolve(); await release.promise; };
  t.after(() => release.resolve());
  const before = structuredClone(f.store.rows.get(f.session.profileId)), pending = f.save(f.env.terms);
  await Promise.race([entered.promise, pending.then(() => { throw Error('Admission settled before the held boundary'); })]);
  success(await f.controller.dispatch({ type: 'profile.lock' }));
  release.resolve(); const result = await pending;
  assert.equal(result.ok, false); assert.ok(['LOCKED', 'CANCELLED'].includes(result.code), result.code);
  assert.deepEqual(f.store.rows.get(f.session.profileId), before); assert.equal(f.store.commits.length, 0);
  assert.equal(f.env.cluster.calls.length, 0); assert.equal(f.env.walletFake.calls.connect, 0);
});
