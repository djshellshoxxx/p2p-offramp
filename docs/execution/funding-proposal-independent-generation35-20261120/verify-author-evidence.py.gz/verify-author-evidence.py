import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path('/workspace/scratch/dcf03ef9bee8');repo=root/'p2p-funding-proposal-codec-review-g35';raw=root/'g35-funding-proposal-independent'
source='4228040248963389d7dae28881f1db2927ca54ec';evidence='adbdffdc95654a4a0bb4a642e41d7343aad4ff39';main='8e836baa877b676a863c877003e277b638fc5061'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def digest(data):return hashlib.sha256(data).hexdigest()
def entries(ref):
 result={}
 for row in git('ls-tree','-r','-z',ref).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);result[path.decode()]=meta.decode()
 return result
s,e=entries(source),entries(evidence)
assert git('show','-s','--format=%P',evidence).decode().strip()==source
changed=sorted(k for k in set(s)|set(e) if s.get(k)!=e.get(k))
assert len(changed)==19 and all(k.startswith('docs/') and k not in s for k in changed)
assert {k:v for k,v in s.items() if not k.startswith('docs/')}=={k:v for k,v in e.items() if not k.startswith('docs/')}
path='docs/execution/solana-funding-proposal-generation35-20261120/receipt.json';data=git('show',evidence+':'+path);receipt=json.loads(data)
assert receipt['source']==source and receipt['tree']==git('rev-parse',source+'^{tree}').decode().strip()
copy=raw/'author-receipt.json';assert not copy.exists();copy.write_bytes(data)
artifacts=[];decoded={}
for item in receipt['artifacts']:
 compressed=git('show',evidence+':'+item['path']);plain=gzip.decompress(compressed)
 assert int.from_bytes(compressed[4:8],'little')==item['gzipMtime']==0
 assert len(compressed)==item['compressedBytes'] and digest(compressed)==item['compressedSha256']
 assert len(plain)==item['decodedBytes'] and digest(plain)==item['decodedSha256']
 assert compressed==gzip.compress(plain,mtime=0)
 original=item['original']
 if original.startswith(str(root/'g35-funding-proposal-author')+'/'):assert Path(original).read_bytes()==plain
 else:
  assert original==receipt['base']+'..'+source
  assert git('diff','--binary','--full-index',receipt['base'],source)==plain
 decoded[item['path']]=plain
 artifacts.append({'path':item['path'],'compressedSha256':digest(compressed),'decodedSha256':digest(plain),'gzipMtime':0})
assert len(artifacts)==16
for command in receipt['commands']:
 original=json.loads((root/'g35-funding-proposal-author'/(command['name']+'.json')).read_text())
 assert all(command[k]==v for k,v in original.items())
 assert decoded[command['retainedLog']]==Path(command['log']).read_bytes()
 assert decoded[command['retainedExecutionPatch']]==git('diff','--binary','--full-index',command['source'],command['executionTree'])
assert len(receipt['commands'])==7
verification=git('show',evidence+':'+receipt['snapshotVerification']);(raw/'author-snapshot-verification.json').write_bytes(verification)
subprocess.run(['git','diff','--check',main+'..'+evidence],cwd=repo,check=True)
result={'source':source,'authorEvidence':evidence,'authorEvidenceTree':git('rev-parse',evidence+'^{tree}').decode().strip(),'manifest':path,'manifestSha256':digest(data),'artifactCount':len(artifacts),'artifacts':artifacts,'executionSnapshots':len(receipt['commands']),'fullWhitespaceBaseline':main,'nonDocumentationEntriesPreserved':1035,'allChangesAreAddedDocumentation':True,'changedDocumentationPaths':changed,'authorSnapshotVerificationSha256':digest(verification),'authorSnapshotVerification':json.loads(verification)}
out=raw/'author-evidence-verification.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
