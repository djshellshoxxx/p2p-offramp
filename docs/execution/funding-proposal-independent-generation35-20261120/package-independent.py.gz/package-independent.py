import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path('/workspace/scratch/dcf03ef9bee8');repo=root/'p2p-funding-proposal-codec-review-g35';raw=root/'g35-funding-proposal-independent'
source='4228040248963389d7dae28881f1db2927ca54ec';tree='cbdc2f8d4335d356fa70a21edbcd37ec916cf2f2';base='0b7832d1c5b348a0755d59152442d0318d4a620c'
author='adbdffdc95654a4a0bb4a642e41d7343aad4ff39';main='8e836baa877b676a863c877003e277b638fc5061'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def digest(data):return hashlib.sha256(data).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain').strip()
destination=repo/'docs/execution/funding-proposal-independent-generation35-20261120'
assert not destination.exists();destination.mkdir(parents=True)
artifacts=[]
def keep(name,data,original=None,compressed=False):
 path=destination/(name+('.gz' if compressed else ''));assert not path.exists()
 saved=gzip.compress(data,mtime=0) if compressed else data
 if compressed:assert gzip.decompress(saved)==data and int.from_bytes(saved[4:8],'little')==0
 path.write_bytes(saved)
 item={'path':str(path.relative_to(repo)),'bytes':len(saved),'sha256':digest(saved)}
 if original is not None:item['original']=original
 if compressed:item.update(decodedBytes=len(data),decodedSha256=digest(data),gzipMtime=0)
 artifacts.append(item);return str(path.relative_to(repo))
commands=[]
for path in sorted(raw.glob('[0-9][0-9]-*.json')):
 command=json.loads(path.read_text());assert command['source']==command['finalSource']==source and command['tree']==command['finalTree']==tree
 assert command['exitCode']==0 and command['finalStatus']==''
 data=Path(command['log']['path']).read_bytes();assert len(data)==command['log']['bytes'] and digest(data)==command['log']['sha256']
 assert Path(command['sourceTreeSnapshot']['path']).read_bytes()==git('ls-tree','-r','-z',source)
 assert Path(command['independentProbes']['path']).read_bytes()==(raw/'probes.test.mjs').read_bytes()
 entry=dict(command);entry['retainedReceipt']=keep(path.name,path.read_bytes(),str(path));entry['retainedLog']=keep(command['name']+'.log',data,command['log']['path'],True)
 commands.append(entry)
assert len(commands)==5
snapshot=keep('execution-source-tree.bin',git('ls-tree','-r','-z',source),[c['sourceTreeSnapshot']['path'] for c in commands],True)
for name in ['setup.json','counts-verification.json','source-and-author-snapshot-verification.json','author-evidence-verification.json','author-receipt.json','author-snapshot-verification.json','probes.test.mjs','run.py','verify-source-and-author.py','verify-author-evidence.py','package-independent.py','packaging-attempt-01-recovered.log']:
 keep(name,(raw/name).read_bytes(),str(raw/name),name.endswith(('.py','.mjs','.log')))
counts=json.loads((raw/'counts-verification.json').read_text());proof=json.loads((raw/'source-and-author-snapshot-verification.json').read_text());verified=json.loads((raw/'author-evidence-verification.json').read_text())
receipt={'schema':'p2p-offramp.funding-proposal-codec-independent-review.generation35.v1','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'tree':tree,'sourceParent':base,'authorEvidence':author,'authorEvidenceTree':verified['authorEvidenceTree'],'fullWhitespaceBaseline':main,'verdict':'No blocking issue found within the inactive proposal-data codec scope.','findings':[],'sourceVerification':proof,'independentCounts':counts,'commands':commands,'authorEvidenceVerification':verified,'retainedSourceTree':snapshot,'artifacts':artifacts,'nonDocumentationEntriesPreserved':1035,'limits':[
'Only two app-profile files were added; there is no production consumer, command, controller change, chain facade export, storage write, wallet grant or economic capability.',
'Installed configuration is a caller precondition. The codec retains validated provenance data, not authentication or executable restored configuration. Later controller admission must independently compare installed pins and enforce quota, collision, deduplication and epoch/CAS guards.',
'Canonical historical terms, non-core commitments and G16-valid amounts remain data. Existing G34 planFund owns funding eligibility. Parsing is not branded binding, peer acceptance, preparation, funding or finality.',
'The maintained compatibility test exercises real encrypted vault/backup services and controller with an in-memory store and scripted RPC. It does not establish browser, validator or live-chain execution.',
'All independent commands passed on the exact source. The original execution capture expected TAP counters, while Node emitted its spec reporter. A separately retained derivative parses the complete original output without rerun, replacement or receipt rewriting.',
'A packaging-script writer initially failed before any repository mutation because its nested triple quotes ended the outer string. Complete original tool output is retained and labeled recovered; the corrected script uses a separate report template.',
'No full repository suite, build, browser, validator, financial flow, remote publication, dependency installation, release or optional activation was performed by this reviewer. ReleaseEnabled remains zero.',
'Independent source review does not substitute for coordinator composition verification, applicable hosted qualification or matching merge authorization.'
]}
output=repo/'docs/engineering/funding-proposal-codec-independent-review-generation35.json';assert not output.exists();output.write_text(json.dumps(receipt,indent=2)+'\n')
report=repo/'docs/engineering/INDEPENDENT_FUNDING_PROPOSAL_CODEC_REVIEW_GENERATION35_20261120.md';assert not report.exists();report.write_bytes((raw/'report.md').read_bytes())
print(json.dumps({'source':source,'artifacts':len(artifacts),'commands':len(commands),'documentationFiles':len(artifacts)+2,'receipt':str(output),'report':str(report)}))
