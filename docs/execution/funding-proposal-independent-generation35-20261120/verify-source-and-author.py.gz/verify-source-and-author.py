import hashlib,json,re,subprocess
from pathlib import Path
root=Path('/workspace/scratch/dcf03ef9bee8');repo=root/'p2p-funding-proposal-codec-review-g35';raw=root/'g35-funding-proposal-author'
source='4228040248963389d7dae28881f1db2927ca54ec';base='0b7832d1c5b348a0755d59152442d0318d4a620c';main='8e836baa877b676a863c877003e277b638fc5061'
expected=['apps/web/src/solana-localnet/funding-proposal.ts','apps/web/test/solana-localnet-funding-proposal.test.mjs']
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def digest(data):return hashlib.sha256(data).hexdigest()
def entries(ref):
 result={}
 for row in git('ls-tree','-r','-z',ref).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);result[path.decode()]=meta.decode()
 return result
b,s=entries(base),entries(source)
assert sorted(set(s)-set(b))==expected and all(s[k]==v for k,v in b.items())
assert sum(not k.startswith('docs/') for k in s)==1035
assert git('rev-parse',source+'^{tree}').decode().strip()=='cbdc2f8d4335d356fa70a21edbcd37ec916cf2f2'
assert git('show','-s','--format=%P',source).decode().strip()==base
for path in expected:assert (repo/path).read_bytes()==git('show',source+':'+path)
subprocess.run(['git','diff','--check',main+'..'+source],cwd=repo,check=True)
subprocess.run(['git','diff','--check',base+'..'+source],cwd=repo,check=True)
executions=[]
for path in sorted(raw.glob('[0-9][0-9]-*.json')):
 r=json.loads(path.read_text());log=Path(r['log']).read_bytes();patch=Path(r['patch']).read_bytes()
 assert len(log)==r['bytes'] and digest(log)==r['sha256']
 assert len(patch)==r['patchBytes'] and digest(patch)==r['patchSha256']
 assert patch==git('diff','--binary','--full-index',r['source'],r['executionTree'])
 counts={k:int(v) for k,v in re.findall(r'^[#ℹ] (tests|pass|fail|cancelled|skipped|todo) ([0-9]+)$',log.decode(),re.M)}
 assert counts==r['counts']
 snapshot=entries(r['executionTree']);delta=sorted(k for k in set(b)|set(snapshot) if b.get(k)!=snapshot.get(k))
 assert delta==([expected[1]] if r['name']=='01-baseline' else expected)
 executions.append({'name':r['name'],'source':r['source'],'executionTree':r['executionTree'],'changedPathsFromBase':delta,'exitCode':r['exitCode'],'counts':counts,'exactSavedPatch':True,'logSha256':digest(log),'patchSha256':digest(patch)})
assert len(executions)==7
assert [(e['name'],e['exitCode']) for e in executions if e['exitCode']!=0]==[('01-baseline',1),('02-first-implementation',1)]
assert executions[0]['counts']=={'tests':78,'pass':1,'fail':77,'cancelled':0,'skipped':0,'todo':0}
assert executions[1]['counts']=={'tests':78,'pass':77,'fail':1,'cancelled':0,'skipped':0,'todo':0}
assert executions[3]['counts']=={'tests':82,'pass':82,'fail':0,'cancelled':0,'skipped':0,'todo':0}
assert executions[3]['executionTree']==git('rev-parse',source+'^{tree}').decode().strip()
result={'source':source,'tree':git('rev-parse',source+'^{tree}').decode().strip(),'base':base,'mainWhitespaceBaseline':main,'newSourcePaths':expected,'nonDocumentationEntries':1035,'preservedBaseEntries':len(b),'sourceBlobs':{path:{'entry':s[path],'sha256':digest(git('show',source+':'+path))}for path in expected},'authorExecutionSnapshots':executions,'limits':['Snapshot and log verification only; no test, build, native or browser rerun.','The author first implementation failure was error-code normalization for a refused endpoint, preserved before the narrow rpcUrl wrapper correction.']}
out=root/'g35-funding-proposal-independent/source-and-author-snapshot-verification.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
