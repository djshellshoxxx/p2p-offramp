import datetime, hashlib, json, os, re, subprocess, sys
from pathlib import Path
root=Path('/workspace/scratch/dcf03ef9bee8')
repo=root/'p2p-funding-proposal-codec-review-g35'
raw=root/'g35-funding-proposal-independent'
name=sys.argv[1]; command=sys.argv[2:]
assert command and re.fullmatch(r'[a-z0-9-]+',name)
record=raw/(name+'.json'); log=raw/(name+'.log')
assert not record.exists() and not log.exists(), 'Refusing execution overwrite'
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def textgit(*args): return git(*args).decode().strip()
def digest(data): return hashlib.sha256(data).hexdigest()
source=textgit('rev-parse','HEAD'); tree=textgit('rev-parse','HEAD^{tree}')
status=textgit('status','--porcelain'); assert not status, status
rows=git('ls-tree','-r','-z',source); snapshot=raw/(name+'-source-tree.bin')
snapshot.write_bytes(rows)
probes=(raw/'probes.test.mjs').read_bytes()
env=os.environ.copy();env['P2P_G35_REVIEW_REPO']=str(repo)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with log.open('wb') as out:
    result=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
ended=datetime.datetime.now(datetime.timezone.utc).isoformat()
data=log.read_bytes()
counts={}
for key in ['tests','pass','fail','cancelled','skipped','todo']:
    matches=re.findall(rb'^# '+key.encode()+rb' ([0-9]+)$',data,re.M)
    if matches: counts[key]=int(matches[-1])
receipt={'name':name,'command':command,'workingDirectory':str(repo),'environment':{'P2P_G35_REVIEW_REPO':str(repo)},'startedAt':started,'completedAt':ended,'source':source,'tree':tree,'sourceTreeSnapshot':{'path':str(snapshot),'bytes':len(rows),'sha256':digest(rows)},'independentProbes':{'path':str(raw/'probes.test.mjs'),'bytes':len(probes),'sha256':digest(probes)},'exitCode':result.returncode,'log':{'path':str(log),'bytes':len(data),'sha256':digest(data)},'counts':counts,'finalSource':textgit('rev-parse','HEAD'),'finalTree':textgit('rev-parse','HEAD^{tree}'),'finalStatus':textgit('status','--porcelain'),'nativeExecuted':False,'browserExecuted':False}
record.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
sys.exit(result.returncode)
