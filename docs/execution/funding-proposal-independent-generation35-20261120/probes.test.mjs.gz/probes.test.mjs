import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
const root = process.env.P2P_G35_REVIEW_REPO;
assert.ok(root, 'explicit review checkout required');
const moduleAt = path => import(pathToFileURL(resolve(root, path)).href);
const proposal = await moduleAt('apps/web/src/solana-localnet/funding-proposal.ts');
const { parseSolanaLocalnetConfig, solanaLocalnetConfigDocument } = await moduleAt('apps/web/src/solana-localnet/config.ts');
const { configOption } = await moduleAt('apps/web/test/solana-localnet-support.mjs');
const { encodeBase64url, decodeBase64url } = await moduleAt('packages/schemas/index.ts');
const vectors = JSON.parse(await readFile(resolve(root, 'packages/domain/test/fixtures/g16-vectors.json'), 'utf8'));
const native = vectors.solanaTerms.find(v => v.input.assetKind === 'native');
const PROFILE = '12'.repeat(16);
const publicBytes = (terms = native.input) => new TextEncoder().encode(JSON.stringify({
  format: proposal.SOLANA_FUNDING_PROPOSAL_FORMAT, terms,
}));
const privateBody = record => JSON.parse(new TextDecoder().decode(decodeBase64url(record.payload, 1, 8192)));
const replaceBody = (record, body) => ({ ...record, payload: encodeBase64url(new TextEncoder().encode(JSON.stringify(body))) });
const expectedId = binding => createHash('sha256').update(JSON.stringify([
  proposal.SOLANA_FUNDING_PROPOSAL_RECORD_FORMAT, binding.chain,
  binding.networkId, binding.deploymentId, binding.tradeId,
])).digest('hex').slice(0, 32);
async function config(change = () => {}) {
  const option = configOption(network => {
    network.genesisHash = network.chainIdentity = native.input.genesisHash;
    network.deployments[0].address = native.input.programId;
    change(network);
  });
  return parseSolanaLocalnetConfig(solanaLocalnetConfigDocument(option));
}
function latch() { let resolve; const promise = new Promise(done => { resolve = done; }); return { promise, resolve }; }
async function gatedDigest(work) {
  const entered = latch(), release = latch(), previous = Object.getOwnPropertyDescriptor(crypto.subtle, 'digest');
  const original = crypto.subtle.digest.bind(crypto.subtle);
  let calls = 0;
  Object.defineProperty(crypto.subtle, 'digest', { configurable: true, value: async (...args) => {
    const snapshot = new Uint8Array(args[1]).slice();
    if (++calls === 1) { entered.resolve(); await release.promise; }
    return original(args[0], snapshot);
  } });
  try { await work(entered.promise, release.resolve); }
  finally {
    release.resolve();
    if (previous) Object.defineProperty(crypto.subtle, 'digest', previous);
    else delete crypto.subtle.digest;
  }
}

test('independent: asynchronous hashes cannot substitute proposal bytes, nested configuration or record wrapper fields', async () => {
  const installed = await config();
  const mutable = { ...installed, network: structuredClone(installed.network), margins: { ...installed.margins } };
  const before = { network: structuredClone(mutable.network), margins: { ...mutable.margins } };
  const bytes = publicBytes();
  let created;
  await gatedDigest(async (entered, release) => {
    const job = proposal.createSolanaFundingProposalRecord(bytes, mutable, PROFILE);
    await entered;
    bytes.fill(0);
    mutable.registrySha256 = 'ef'.repeat(32);
    mutable.rpcUrl = 'http://127.0.0.1:19998/';
    mutable.network.id = 'changed-network';
    mutable.network.deployments[0].id = 'changed-deployment';
    mutable.network.deployments[0].artifactSha256 = 'de'.repeat(32);
    mutable.margins.submitMarginSeconds = '0';
    release(); created = await job;
  });
  assert.equal(created.value.binding.tradeId, native.termsHash);
  assert.equal(created.value.binding.networkId, before.network.id);
  assert.equal(created.value.binding.deploymentId, before.network.deployments[0].id);
  assert.equal(created.value.configuration.registrySha256, installed.registrySha256);
  assert.equal(created.value.configuration.rpcUrl, installed.rpcUrl);
  assert.deepEqual(created.value.configuration.margins, before.margins);
  assert.equal(created.value.configuration.artifactSha256, before.network.deployments[0].artifactSha256);
  const wrapper = { ...created.record };
  await gatedDigest(async (entered, release) => {
    const job = proposal.decodeSolanaFundingProposalRecord(wrapper);
    await entered;
    wrapper.id = 'ff'.repeat(16); wrapper.payload = 'e30'; wrapper.kind = 'journal'; wrapper.schemaVersion = 2;
    release(); assert.deepEqual(await job, created.value);
  });
  for (const item of [created, created.record, created.value, created.value.proposal, created.value.proposal.terms,
    created.value.binding, created.value.configuration, created.value.configuration.margins]) assert.equal(Object.isFrozen(item), true);
});

test('independent: storage identity binds the full domain and cannot be replaced by a terms hash or a transplanted wrapper', async () => {
  const first = await proposal.createSolanaFundingProposalRecord(publicBytes(), await config(), PROFILE);
  const second = await proposal.createSolanaFundingProposalRecord(publicBytes(), await config(n => { n.id = 'other-local-network'; }), PROFILE);
  const third = await proposal.createSolanaFundingProposalRecord(publicBytes(), await config(n => { n.deployments[0].id = 'other-deployment'; }), PROFILE);
  assert.equal(first.value.binding.tradeId, second.value.binding.tradeId);
  assert.equal(first.value.binding.tradeId, third.value.binding.tradeId);
  assert.equal(new Set([first.record.id, second.record.id, third.record.id]).size, 3);
  for (const row of [first, second, third]) {
    assert.equal(row.record.id, expectedId(row.value.binding));
    assert.notEqual(row.record.id, row.value.binding.tradeId.slice(0, 32));
    assert.deepEqual(await proposal.decodeSolanaFundingProposalRecord(row.record), row.value);
  }
  await assert.rejects(proposal.decodeSolanaFundingProposalRecord({ ...second.record, id: first.record.id }));
  const bad = privateBody(first.record); bad.binding.chain = 'evm';
  await assert.rejects(proposal.decodeSolanaFundingProposalRecord({ ...replaceBody(first.record, bad), id: expectedId(bad.binding) }));
});

test('independent: canonical historical data remain parseable without funding authority or hidden temporal effects', async () => {
  const installed = await config(), terms = { ...native.input, capabilitiesHash: '00'.repeat(32),
    amountBaseUnits: '18446744073709551615', acceptBeforeSeconds: '0', escrowExpirySeconds: '0' };
  const oldNow = Date.now, oldRandom = Math.random, previousFetch = Object.getOwnPropertyDescriptor(globalThis, 'fetch');
  const previousRandom = Object.getOwnPropertyDescriptor(crypto, 'getRandomValues');
  let calls = 0;
  const forbidden = () => { calls++; throw Error('forbidden side effect'); };
  Date.now = forbidden; Math.random = forbidden;
  Object.defineProperty(globalThis, 'fetch', { configurable: true, value: forbidden });
  Object.defineProperty(crypto, 'getRandomValues', { configurable: true, value: forbidden });
  let result;
  try {
    result = await proposal.createSolanaFundingProposalRecord(publicBytes(terms), installed, PROFILE);
    assert.deepEqual(await proposal.decodeSolanaFundingProposalRecord(result.record), result.value);
  } finally {
    Date.now = oldNow; Math.random = oldRandom;
    if (previousFetch) Object.defineProperty(globalThis, 'fetch', previousFetch); else delete globalThis.fetch;
    if (previousRandom) Object.defineProperty(crypto, 'getRandomValues', previousRandom); else delete crypto.getRandomValues;
  }
  assert.equal(calls, 0);
  assert.deepEqual(result.value.proposal.terms, Object.fromEntries(Object.entries(terms).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)));
  for (const forbiddenKey of ['accepted', 'funded', 'canFund', 'prepared', 'wallet', 'restored', 'confirmationAuthority']) {
    assert.equal(Object.hasOwn(result.value, forbiddenKey), false);
    assert.equal(Object.hasOwn(result.value.proposal, forbiddenKey), false);
  }
});

test('independent: wrapper accessors and nested provenance substitutions reject without evaluating getters', async () => {
  const valid = await proposal.createSolanaFundingProposalRecord(publicBytes(), await config(), PROFILE);
  let getters = 0;
  for (const key of ['id', 'kind', 'schemaVersion', 'payload']) {
    const accessor = { ...valid.record };
    Object.defineProperty(accessor, key, { enumerable: true, get() { getters++; throw Error('private getter'); } });
    await assert.rejects(proposal.decodeSolanaFundingProposalRecord(accessor));
  }
  assert.equal(getters, 0);
  for (const mutate of [
    body => { body.binding.tradeId = 'ab'.repeat(32); },
    body => { body.configuration.margins.submitMarginSeconds = '01'; },
    body => { body.configuration.rpcUrl = 'https://rpc.example.invalid/'; },
    body => { body.originProfileId = '0'.repeat(32); },
    body => { body.configuration.artifactSha256 = 'AB'.repeat(32); },
    body => { body.proposal.terms.privateAgreementHash = 'de'.repeat(32); },
  ]) {
    const body = privateBody(valid.record); mutate(body);
    await assert.rejects(proposal.decodeSolanaFundingProposalRecord(replaceBody(valid.record, body)));
  }
});
