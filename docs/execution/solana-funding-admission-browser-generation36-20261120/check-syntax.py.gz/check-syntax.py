import json
import subprocess
from pathlib import Path

repo = Path('/workspace/scratch/dcf03ef9bee8/p2p-funding-admission-native-driver-g36')
paths = ['scripts/test-solana-localnet-browser.mjs', 'scripts/lib/solana-localnet-browser-fixture.mjs',
         'scripts/lib/solana-localnet-send-evidence.mjs', 'apps/web/test/solana-localnet-proposal-browser-evidence.test.mjs']
for path in paths:
    subprocess.run(['node', '--check', path], cwd=repo, check=True)
print(json.dumps({'syntaxChecked': paths, 'moduleEvaluation': False, 'nativeExecuted': False}, indent=2))
