import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

repo = Path('/workspace/scratch/dcf03ef9bee8/p2p-funding-admission-native-driver-g36')
root = Path('/workspace/scratch/dcf03ef9bee8/g36-admission-native-driver')
name, *command = sys.argv[1:]
assert name and command
output = root / (name + '.log')
assert not output.exists(), 'Refusing to overwrite a retained execution'
index = root / (name + '.index')
environment = {**os.environ, 'GIT_INDEX_FILE': str(index)}


def git(*args, env=None):
    return subprocess.check_output(['git', *args], cwd=repo, env=env)


source = git('rev-parse', 'HEAD').decode().strip()
subprocess.run(['git', 'read-tree', source], cwd=repo, env=environment, check=True)
subprocess.run(['git', 'add', '-A'], cwd=repo, env=environment, check=True)
tree = git('write-tree', env=environment).decode().strip()
patch = git('diff', '--cached', '--binary', source, env=environment)
(root / (name + '.patch')).write_bytes(patch)
index.unlink()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with output.open('xb') as stream:
    result = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
data = output.read_bytes()
counts = {match[0]: int(match[1]) for match in re.findall(rb'^[#\xe2\x84\xb9]+\s+(tests|pass|fail|cancelled|skipped|todo)\s+(\d+)', data, re.M)}
counts = {key.decode(): value for key, value in counts.items()}
record = {'name': name, 'source': source, 'headTree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
          'executionTree': tree, 'uncommittedChanges': bool(patch), 'command': command,
          'startedAt': started, 'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'exitCode': result.returncode, 'log': str(output), 'bytes': len(data),
          'sha256': hashlib.sha256(data).hexdigest(), 'patch': str(root / (name + '.patch')),
          'patchSha256': hashlib.sha256(patch).hexdigest(), 'counts': counts}
(root / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
raise SystemExit(result.returncode)
