import hashlib
import json
import subprocess
from pathlib import Path

repo = Path('/workspace/scratch/dcf03ef9bee8/p2p-funding-admission-native-driver-g36')
baseline = 'ea3ee7f5b5d36456616bd9fef893257327560a10'
driver = 'scripts/test-solana-localnet-browser.mjs'
oracle = 'scripts/lib/solana-localnet-send-evidence.mjs'
fixture = 'scripts/lib/solana-localnet-browser-fixture.mjs'


def original(path):
    return subprocess.check_output(['git', 'show', baseline + ':' + path], cwd=repo)


def function(source, name):
    start = source.index(('export function ' + name + '(').encode())
    return source[start:source.index(b'\n}\n', start) + 3]


before, after = original(driver).splitlines(keepends=True), (repo / driver).read_bytes().splitlines(keepends=True)
cursor = iter(after)
assert all(any(candidate == line for candidate in cursor) for line in before), 'Original driver line removed or changed'
old_oracle = original(oracle)
new_oracle = (repo / oracle).read_bytes()
for name in ['readSolanaVaultRecords', 'assertSolanaSendMarked']:
    assert function(old_oracle, name) == function(new_oracle, name), name + ' changed'
expected = original(fixture).replace(b'import { assertSolanaSendMarked, readSolanaVaultRecords }',
                                    b'import { assertSolanaSendMarked, readSolanaBrowserVaultRecords }')
expected = expected.replace(b'...readSolanaVaultRecords(opened.snapshot)', b'...await readSolanaBrowserVaultRecords(opened.snapshot)')
assert expected == (repo / fixture).read_bytes(), 'Unexpected fixture mutation'
for path in ['scripts/lib/solana-localnet-fixture.mjs', 'contracts/solana/localnet/driver.mjs']:
    assert original(path) == (repo / path).read_bytes(), 'Financial fixture changed: ' + path
ui = (repo / 'apps/web/src/solana-localnet/SolanaLocalnetRoot.tsx').read_text()
selectors = ['Funding proposal JSON', 'Save seller funding proposal', 'data-proposal-id',
             'Saved proposal', 'Original provenance preserved after restore', 'Your encrypted recovery profile']
assert all(value in ui for value in selectors)
subprocess.run(['git', 'diff', '--check', '8e836baa877b676a863c877003e277b638fc5061'], cwd=repo, check=True)
print(json.dumps({'baseline': baseline, 'originalDriverLinesPreserved': len(before),
                  'driverAddedLines': len(after) - len(before),
                  'legacyFunctionsByteIdentical': ['readSolanaVaultRecords', 'assertSolanaSendMarked'],
                  'fixtureChange': 'Only import and awaited proposal-aware oracle call',
                  'financialFixturesUnchanged': True, 'fullMainWhitespacePassed': True,
                  'currentUISelectorsVerified': selectors,
                  'driverSha256': hashlib.sha256((repo / driver).read_bytes()).hexdigest(),
                  'nativeExecuted': False}, indent=2))
