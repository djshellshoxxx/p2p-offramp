import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { isAbsolute, relative, resolve } from 'node:path';
import { gzipSync } from 'node:zlib';
const fromRepository = createRequire(resolve('package.json'));
const { rolldown, VERSION } = await import(fromRepository.resolve('rolldown'));
const source = 'scripts/test-solana-localnet-browser.mjs';
const destination = '/workspace/scratch/dcf03ef9bee8/g36-admission-native-driver/';
const warnings = [], sha = bytes => createHash('sha256').update(bytes).digest('hex');
const build = await rolldown({ input: resolve(source), platform: 'node',
  external: id => !id.startsWith('.') && !isAbsolute(id), onwarn: warning => warnings.push(warning) });
try {
  const result = await build.generate({ format: 'esm' });
  const chunks = result.output.filter(output => output.type === 'chunk');
  const outputs = chunks.map((chunk, index) => {
    const bytes = Buffer.from(chunk.code), compressed = gzipSync(bytes, { mtime: 0 });
    const file = `compiled-driver-${index}.mjs.gz`;
    if (existsSync(destination + file)) throw Error('Refusing compiled output overwrite');
    writeFileSync(destination + file, compressed);
    return { file, rawBytes: bytes.length, rawSha256: sha(bytes), compressedBytes: compressed.length,
      compressedSha256: sha(compressed), gzipMtime: 0 };
  });
  const inputs = [...new Set(chunks.flatMap(chunk => Object.keys(chunk.modules)))].sort().map(path => {
    if (!isAbsolute(path)) return { path, virtual: true };
    return { path: relative(process.cwd(), path), sha256: sha(readFileSync(path)) };
  });
  for (const expected of [source, 'scripts/lib/solana-localnet-browser-fixture.mjs',
    'scripts/lib/solana-localnet-send-evidence.mjs', 'apps/web/src/solana-localnet/funding-proposal.ts']) {
    if (!inputs.some(item => item.path === expected)) throw Error('Expected compiled module absent: ' + expected);
  }
  console.log(JSON.stringify({ check: 'Build-only Node browser-driver compilation; generated output is never evaluated',
    nodeVersion: process.version, rolldownVersion: VERSION, source, inputCount: inputs.length, inputs, warnings, outputs,
    external: 'Node builtins and bare package imports', nativeBrowserExecuted: false, nativeValidatorExecuted: false,
    compiledOutputExecuted: false, ReleaseEnabled: 0 }, null, 2));
} finally { await build.close(); }
