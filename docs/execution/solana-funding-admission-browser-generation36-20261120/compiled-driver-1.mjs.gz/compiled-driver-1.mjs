import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { resolve } from "node:path";
import { SyntaxKind, createScanner } from "typescript/unstable/ast";
// apps/web/scripts/artifact-policy.mjs
/** Bounded static checks complement browser probes; they do not prove absence of XSS. */
const forbiddenMembers = /* @__PURE__ */ new Set([
	"innerHTML",
	"outerHTML",
	"insertAdjacentHTML",
	"dangerouslySetInnerHTML",
	"serviceWorker",
	"sendBeacon"
]);
/**
* `allowWebSocketConstructor` is set only by the localnet build plugin, and only for packages/relay/src/pool.ts; every
* other token check still applies there, and every other module and profile keeps the full policy.
*/
function inspectApplicationSource(path, source, { allowWebSocketConstructor = false, allowFetch = false } = {}) {
	const scanner = createScanner(true, void 0, source);
	const tokens = [], templates = [];
	let braces = 0, previousEnd = -1;
	for (let kind = scanner.scan(); kind !== SyntaxKind.EndOfFile; kind = scanner.scan()) {
		if (kind === SyntaxKind.SlashToken && [
			"=",
			"(",
			"[",
			",",
			":",
			"return",
			"!",
			"&&",
			"||",
			"?",
			"=>"
		].includes(tokens.at(-1)?.text)) kind = scanner.reScanSlashToken();
		if (kind === SyntaxKind.CloseBraceToken && templates.at(-1) === braces) {
			kind = scanner.reScanTemplateToken(false);
			if (kind === SyntaxKind.TemplateTail) templates.pop();
		} else if (kind === SyntaxKind.OpenBraceToken) braces++;
		else if (kind === SyntaxKind.CloseBraceToken) braces--;
		if (kind === SyntaxKind.TemplateHead) templates.push(braces);
		if (tokens.length > source.length * 2 + 1 || scanner.getTokenEnd() <= previousEnd) throw new Error(`SOURCE_SCANNER_LIMIT: ${path}`);
		previousEnd = scanner.getTokenEnd();
		tokens.push({
			kind,
			text: scanner.getTokenText(),
			value: scanner.getTokenValue()
		});
	}
	const fail = () => {
		throw new Error(`SOURCE_POLICY: ${path}`);
	};
	for (let i = 0; i < tokens.length; i++) {
		const token = tokens[i], previous = tokens[i - 1]?.text, next = tokens[i + 1]?.text;
		if ((token.kind === SyntaxKind.Identifier || token.kind === SyntaxKind.StringLiteral && previous === "[") && forbiddenMembers.has(token.value)) fail();
		if (token.kind === SyntaxKind.Identifier && [
			"eval",
			"Function",
			"fetch",
			"WebSocket",
			"XMLHttpRequest",
			"EventSource"
		].includes(token.value) && next === "(" && !(allowWebSocketConstructor === true && token.value === "WebSocket" && previous === "new") && !(allowFetch === true && token.value === "fetch")) fail();
		if (["write", "writeln"].includes(token.value) && previous === "." && tokens[i - 2]?.text === "document") fail();
		if (token.value === "style" && next === "=") fail();
		if (token.value === "setAttribute" && next === "(" && tokens[i + 2]?.kind === SyntaxKind.StringLiteral && /^(?:on|style$)/i.test(tokens[i + 2].value)) fail();
	}
}
function safeArtifactPath(path) {
	if (typeof path !== "string" || path.length < 1 || path.length > 240 || !/^[a-zA-Z0-9._/-]+$/.test(path) || path.startsWith("/") || path.split("/").some((part) => !part || part === "." || part === "..")) throw new Error("ARTIFACT_PATH");
	return path;
}
const localResource = (value) => /^(?:\.\/)?[a-zA-Z0-9_-][a-zA-Z0-9._/-]*$/.test(value) && !value.split("/").includes("..");
function inspectArtifactFiles(files) {
	const paths = Object.keys(files);
	if (paths.length > 1e4 || new Set(paths.map((path) => safeArtifactPath(path).toLowerCase())).size !== paths.length) throw new Error("ARTIFACT_POLICY: paths");
	let total = 0, frameworkSinkTokens = 0;
	for (const path of paths) {
		const text = String(files[path]);
		total += Buffer.byteLength(text);
		const fail = () => {
			throw new Error(`ARTIFACT_POLICY: ${path}`);
		};
		if (total > 268435456 || path.endsWith(".map") || /sourceMappingURL|-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----/.test(text)) fail();
		if (/\.(?:html|css|js)$/.test(path) && /\b(?:eval\s*\(|new\s+Function\s*\(|serviceWorker\s*\.\s*register\s*\()/.test(text)) fail();
		if (path.endsWith(".html")) {
			if (/\s(?:on[a-z]+|style|srcset|poster|action)\s*=/i.test(text) || /http-equiv\s*=\s*["']?\s*refresh\b/i.test(text) || /<(?:style|iframe|object|embed|base)\b/i.test(text)) fail();
			for (const script of text.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) if (script[2].trim() || !/\bsrc\s*=/.test(script[1])) fail();
			for (const match of text.matchAll(/\b(?:src|href)\s*=\s*["']([^"']*)["']/gi)) {
				if (!localResource(match[1]) && !/^#\/[a-z/]*$/.test(match[1])) fail();
				if (localResource(match[1]) && !Object.hasOwn(files, match[1].replace(/^\.\//, ""))) fail();
			}
		}
		if (path.endsWith(".css")) {
			if (/@import\b/i.test(text)) fail();
			for (const match of text.matchAll(/url\(\s*["']?([^\s"')]+)/gi)) if (!localResource(match[1])) fail();
		}
		if (path.endsWith(".js")) {
			if (/\b(?:import|export)\s*(?:\([^)]*|[^;]*?from\s*)?["'](?:https?:|\/\/|data:|blob:)/.test(text)) fail();
			frameworkSinkTokens += (text.match(/innerHTML|outerHTML|insertAdjacentHTML|dangerouslySetInnerHTML/g) ?? []).length;
		}
	}
	return {
		files: paths.length,
		bytes: total,
		bundledSinkTokensRequiringFrameworkReview: frameworkSinkTokens,
		completeXssProof: false
	};
}
// packages/security/src/content-policy.ts
var ContentBoundaryError = class extends Error {
	code;
	messageKey;
	constructor(code = "INVALID_INPUT") {
		super("Content boundary input unavailable.");
		this.name = "ContentBoundaryError";
		this.code = code;
		this.messageKey = `content.error.${code.toLowerCase()}`;
	}
};
function fail(code = "INVALID_INPUT") {
	throw new ContentBoundaryError(code);
}
function exact(input, keys) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail();
		const prototype = Object.getPrototypeOf(input);
		if (prototype !== Object.prototype && prototype !== null) return fail();
		const own = Reflect.ownKeys(input);
		if (own.length !== keys.length || own.some((key) => typeof key !== "string" || !keys.includes(key))) return fail();
		const copy = Object.create(null);
		for (const key of keys) {
			const descriptor = Object.getOwnPropertyDescriptor(input, key);
			if (!descriptor || !("value" in descriptor)) return fail();
			copy[key] = descriptor.value;
		}
		return copy;
	} catch {
		return fail();
	}
}
/** Offline-only build data. Registry-derived external origins require a separate authenticated issuer. */
function buildOfflineContentPolicy(input) {
	const raw = exact(input, [
		"version",
		"releaseId",
		"delivery"
	]);
	const delivery = policyInput(raw);
	const csp = offlineCsp(delivery, "'none'");
	return assemble(Object.freeze({
		version: 1,
		releaseId: raw.releaseId,
		connectOrigins: Object.freeze([]),
		delivery,
		framingProtected: false
	}), csp, delivery, []);
}
function policyInput(raw) {
	if (raw.version !== 1 || typeof raw.releaseId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(raw.releaseId) || raw.delivery !== "header" && raw.delivery !== "meta") return fail();
	return raw.delivery;
}
function offlineCsp(delivery, connectSource) {
	const directives = {
		"default-src": "'none'",
		"script-src": "'self'",
		"style-src": "'self'",
		"img-src": "'self'",
		"font-src": "'self'",
		"connect-src": connectSource,
		"worker-src": "'self'",
		"manifest-src": "'self'",
		"base-uri": "'none'",
		"object-src": "'none'",
		"form-action": "'none'",
		"frame-src": "'none'"
	};
	if (delivery === "header") directives["frame-ancestors"] = "'none'";
	return Object.keys(directives).sort().map((name) => `${name} ${directives[name]}`).join("; ");
}
function assemble(manifest, csp, delivery, extraNotices) {
	const headers = delivery === "header" ? Object.freeze({
		"Content-Security-Policy": csp,
		"Referrer-Policy": "no-referrer",
		"X-Content-Type-Options": "nosniff"
	}) : Object.freeze({});
	const meta = delivery === "header" ? Object.freeze([]) : Object.freeze([Object.freeze({
		httpEquiv: "Content-Security-Policy",
		content: csp
	}), Object.freeze({
		name: "referrer",
		content: "no-referrer"
	})]);
	const notices = ["content.policy.deployment-unverified", "content.policy.framing-unverified"];
	if (delivery === "meta") notices.push("content.policy.meta-before-resources-required");
	notices.push(...extraNotices);
	return Object.freeze({
		manifest,
		csp,
		headers,
		meta,
		notices: Object.freeze(notices)
	});
}
/**
* Localnet build profile only (apps/web/scripts/build.mjs `delivery: 'localnet'`, a library-only test seam). Identical to
* the offline policy except that connect-src names exactly one plain-WebSocket loopback relay origin
* (`ws://127.0.0.1:PORT` or `ws://[::1]:PORT`, explicit canonical port, no path/credentials/query/fragment). No other
* origin, scheme, wildcard or 'self' is ever added. A browser whose CSP parser refuses an IPv6 literal drops the source,
* which leaves connect-src empty: the relay is then blocked (fail closed), never widened.
*/
const LOCALNET_RELAY_ORIGIN_PATTERN = /^ws:\/\/(?:127\.0\.0\.1|\[::1\]):([1-9][0-9]{0,4})$/;
function isLocalnetRelayOrigin(value) {
	if (typeof value !== "string") return false;
	const match = LOCALNET_RELAY_ORIGIN_PATTERN.exec(value);
	return match !== null && Number(match[1]) <= 65535;
}
function buildLocalnetContentPolicy(input) {
	const raw = exact(input, [
		"version",
		"releaseId",
		"delivery",
		"relayOrigin"
	]);
	const delivery = policyInput(raw);
	if (!isLocalnetRelayOrigin(raw.relayOrigin)) return fail();
	const relayOrigin = raw.relayOrigin;
	const csp = offlineCsp(delivery, relayOrigin);
	return assemble(Object.freeze({
		version: 1,
		releaseId: raw.releaseId,
		connectOrigins: Object.freeze([relayOrigin]),
		delivery,
		framingProtected: false,
		profile: "localnet",
		testFundsOnly: true
	}), csp, delivery, ["content.policy.localnet-test-funds-only"]);
}
function buildSolanaLocalnetContentPolicy(input) {
	const raw = exact(input, [
		"version",
		"releaseId",
		"delivery",
		"rpcOrigin"
	]);
	const delivery = policyInput(raw), origin = raw.rpcOrigin;
	if (typeof origin !== "string" || !/^http:\/\/127\.0\.0\.1:[1-9][0-9]{0,4}$/.test(origin)) return fail();
	let parsed;
	try {
		parsed = new URL(origin);
	} catch {
		return fail();
	}
	if (parsed.origin !== origin || !parsed.port || Number(parsed.port) > 65535) return fail();
	return assemble(Object.freeze({
		version: 1,
		releaseId: raw.releaseId,
		connectOrigins: Object.freeze([origin]),
		delivery,
		framingProtected: false,
		profile: "solana-localnet",
		testFundsOnly: true
	}), offlineCsp(delivery, origin), delivery, ["content.policy.localnet-test-funds-only"]);
}
// apps/web/scripts/qr-build-policy.mjs
/** The public image decoder is a separate, exact module/asset role; it is never a private runtime Worker. */
const QR_DECODER_ENTRY = "apps/web/src/qr/decode.worker.ts";
const QR_DECODER_GRAPH = "qr-graph-worker.json";
const JSQR_DIST_SHA256 = "bc40c8a15196236b2314db0856f72ca0b49980cd5413b8c852a7349f5fee0859";
const QR_DECODER_MODULES = Object.freeze([
	QR_DECODER_ENTRY,
	"apps/web/src/qr/decoder.ts",
	"apps/web/src/qr/protocol.ts",
	"node_modules/jsqr/dist/jsQR.js"
]);
const allowed = new Set(QR_DECODER_MODULES);
const assetPattern = /^assets\/decode\.worker-[A-Za-z0-9_-]+\.js$/;
const digest = (value) => createHash("sha256").update(value).digest("hex");
function assertQrDecoderModule(path) {
	if (!allowed.has(path)) throw new Error(`QR_DECODER_MODULE: ${path}`);
}
function assertNotQrDecoderModule(path) {
	if (path === "apps/web/src/qr/decode.worker.ts" || path === "apps/web/src/qr/decoder.ts" || /(?:^|\/)node_modules\/jsqr(?:\/|$)/.test(path)) throw new Error(`QR_DECODER_SCOPE: ${path}`);
}
function checkedModules(modules) {
	if (!Array.isArray(modules) || modules.length !== allowed.size || new Set(modules.map((item) => item?.path)).size !== allowed.size) throw new Error("QR_DECODER_MODULE");
	for (const item of modules) {
		assertQrDecoderModule(item?.path);
		if (!/^[0-9a-f]{64}$/.test(item.sha256)) throw new Error("QR_DECODER_MODULE");
		if (item.path === "node_modules/jsqr/dist/jsQR.js" && item.sha256 !== "bc40c8a15196236b2314db0856f72ca0b49980cd5413b8c852a7349f5fee0859") throw new Error("QR_DECODER_PIN");
	}
}
function qrDecoderGraph(modules, bundle, repositoryPath) {
	checkedModules(modules);
	const entries = Object.values(bundle).filter((file) => file.type === "chunk" && file.isEntry);
	if (entries.length !== 1 || !assetPattern.test(entries[0].fileName) || repositoryPath(entries[0].facadeModuleId) !== "apps/web/src/qr/decode.worker.ts") throw new Error("QR_DECODER_ASSET");
	return {
		version: 1,
		scope: "public-qr-decoder",
		entry: QR_DECODER_ENTRY,
		asset: {
			path: entries[0].fileName,
			sha256: digest(entries[0].code)
		},
		modules,
		authority: "none",
		privateRuntime: false,
		network: false
	};
}
function parseGraph(text) {
	let graph;
	try {
		graph = JSON.parse(text);
	} catch {
		throw new Error("QR_DECODER_GRAPH");
	}
	if (graph?.version !== 1 || graph.scope !== "public-qr-decoder" || graph.entry !== "apps/web/src/qr/decode.worker.ts" || graph.authority !== "none" || graph.privateRuntime !== false || graph.network !== false) throw new Error("QR_DECODER_GRAPH");
	checkedModules(graph.modules);
	return graph;
}
function inspectQrArtifact(files, documentModules, nativeModules) {
	if (!Array.isArray(documentModules) || !Array.isArray(nativeModules)) throw new Error("CORE_GRAPH_INVALID");
	for (const module of [...documentModules, ...nativeModules]) assertNotQrDecoderModule(module.path);
	const expected = documentModules.some((item) => item.path === "apps/web/src/ui/QrPanel.tsx");
	const assets = Object.keys(files).filter((path) => assetPattern.test(path));
	const graphPresent = Object.hasOwn(files, QR_DECODER_GRAPH);
	if (!expected) {
		if (assets.length || graphPresent) throw new Error("QR_DECODER_UNREACHABLE");
		return null;
	}
	if (!graphPresent) throw new Error("QR_DECODER_GRAPH");
	if (assets.length !== 1) throw new Error("QR_DECODER_ASSET");
	const graph = parseGraph(files[QR_DECODER_GRAPH]);
	if (graph.asset?.path !== assets[0] || graph.asset?.sha256 !== digest(files[assets[0]])) throw new Error("QR_DECODER_ASSET");
	let licenses;
	try {
		licenses = JSON.parse(files["third-party-licenses.json"]);
	} catch {
		throw new Error("LICENSE_ATTRIBUTION_MISSING");
	}
	if (!Array.isArray(licenses) || !licenses.some((item) => item.name === "jsqr" && item.version === "1.4.0" && item.identifier === "Apache-2.0" && typeof item.text === "string" && item.text.includes("Apache License") && item.text.includes("Version 2.0"))) throw new Error("LICENSE_ATTRIBUTION_MISSING");
	return {
		decoderVersion: "1.4.0",
		dependencySha256: JSQR_DIST_SHA256,
		graph: QR_DECODER_GRAPH,
		worker: graph.asset.path,
		authority: "none",
		physicalDeviceQualification: false
	};
}
async function completeQrWorkerLicense(directory, inventory, dependencyRoot) {
	let text;
	try {
		text = await readFile(resolve(directory, QR_DECODER_GRAPH), "utf8");
	} catch (error) {
		if (error?.code === "ENOENT") return;
		throw error;
	}
	parseGraph(text);
	const root = resolve(dependencyRoot, "jsqr");
	const manifest = JSON.parse(await readFile(resolve(root, "package.json"), "utf8"));
	const license = await readFile(resolve(root, "LICENSE"), "utf8");
	if (manifest.name !== "jsqr" || manifest.version !== "1.4.0" || manifest.license !== "Apache-2.0" || !license.includes("Apache License") || !license.includes("Version 2.0") || digest(await readFile(resolve(root, "dist/jsQR.js"))) !== "bc40c8a15196236b2314db0856f72ca0b49980cd5413b8c852a7349f5fee0859") throw new Error("QR_DECODER_PIN");
	const existing = inventory.find((item) => item.name === "jsqr");
	if (existing) {
		if (existing.version !== "1.4.0" || existing.identifier !== "Apache-2.0" || existing.text !== license) throw new Error("LICENSE_ATTRIBUTION_MISSING");
	} else inventory.push({
		name: manifest.name,
		version: manifest.version,
		identifier: manifest.license,
		text: license
	});
}
export { completeQrWorkerLicense as a, buildLocalnetContentPolicy as c, inspectApplicationSource as d, inspectArtifactFiles as f, assertQrDecoderModule as i, buildOfflineContentPolicy as l, QR_DECODER_GRAPH as n, inspectQrArtifact as o, safeArtifactPath as p, assertNotQrDecoderModule as r, qrDecoderGraph as s, QR_DECODER_ENTRY as t, buildSolanaLocalnetContentPolicy as u };
