#!/usr/bin/env node
import { a as completeQrWorkerLicense, c as buildLocalnetContentPolicy, f as inspectArtifactFiles, o as inspectQrArtifact, p as safeArtifactPath, u as buildSolanaLocalnetContentPolicy } from "./qr-build-policy-0fAj4LOV.js";
import { createRequire } from "node:module";
import assert from "node:assert/strict";
import { lstat, mkdir, mkdtemp, readFile, readdir, realpath, rm, writeFile } from "node:fs/promises";
import { createHash, createPublicKey, randomBytes, verify } from "node:crypto";
import { accessSync, closeSync, constants, existsSync, openSync, readFileSync, readdirSync, realpathSync, statSync, writeFileSync } from "node:fs";
import { ed25519 } from "@noble/curves/ed25519.js";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { createServer as createServer$1 } from "node:net";
import { tmpdir } from "node:os";
import { basename, delimiter, dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { sha256 } from "@noble/hashes/sha2.js";
import { chromium } from "playwright-core";
import { build } from "vite";
// contracts/solana/vectors/derive.mjs
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const enc$1 = new TextEncoder();
const FORMAT = "p2p-offramp/solana-independent-vectors/v1";
const FIXTURE_PATH = fileURLToPath(new URL("./solana-independent.json", import.meta.url));
const sha256$1 = (...parts) => {
	const h = createHash("sha256");
	for (const p of parts) h.update(p);
	return new Uint8Array(h.digest());
};
const toHex = (b) => Buffer.from(b).toString("hex");
function base58Encode(bytes) {
	let n = 0n;
	for (const b of bytes) n = n << 8n | BigInt(b);
	let out = "";
	while (n > 0n) {
		out = ALPHABET[Number(n % 58n)] + out;
		n /= 58n;
	}
	let zeros = 0;
	while (zeros < bytes.length && bytes[zeros] === 0) zeros++;
	return "1".repeat(zeros) + out;
}
function base58Decode(str, expectedLength = null) {
	if (typeof str !== "string" || str.length === 0) throw new Error("base58: empty input");
	let n = 0n;
	for (const ch of str) {
		const i = ALPHABET.indexOf(ch);
		if (i < 0) throw new Error(`base58: invalid character ${JSON.stringify(ch)}`);
		n = n * 58n + BigInt(i);
	}
	let hex = n.toString(16);
	if (hex.length % 2) hex = "0" + hex;
	let body = n === 0n ? [] : [...Buffer.from(hex, "hex")];
	let zeros = 0;
	while (zeros < str.length && str[zeros] === "1") zeros++;
	const bytes = Uint8Array.from([...new Array(zeros).fill(0), ...body]);
	if (base58Encode(bytes) !== str) throw new Error("base58: non-canonical encoding");
	if (expectedLength !== null && bytes.length !== expectedLength) throw new Error(`base58: expected ${expectedLength} bytes, got ${bytes.length}`);
	return bytes;
}
const decodeKey$1 = (s) => base58Decode(s, 32);
function isOnCurve$1(bytes32) {
	try {
		ed25519.Point.fromBytes(bytes32);
		return true;
	} catch {
		return false;
	}
}
function createProgramAddress(seeds, programId) {
	if (seeds.length > 16) throw new Error("PDA: max 16 seeds");
	for (const s of seeds) if (s.length > 32) throw new Error("PDA: seed longer than 32 bytes");
	if (programId.length !== 32) throw new Error("PDA: program id must be 32 bytes");
	const hash = sha256$1(...seeds, programId, enc$1.encode("ProgramDerivedAddress"));
	if (isOnCurve$1(hash)) throw new Error("PDA: derived address is on curve");
	return hash;
}
function findProgramAddress$1(seeds, programId) {
	for (let bump = 255; bump >= 0; bump--) try {
		return {
			address: createProgramAddress([...seeds, Uint8Array.of(bump)], programId),
			bump
		};
	} catch (e) {
		if (!/on curve/.test(e.message)) throw e;
	}
	throw new Error("PDA: no viable bump");
}
const ATA_PROGRAM_ID$1 = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL";
const SPL_PROGRAM_ID$1 = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
const PROGRAM_ID_ASCII = "escrow-program:p2p-offramp:local";
const PROGRAM_ID = base58Encode(enc$1.encode(PROGRAM_ID_ASCII));
const MINT_ASCII = ["mint-6dp-open:p2p-offramp:local1", "freezable-mint-6dp:p2p-offramp:1"];
const MINTS = MINT_ASCII.map((m) => base58Encode(enc$1.encode(m)));
if (PROGRAM_ID !== "7q2EChqznfQea58ZfUvBzRd97Bc28kwHaey1tYy7ADjq") throw new Error("PROGRAM_ID mismatch");
function findAta(owner, mint) {
	return findProgramAddress$1([
		owner,
		decodeKey$1(SPL_PROGRAM_ID$1),
		mint
	], decodeKey$1(ATA_PROGRAM_ID$1));
}
const pda$1 = (r) => ({
	address: base58Encode(r.address),
	bump: r.bump
});
function discriminator$1(ns, name) {
	return toHex(sha256$1(enc$1.encode(`${ns}:${name}`)).slice(0, 8));
}
function escrowCase(i, seller, nonce, nonceLabel) {
	const programId = decodeKey$1(PROGRAM_ID);
	const escrow = findProgramAddress$1([
		enc$1.encode("p2p-offramp-escrow-v1"),
		seller,
		nonce
	], programId);
	const vault = findProgramAddress$1([enc$1.encode("p2p-offramp-vault-v1"), escrow.address], programId);
	const buyer = sha256$1(enc$1.encode(`vector-buyer-${i}`));
	return {
		index: i,
		seller: base58Encode(seller),
		sellerHex: toHex(seller),
		nonce: base58Encode(nonce),
		nonceHex: toHex(nonce),
		nonceLabel,
		escrow: pda$1(escrow),
		vault: pda$1(vault),
		buyer: base58Encode(buyer),
		buyerAtas: MINTS.map((m) => ({
			mint: m,
			ata: pda$1(findAta(buyer, decodeKey$1(m)))
		}))
	};
}
function buildEscrowCases() {
	const cases = [];
	for (let i = 0; i < 6; i++) {
		const seller = sha256$1(enc$1.encode(`vector-seller-${i}`));
		let nonce = sha256$1(enc$1.encode(`vector-nonce-${i}`));
		let label = "sha256";
		if (i === 2) [nonce, label] = [/* @__PURE__ */ new Uint8Array(32), "all-zero"];
		if (i === 4) [nonce, label] = [(/* @__PURE__ */ new Uint8Array(32)).fill(255), "all-0xff"];
		cases.push(escrowCase(i, seller, nonce, label));
	}
	const low = (c) => [
		c.escrow,
		c.vault,
		...c.buyerAtas.map((a) => a.ata)
	].some((p) => p.bump < 255);
	for (let i = 6; !cases.some(low) && i < 200; i++) {
		const seller = sha256$1(enc$1.encode(`vector-seller-${i}`));
		cases.push(escrowCase(i, seller, sha256$1(enc$1.encode(`vector-nonce-${i}`)), "sha256"));
	}
	return cases;
}
function negativeCases() {
	const attempt = (fn) => {
		try {
			fn();
			return false;
		} catch {
			return true;
		}
	};
	const pid = decodeKey$1(PROGRAM_ID);
	const k = (n) => base58Encode(new Uint8Array(n).fill(1));
	const seeds = (n) => Array.from({ length: n }, () => Uint8Array.of(1));
	return [
		["createProgramAddress with 17 one-byte seeds", () => createProgramAddress(seeds(17), pid)],
		["createProgramAddress with one 33-byte seed", () => createProgramAddress([/* @__PURE__ */ new Uint8Array(33)], pid)],
		["findProgramAddress with 16 user seeds (bump makes 17)", () => findProgramAddress$1(seeds(16), pid)],
		["base58 decode of \"0OIl\" (excluded characters)", () => base58Decode("0OIl")],
		["base58 decode of 31-byte key", () => decodeKey$1(k(31))],
		["base58 decode of 33-byte key", () => decodeKey$1(k(33))]
	].map(([description, fn]) => ({
		description,
		expectError: attempt(fn)
	}));
}
function buildFixture() {
	const req = createRequire(import.meta.url);
	const ver = (p) => {
		const entry = req.resolve(`${p}/utils.js`);
		const root = entry.slice(0, entry.lastIndexOf(`node_modules/${p}/`) + `node_modules/${p}/`.length);
		return JSON.parse(readFileSync(root + "package.json", "utf8")).version;
	};
	const names = [
		"fund_native",
		"fund_spl",
		"release",
		"refund",
		"payout_native",
		"payout_spl"
	];
	const disc = (ns, list) => Object.fromEntries(list.map((n) => [n, discriminator$1(ns, n)]));
	return {
		format: FORMAT,
		generator: {
			file: "contracts/solana/vectors/derive.mjs",
			nodeMajor: process.versions.node.split(".")[0],
			nobleCurves: ver("@noble/curves"),
			nobleHashes: ver("@noble/hashes")
		},
		constants: {
			programId: PROGRAM_ID,
			programIdAscii: PROGRAM_ID_ASCII,
			ataProgramId: ATA_PROGRAM_ID$1,
			tokenProgramId: SPL_PROGRAM_ID$1,
			idsSource: "known-constant-unverified-on-disk",
			escrowSeedPrefix: "p2p-offramp-escrow-v1",
			vaultSeedPrefix: "p2p-offramp-vault-v1",
			mints: MINT_ASCII.map((a, i) => ({
				ascii: a,
				address: MINTS[i]
			}))
		},
		discriminators: {
			accounts: disc("account", ["EscrowV1"]),
			instructions: disc("global", names),
			events: disc("event", [
				"Funded",
				"Released",
				"Refunded",
				"PaidOut"
			])
		},
		escrowCases: buildEscrowCases(),
		negativeCases: negativeCases()
	};
}
const render = () => JSON.stringify(buildFixture(), null, 2) + "\n";
if (process.argv[1] === fileURLToPath(import.meta.url)) {
	const out = render();
	if (process.argv.includes("--write")) writeFileSync(FIXTURE_PATH, out);
	else if (process.argv.includes("--check")) {
		let cur = "";
		try {
			cur = readFileSync(FIXTURE_PATH, "utf8");
		} catch {}
		if (cur !== out) {
			console.error("fixture differs from regenerated output");
			process.exit(1);
		}
	} else {
		console.error("usage: derive.mjs --write | --check");
		process.exit(2);
	}
}
// contracts/solana/localnet/driver.mjs
const LOADER_V3_ID$1 = "BPFLoaderUpgradeab1e11111111111111111111111";
const SYSVAR_CLOCK_ID = "SysvarC1ock11111111111111111111111111111111";
MINTS[0];
MINTS[1];
const GENESIS_HASH_ASCII = "genesis-hash:p2p-offramp:localv1";
const enc = new TextEncoder();
const utf8$3 = (s) => enc.encode(s);
const view = (data) => new DataView(data.buffer, data.byteOffset, data.byteLength);
const readU64$1 = (data, off) => view(data).getBigUint64(off, true);
const readI64$1 = (data, off) => view(data).getBigInt64(off, true);
const readKey = (data, off) => base58Encode(data.slice(off, off + 32));
function keypairFromSeed(seed) {
	if (seed.length !== 32) throw new Error("keypair: seed must be 32 bytes");
	const publicKey = ed25519.getPublicKey(Uint8Array.from(seed));
	const kp = {
		address: base58Encode(publicKey),
		publicKey
	};
	Object.defineProperty(kp, "seed", {
		value: Uint8Array.from(seed),
		enumerable: false
	});
	kp.toJSON = () => kp.address;
	return kp;
}
const generateKeypair = () => keypairFromSeed(randomBytes(32));
function writeKeypairFile(path, kp) {
	writeFileSync(path, JSON.stringify([...kp.seed, ...kp.publicKey]), { mode: 384 });
}
var RpcError = class extends Error {
	constructor(method, error) {
		super(`rpc ${method}: ${error.code} ${error.message}`);
		this.code = error.code;
		this.data = error.data;
	}
};
var Rpc = class {
	constructor(url, timeoutMs = 15e3) {
		this.url = url;
		this.timeoutMs = timeoutMs;
		this.nextId = 1;
	}
	async call(method, params = []) {
		const body = JSON.stringify({
			jsonrpc: "2.0",
			id: this.nextId++,
			method,
			params
		});
		const res = await fetch(this.url, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body,
			signal: AbortSignal.timeout(this.timeoutMs)
		});
		if (!res.ok) throw new Error(`rpc ${method}: HTTP ${res.status}`);
		const json = await res.json();
		if (json.error) throw new RpcError(method, json.error);
		return json.result;
	}
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const LEVELS = {
	processed: 0,
	confirmed: 1,
	finalized: 2
};
async function getAccount(rpc, address, commitment = "confirmed") {
	const res = await rpc.call("getAccountInfo", [address, {
		encoding: "base64",
		commitment
	}]);
	const v = res.value;
	if (!v) return null;
	const data = new Uint8Array(Buffer.from(v.data[0], "base64"));
	return {
		lamports: v.lamports,
		owner: v.owner,
		executable: v.executable,
		data,
		slot: res.context.slot
	};
}
async function getBalance(rpc, address, commitment = "finalized") {
	return (await rpc.call("getBalance", [address, { commitment }])).value;
}
async function readClock(rpc, commitment = "confirmed") {
	const acc = await getAccount(rpc, SYSVAR_CLOCK_ID, commitment);
	if (!acc || acc.data.length < 40) throw new Error("clock sysvar: missing or short");
	return {
		slot: Number(readU64$1(acc.data, 0)),
		epochStartTimestamp: Number(readI64$1(acc.data, 8)),
		epoch: Number(readU64$1(acc.data, 16)),
		unixTimestamp: Number(readI64$1(acc.data, 32))
	};
}
async function waitForSignature(rpc, signature, commitment, timeoutMs) {
	const deadline = Date.now() + timeoutMs;
	for (;;) {
		const st = (await rpc.call("getSignatureStatuses", [[signature], { searchTransactionHistory: true }])).value[0];
		if (st && LEVELS[st.confirmationStatus] >= LEVELS[commitment]) return st;
		if (Date.now() > deadline) throw new Error(`signature ${signature}: not ${commitment} within ${timeoutMs} ms (last ${JSON.stringify(st)})`);
		await sleep(500);
	}
}
function programDataAddress$1(programId) {
	return base58Encode(findProgramAddress$1([decodeKey$1(programId)], decodeKey$1(LOADER_V3_ID$1)).address);
}
function decodeProgramDataHeader(data) {
	if (data.length < 45 || view(data).getUint32(0, true) !== 3) throw new Error("loader-v3 ProgramData: bad header");
	const tag = data[12];
	if (tag > 1) throw new Error("loader-v3 ProgramData: bad authority option tag");
	return {
		slot: Number(readU64$1(data, 4)),
		upgradeAuthority: tag === 1 ? readKey(data, 13) : null
	};
}
// contracts/solana/localnet/tool-path.mjs
/**
* Resolve a developer tool (solana, solana-test-validator, solana-keygen) to an absolute executable path.
* Only absolute PATH entries are searched, and a world-writable entry or candidate is skipped, so a planted
* binary in a shared directory or a relative "." entry is never selected.
*/
function resolveTool(name, searchPath = process.env.PATH ?? "") {
	if (typeof name !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(name)) throw new Error("TOOL_NAME_INVALID");
	for (const directory of String(searchPath).split(delimiter)) {
		if (!isAbsolute(directory) || worldWritable(directory, true)) continue;
		const candidate = join(directory, name);
		if (worldWritable(candidate, false)) continue;
		try {
			accessSync(candidate, constants.X_OK);
			return candidate;
		} catch {}
	}
	throw new Error(`TOOL_NOT_FOUND: ${name}`);
}
/** True when the path is missing, has the wrong kind, or grants write access to every user. */
function worldWritable(path, directory) {
	try {
		const info = statSync(path);
		if (directory ? !info.isDirectory() : !info.isFile()) return true;
		return (info.mode & 2) !== 0;
	} catch {
		return true;
	}
}
// packages/domain/src/errors.ts
const ACTIONS = Object.freeze({
	INVALID_INPUT: "edit-input",
	UNSUPPORTED_VERSION: "export",
	UNSUPPORTED_PROVIDER: "change-provider",
	WRONG_CHAIN: "reconnect",
	UNAUTHORIZED: "reconnect",
	USER_REJECTED: "none",
	LOCKED: "unlock",
	CONFLICT: "reload",
	UNAVAILABLE: "change-provider",
	TIMEOUT: "change-provider",
	CANCELLED: "none",
	LIMIT_EXCEEDED: "none",
	INTEGRITY_FAILURE: "change-provider",
	BROADCAST_UNKNOWN: "reconcile",
	EXPIRED: "edit-input"
});
let diagnosticSequence = 0n;
/** Diagnostic correlation only: never a key, nonce, capability, intent or authorization identifier. */
function createOperationId() {
	const bytes = /* @__PURE__ */ new Uint8Array(16);
	try {
		crypto.getRandomValues(bytes);
		return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
	} catch {
		diagnosticSequence = diagnosticSequence + 1n & (1n << 64n) - 1n;
		return `0000000000000000${diagnosticSequence.toString(16).padStart(16, "0")}`;
	} finally {
		bytes.fill(0);
	}
}
function createCoreError(code, context) {
	const validCode = typeof code === "string" && Object.hasOwn(ACTIONS, code) ? code : "INVALID_INPUT";
	const correlationId = typeof context.operationId === "string" && /^[0-9a-f]{32}$/.test(context.operationId) ? context.operationId : createOperationId();
	return Object.freeze({
		code: validCode,
		retryable: context.readOnly && (validCode === "TIMEOUT" || validCode === "UNAVAILABLE"),
		action: ACTIONS[validCode],
		correlationId,
		messageKey: `core.error.${validCode.toLowerCase()}`
	});
}
function normalizeError(input, context) {
	if (context.phase === "send-started") return createCoreError("BROADCAST_UNKNOWN", {
		operationId: context.operationId,
		readOnly: false
	});
	let code;
	try {
		if (typeof input === "object" && input !== null) {
			const descriptor = Object.getOwnPropertyDescriptor(input, "code");
			if (descriptor && "value" in descriptor) code = descriptor.value;
		}
	} catch {}
	return createCoreError(code === 4001 ? "USER_REJECTED" : typeof code === "string" && Object.hasOwn(ACTIONS, code) ? code : "UNAVAILABLE", {
		operationId: context.operationId,
		readOnly: context.phase === "read"
	});
}
// packages/schemas/src/vault.ts
/** G02 wire format. Validation grants no claim that ciphertext is authentic. */
const MAX_REVISION = 1048575;
const MAX_PAYLOAD_BYTES = 262144;
var ValidationError = class extends Error {
	code;
	constructor(code = "INVALID_INPUT") {
		super("Invalid vault data.");
		this.name = "ValidationError";
		this.code = code;
	}
};
function fail$8(code = "INVALID_INPUT") {
	throw new ValidationError(code);
}
function reflect$1(operation) {
	try {
		return operation();
	} catch {
		fail$8();
	}
}
/** Read only own data properties; never invoke user-provided getters. */
function object$1(input, keys) {
	if (typeof input !== "object" || input === null || reflect$1(() => Array.isArray(input))) fail$8();
	const proto = reflect$1(() => Object.getPrototypeOf(input));
	if (proto !== Object.prototype && proto !== null) fail$8();
	const actual = reflect$1(() => Reflect.ownKeys(input));
	if (actual.length !== keys.length || actual.some((key) => typeof key !== "string" || !keys.includes(key))) fail$8();
	const out = Object.create(null);
	for (const key of keys) {
		const descriptor = reflect$1(() => Object.getOwnPropertyDescriptor(input, key));
		if (!descriptor || !("value" in descriptor)) fail$8();
		out[key] = descriptor.value;
	}
	return out;
}
function integer$1(input, minimum, maximum) {
	if (typeof input !== "number" || !Number.isSafeInteger(input) || input < minimum || input > maximum) fail$8();
	return input;
}
function id$1(input) {
	if (typeof input !== "string" || !/^[0-9a-f]{32}$/.test(input)) fail$8();
	return input;
}
function version(input) {
	if (input !== 1) fail$8("UNSUPPORTED_VERSION");
	return 1;
}
function literal(input, expected) {
	if (input !== expected) fail$8();
	return expected;
}
function encodeBase64url(bytes) {
	if (!(bytes instanceof Uint8Array)) fail$8();
	let binary = "";
	for (let offset = 0; offset < bytes.length; offset += 8192) binary += String.fromCharCode(...bytes.subarray(offset, offset + 8192));
	return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}
function decodeBase64url(input, minimum, maximum) {
	integer$1(minimum, 0, 8388624);
	integer$1(maximum, minimum, 8388624);
	if (typeof input !== "string") fail$8();
	if (input.length > Math.ceil(maximum * 4 / 3)) fail$8("LIMIT_EXCEEDED");
	if (!/^[A-Za-z0-9_-]*$/.test(input) || input.length % 4 === 1) fail$8();
	let binary;
	try {
		binary = atob(input.replaceAll("-", "+").replaceAll("_", "/"));
	} catch {
		fail$8();
	}
	if (binary.length > maximum) fail$8("LIMIT_EXCEEDED");
	if (binary.length < minimum) fail$8();
	const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
	if (encodeBase64url(bytes) !== input) fail$8();
	return bytes;
}
function base64(input, minimum, maximum) {
	decodeBase64url(input, minimum, maximum);
	return input;
}
function parseVaultEnvelope(input) {
	const value = object$1(input, [
		"format",
		"version",
		"profileId",
		"keyId",
		"revision",
		"wrappedKey",
		"snapshot"
	]);
	const format = literal(value.format, "p2p-offramp-vault");
	const v = version(value.version);
	const profileId = id$1(value.profileId), keyId = id$1(value.keyId);
	const revision = integer$1(value.revision, 0, MAX_REVISION);
	const key = object$1(value.wrappedKey, [
		"kdf",
		"iterations",
		"salt",
		"cipher",
		"nonce",
		"ciphertext"
	]);
	const wrappedKey = {
		kdf: literal(key.kdf, "PBKDF2-SHA256"),
		iterations: integer$1(key.iterations, 6e5, 6e5),
		salt: base64(key.salt, 32, 32),
		cipher: literal(key.cipher, "AES-256-GCM"),
		nonce: base64(key.nonce, 12, 12),
		ciphertext: base64(key.ciphertext, 48, 48)
	};
	const snapshot = object$1(value.snapshot, ["nonce", "ciphertext"]);
	const nonce = base64(snapshot.nonce, 12, 12);
	if ((decodeBase64url(snapshot.ciphertext, 4112, 8388624).length - 16) % 4096 !== 0) fail$8();
	return {
		format,
		version: v,
		profileId,
		keyId,
		revision,
		wrappedKey,
		snapshot: {
			nonce,
			ciphertext: snapshot.ciphertext
		}
	};
}
function recordArray(input) {
	if (!reflect$1(() => Array.isArray(input)) || reflect$1(() => Object.getPrototypeOf(input)) !== Array.prototype) fail$8();
	const lengthProperty = reflect$1(() => Object.getOwnPropertyDescriptor(input, "length"));
	if (!lengthProperty || !("value" in lengthProperty)) fail$8();
	const length = lengthProperty.value;
	if (typeof length !== "number" || !Number.isSafeInteger(length) || length < 0) fail$8();
	if (length > 1e4) fail$8("LIMIT_EXCEEDED");
	const keys = reflect$1(() => Reflect.ownKeys(input));
	if (keys.length !== length + 1 || keys.some((key) => typeof key !== "string")) fail$8();
	const records = [];
	for (let index = 0; index < length; index++) {
		const descriptor = reflect$1(() => Object.getOwnPropertyDescriptor(input, String(index)));
		if (!descriptor || !("value" in descriptor)) fail$8();
		records.push(descriptor.value);
	}
	return records;
}
function parsePrivateSnapshot(input) {
	const value = object$1(input, [
		"format",
		"version",
		"profileId",
		"keyId",
		"revision",
		"records"
	]);
	const header = {
		format: literal(value.format, "p2p-offramp-private-records"),
		version: version(value.version),
		profileId: id$1(value.profileId),
		keyId: id$1(value.keyId),
		revision: integer$1(value.revision, 0, MAX_REVISION)
	};
	const records = [];
	let jsonBytes = JSON.stringify({
		...header,
		records: []
	}).length;
	let previousId = "";
	for (const raw of recordArray(value.records)) {
		const item = object$1(raw, [
			"id",
			"kind",
			"schemaVersion",
			"payload"
		]);
		const recordId = id$1(item.id);
		if (recordId <= previousId) fail$8();
		const kind = item.kind;
		if (kind !== "identity" && kind !== "preference" && kind !== "trade" && kind !== "chat" && kind !== "journal") fail$8();
		const schemaVersion = integer$1(item.schemaVersion, 1, 65535);
		if (typeof item.payload !== "string") fail$8();
		jsonBytes += JSON.stringify({
			id: recordId,
			kind,
			schemaVersion,
			payload: ""
		}).length + item.payload.length + (records.length ? 1 : 0);
		if (jsonBytes > 8388604) fail$8("LIMIT_EXCEEDED");
		const payload = base64(item.payload, 0, MAX_PAYLOAD_BYTES);
		records.push({
			id: recordId,
			kind,
			schemaVersion,
			payload
		});
		previousId = recordId;
	}
	return {
		...header,
		records
	};
}
function decodeSnapshot(bytes) {
	if (!(bytes instanceof Uint8Array) || bytes.length < 4096 || bytes.length > 8388608 || bytes.length % 4096 !== 0) fail$8();
	const length = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getUint32(0, false);
	if (length > 8388604 || length > bytes.length - 4 || length === 0) fail$8();
	for (let index = length + 4; index < bytes.length; index++) if (bytes[index] !== 0) fail$8();
	let text, parsed;
	try {
		text = new TextDecoder("utf-8", {
			fatal: true,
			ignoreBOM: true
		}).decode(bytes.subarray(4, 4 + length));
		parsed = JSON.parse(text);
	} catch {
		fail$8();
	}
	const snapshot = parsePrivateSnapshot(parsed);
	if (JSON.stringify(snapshot) !== text) fail$8();
	return snapshot;
}
function encodePassphrase(input) {
	if (typeof input !== "string" || input.length > 1024) fail$8();
	for (let index = 0; index < input.length; index++) {
		const code = input.charCodeAt(index);
		if (code >= 55296 && code <= 56319) {
			const next = input.charCodeAt(++index);
			if (!(next >= 56320 && next <= 57343)) fail$8();
		} else if (code >= 56320 && code <= 57343) fail$8();
	}
	const bytes = new TextEncoder().encode(input);
	if (bytes.length < 12 || bytes.length > 1024) fail$8();
	return bytes;
}
new TextEncoder();
new TextDecoder("utf-8", { fatal: true });
// packages/schemas/src/core.ts
var CoreSchemaError = class extends Error {
	code;
	constructor(code = "INVALID_INPUT") {
		super("Invalid core data.");
		this.name = "CoreSchemaError";
		this.code = code;
	}
};
function fail$7(code = "INVALID_INPUT") {
	throw new CoreSchemaError(code);
}
function reflect(read) {
	try {
		return read();
	} catch {
		return fail$7();
	}
}
function exact$1(input, keys) {
	if (typeof input !== "object" || input === null || reflect(() => Array.isArray(input))) fail$7();
	const prototype = reflect(() => Object.getPrototypeOf(input));
	if (prototype !== Object.prototype && prototype !== null) fail$7();
	const actual = reflect(() => Reflect.ownKeys(input));
	if (actual.length !== keys.length || actual.some((key) => typeof key !== "string" || !keys.includes(key))) fail$7();
	const out = Object.create(null);
	for (const key of keys) {
		const descriptor = reflect(() => Object.getOwnPropertyDescriptor(input, key));
		if (!descriptor || !("value" in descriptor)) fail$7();
		out[key] = descriptor.value;
	}
	return out;
}
function text$3(input, max = 256) {
	if (typeof input !== "string") fail$7();
	if (input.length > max) fail$7("LIMIT_EXCEEDED");
	if (input.length === 0 || !/^[A-Za-z0-9._:~-]+$/.test(input)) fail$7();
	return input;
}
function choice$1(input, values) {
	if (typeof input !== "string" || !values.includes(input)) fail$7();
	return input;
}
function parseTradeBinding(input) {
	const raw = exact$1(input, [
		"chain",
		"networkId",
		"deploymentId",
		"tradeId"
	]);
	return Object.freeze({
		chain: choice$1(raw.chain, ["evm", "solana"]),
		networkId: text$3(raw.networkId),
		deploymentId: text$3(raw.deploymentId),
		tradeId: text$3(raw.tradeId)
	});
}
function sameBinding(a, b) {
	return a.chain === b.chain && a.networkId === b.networkId && a.deploymentId === b.deploymentId && a.tradeId === b.tradeId;
}
// packages/schemas/src/intent.ts
var IntentSchemaError = class extends Error {
	code;
	constructor(code = "INVALID_INPUT") {
		super("Invalid private intent data.");
		this.name = "IntentSchemaError";
		this.code = code;
	}
};
function fail$6(code) {
	throw new IntentSchemaError(code);
}
function parseIntentId(value) {
	let bytes;
	try {
		bytes = decodeBase64url(value, 32, 32);
		return value;
	} catch {
		return fail$6();
	} finally {
		bytes?.fill(0);
	}
}
// packages/schemas/src/registry.ts
/**
* G11 v1 chain/asset/deployment registry: strict structural parsing only. Parsing is not authentication
* (the caller must first match the exact bytes to a G15-signed digest) and never contacts a chain or RPC.
* No network, asset, deployment or endpoint is approved by this module.
*/
const viewByteLength$2 = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint8Array.prototype), "byteLength").get;
const MAX_REGISTRY_BYTES = 1048576;
const fail$5 = (code = "INVALID_INPUT") => {
	throw new ValidationError(code);
};
/** Bounded JSON subset parser: objects, arrays, strings, non-negative safe integers, true/false/null. Duplicate keys reject. */
var RegistryJsonParser = class {
	#index = 0;
	#nodes = 0;
	#source;
	constructor(source) {
		this.#source = source;
	}
	#ws() {
		while (/[\t\n\r ]/.test(this.#source[this.#index] ?? "x")) this.#index++;
	}
	#string() {
		const start = this.#index++;
		for (;;) {
			const character = this.#source[this.#index++];
			if (character === void 0) return fail$5();
			if (character === "\\") {
				if (this.#source[this.#index++] === void 0) return fail$5();
			} else if (character === "\"") try {
				return JSON.parse(this.#source.slice(start, this.#index));
			} catch {
				return fail$5();
			}
		}
	}
	#literal(word, value) {
		if (this.#source.startsWith(word, this.#index)) {
			this.#index += word.length;
			return value;
		}
		return fail$5();
	}
	#value(depth) {
		if (depth > 6 || ++this.#nodes > 5e4) return fail$5();
		this.#ws();
		const character = this.#source[this.#index];
		if (character === "\"") return this.#string();
		if (character === "t") return this.#literal("true", true);
		if (character === "f") return this.#literal("false", false);
		if (character === "n") return this.#literal("null", null);
		if (character === "[") {
			this.#index++;
			this.#ws();
			const items = [];
			if (this.#source[this.#index] === "]") {
				this.#index++;
				return items;
			}
			for (;;) {
				items.push(this.#value(depth + 1));
				this.#ws();
				const separator = this.#source[this.#index++];
				if (separator === "]") return items;
				if (separator !== "," || items.length >= 256) return fail$5();
			}
		}
		if (character === "{") {
			this.#index++;
			this.#ws();
			const value = Object.create(null);
			if (this.#source[this.#index] === "}") {
				this.#index++;
				return value;
			}
			for (let count = 0;; count++) {
				this.#ws();
				if (this.#source[this.#index] !== "\"" || count >= 32) return fail$5();
				const key = this.#string();
				if (Object.hasOwn(value, key) || key === "__proto__" || key === "constructor" || key === "prototype") return fail$5();
				this.#ws();
				if (this.#source[this.#index++] !== ":") return fail$5();
				value[key] = this.#value(depth + 1);
				this.#ws();
				const separator = this.#source[this.#index++];
				if (separator === "}") return value;
				if (separator !== ",") return fail$5();
			}
		}
		const start = this.#index;
		while (/[0-9]/.test(this.#source[this.#index] ?? "x")) this.#index++;
		const encoded = this.#source.slice(start, this.#index);
		if (!/^(0|[1-9][0-9]{0,15})$/.test(encoded) || !Number.isSafeInteger(Number(encoded))) return fail$5();
		return Number(encoded);
	}
	parse() {
		const value = this.#value(0);
		this.#ws();
		if (this.#index !== this.#source.length) fail$5();
		return value;
	}
};
function exact(input, keys) {
	if (typeof input !== "object" || input === null || Array.isArray(input)) return fail$5();
	const actual = Object.keys(input);
	if (actual.length !== keys.length || actual.some((key) => !keys.includes(key))) return fail$5();
	return input;
}
function list(input, maximum) {
	if (!Array.isArray(input)) return fail$5();
	if (input.length > maximum) return fail$5("LIMIT_EXCEEDED");
	return input;
}
const ID$1 = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
function id(input) {
	if (typeof input !== "string" || !ID$1.test(input) || input.includes("..")) return fail$5();
	return input;
}
function hex64(input) {
	if (typeof input !== "string" || !/^[0-9a-f]{64}$/.test(input)) return fail$5();
	return input;
}
function evmAddress(input) {
	if (typeof input !== "string" || !/^0x[0-9a-f]{40}$/.test(input) || /^0x0{40}$/.test(input)) return fail$5();
	return input;
}
const BASE58$2 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
/** Canonical Solana base58 public key: decodes to exactly 32 bytes with no non-canonical leading zeros. */
function solanaKey$1(input) {
	if (typeof input !== "string" || input.length < 32 || input.length > 44) return fail$5();
	let value = 0n;
	for (const character of input) {
		const digit = BASE58$2.indexOf(character);
		if (digit < 0) return fail$5();
		value = value * 58n + BigInt(digit);
	}
	if (input.length - input.replace(/^1+/, "").length + (value === 0n ? 0 : value.toString(16).length + 1 >> 1) !== 32) return fail$5();
	return input;
}
function unique(values) {
	if (new Set(values).size !== values.length) fail$5();
}
/**
* Credential-bearing or ambiguous URLs are rejected, not logged. HTTPS only; plain HTTP only for loopback in a
* network labeled `local`. Query strings are rejected because RPC providers commonly carry API keys there; a
* key embedded in a path segment cannot be detected and remains a documented residual.
*/
function endpointUrl(input, environment) {
	if (typeof input !== "string" || input.length > 2048) return fail$5();
	let url;
	try {
		url = new URL(input);
	} catch {
		return fail$5();
	}
	if (url.username || url.password || url.hash || input.includes("#") || url.search || input.includes("?") || url.href !== input) return fail$5();
	const loopback = url.hostname === "127.0.0.1" || url.hostname === "[::1]" || url.hostname === "localhost";
	if (url.protocol === "https:") return input;
	if (url.protocol === "http:" && loopback && environment === "local") return input;
	return fail$5();
}
function asset(input, chain) {
	const raw = exact(input, [
		"id",
		"kind",
		"address",
		"decimals",
		"transferPolicy"
	]);
	const kind = raw.kind;
	if (kind !== "native" && !(kind === "erc20" && chain === "evm") && !(kind === "spl" && chain === "solana")) return fail$5();
	const address = kind === "native" ? raw.address === null ? null : fail$5() : chain === "evm" ? evmAddress(raw.address) : solanaKey$1(raw.address);
	if (typeof raw.decimals !== "number" || !Number.isSafeInteger(raw.decimals) || raw.decimals < 0 || raw.decimals > 38) return fail$5();
	if (raw.transferPolicy !== "exact-transfer") return fail$5();
	return Object.freeze({
		id: id(raw.id),
		kind,
		address,
		decimals: raw.decimals,
		transferPolicy: "exact-transfer"
	});
}
function deployment(input, chain, assetIds) {
	const raw = exact(input, [
		"id",
		"address",
		"protocolVersion",
		"artifactSha256",
		"runtime",
		"supportedAssetIds"
	]);
	if (raw.protocolVersion !== 1) return fail$5("UNSUPPORTED_VERSION");
	let runtime;
	const kind = typeof raw.runtime === "object" && raw.runtime !== null ? raw.runtime.kind : void 0;
	if (chain === "evm" && kind === "evm-code") {
		const value = exact(raw.runtime, [
			"kind",
			"keccak256",
			"upgradeable"
		]);
		if (value.upgradeable !== false) return fail$5();
		runtime = Object.freeze({
			kind: "evm-code",
			keccak256: hex64(value.keccak256),
			upgradeable: false
		});
	} else if (chain === "solana" && kind === "solana-program") {
		const value = exact(raw.runtime, [
			"kind",
			"programDataSha256",
			"upgradeAuthority"
		]);
		if (value.upgradeAuthority !== null) return fail$5();
		runtime = Object.freeze({
			kind: "solana-program",
			programDataSha256: hex64(value.programDataSha256),
			upgradeAuthority: null
		});
	} else return fail$5();
	const supported = list(raw.supportedAssetIds, 64).map(id);
	unique(supported);
	if (supported.length === 0 || supported.some((value) => !assetIds.has(value))) return fail$5();
	return Object.freeze({
		id: id(raw.id),
		address: chain === "evm" ? evmAddress(raw.address) : solanaKey$1(raw.address),
		protocolVersion: 1,
		artifactSha256: hex64(raw.artifactSha256),
		runtime,
		supportedAssetIds: Object.freeze(supported)
	});
}
function network(input) {
	const raw = exact(input, [
		"id",
		"chain",
		"chainIdentity",
		"genesisHash",
		"endpoints",
		"finality",
		"assets",
		"deployments",
		"environment"
	]);
	const chain = raw.chain;
	if (chain !== "evm" && chain !== "solana") return fail$5();
	const environment = raw.environment;
	if (environment !== "local" && environment !== "testnet" && environment !== "mainnet") return fail$5();
	let chainIdentity, genesisHash;
	if (chain === "evm") {
		if (typeof raw.chainIdentity !== "string" || !/^[1-9][0-9]{0,19}$/.test(raw.chainIdentity)) return fail$5();
		chainIdentity = raw.chainIdentity;
		if (typeof raw.genesisHash !== "string" || !/^0x[0-9a-f]{64}$/.test(raw.genesisHash)) return fail$5();
		genesisHash = raw.genesisHash;
	} else {
		chainIdentity = solanaKey$1(raw.chainIdentity);
		genesisHash = solanaKey$1(raw.genesisHash);
		if (chainIdentity !== genesisHash) return fail$5();
	}
	const finalityRaw = raw.finality;
	let finality;
	if (chain === "evm") {
		exact(finalityRaw, ["kind"]);
		if (finalityRaw.kind !== "evm-finalized-tag") return fail$5();
		finality = Object.freeze({ kind: "evm-finalized-tag" });
	} else {
		exact(finalityRaw, ["kind", "commitment"]);
		if (finalityRaw.kind !== "solana-commitment" || finalityRaw.commitment !== "finalized") return fail$5();
		finality = Object.freeze({
			kind: "solana-commitment",
			commitment: "finalized"
		});
	}
	const endpoints = list(raw.endpoints, 8).map((value) => {
		const endpoint = exact(value, ["id", "url"]);
		return Object.freeze({
			id: id(endpoint.id),
			url: endpointUrl(endpoint.url, environment)
		});
	});
	if (endpoints.length === 0) return fail$5();
	unique(endpoints.map((value) => value.id));
	unique(endpoints.map((value) => value.url));
	const assets = list(raw.assets, 64).map((value) => asset(value, chain));
	unique(assets.map((value) => value.id));
	if (assets.filter((value) => value.kind === "native").length > 1) return fail$5();
	unique(assets.filter((value) => value.address !== null).map((value) => value.address));
	const assetIds = new Set(assets.map((value) => value.id));
	const deployments = list(raw.deployments, 16).map((value) => deployment(value, chain, assetIds));
	unique(deployments.map((value) => value.id));
	unique(deployments.map((value) => value.address));
	return Object.freeze({
		id: id(raw.id),
		chain,
		chainIdentity,
		genesisHash,
		endpoints: Object.freeze(endpoints),
		finality,
		assets: Object.freeze(assets),
		deployments: Object.freeze(deployments),
		environment
	});
}
/**
* Strict UTF-8 (fatal, BOM rejected) → the same bounded JSON subset used for the registry: duplicate and prototype keys,
* floats, negatives and unsafe integers reject; depth <= 6, <= 32 keys per object, <= 256 items per array.
* The size bound uses the genuine view length, never a caller-owned byteLength accessor; proxies fail closed.
* Structure is unchecked: callers validate exact keys and types afterwards.
*/
function parseStrictJsonBytes(bytes, maxBytes) {
	let length;
	try {
		if (!(bytes instanceof Uint8Array)) return fail$5();
		length = viewByteLength$2.call(bytes);
	} catch {
		return fail$5();
	}
	if (length > maxBytes) return fail$5("LIMIT_EXCEEDED");
	let text;
	try {
		text = new TextDecoder("utf-8", {
			fatal: true,
			ignoreBOM: true
		}).decode(bytes);
	} catch {
		return fail$5();
	}
	if (text.charCodeAt(0) === 65279) return fail$5();
	return new RegistryJsonParser(text).parse();
}
/** Strict UTF-8 → bounded JSON → frozen RegistryV1. Callers MUST have matched the bytes to a trusted digest first. */
function parseRegistryBytes(bytes) {
	const raw = parseStrictJsonBytes(bytes, MAX_REGISTRY_BYTES);
	if (typeof raw !== "object" || raw === null || Array.isArray(raw)) return fail$5();
	if (raw.version !== 1) return fail$5("UNSUPPORTED_VERSION");
	const top = exact(raw, [
		"version",
		"releaseId",
		"networks"
	]);
	const networks = list(top.networks, 32).map(network);
	unique(networks.map((value) => value.id));
	unique(networks.map((value) => `${value.chain}:${value.chainIdentity}`));
	return Object.freeze({
		version: 1,
		releaseId: id(top.releaseId),
		networks: Object.freeze(networks)
	});
}
Object.freeze([
	"prepared",
	"signed",
	"sendMarked",
	"sent",
	"unknown",
	"finalized",
	"failed",
	"dropped",
	"cancelled"
]);
Object.freeze([
	"prepared",
	"broadcast-unknown",
	"pending",
	"confirmed",
	"finalized",
	"failed",
	"reorged",
	"expired",
	"replaced"
]);
Number.MAX_SAFE_INTEGER - 1;
Object.freeze([
	"rpc",
	"relay",
	"map",
	"proof",
	"update",
	"wallet"
]);
Number.MAX_SAFE_INTEGER - 1;
Object.freeze([
	"rpc",
	"relay",
	"map",
	"proof",
	"update"
]);
// packages/domain/src/registry.ts
/**
* G11 RegistryService (load/lookup only). The expected SHA-256 MUST come from the separately trusted G15
* signed manifest; that trust root is an unresolved owner decision, so nothing here chooses a signer or
* trusts the registry bytes on their own. This service performs no network access and no live RPC/deployment validation;
* live validation (validateLive) lives in the chain readers (chain-evm, chain-solana), not here.
*/
const viewByteLength$1 = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint8Array.prototype), "byteLength").get;
const copyBytes$1 = Uint8Array.prototype.set;
const failure$4 = (code) => Object.freeze({
	ok: false,
	error: createCoreError(code, {
		operationId: createOperationId(),
		readOnly: true
	})
});
var RegistryService = class {
	#registry;
	#digest;
	#sha256;
	constructor(sha256 = (bytes) => globalThis.crypto.subtle.digest("SHA-256", bytes)) {
		this.#sha256 = sha256;
	}
	/**
	* Hashes the exact delivered bytes before parsing anything. A different registry needs the G15 update flow,
	* so once loaded a service refuses a different digest (CONFLICT) instead of silently replacing entries.
	* Deviation: G11 sketches a synchronous load; native Web Crypto SHA-256 is asynchronous.
	*/
	async load(bytes, expectedSha256) {
		if (typeof expectedSha256 !== "string" || !/^[0-9a-f]{64}$/.test(expectedSha256)) return failure$4("INVALID_INPUT");
		let length;
		try {
			if (!(bytes instanceof Uint8Array)) return failure$4("INVALID_INPUT");
			length = viewByteLength$1.call(bytes);
		} catch {
			return failure$4("INVALID_INPUT");
		}
		if (length > 1048576) return failure$4("LIMIT_EXCEEDED");
		let copy;
		try {
			copy = new Uint8Array(length);
			copyBytes$1.call(copy, bytes);
		} catch {
			return failure$4("INVALID_INPUT");
		}
		let actual;
		try {
			actual = Array.from(new Uint8Array(await this.#sha256(copy)), (byte) => byte.toString(16).padStart(2, "0")).join("");
		} catch {
			return failure$4("UNAVAILABLE");
		}
		if (actual !== expectedSha256) return failure$4("INTEGRITY_FAILURE");
		if (this.#registry) return this.#digest === actual ? Object.freeze({
			ok: true,
			value: this.#registry
		}) : failure$4("CONFLICT");
		let registry;
		try {
			registry = parseRegistryBytes(copy);
		} catch (error) {
			const code = error instanceof ValidationError ? error.code : "INVALID_INPUT";
			return failure$4(code === "UNSUPPORTED_VERSION" || code === "LIMIT_EXCEEDED" ? code : "INVALID_INPUT");
		}
		this.#registry = registry;
		this.#digest = actual;
		return Object.freeze({
			ok: true,
			value: registry
		});
	}
	network(id) {
		return this.#registry?.networks.find((value) => value.id === id) ?? null;
	}
	deployment(networkId, deploymentId) {
		return this.network(networkId)?.deployments.find((value) => value.id === deploymentId) ?? null;
	}
};
// packages/domain/src/trade-terms.ts
const SOLANA_PREFIX = "p2p-offramp/solana/basic/v1";
const U64 = (1n << 64n) - 1n;
var TermsError = class extends Error {
	code;
	constructor(code = "INVALID_INPUT") {
		super("Invalid trade terms.");
		this.name = "TermsError";
		this.code = code;
	}
};
const fail$4 = (code) => {
	throw new TermsError(code);
};
/** Snapshot an exact JSON-shaped record using data descriptors only; untrusted accessors are never invoked. */
function exactDataObject(input, fields) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail$4();
		const prototype = Object.getPrototypeOf(input);
		if (prototype !== Object.prototype && prototype !== null) return fail$4();
		const ownKeys = Reflect.ownKeys(input);
		if (ownKeys.length !== fields.length || ownKeys.some((key) => typeof key !== "string" || !fields.includes(key))) return fail$4();
		const copy = Object.create(null);
		for (const field of fields) {
			const descriptor = Object.getOwnPropertyDescriptor(input, field);
			if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) return fail$4();
			Object.defineProperty(copy, field, {
				value: descriptor.value,
				enumerable: true
			});
		}
		return Object.freeze(copy);
	} catch {
		return fail$4();
	}
}
/** Copy dense arrays with no custom properties or accessor elements. */
function exactDataArray(input, maximum) {
	const tooLarge = Symbol("too-large");
	try {
		if (!Array.isArray(input) || Object.getPrototypeOf(input) !== Array.prototype) return fail$4();
		const lengthDescriptor = Object.getOwnPropertyDescriptor(input, "length");
		if (!lengthDescriptor || !("value" in lengthDescriptor) || typeof lengthDescriptor.value !== "number" || !Number.isSafeInteger(lengthDescriptor.value) || lengthDescriptor.value < 0) return fail$4();
		if (lengthDescriptor.value > maximum) throw tooLarge;
		const length = lengthDescriptor.value;
		const ownKeys = Reflect.ownKeys(input);
		if (ownKeys.length !== length + 1 || ownKeys.some((key) => key !== "length" && (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= length))) return fail$4();
		const copy = [];
		for (let index = 0; index < length; index++) {
			const descriptor = Object.getOwnPropertyDescriptor(input, String(index));
			if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) return fail$4();
			copy.push(descriptor.value);
		}
		return Object.freeze(copy);
	} catch (error) {
		return error === tooLarge ? fail$4("LIMIT_EXCEEDED") : fail$4();
	}
}
function hex32(input) {
	if (typeof input !== "string" || !/^[0-9a-f]{64}$/.test(input)) return fail$4();
	return Uint8Array.from(input.match(/../g), (pair) => parseInt(pair, 16));
}
/** Canonical unsigned decimal string (no sign, no leading zeros, no exponent/float) bounded by `max`. */
function unsigned(input, max, minimum = 0n) {
	if (typeof input !== "string" || !/^(0|[1-9][0-9]{0,39})$/.test(input)) return fail$4();
	const value = BigInt(input);
	if (value < minimum || value > max) return fail$4();
	return value;
}
const utf8$2 = new TextEncoder();
/** Exact UTF-8 of an already-valid JS string; lone surrogates are rejected rather than replaced. */
function text$2(input, minimum, maximum, ascii = false) {
	if (typeof input !== "string") return fail$4();
	if (input.length > maximum) return fail$4("LIMIT_EXCEEDED");
	if (/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/.test(input)) return fail$4();
	if (ascii && !/^[\x21-\x7e]*$/.test(input)) return fail$4();
	const bytes = utf8$2.encode(input);
	if (bytes.byteLength < minimum) return fail$4();
	if (bytes.byteLength > maximum) return fail$4("LIMIT_EXCEEDED");
	return bytes;
}
function beFixed(value, bytes) {
	const out = new Uint8Array(bytes);
	for (let index = bytes - 1, rest = value; index >= 0; index--, rest >>= 8n) out[index] = Number(rest & 255n);
	return out;
}
function leU64(value) {
	return beFixed(value, 8).reverse();
}
function lengthPrefixed(bytes) {
	return [beFixed(BigInt(bytes.byteLength), 4), bytes];
}
function concat(parts) {
	const out = new Uint8Array(parts.reduce((sum, part) => sum + part.byteLength, 0));
	let offset = 0;
	for (const part of parts) {
		out.set(part, offset);
		offset += part.byteLength;
	}
	return out;
}
function prefix(label) {
	return concat([utf8$2.encode(label), new Uint8Array([0])]);
}
/** count u8 + entries (id, version as length-prefixed UTF-8; policyHash as length-prefixed UTF-8 hex). Sorted unique IDs. */
function capabilityBytes(input) {
	const entries = exactDataArray(input, 8);
	const parts = [new Uint8Array([entries.length])];
	let previous;
	for (const raw of entries) {
		const capability = exactDataObject(raw, [
			"id",
			"policyHash",
			"version"
		]);
		const id = text$2(capability.id, 1, 64, true);
		if (previous !== void 0 && !(previous < capability.id)) return fail$4();
		previous = capability.id;
		hex32(capability.policyHash);
		parts.push(...lengthPrefixed(id), ...lengthPrefixed(text$2(capability.version, 1, 32)), ...lengthPrefixed(text$2(capability.policyHash, 64, 64, true)));
	}
	return parts;
}
/** Same count+entry capability encoding without salt or prefix; a core trade uses count zero. */
function encodeCapabilities(input) {
	return concat(capabilityBytes(input));
}
const BASE58$1 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function solanaKey(input) {
	if (typeof input !== "string" || input.length < 32 || input.length > 44) return fail$4();
	let value = 0n;
	for (const character of input) {
		const digit = BASE58$1.indexOf(character);
		if (digit < 0) return fail$4();
		value = value * 58n + BigInt(digit);
	}
	const leading = input.length - input.replace(/^1+/, "").length;
	const body = value === 0n ? /* @__PURE__ */ new Uint8Array(0) : beFixed(value, value.toString(16).length + 1 >> 1);
	if (leading + body.byteLength !== 32) return fail$4();
	return concat([new Uint8Array(leading), body]);
}
/** G16 Solana raw canonical terms message (signed directly by both Ed25519 keys; termsHash = SHA-256 of it). */
function encodeSolanaTerms(input) {
	const terms = exactDataObject(input, [
		"acceptBeforeSeconds",
		"amountBaseUnits",
		"assetKind",
		"buyer",
		"capabilitiesHash",
		"escrowExpirySeconds",
		"genesisHash",
		"mint",
		"orderId",
		"privateAgreementHash",
		"programId",
		"revision",
		"seller",
		"sellerNonce",
		"tokenProgram"
	]);
	const seller = solanaKey(terms.seller), buyer = solanaKey(terms.buyer);
	if (terms.seller === terms.buyer) return fail$4();
	let mint, tokenProgram, kind;
	if (terms.assetKind === "native") {
		if (terms.mint !== null || terms.tokenProgram !== null) return fail$4();
		mint = /* @__PURE__ */ new Uint8Array(32);
		tokenProgram = /* @__PURE__ */ new Uint8Array(32);
		kind = 0;
	} else if (terms.assetKind === "spl") {
		mint = solanaKey(terms.mint);
		tokenProgram = solanaKey(terms.tokenProgram);
		kind = 2;
	} else return fail$4();
	const accept = unsigned(terms.acceptBeforeSeconds, U64), expiry = unsigned(terms.escrowExpirySeconds, U64);
	return concat([
		prefix(SOLANA_PREFIX),
		solanaKey(terms.genesisHash),
		solanaKey(terms.programId),
		hex32(terms.orderId),
		seller,
		buyer,
		mint,
		tokenProgram,
		hex32(terms.privateAgreementHash),
		hex32(terms.capabilitiesHash),
		hex32(terms.sellerNonce),
		new Uint8Array([1]),
		leU64(unsigned(terms.revision, U64, 1n)),
		new Uint8Array([kind]),
		leU64(unsigned(terms.amountBaseUnits, U64, 1n)),
		leU64(accept),
		leU64(expiry),
		new Uint8Array([0])
	]);
}
/**
* G16 funding-window rule evaluated against an observed chain time: chainTime < acceptBefore and
* 1800 <= expiry - chainTime <= 604800. A funded trade ignores later acceptance expiry; that is the caller's state.
*/
function checkFundingWindow(acceptBeforeSeconds, escrowExpirySeconds, chainTimeSeconds) {
	const accept = unsigned(acceptBeforeSeconds, U64), expiry = unsigned(escrowExpirySeconds, U64), now = unsigned(chainTimeSeconds, U64);
	if (now >= accept) fail$4("EXPIRED");
	if (expiry < now + BigInt(1800) || expiry - now > BigInt(604800)) fail$4();
}
async function sha256Hex(bytes, digest = (data) => globalThis.crypto.subtle.digest("SHA-256", data)) {
	return Array.from(new Uint8Array(await digest(bytes)), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint8Array.prototype), "byteLength").get;
Uint8Array.prototype.set;
`${"0".repeat(40)}`;
Object.freeze([]);
`${"0".repeat(40)}`;
Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint8Array.prototype), "byteLength").get;
// packages/chain-solana/src/codec.ts
/** Internal fixed-code failure. Its message never carries input or provider detail. */
var SolanaFailure = class extends Error {
	code;
	constructor(code) {
		super("Solana read failed.");
		this.name = "SolanaFailure";
		this.code = code;
	}
};
const fail$3 = (code = "INTEGRITY_FAILURE") => {
	throw new SolanaFailure(code);
};
/** Maps any thrown value to a fixed code; only our own failures keep their code. */
function failureCode(error, fallback) {
	try {
		return error instanceof SolanaFailure ? error.code : fallback;
	} catch {
		return fallback;
	}
}
const BASE58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const BASE64$1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const U64_MAX = (1n << 64n) - 1n;
function encodeBase58(bytes) {
	let value = 0n;
	for (const byte of bytes) value = value << 8n | BigInt(byte);
	let out = "";
	while (value > 0n) {
		out = BASE58[Number(value % 58n)] + out;
		value /= 58n;
	}
	let zeros = 0;
	while (zeros < bytes.length && bytes[zeros] === 0) zeros++;
	return "1".repeat(zeros) + out;
}
/** Canonical 32-byte base58 key: 32..44 alphabet characters that re-encode to the same string. */
function decodeKey(input, code = "INTEGRITY_FAILURE") {
	if (typeof input !== "string" || input.length < 32 || input.length > 44) return fail$3(code);
	let value = 0n;
	for (const character of input) {
		const digit = BASE58.indexOf(character);
		if (digit < 0) return fail$3(code);
		value = value * 58n + BigInt(digit);
	}
	const leading = input.length - input.replace(/^1+/, "").length;
	const body = [];
	for (let rest = value; rest > 0n; rest >>= 8n) body.unshift(Number(rest & 255n));
	if (leading + body.length !== 32) return fail$3(code);
	const out = /* @__PURE__ */ new Uint8Array(32);
	out.set(body, leading);
	if (encodeBase58(out) !== input) return fail$3(code);
	return out;
}
/** Returns the input when it is a canonical key; used to validate without keeping bytes. */
function canonicalKey(input, code = "INTEGRITY_FAILURE") {
	decodeKey(input, code);
	return input;
}
/** Strict RFC 4648 standard base64 with mandatory padding and zero pad bits. `maxChars` is checked first. */
function decodeBase64(input, maxChars) {
	if (typeof input !== "string" || input.length > maxChars || input.length % 4 !== 0) return fail$3();
	if (!/^[A-Za-z0-9+/]*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(input)) return fail$3();
	const padding = input.endsWith("==") ? 2 : input.endsWith("=") ? 1 : 0;
	const out = new Uint8Array(input.length / 4 * 3 - padding);
	let bits = 0, buffer = 0, index = 0;
	for (const character of input) {
		if (character === "=") break;
		buffer = buffer << 6 | BASE64$1.indexOf(character);
		bits += 6;
		if (bits >= 8) {
			bits -= 8;
			out[index++] = buffer >> bits & 255;
		}
	}
	if ((buffer & (1 << bits) - 1) !== 0) return fail$3();
	return out;
}
function hex$1(bytes) {
	return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}
/** Lowercase 64-hex digest to 32 bytes. */
function fromHex32(input, code = "INVALID_INPUT") {
	if (typeof input !== "string" || !/^[0-9a-f]{64}$/.test(input)) return fail$3(code);
	return Uint8Array.from(input.match(/../g), (pair) => parseInt(pair, 16));
}
function readUintLE(bytes, offset, width) {
	if (offset < 0 || offset + width > bytes.length) return fail$3();
	let value = 0n;
	for (let index = width - 1; index >= 0; index--) value = value << 8n | BigInt(bytes[offset + index]);
	return value;
}
const readU64 = (bytes, offset) => readUintLE(bytes, offset, 8);
const readU32 = (bytes, offset) => Number(readUintLE(bytes, offset, 4));
/** Two's-complement i64. */
function readI64(bytes, offset) {
	const raw = readU64(bytes, offset);
	return raw >= 1n << 63n ? raw - (1n << 64n) : raw;
}
function u64LE(value) {
	if (value < 0n || value > U64_MAX) return fail$3("INVALID_INPUT");
	const out = /* @__PURE__ */ new Uint8Array(8);
	for (let index = 0, rest = value; index < 8; index++, rest >>= 8n) out[index] = Number(rest & 255n);
	return out;
}
function concatBytes(parts) {
	const out = new Uint8Array(parts.reduce((sum, part) => sum + part.length, 0));
	let offset = 0;
	for (const part of parts) {
		out.set(part, offset);
		offset += part.length;
	}
	return out;
}
function equalBytes(a, b) {
	return a.length === b.length && a.every((byte, index) => byte === b[index]);
}
/** Canonical u64 decimal string: at most 20 digits, no sign or leading zero, below 2^64. */
function decimalU64(input, code = "INVALID_INPUT") {
	if (typeof input !== "string" || !/^(?:0|[1-9][0-9]{0,19})$/.test(input)) return fail$3(code);
	const value = BigInt(input);
	if (value > U64_MAX) return fail$3(code);
	return value;
}
// packages/chain-solana/src/address.ts
/** Solana program IDs, the ed25519 on-curve test and PDA/ATA derivation. Pure: no RPC, no key material. */
const SYSTEM_PROGRAM_ID = "11111111111111111111111111111111";
/** Address of the original SPL Token program (a public program ID, not a credential). */
const SPL_PROGRAM_ID = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
const ATA_PROGRAM_ID = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL";
const LOADER_V3_ID = "BPFLoaderUpgradeab1e11111111111111111111111";
const SYSVAR_OWNER_ID = "Sysvar1111111111111111111111111111111111111";
const CLOCK_SYSVAR_ID = "SysvarC1ock11111111111111111111111111111111";
const RENT_SYSVAR_ID = "SysvarRent111111111111111111111111111111111";
/** Wrapped-SOL mints of SPL Token and Token-2022; the program refuses both (network.rs). */
const WRAPPED_SOL_MINTS = Object.freeze(["So11111111111111111111111111111111111111112", "9pan9bMn5HatX4EJdBwg9VgCa7Uz5HL8N1m5D3NdXejP"]);
const ESCROW_SEED = new TextEncoder().encode("p2p-offramp-escrow-v1");
const VAULT_SEED = new TextEncoder().encode("p2p-offramp-vault-v1");
const PDA_MARKER = new TextEncoder().encode("ProgramDerivedAddress");
const MAX_SEEDS = 15;
const MAX_SEED_BYTES = 32;
const P = (1n << 255n) - 19n;
function modPow(base, exponent) {
	let result = 1n, factor = base % P;
	for (let rest = exponent; rest > 0n; rest >>= 1n) {
		if (rest & 1n) result = result * factor % P;
		factor = factor * factor % P;
	}
	return result;
}
const D = (P - 121665n) * modPow(121666n, P - 2n) % P;
/**
* Matches curve25519-dalek `CompressedEdwardsY::decompress().is_some()`: the sign bit is dropped, y is
* reduced mod p (non-canonical y is accepted), and the point exists iff (y²-1)/(d·y²+1) is a square or 0.
* v = d·y²+1 is never 0 because d is a non-square, so Euler's criterion on u·v decides it.
*/
function isOnCurve(bytes32) {
	if (bytes32.length !== 32) return fail$3("INVALID_INPUT");
	let y = 0n;
	for (let index = 31; index >= 0; index--) y = y << 8n | BigInt(bytes32[index]);
	y = (y & (1n << 255n) - 1n) % P;
	const y2 = y * y % P;
	const legendre = modPow((y2 - 1n + P) % P * ((D * y2 + 1n) % P) % P, (P - 1n) / 2n);
	return legendre === 0n || legendre === 1n;
}
/** First off-curve sha256(seeds ‖ [bump] ‖ programId ‖ marker), bump counting down from 255. */
function findProgramAddress(seeds, programId) {
	if (seeds.length > MAX_SEEDS || seeds.some((seed) => seed.length > MAX_SEED_BYTES) || programId.length !== 32) return fail$3("INVALID_INPUT");
	for (let bump = 255; bump >= 0; bump--) {
		const candidate = sha256(concatBytes([
			...seeds,
			Uint8Array.of(bump),
			programId,
			PDA_MARKER
		]));
		if (!isOnCurve(candidate)) return Object.freeze({
			address: encodeBase58(candidate),
			bump
		});
	}
	return fail$3("INVALID_INPUT");
}
const key = (value) => decodeKey(value, "INVALID_INPUT");
function escrowAddress(programId, seller, sellerNonceHex) {
	return findProgramAddress([
		ESCROW_SEED,
		key(seller),
		fromHex32(sellerNonceHex)
	], key(programId));
}
function vaultAddress(programId, escrow) {
	return findProgramAddress([VAULT_SEED, key(escrow)], key(programId));
}
/** Canonical ATA for the original SPL Token program only. */
function associatedTokenAddress(owner, mint) {
	return findProgramAddress([
		key(owner),
		key(SPL_PROGRAM_ID),
		key(mint)
	], key(ATA_PROGRAM_ID));
}
/** Loader-v3 ProgramData account: PDA of [programId] under the upgradeable loader. */
function programDataAddress(programId) {
	return findProgramAddress([key(programId)], key(LOADER_V3_ID));
}
// packages/chain-solana/src/bind.ts
/** Binds a G08 trade binding and G16 Solana terms to one registry deployment. Pure: no RPC. */
const TERMS_KEYS$2 = Object.freeze([
	"acceptBeforeSeconds",
	"amountBaseUnits",
	"assetKind",
	"buyer",
	"capabilitiesHash",
	"escrowExpirySeconds",
	"genesisHash",
	"mint",
	"orderId",
	"privateAgreementHash",
	"programId",
	"revision",
	"seller",
	"sellerNonce",
	"tokenProgram"
]);
const MAX_SAFE_LAMPORTS = BigInt(Number.MAX_SAFE_INTEGER);
/** Only objects produced here carry the brand; builders refuse structurally identical copies. */
const BOUND = /* @__PURE__ */ new WeakSet();
const isBoundSolanaTrade = (value) => typeof value === "object" && value !== null && BOUND.has(value);
function deepFreeze(value) {
	if (typeof value !== "object" || value === null || value instanceof Uint8Array) return value;
	if (Object.isFrozen(value)) return value;
	for (const key of Reflect.ownKeys(value)) deepFreeze(value[key]);
	return Object.freeze(value);
}
/**
* Exactly the 15 G16 fields as own enumerable data properties, copied into a frozen null-prototype object.
* Accessors are never invoked. structuredClone runs only after every value is known to be a primitive data
* property, so it reads nothing new; it refuses Proxy objects without calling any trap.
*/
function snapshotTerms(input) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail$3("INVALID_INPUT");
		const prototype = Object.getPrototypeOf(input);
		if (prototype !== Object.prototype && prototype !== null) return fail$3("INVALID_INPUT");
		const keys = Reflect.ownKeys(input);
		if (keys.length !== TERMS_KEYS$2.length || keys.some((key) => typeof key !== "string" || !TERMS_KEYS$2.includes(key))) return fail$3("INVALID_INPUT");
		const copy = Object.create(null);
		for (const key of TERMS_KEYS$2) {
			const field = Object.getOwnPropertyDescriptor(input, key);
			if (!field || !field.enumerable || !("value" in field)) return fail$3("INVALID_INPUT");
			if (typeof field.value !== "string" && field.value !== null) return fail$3("INVALID_INPUT");
			Object.defineProperty(copy, key, {
				value: field.value,
				enumerable: true
			});
		}
		structuredClone(input);
		return Object.freeze(copy);
	} catch {
		return fail$3("INVALID_INPUT");
	}
}
/** G08 binding for Solana: lowercase 64-hex trade id and a network id without ':'. */
function parseSolanaBinding(input) {
	let binding;
	try {
		binding = parseTradeBinding(input);
	} catch {
		return fail$3("INVALID_INPUT");
	}
	if (binding.chain !== "solana" || !/^[0-9a-f]{64}$/.test(binding.tradeId) || binding.networkId.includes(":")) return fail$3("INVALID_INPUT");
	return binding;
}
function finalizedCommitment(network) {
	const finality = network.finality;
	return Object.keys(finality).length === 2 && finality.kind === "solana-commitment" && finality.commitment === "finalized";
}
/** Registry policy only (UNSUPPORTED_PROVIDER): finalized Solana network with an immutable v1 program. */
function resolveDeployment(registry, networkId, deploymentId) {
	try {
		if (networkId.includes(":")) return fail$3("INVALID_INPUT");
		const network = registry.network(networkId), deployment = registry.deployment(networkId, deploymentId);
		if (!network || !deployment || network.chain !== "solana" || !finalizedCommitment(network)) return fail$3("UNSUPPORTED_PROVIDER");
		const runtime = deployment.runtime;
		if (deployment.protocolVersion !== 1 || runtime.kind !== "solana-program" || runtime.upgradeAuthority !== null || !/^[0-9a-f]{64}$/.test(runtime.programDataSha256)) return fail$3("UNSUPPORTED_PROVIDER");
		canonicalKey(network.genesisHash, "UNSUPPORTED_PROVIDER");
		const programData = programDataAddress(canonicalKey(deployment.address, "UNSUPPORTED_PROVIDER"));
		return Object.freeze({
			network,
			deployment,
			programDataAddress: programData.address
		});
	} catch (error) {
		return fail$3(failureCode(error, "UNSUPPORTED_PROVIDER"));
	}
}
/** Native uses the native asset; SPL needs Tokenkeg, a non-wrapped mint and an exact `spl` asset entry. */
function selectAsset(network, deployment, terms) {
	let asset;
	if (terms.assetKind === "native") asset = network.assets.find((entry) => entry.kind === "native");
	else {
		if (terms.tokenProgram !== "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" || terms.mint === null || WRAPPED_SOL_MINTS.includes(terms.mint)) return fail$3("UNSUPPORTED_PROVIDER");
		asset = network.assets.find((entry) => entry.kind === "spl" && entry.address === terms.mint);
	}
	if (!asset || !deployment.supportedAssetIds.includes(asset.id)) return fail$3("UNSUPPORTED_PROVIDER");
	return asset;
}
/** Throwing core shared with the reader; codes follow the spec's pre-RPC order. */
function bindTrade(registry, input, rawTerms) {
	const binding = parseSolanaBinding(input);
	const terms = snapshotTerms(rawTerms);
	let termsHash;
	try {
		termsHash = hex$1(sha256(encodeSolanaTerms(terms)));
	} catch {
		return fail$3("INVALID_INPUT");
	}
	if (termsHash !== binding.tradeId) return fail$3("INVALID_INPUT");
	const { network, deployment, programDataAddress: programData } = resolveDeployment(registry, binding.networkId, binding.deploymentId);
	if (terms.genesisHash !== network.genesisHash || terms.programId !== deployment.address) return fail$3("WRONG_CHAIN");
	const asset = selectAsset(network, deployment, terms);
	const escrow = escrowAddress(deployment.address, terms.seller, terms.sellerNonce);
	const vault = terms.assetKind === "spl" ? vaultAddress(deployment.address, escrow.address) : null;
	if (terms.buyer === "11111111111111111111111111111111" || terms.buyer === escrow.address || terms.buyer === vault?.address) return fail$3("INVALID_INPUT");
	if (terms.assetKind === "native" && BigInt(terms.amountBaseUnits) > MAX_SAFE_LAMPORTS) return fail$3("LIMIT_EXCEEDED");
	const bound = deepFreeze({
		binding,
		terms,
		termsHash,
		network,
		deployment,
		asset,
		programDataAddress: programData,
		escrow,
		vault
	});
	BOUND.add(bound);
	return bound;
}
function bindSolanaTrade(registry, binding, terms) {
	try {
		return {
			ok: true,
			value: bindTrade(registry, binding, terms)
		};
	} catch (error) {
		return {
			ok: false,
			error: createCoreError(failureCode(error, "INVALID_INPUT"), {
				operationId: createOperationId(),
				readOnly: true
			})
		};
	}
}
// packages/chain-solana/src/message.ts
/**
* Legacy Solana messages and wire transactions: compile, serialize and strictly parse. Pure: no RPC, no keys.
*
* Wire format, from the Solana docs "Transaction Structure" (solana-foundation/solana-com@14537348,
* apps/docs/content/docs/en/core/transactions/transaction-structure.mdx) and solana-sdk@129a6da7
* (message/src/legacy.rs, message/src/compiled_keys.rs, message/src/compiled_instruction.rs, short-vec/src/lib.rs):
*
*   message     = num_required_signatures u8 ‖ num_readonly_signed u8 ‖ num_readonly_unsigned u8
*                 ‖ compact-u16 n ‖ n × 32-byte account keys ‖ recent_blockhash (32 bytes)
*                 ‖ compact-u16 m ‖ m × (program_id_index u8 ‖ compact-u16 k ‖ k × u8 ‖ compact-u16 d ‖ d bytes)
*   transaction = compact-u16 s ‖ s × 64-byte Ed25519 signatures ‖ message, at most 1232 bytes (PACKET_DATA_SIZE)
*
* Account keys are ordered writable signers, readonly signers, writable non-signers, readonly non-signers, with the
* fee payer first. Flags of a key used twice are OR-ed. Inside each group the keys follow CompiledKeys (a BTreeMap,
* so ascending key bytes), which makes the bytes equal `solana_message::legacy::Message::new(ixs, Some(payer))`.
* The parser applies the legacy `Message::sanitize` rules (signing and readonly-unsigned areas do not overlap, at
* least one writable signer, every index in range, program index never 0) and also refuses duplicate keys,
* non-canonical compact-u16, a versioned prefix and trailing bytes.
*/
/** PACKET_DATA_SIZE: the whole serialized transaction, signatures included. */
const MAX_TRANSACTION_BYTES = 1232;
const MAX_KEYS = 255;
/** compact-u16 (ShortU16): 7 bits per byte, low bits first, continuation bit 0x80, at most 3 bytes. */
function encodeCompactU16(value) {
	if (!Number.isSafeInteger(value) || value < 0 || value > 65535) return fail$3("INVALID_INPUT");
	const out = [];
	for (let rest = value;; rest >>= 7) {
		if (rest < 128) {
			out.push(rest);
			return Uint8Array.from(out);
		}
		out.push(rest & 127 | 128);
	}
}
/** Canonical decode: no zero continuation byte (alias), no fourth byte, no overflow above 0xffff. */
function decodeCompactU16(bytes, offset) {
	let value = 0;
	for (let index = 0; index < 3; index++) {
		const byte = bytes[offset + index];
		if (byte === void 0) return fail$3();
		if (byte === 0 && index > 0) return fail$3();
		value |= (byte & 127) << 7 * index;
		if ((byte & 128) === 0) {
			if (value > 65535) return fail$3();
			return {
				value,
				next: offset + index + 1
			};
		}
		if (index === 2) return fail$3();
	}
	return fail$3();
}
const groupOf = (flags) => (flags.signer ? 0 : 2) + (flags.writable ? 0 : 1);
function compareKeys(a, b) {
	const left = decodeKey(a, "INVALID_INPUT"), right = decodeKey(b, "INVALID_INPUT");
	for (let index = 0; index < 32; index++) if (left[index] !== right[index]) return left[index] - right[index];
	return 0;
}
/** Ordered keys and header for one fee payer and instruction list (CompiledKeys::compile semantics). */
function compileKeys(feePayer, instructions) {
	const flags = /* @__PURE__ */ new Map();
	const add = (key, signer, writable) => {
		decodeKey(key, "INVALID_INPUT");
		const entry = flags.get(key) ?? {
			signer: false,
			writable: false
		};
		flags.set(key, {
			signer: entry.signer || signer,
			writable: entry.writable || writable
		});
	};
	for (const instruction of instructions) {
		add(instruction.programId, false, false);
		for (const account of instruction.accounts) add(account.pubkey, account.isSigner, account.isWritable);
	}
	add(feePayer, true, true);
	const ordered = [feePayer, ...[...flags.entries()].filter(([key]) => key !== feePayer).sort(([a, x], [b, y]) => groupOf(x) - groupOf(y) || compareKeys(a, b)).map(([key]) => key)];
	if (ordered.length > MAX_KEYS) return fail$3("LIMIT_EXCEEDED");
	const counts = [
		0,
		0,
		0,
		0
	];
	for (const key of ordered) counts[groupOf(flags.get(key))]++;
	return {
		ordered,
		header: Object.freeze({
			numRequiredSignatures: counts[0] + counts[1],
			numReadonlySigned: counts[1],
			numReadonlyUnsigned: counts[3]
		})
	};
}
/** Serializes a legacy message. Throws a fixed-code SolanaFailure on any invalid input. */
function compileLegacyMessage(feePayer, instructions, recentBlockhash) {
	if (instructions.length < 1 || instructions.length > 64) return fail$3("INVALID_INPUT");
	const { ordered, header } = compileKeys(feePayer, instructions);
	const index = new Map(ordered.map((key, position) => [key, position]));
	const compiled = instructions.map((instruction) => concatBytes([
		Uint8Array.of(index.get(instruction.programId)),
		encodeCompactU16(instruction.accounts.length),
		Uint8Array.from(instruction.accounts, (meta) => index.get(meta.pubkey)),
		encodeCompactU16(instruction.data.length),
		instruction.data
	]));
	const message = concatBytes([
		Uint8Array.of(header.numRequiredSignatures, header.numReadonlySigned, header.numReadonlyUnsigned),
		encodeCompactU16(ordered.length),
		...ordered.map((key) => decodeKey(key, "INVALID_INPUT")),
		decodeKey(recentBlockhash, "INVALID_INPUT"),
		encodeCompactU16(instructions.length),
		...compiled
	]);
	if (transactionLength(header.numRequiredSignatures, message.length) > 1232) return fail$3("LIMIT_EXCEEDED");
	return message;
}
const transactionLength = (signatures, messageLength) => encodeCompactU16(signatures).length + signatures * 64 + messageLength;
/** Strict legacy parse; see the module comment for the refused forms. */
function parseLegacyMessage(bytes) {
	if (!(bytes instanceof Uint8Array) || bytes.length < 3 || bytes.length > 1232) return fail$3();
	if ((bytes[0] & 128) !== 0) return fail$3();
	const header = Object.freeze({
		numRequiredSignatures: bytes[0],
		numReadonlySigned: bytes[1],
		numReadonlyUnsigned: bytes[2]
	});
	const keyCount = decodeCompactU16(bytes, 3);
	let offset = keyCount.next;
	const keys = [];
	for (let index = 0; index < keyCount.value; index++, offset += 32) {
		if (offset + 32 > bytes.length) return fail$3();
		keys.push(encodeBase58(bytes.subarray(offset, offset + 32)));
	}
	if (offset + 32 > bytes.length) return fail$3();
	const recentBlockhash = encodeBase58(bytes.subarray(offset, offset + 32));
	offset += 32;
	const count = decodeCompactU16(bytes, offset);
	offset = count.next;
	const instructions = [];
	for (let index = 0; index < count.value; index++) {
		const programIdIndex = bytes[offset];
		if (programIdIndex === void 0) return fail$3();
		const accountCount = decodeCompactU16(bytes, offset + 1);
		offset = accountCount.next;
		if (offset + accountCount.value > bytes.length) return fail$3();
		const accounts = Array.from(bytes.subarray(offset, offset + accountCount.value));
		offset += accountCount.value;
		const dataLength = decodeCompactU16(bytes, offset);
		offset = dataLength.next;
		if (offset + dataLength.value > bytes.length) return fail$3();
		instructions.push(Object.freeze({
			programIdIndex,
			accounts: Object.freeze(accounts),
			data: bytes.slice(offset, offset + dataLength.value)
		}));
		offset += dataLength.value;
	}
	if (offset !== bytes.length) return fail$3();
	sanitize(header, keys, instructions);
	return Object.freeze({
		header,
		accountKeys: Object.freeze(keys),
		recentBlockhash,
		instructions: Object.freeze(instructions)
	});
}
function sanitize(header, keys, instructions) {
	const { numRequiredSignatures: signers, numReadonlySigned: readonlySigned } = header;
	if (signers + header.numReadonlyUnsigned > keys.length || readonlySigned >= signers) return fail$3();
	if (new Set(keys).size !== keys.length) return fail$3();
	for (const instruction of instructions) {
		if (instruction.programIdIndex === 0 || instruction.programIdIndex >= keys.length) return fail$3();
		if (instruction.accounts.some((index) => index >= keys.length)) return fail$3();
	}
}
/** Wire transaction with zeroed signature slots, the input the Wallet Standard `signTransaction` expects. */
function unsignedTransaction(message) {
	const signers = parseLegacyMessage(message).header.numRequiredSignatures;
	return concatBytes([
		encodeCompactU16(signers),
		new Uint8Array(signers * 64),
		message
	]);
}
/** Strict wire decode: signature count equals the header's, the message parses, size at most 1232 bytes. */
function decodeTransaction(wire) {
	if (!(wire instanceof Uint8Array) || wire.length > 1232) return fail$3();
	const count = decodeCompactU16(wire, 0);
	const start = count.next + count.value * 64;
	if (count.value < 1 || start >= wire.length) return fail$3();
	const signatures = Array.from({ length: count.value }, (_, index) => wire.slice(count.next + index * 64, count.next + (index + 1) * 64));
	const message = wire.slice(start);
	if (parseLegacyMessage(message).header.numRequiredSignatures !== count.value) return fail$3();
	return Object.freeze({
		signatures: Object.freeze(signatures),
		message
	});
}
const BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
/** RFC 4648 standard base64 with padding (the inverse of codec.ts `decodeBase64`). */
function encodeBase64(bytes) {
	let out = "";
	for (let index = 0; index < bytes.length; index += 3) {
		const chunk = bytes[index] << 16 | (bytes[index + 1] ?? 0) << 8 | (bytes[index + 2] ?? 0);
		const left = bytes.length - index;
		out += BASE64[chunk >> 18 & 63] + BASE64[chunk >> 12 & 63] + (left > 1 ? BASE64[chunk >> 6 & 63] : "=") + (left > 2 ? BASE64[chunk & 63] : "=");
	}
	return out;
}
// packages/chain-solana/src/auxiliary.ts
/**
* The two non-escrow instructions a payout message may carry. Pure data, frozen like instructions.ts.
*
* - Associated Token Account `CreateIdempotent` (solana-program/associated-token-account@fbf5379e,
*   interface/src/instruction.rs): data `[1]`; accounts funding(w,s), ata(w), wallet, mint, System program, token
*   program. Only the original SPL Token program and the canonical ATA are ever used here.
* - System `Transfer` (solana-sdk@129a6da7, system-interface/src/instruction.rs): bincode u32 LE variant 2 then
*   u64 LE lamports; accounts from(w,s), to(w). Used only to top up a native escrow's rent reserve (D5 "Rent").
*
* Nothing here can build `AdvanceNonceAccount` (variant 4): durable-nonce transactions are refused.
*/
const SYSTEM_TRANSFER = 2;
const meta$1 = (pubkey, isWritable, isSigner = false) => Object.freeze({
	pubkey,
	isSigner,
	isWritable
});
const u32LE = (value) => Uint8Array.of(value & 255, value >> 8 & 255, value >> 16 & 255, value >>> 24);
/** CreateIdempotent for the canonical original-SPL-Token ATA of `owner`; `payer` funds its rent if created. */
function buildCreateAtaIdempotent(payer, owner, mint) {
	const funder = canonicalKey(payer, "INVALID_INPUT"), wallet = canonicalKey(owner, "INVALID_INPUT");
	const tokenMint = canonicalKey(mint, "INVALID_INPUT");
	const ata = associatedTokenAddress(wallet, tokenMint).address;
	return Object.freeze({
		programId: ATA_PROGRAM_ID,
		accounts: Object.freeze([
			meta$1(funder, true, true),
			meta$1(ata, true),
			meta$1(wallet, false),
			meta$1(tokenMint, false),
			meta$1(SYSTEM_PROGRAM_ID, false),
			meta$1(SPL_PROGRAM_ID, false)
		]),
		data: Uint8Array.of(1)
	});
}
/** System transfer of `lamports` (1..u64) from a signer to a different account. */
function buildSystemTransfer(from, to, lamports) {
	const source = canonicalKey(from, "INVALID_INPUT"), target = canonicalKey(to, "INVALID_INPUT");
	if (typeof lamports !== "bigint" || lamports < 1n || source === target) return fail$3("INVALID_INPUT");
	return Object.freeze({
		programId: SYSTEM_PROGRAM_ID,
		accounts: Object.freeze([meta$1(source, true, true), meta$1(target, true)]),
		data: concatBytes([u32LE(SYSTEM_TRANSFER), u64LE(lamports)])
	});
}
// packages/chain-solana/src/instructions.ts
/**
* Unsigned D5 instruction builders. Pure data: no message, blockhash, fee payer, signature or send. No
* System Program instruction is ever produced, so a durable-nonce advance cannot be smuggled in here.
*/
const DISCRIMINATOR = Object.freeze({
	fundNative: "ecf06fea0be6652b",
	fundSpl: "7eaf579ec83b6a50",
	release: "fdf90fce1c7fc1f1",
	refund: "0260b7fb3fd02e2e",
	payoutNative: "241ed8ee67326263",
	payoutSpl: "890a23c66dc09e25"
});
const discriminator = (value) => Uint8Array.from(value.match(/../g), (pair) => parseInt(pair, 16));
const meta = (pubkey, isWritable, isSigner = false) => Object.freeze({
	pubkey,
	isSigner,
	isWritable
});
function result$2(build) {
	try {
		return {
			ok: true,
			value: build()
		};
	} catch (error) {
		return {
			ok: false,
			error: createCoreError(failureCode(error, "INVALID_INPUT"), {
				operationId: createOperationId(),
				readOnly: true
			})
		};
	}
}
function instruction(trade, accounts, data) {
	const programId = trade.deployment.address;
	return Object.freeze({
		programId,
		accounts: Object.freeze([...accounts]),
		data: Uint8Array.from(data)
	});
}
/** Only branded trades from bindSolanaTrade, of the expected asset kind. */
function branded(trade, kind) {
	if (!isBoundSolanaTrade(trade)) return fail$3("INVALID_INPUT");
	if (kind !== void 0 && trade.terms.assetKind !== kind) return fail$3("INVALID_INPUT");
	return trade;
}
/** FundArgs (192 bytes): order_id, buyer, private_agreement_hash, capabilities_hash, seller_nonce, then 4 u64 LE. */
function fundArgs(trade) {
	const terms = trade.terms;
	const u64 = (value) => u64LE(decimalU64(value));
	return concatBytes([
		fromHex32(terms.orderId),
		decodeKey(terms.buyer, "INVALID_INPUT"),
		fromHex32(terms.privateAgreementHash),
		fromHex32(terms.capabilitiesHash),
		fromHex32(terms.sellerNonce),
		u64(terms.revision),
		u64(terms.amountBaseUnits),
		u64(terms.acceptBeforeSeconds),
		u64(terms.escrowExpirySeconds)
	]);
}
function buildFundNative(trade) {
	return result$2(() => {
		const bound = branded(trade, "native");
		return instruction(bound, [
			meta(bound.terms.seller, true, true),
			meta(bound.escrow.address, true),
			meta(bound.terms.buyer, true),
			meta(SYSTEM_PROGRAM_ID, false)
		], concatBytes([discriminator(DISCRIMINATOR.fundNative), fundArgs(bound)]));
	});
}
function buildFundSpl(trade, sellerTokenAccount) {
	return result$2(() => {
		const bound = branded(trade, "spl"), mint = bound.terms.mint, vault = bound.vault.address;
		const source = canonicalKey(sellerTokenAccount, "INVALID_INPUT");
		if (source === bound.escrow.address || source === vault || source === mint) return fail$3("INVALID_INPUT");
		return instruction(bound, [
			meta(bound.terms.seller, true, true),
			meta(bound.escrow.address, true),
			meta(mint, false),
			meta(source, true),
			meta(vault, true),
			meta(SPL_PROGRAM_ID, false),
			meta(SYSTEM_PROGRAM_ID, false)
		], concatBytes([discriminator(DISCRIMINATOR.fundSpl), fundArgs(bound)]));
	});
}
/** Seller signs read-only; the program requires it to equal the stored seller. */
function buildRelease(trade) {
	return result$2(() => {
		const bound = branded(trade);
		return instruction(bound, [meta(bound.terms.seller, false, true), meta(bound.escrow.address, true)], discriminator(DISCRIMINATOR.release));
	});
}
/** Permissionless after the deadline: only the escrow account. */
function buildRefund(trade) {
	return result$2(() => {
		const bound = branded(trade);
		return instruction(bound, [meta(bound.escrow.address, true)], discriminator(DISCRIMINATOR.refund));
	});
}
/** Recipient follows the terminal state: buyer after release, seller after refund. */
function buildPayout(trade, outcome) {
	return result$2(() => {
		const bound = branded(trade);
		if (outcome !== "released" && outcome !== "refunded") return fail$3("INVALID_INPUT");
		const recipient = outcome === "released" ? bound.terms.buyer : bound.terms.seller;
		if (bound.terms.assetKind === "native") return instruction(bound, [meta(bound.escrow.address, true), meta(recipient, true)], discriminator(DISCRIMINATOR.payoutNative));
		const mint = bound.terms.mint;
		return instruction(bound, [
			meta(bound.escrow.address, true),
			meta(bound.vault.address, true),
			meta(mint, false),
			meta(associatedTokenAddress(recipient, mint).address, true),
			meta(SPL_PROGRAM_ID, false)
		], discriminator(DISCRIMINATOR.payoutSpl));
	});
}
const ESCROW_DISCRIMINATOR = "1a5ac1dabcfb8bd3";
const STATES$2 = [
	"funded",
	"released",
	"refunded"
];
const ZERO_KEY = /* @__PURE__ */ new Uint8Array(32);
const slice32 = (bytes, offset) => bytes.subarray(offset, offset + 32);
const keyAt$1 = (bytes, offset) => encodeBase58(slice32(bytes, offset));
const exactLength = (bytes, length) => {
	if (bytes.length !== length) fail$3();
};
/** COption tags are exactly [0,0,0,0] (None) or [1,0,0,0] (Some); the body of None is ignored. */
function optionTag$1(bytes, offset) {
	const tag = readU32(bytes, offset);
	if (tag > 1) return fail$3();
	return tag === 1;
}
/** ProgramData hash: requires tag 3, option byte 0/1 and a 1..1 MiB region; padding is included. */
function programDataSha256(accountData) {
	const length = accountData.length;
	if (length <= 45 || length > 1048621) return fail$3();
	if (readU32(accountData, 0) !== 3 || accountData[12] > 1) return fail$3();
	return hex$1(sha256(accountData.subarray(45)));
}
/** Registry pin from a verifiable build: sha256(elf ‖ zero padding up to the deployed region length). */
function programDataSha256FromElf(elf, programDataLength) {
	if (!Number.isSafeInteger(programDataLength) || elf.length < 1) return fail$3("INVALID_INPUT");
	const padding = programDataLength - 45 - elf.length;
	if (padding < 0 || programDataLength > 1048621) return fail$3("INVALID_INPUT");
	return hex$1(sha256.create().update(elf).update(new Uint8Array(padding)).digest());
}
/** Reader view: additionally requires the authority option to be None ([13..45) is never read). */
function decodeProgramData(bytes) {
	const digest = programDataSha256(bytes);
	if (bytes[12] !== 0) return fail$3();
	return Object.freeze({
		deploySlot: readU64(bytes, 4),
		sha256: digest
	});
}
/** Loader-v3 Program account: tag 2 and the programdata pointer. */
function decodeProgramAccount(bytes) {
	exactLength(bytes, 36);
	if (readU32(bytes, 0) !== 2) return fail$3();
	return keyAt$1(bytes, 4);
}
function decodeClock(bytes) {
	exactLength(bytes, 40);
	return Object.freeze({
		slot: readU64(bytes, 0),
		unixTimestamp: readI64(bytes, 32)
	});
}
const THRESHOLD_ONE = "000000000000f03f";
const THRESHOLD_TWO = "0000000000000040";
/**
* Rent-exempt minimum of a 222-byte escrow: (128 + 222) * lamportsPerByteYear * threshold. Only the two
* exact f64 thresholds 1.0 and 2.0 are understood (no floats); any other value is unknown (null).
*/
function escrowRentMinimum(bytes) {
	return rentExemptMinimum(bytes, 222);
}
/** The same rule for any account size: (128 + dataLength) * lamportsPerByteYear * threshold, or null. */
function rentExemptMinimum(bytes, dataLength) {
	exactLength(bytes, 17);
	if (!Number.isSafeInteger(dataLength) || dataLength < 0) return fail$3();
	const lamportsPerByteYear = readU64(bytes, 0), threshold = hex$1(bytes.subarray(8, 16));
	const base = (128n + BigInt(dataLength)) * lamportsPerByteYear;
	if (threshold === THRESHOLD_ONE) return base;
	if (threshold === THRESHOLD_TWO) return 2n * base;
	return null;
}
/** SPL Token account; refuses delegate, close authority, native wrapping and uninitialized state. */
function decodeTokenAccount(bytes) {
	exactLength(bytes, 165);
	const state = bytes[108];
	if (state !== 1 && state !== 2) return fail$3();
	if (optionTag$1(bytes, 72) || optionTag$1(bytes, 109) || optionTag$1(bytes, 129)) return fail$3();
	if (readU64(bytes, 121) !== 0n) return fail$3();
	const amount = readU64(bytes, 64);
	return Object.freeze({
		mint: keyAt$1(bytes, 0),
		owner: keyAt$1(bytes, 32),
		amount,
		frozen: state === 2
	});
}
function decodeMint(bytes) {
	exactLength(bytes, 82);
	optionTag$1(bytes, 0);
	if (bytes[45] !== 1) return fail$3();
	const freezeAuthority = optionTag$1(bytes, 46) ? keyAt$1(bytes, 50) : null;
	return Object.freeze({
		decimals: bytes[44],
		freezeAuthority
	});
}
/** Structural EscrowV1 decode. Relational checks (PDA bumps, terms) belong to the reader. */
function decodeEscrow(bytes) {
	exactLength(bytes, 222);
	if (hex$1(bytes.subarray(0, 8)) !== ESCROW_DISCRIMINATOR || bytes[8] !== 1) return fail$3();
	const stateIndex = bytes[11], paid = bytes[12], kind = bytes[13];
	if (stateIndex > 2 || paid > 1 || paid === 1 && stateIndex === 0 || kind !== 0 && kind !== 2) return fail$3();
	const mint = slice32(bytes, 78), tokenProgram = slice32(bytes, 110), amount = readU64(bytes, 142);
	if (amount < 1n) return fail$3();
	const zeroAssets = equalBytes(mint, ZERO_KEY) && equalBytes(tokenProgram, ZERO_KEY);
	if (kind === 0 && (!zeroAssets || bytes[10] !== 0)) return fail$3();
	if (kind === 2 && (keyAt$1(bytes, 110) !== "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" || equalBytes(mint, ZERO_KEY))) return fail$3();
	return Object.freeze({
		escrowBump: bytes[9],
		vaultBump: bytes[10],
		state: STATES$2[stateIndex],
		paidOut: paid === 1,
		assetKind: kind === 0 ? "native" : "spl",
		seller: keyAt$1(bytes, 14),
		buyer: keyAt$1(bytes, 46),
		mint: kind === 0 ? null : encodeBase58(mint),
		tokenProgram: kind === 0 ? null : SPL_PROGRAM_ID,
		amountBaseUnits: amount.toString(),
		deadlineSeconds: readU64(bytes, 150).toString(),
		termsHash: hex$1(slice32(bytes, 158)),
		sellerNonce: hex$1(slice32(bytes, 190))
	});
}
// packages/chain-solana/src/payout.ts
const STATES$1 = [
	"uninitialized",
	"initialized",
	"frozen"
];
const ABSENT = Object.freeze({ kind: "absent" });
const PREFUNDED = Object.freeze({ kind: "system-prefunded" });
const keyAt = (bytes, offset) => encodeBase58(bytes.subarray(offset, offset + 32));
function optionTag(bytes, offset) {
	const tag = readU32(bytes, offset);
	if (tag > 1) return fail$3();
	return tag === 1;
}
/** Lenient SPL Token account decode for a destination: delegates, freezes and close authorities are reported. */
function classifyTokenAccount(account) {
	if (account === null) return ABSENT;
	if (account.owner === "11111111111111111111111111111111" && account.dataLength === 0 && !account.executable) return PREFUNDED;
	const bytes = account.data;
	if (account.owner !== "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" || account.executable || account.dataLength !== 165 || bytes === null || bytes.length !== 165) return Object.freeze({
		kind: "foreign",
		programOwner: account.owner
	});
	const state = STATES$1[bytes[108]];
	if (state === void 0) return fail$3();
	const delegated = optionTag(bytes, 72) || readU64(bytes, 121) !== 0n;
	return Object.freeze({
		kind: "token",
		mint: keyAt(bytes, 0),
		owner: keyAt(bytes, 32),
		amount: readU64(bytes, 64).toString(),
		state,
		delegated,
		native: optionTag(bytes, 109),
		closeAuthority: optionTag(bytes, 129)
	});
}
/** Precedence follows what fails first on chain or matters most to the user; the first match wins. */
function splPlan(recipient, mint, destination, view, custodyBlockedBy, rentLamports) {
	const blocked = (reason) => Object.freeze({
		kind: "blocked",
		destination,
		reason
	});
	if (custodyBlockedBy.includes("vault-frozen")) return blocked("vault-frozen");
	if (view.kind === "absent" || view.kind === "system-prefunded") return Object.freeze({
		kind: "create-ata-idempotent",
		destination,
		owner: recipient,
		mint,
		rentLamports
	});
	if (view.kind === "foreign") return blocked("destination-not-spl-token");
	if (view.state === "uninitialized") return blocked("destination-uninitialized");
	if (view.mint !== mint) return blocked("destination-wrong-mint");
	if (view.owner !== recipient) return blocked("destination-wrong-owner");
	if (view.state === "frozen") return blocked("destination-frozen");
	if (view.native) return blocked("destination-native");
	if (view.delegated) return blocked("destination-delegated");
	return Object.freeze({
		kind: "ready",
		destination
	});
}
/**
* Native payout credits exactly the principal. A recipient left between 0 and its rent-exempt minimum fails the
* transaction (InsufficientFundsForRent), so the plan asks for a top-up in the same payout transaction.
*/
function nativePlan(recipient, principal, wallet, custodyBlockedBy) {
	const blocked = (reason) => Object.freeze({
		kind: "blocked",
		recipient,
		reason
	});
	if (custodyBlockedBy.includes("rent-unknown")) return blocked("rent-unknown");
	if (custodyBlockedBy.includes("rent-shortfall")) return blocked("rent-shortfall");
	if (wallet.executable) return blocked("recipient-executable");
	if (wallet.rentExemptMinimum === null) return blocked("rent-unknown");
	const minimum = BigInt(wallet.rentExemptMinimum), after = BigInt(wallet.lamports) + principal;
	if (after >= minimum) return Object.freeze({
		kind: "ready",
		recipient
	});
	return Object.freeze({
		kind: "rent-top-up",
		recipient,
		lamports: (minimum - after).toString(),
		rentExemptMinimum: minimum.toString()
	});
}
/** Internal entry points for the reader, whose inputs are already validated. */
const payoutPlanners = Object.freeze({
	spl: splPlan,
	native: nativePlan
});
// packages/chain-solana/src/window.ts
/**
* Funding and settlement windows against a finalized chain time (`live.timestampSeconds`). The finalized
* Clock lags the tip, so an open window is necessary but not sufficient. Neither helper reads a wall clock.
*/
const MAX_SUBMIT_MARGIN = 3600n;
const MAX_RELEASE_MARGIN = 604800n;
const invalid$1 = () => ({
	ok: false,
	error: createCoreError("INVALID_INPUT", {
		operationId: createOperationId(),
		readOnly: true
	})
});
function margin$1(input, maximum) {
	try {
		const value = decimalU64(input);
		return value <= maximum ? value : null;
	} catch {
		return null;
	}
}
function u64(input) {
	try {
		return decimalU64(input);
	} catch {
		return null;
	}
}
/** Program error 6004 (AcceptanceExpired) or 6005 (DeadlineOutOfRange) at one chain time, else open. */
function fundingAt(acceptBefore, expiry, chainTime) {
	if (chainTime > U64_MAX) return "acceptance-expired";
	try {
		checkFundingWindow(acceptBefore, expiry, chainTime.toString());
		return "open";
	} catch (error) {
		return error instanceof TermsError && error.code === "EXPIRED" ? "acceptance-expired" : "deadline-out-of-range";
	}
}
/**
* Open only if funding would pass at both `chainTime` and `chainTime + submitMargin`. The feasible chain times
* form one interval (t < acceptBefore, expiry - 604800 <= t <= expiry - 1800), so the two endpoints suffice.
*/
function fundingWindow(acceptBefore, expiry, chainTime, submitMargin) {
	const now = u64(chainTime), slack = margin$1(submitMargin, MAX_SUBMIT_MARGIN);
	if (u64(acceptBefore) === null || u64(expiry) === null || now === null || slack === null) return invalid$1();
	const first = fundingAt(acceptBefore, expiry, now);
	return {
		ok: true,
		value: first !== "open" ? first : fundingAt(acceptBefore, expiry, now + slack)
	};
}
/** Program rules: release needs now < deadline (kept `releaseMargin` clear); refund needs now >= deadline. */
function settlementWindow(deadline, chainTime, releaseMargin) {
	const end = u64(deadline), now = u64(chainTime), slack = margin$1(releaseMargin, MAX_RELEASE_MARGIN);
	if (end === null || now === null || slack === null) return invalid$1();
	return {
		ok: true,
		value: Object.freeze({
			releaseOpen: now + slack < end,
			refundOpen: now >= end
		})
	};
}
const MAX_PERMITS = 64;
const invalid = () => {
	throw new Error("Invalid Solana freeze-authority permits.");
};
function field(entry, name) {
	const descriptor = Object.getOwnPropertyDescriptor(entry, name);
	if (!descriptor || !("value" in descriptor)) return invalid();
	try {
		return canonicalKey(descriptor.value, "INVALID_INPUT");
	} catch {
		return invalid();
	}
}
function copyPermits(input) {
	const permits = /* @__PURE__ */ new Map();
	if (input === void 0) return permits;
	if (!Array.isArray(input) || Object.getPrototypeOf(input) !== Array.prototype) return invalid();
	const lengthField = Object.getOwnPropertyDescriptor(input, "length");
	const length = lengthField && "value" in lengthField ? lengthField.value : void 0;
	if (typeof length !== "number" || length > MAX_PERMITS || Reflect.ownKeys(input).length !== length + 1) return invalid();
	for (let index = 0; index < length; index++) {
		const descriptor = Object.getOwnPropertyDescriptor(input, String(index));
		const entry = descriptor && "value" in descriptor ? descriptor.value : void 0;
		if (typeof entry !== "object" || entry === null || Reflect.ownKeys(entry).length !== 2) return invalid();
		const mint = field(entry, "mint"), freezeAuthority = field(entry, "freezeAuthority");
		if (permits.has(mint)) return invalid();
		permits.set(mint, freezeAuthority);
	}
	return permits;
}
/**
* Validates permits (a dense plain array of at most 64 `{ mint, freezeAuthority }` own data properties with
* canonical keys and unique mints) into a private copy. Accessors are never invoked. Throws a fixed-message
* Error, like the reader's timeout check, so a bad configuration never starts a reader.
*/
function parseFreezeAuthorityPermits(input) {
	try {
		return copyPermits(input);
	} catch {
		return invalid();
	}
}
/**
* Pre-funding admission: no freeze authority is always acceptable (None can never be set again); a mint with one
* is acceptable only when its permit names that exact key, so a rotated freeze authority needs a new owner choice.
*/
function freezeAuthorityPermitted(permits, mint, freezeAuthority) {
	return freezeAuthority === null || permits.get(mint) === freezeAuthority;
}
/** base64 character caps, checked before decoding (ceil(bytes / 3) * 4). */
const CAP = Object.freeze({
	program: 48,
	programData: 1398164,
	clock: 56,
	rent: 24,
	escrow: 296,
	token: 220,
	mint: 112
});
/** MAX_PERMITTED_DATA_LENGTH. A recipient wallet's size comes only via its `space` field; it is never decoded. */
const MAX_ACCOUNT_BYTES = 10485760;
function own$3(input, key) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail$3();
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field || !("value" in field)) return fail$3();
		return field.value;
	} catch {
		return fail$3();
	}
}
function optionalOwn$1(input, key) {
	try {
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field) return void 0;
		if (!("value" in field)) return fail$3();
		return field.value;
	} catch {
		return fail$3();
	}
}
/** Dense plain array of at most `maximum` data elements, copied without invoking accessors. */
function ownArray$1(input, maximum) {
	try {
		if (!Array.isArray(input) || Object.getPrototypeOf(input) !== Array.prototype) return fail$3();
		const lengthField = Object.getOwnPropertyDescriptor(input, "length");
		const length = lengthField && "value" in lengthField ? lengthField.value : void 0;
		if (typeof length !== "number" || !Number.isSafeInteger(length) || length > maximum) return fail$3();
		if (Reflect.ownKeys(input).length !== length + 1) return fail$3();
		const copy = [];
		for (let index = 0; index < length; index++) {
			const field = Object.getOwnPropertyDescriptor(input, String(index));
			if (!field || !("value" in field)) return fail$3();
			copy.push(field.value);
		}
		return copy;
	} catch {
		return fail$3();
	}
}
function safeInt$1(input, code = "INTEGRITY_FAILURE") {
	if (typeof input !== "number" || !Number.isSafeInteger(input) || input < 0) return fail$3(code);
	return input;
}
/** `data` must be exactly [string, 'base64'], capped before decoding; `space`, if present, equals the length. */
function readAccount(entry, cap) {
	if (entry === null) return null;
	if (typeof entry !== "object") return fail$3();
	const owner = canonicalKey(own$3(entry, "owner")), executable = own$3(entry, "executable");
	if (typeof executable !== "boolean") return fail$3();
	const tuple = ownArray$1(own$3(entry, "data"), 2);
	if (tuple.length !== 2 || tuple[1] !== "base64") return fail$3();
	const data = decodeBase64(tuple[0], cap);
	const space = optionalOwn$1(entry, "space");
	if (space !== void 0 && space !== data.length) return fail$3();
	return {
		owner,
		executable,
		data,
		entry
	};
}
function present(entry, cap, owner, executable = false) {
	const account = readAccount(entry, cap);
	if (account === null || account.owner !== owner || account.executable !== executable) return fail$3();
	return account;
}
/** An uninitialized system account: a pre-init lamport donation leaves exactly this behind. */
const isSystemEmpty = (account) => account.owner === "11111111111111111111111111111111" && account.data.length === 0 && !account.executable;
/** Re-run on every read: nothing about identity is cached that could let a later read skip a check. */
function checkIdentity(ref, accounts, slot) {
	if (decodeProgramAccount(present(accounts[0], CAP.program, LOADER_V3_ID, true).data) !== ref.programDataAddress) return fail$3();
	const programData = decodeProgramData(present(accounts[1], CAP.programData, LOADER_V3_ID).data);
	const runtime = ref.deployment.runtime;
	if (programData.deploySlot > BigInt(slot) || runtime.kind !== "solana-program") return fail$3();
	if (programData.sha256 !== runtime.programDataSha256) return fail$3();
	const clock = decodeClock(present(accounts[2], CAP.clock, SYSVAR_OWNER_ID).data);
	if (clock.slot !== BigInt(slot) || clock.unixTimestamp < 0n) return fail$3();
	return {
		identity: {
			timestampSeconds: clock.unixTimestamp.toString(),
			programDataSha256: programData.sha256
		},
		deploySlot: programData.deploySlot
	};
}
function block(input, slot) {
	if (input === null) return fail$3();
	const hash = canonicalKey(own$3(input, "blockhash")), height = safeInt$1(own$3(input, "blockHeight"));
	const parent = safeInt$1(own$3(input, "parentSlot"));
	if (height > slot || !(parent < slot || slot === 0 && parent === 0)) return fail$3();
	return {
		hash,
		height,
		parent
	};
}
/** Index 3: absent, a pre-init System donation, or a program-owned EscrowV1 bound to these exact terms. */
function classifyEscrow(trade, entry) {
	const account = readAccount(entry, CAP.escrow);
	if (account === null) return {
		occupant: "none",
		escrow: null,
		entry: null
	};
	if (isSystemEmpty(account)) return {
		occupant: "system-prefunded",
		escrow: null,
		entry: null
	};
	if (account.owner !== trade.deployment.address || account.executable) return fail$3();
	if (account.data.length !== 222) return fail$3();
	const escrow = decodeEscrow(account.data), terms = trade.terms;
	if (!(escrow.seller === terms.seller && escrow.sellerNonce === terms.sellerNonce) || escrow.escrowBump !== trade.escrow.bump) return fail$3();
	if (escrow.termsHash !== trade.termsHash) return fail$3("CONFLICT");
	if (escrow.buyer !== terms.buyer || escrow.assetKind !== terms.assetKind || escrow.mint !== terms.mint || escrow.tokenProgram !== terms.tokenProgram || escrow.amountBaseUnits !== terms.amountBaseUnits || escrow.deadlineSeconds !== terms.escrowExpirySeconds) return fail$3();
	if (escrow.vaultBump !== (trade.vault?.bump ?? 0)) return fail$3();
	return {
		occupant: "escrow",
		escrow,
		entry: account.entry
	};
}
/** Native principal stays in the escrow PDA beside its rent reserve and any donated surplus. */
function nativeCustody(escrow, entry, minimum) {
	const lamports = BigInt(safeInt$1(own$3(entry, "lamports")));
	const principal = escrow.paidOut ? 0n : BigInt(escrow.amountBaseUnits);
	if (!escrow.paidOut && lamports <= principal) return fail$3();
	const blockedBy = [];
	if (minimum === null) blockedBy.push("rent-unknown");
	if (!escrow.paidOut && minimum !== null && lamports - principal < minimum) blockedBy.push("rent-shortfall");
	const spare = minimum === null ? null : lamports - principal - minimum;
	return {
		kind: "native",
		lamports: lamports.toString(),
		principalHeld: principal.toString(),
		rentExemptMinimum: minimum === null ? null : minimum.toString(),
		surplus: spare === null ? null : (spare > 0n ? spare : 0n).toString(),
		payoutBlockedBy: blockedBy
	};
}
/**
* The mint is checked even when no escrow exists (the state in which the app decides to fund): SPL Token owner,
* registry decimals, then the pre-funding freeze-authority policy. Existing validated escrows retain their exits.
* A changed admission permit never vetoes release/refund or an otherwise executable payout after funding.
*/
function splMint(trade, mintEntry, permits, existing) {
	const mint = decodeMint(present(mintEntry, CAP.mint, SPL_PROGRAM_ID).data), address = trade.terms.mint;
	if (mint.decimals !== trade.asset.decimals) return fail$3();
	if (existing === null && !freezeAuthorityPermitted(permits, address, mint.freezeAuthority)) return fail$3("UNSUPPORTED_PROVIDER");
	return {
		address,
		decimals: mint.decimals,
		freezeAuthority: mint.freezeAuthority
	};
}
/** SPL principal sits in the vault PDA token account. */
function splCustody(trade, classified, vaultEntry, mint) {
	const escrow = classified.escrow, vaultAddress = trade.vault.address;
	if (escrow === null) {
		const vault = readAccount(vaultEntry, CAP.token);
		if (vault !== null && !isSystemEmpty(vault)) return fail$3();
		return null;
	}
	const vault = decodeTokenAccount(present(vaultEntry, CAP.token, SPL_PROGRAM_ID).data);
	const principal = escrow.paidOut ? 0n : BigInt(escrow.amountBaseUnits);
	if (vault.mint !== escrow.mint || vault.owner !== trade.escrow.address || vault.amount < principal) return fail$3();
	const blockedBy = vault.frozen && !escrow.paidOut ? ["vault-frozen"] : [];
	return {
		kind: "spl",
		vault: vaultAddress,
		vaultAmount: vault.amount.toString(),
		principalHeld: principal.toString(),
		surplus: (vault.amount - principal).toString(),
		vaultFrozen: vault.frozen,
		mintDecimals: mint.decimals,
		mintFreezeAuthority: mint.freezeAuthority,
		payoutBlockedBy: blockedBy
	};
}
/**
* A payout recipient may be any account (a native buyer can be a data account of any size), so only its
* metadata is read: `space` is required, the base64 length (with its padding) must encode exactly that many
* bytes, and only a 165-byte SPL Token account is decoded.
*/
function shallowAccount(entry) {
	if (entry === null) return null;
	if (typeof entry !== "object") return fail$3();
	const owner = canonicalKey(own$3(entry, "owner")), executable = own$3(entry, "executable");
	const lamports = own$3(entry, "lamports"), space = safeInt$1(own$3(entry, "space"));
	if (typeof executable !== "boolean" || typeof lamports !== "number" || !Number.isInteger(lamports) || lamports < 0) return fail$3();
	const tuple = ownArray$1(own$3(entry, "data"), 2), encoded = tuple[0];
	if (tuple.length !== 2 || tuple[1] !== "base64" || typeof encoded !== "string") return fail$3();
	const padding = encoded.endsWith("==") ? 2 : encoded.endsWith("=") ? 1 : 0;
	if (space > MAX_ACCOUNT_BYTES || encoded.length % 4 !== 0 || encoded.length / 4 * 3 - padding !== space) return fail$3();
	return {
		owner,
		executable,
		lamports: Math.min(lamports, Number.MAX_SAFE_INTEGER),
		dataLength: space,
		data: owner === "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" && !executable && space === 165 ? decodeBase64(encoded, CAP.token) : null
	};
}
function walletView(entry, rent) {
	const account = shallowAccount(entry), dataLength = account?.dataLength ?? 0;
	const minimum = rentExemptMinimum(rent, dataLength);
	return {
		lamports: String(account?.lamports ?? 0),
		dataLength,
		executable: account?.executable ?? false,
		rentExemptMinimum: minimum === null ? null : minimum.toString()
	};
}
/** Extra keys for `readPayout`, after the snapshot keys: both parties' payout destinations at the same slot. */
function payoutKeys(trade) {
	const { buyer, seller, mint } = trade.terms;
	if (mint === null) return [buyer, seller];
	return [
		RENT_SYSVAR_ID,
		associatedTokenAddress(buyer, mint).address,
		associatedTokenAddress(seller, mint).address
	];
}
function payoutPlans(trade, snapshot, accounts) {
	const escrow = snapshot.escrow, blockedBy = snapshot.custody?.payoutBlockedBy ?? [];
	if (escrow?.paidOut) return {
		buyer: null,
		seller: null,
		pending: null
	};
	const { buyer: buyerKey, seller: sellerKey, mint } = trade.terms;
	let buyer, seller;
	if (mint === null) {
		const rent = present(accounts[4], CAP.rent, SYSVAR_OWNER_ID).data;
		const principal = BigInt(escrow?.amountBaseUnits ?? trade.terms.amountBaseUnits);
		buyer = payoutPlanners.native(buyerKey, principal, walletView(accounts[5], rent), blockedBy);
		seller = payoutPlanners.native(sellerKey, principal, walletView(accounts[6], rent), blockedBy);
	} else {
		const ataRent = rentExemptMinimum(present(accounts[6], CAP.rent, SYSVAR_OWNER_ID).data, 165);
		const rentLamports = ataRent === null ? null : ataRent.toString();
		const plan = (recipient, index) => payoutPlanners.spl(recipient, mint, associatedTokenAddress(recipient, mint).address, classifyTokenAccount(shallowAccount(accounts[index])), blockedBy, rentLamports);
		buyer = plan(buyerKey, 7);
		seller = plan(sellerKey, 8);
	}
	const pending = escrow?.state === "released" ? buyer : escrow?.state === "refunded" ? seller : null;
	return {
		buyer,
		seller,
		pending
	};
}
function payoutOf(escrow) {
	if (escrow === null || escrow.state === "funded") return "not-applicable";
	return escrow.paidOut ? "complete" : "pending";
}
function counter$1(value) {
	return safeInt$1(value, "INVALID_INPUT");
}
/** A request counter; a getter that throws is the caller's fault (INVALID_INPUT), not a provider failure. */
function requestCounter(read) {
	let value;
	try {
		value = read();
	} catch {
		return fail$3("INVALID_INPUT");
	}
	return counter$1(value);
}
/** Only snapshots produced by `read()` carry the brand; the settlement planner refuses copies. */
const SNAPSHOTS = /* @__PURE__ */ new WeakSet();
var SolanaChainReader = class {
	#options;
	#timeoutMs;
	#disposed = false;
	#jobs = /* @__PURE__ */ new Set();
	/** Highest finalized slot accepted per network; later reads must not observe an older context. */
	#floors = /* @__PURE__ */ new Map();
	/**
	* ProgramData deploy slot first confirmed per network and program. With no upgrade authority the ProgramData
	* can never be rewritten, so a later read showing another deploy slot is inconsistent and fails. This only
	* adds a refusal; every read still re-checks the whole identity.
	*/
	#deploySlots = /* @__PURE__ */ new Map();
	#permits;
	constructor(options) {
		this.#options = options;
		this.#timeoutMs = options.timeoutMs ?? 1e4;
		if (!Number.isSafeInteger(this.#timeoutMs) || this.#timeoutMs < 1 || this.#timeoutMs > 6e4) throw new Error("Invalid Solana reader timeout.");
		this.#permits = parseFreezeAuthorityPermits(options.freezeAuthorityPermits);
	}
	/** Same job discipline as the EVM reader: a slot is freed only when the physical work settles. */
	#run(signalOf, work) {
		const operationId = createOperationId();
		const failure = (code) => ({
			ok: false,
			error: createCoreError(code, {
				operationId,
				readOnly: true
			})
		});
		if (this.#disposed) return Promise.resolve(failure("CANCELLED"));
		const invalid = () => Promise.resolve(failure("INVALID_INPUT"));
		let external, aborted;
		try {
			const value = signalOf();
			if (value !== void 0 && !(value instanceof AbortSignal)) return invalid();
			external = value;
			aborted = external?.aborted === true;
		} catch {
			return invalid();
		}
		if (aborted) return Promise.resolve(failure("CANCELLED"));
		if (this.#jobs.size >= 4) return Promise.resolve(failure("LIMIT_EXCEEDED"));
		const controller = new AbortController();
		const onExternal = () => controller.abort();
		const detach = () => {
			try {
				external?.removeEventListener("abort", onExternal);
			} catch {}
		};
		this.#jobs.add(controller);
		try {
			external?.addEventListener("abort", onExternal, { once: true });
		} catch {
			detach();
			this.#jobs.delete(controller);
			return invalid();
		}
		let abortCode = "CANCELLED";
		const timer = setTimeout(() => {
			abortCode = "TIMEOUT";
			controller.abort();
		}, this.#timeoutMs);
		const guard = () => {
			if (this.#disposed || controller.signal.aborted) fail$3(abortCode);
		};
		const context = {
			signal: controller.signal,
			guard,
			call: async (method, params) => {
				guard();
				let boxed;
				try {
					boxed = { value: await this.#options.rpc.request({
						method,
						params,
						signal: controller.signal
					}) };
				} catch {
					guard();
					return fail$3("UNAVAILABLE");
				}
				guard();
				return boxed;
			}
		};
		let onAbort;
		const cancelled = new Promise((resolve) => {
			onAbort = () => resolve(failure(abortCode));
			controller.signal.addEventListener("abort", onAbort, { once: true });
		});
		const physical = Promise.resolve().then(() => {
			guard();
			return work(context);
		}).then((value) => {
			guard();
			return {
				ok: true,
				value
			};
		}).catch((error) => failure(failureCode(error, "UNAVAILABLE"))).finally(() => {
			this.#jobs.delete(controller);
			clearTimeout(timer);
			detach();
		});
		return Promise.race([physical, cancelled]).finally(() => {
			controller.signal.removeEventListener("abort", onAbort);
			detach();
		});
	}
	/** Steps 1-2 plus identity: genesis, one finalized getMultipleAccounts at slot S >= floor. */
	async #anchor(ref, extraKeys, context) {
		if ((await context.call("getGenesisHash", [])).value !== ref.network.genesisHash) return fail$3("WRONG_CHAIN");
		const floor = this.#floors.get(ref.network.id);
		const config = floor === void 0 ? {
			commitment: "finalized",
			encoding: "base64"
		} : {
			commitment: "finalized",
			encoding: "base64",
			minContextSlot: floor
		};
		const keys = [
			ref.deployment.address,
			ref.programDataAddress,
			CLOCK_SYSVAR_ID,
			...extraKeys
		];
		const response = (await context.call("getMultipleAccounts", [keys, config])).value;
		const slot = safeInt$1(own$3(own$3(response, "context"), "slot"));
		if (floor !== void 0 && slot < floor) return fail$3();
		const accounts = ownArray$1(own$3(response, "value"), keys.length);
		if (accounts.length !== keys.length) return fail$3();
		return {
			slot,
			accounts,
			...checkIdentity(ref, accounts, slot)
		};
	}
	/** Steps 3-5: the block at S twice, then the genesis again; only then is the floor raised. */
	async #confirm(ref, anchored, context) {
		const params = [anchored.slot, {
			commitment: "finalized",
			transactionDetails: "none",
			rewards: false
		}];
		const first = block((await context.call("getBlock", params)).value, anchored.slot);
		const second = block((await context.call("getBlock", params)).value, anchored.slot);
		if (first.hash !== second.hash || first.height !== second.height || first.parent !== second.parent) return fail$3();
		if ((await context.call("getGenesisHash", [])).value !== ref.network.genesisHash) return fail$3();
		context.guard();
		const program = `${ref.network.id}:${ref.deployment.address}`, pinned = this.#deploySlots.get(program);
		if (pinned !== void 0 && pinned !== anchored.deploySlot) return fail$3();
		this.#deploySlots.set(program, anchored.deploySlot);
		this.#floors.set(ref.network.id, Math.max(this.#floors.get(ref.network.id) ?? 0, anchored.slot));
		return {
			height: String(anchored.slot),
			hash: first.hash,
			blockHeight: String(first.height),
			...anchored.identity
		};
	}
	validateLive(networkId, deploymentId, signal) {
		return this.#run(() => signal, async (context) => {
			const ref = resolveDeployment(this.#options.registry, networkId, deploymentId);
			return deepFreeze(await this.#confirm(ref, await this.#anchor(ref, [], context), context));
		});
	}
	/** One anchored read; `payout` appends both parties' payout destinations to the same getMultipleAccounts. */
	async #observe(binding, request, terms, context, payout) {
		const generation = requestCounter(() => request.generation);
		const requestSequence = requestCounter(() => request.requestSequence);
		const trade = bindTrade(this.#options.registry, binding, terms);
		const native = trade.terms.assetKind === "native";
		const extra = native ? [trade.escrow.address, RENT_SYSVAR_ID] : [
			trade.escrow.address,
			trade.vault.address,
			trade.terms.mint
		];
		const anchored = await this.#anchor(trade, payout ? [...extra, ...payoutKeys(trade)] : extra, context);
		const classified = classifyEscrow(trade, anchored.accounts[3]);
		let custody, mint = null;
		if (native) {
			const minimum = escrowRentMinimum(present(anchored.accounts[4], CAP.rent, SYSVAR_OWNER_ID).data);
			custody = classified.escrow === null ? null : nativeCustody(classified.escrow, classified.entry, minimum);
		} else {
			mint = splMint(trade, anchored.accounts[5], this.#permits, classified.escrow);
			custody = splCustody(trade, classified, anchored.accounts[4], mint);
		}
		const live = await this.#confirm(trade, anchored, context);
		const observedAt = counter$1((this.#options.now ?? Date.now)());
		return {
			trade,
			snapshot: {
				observation: {
					binding: trade.binding,
					generation,
					requestSequence,
					anchor: {
						height: live.height,
						hash: live.hash
					},
					state: classified.escrow?.state ?? "absent",
					finality: "finalized",
					observedAt
				},
				live,
				escrowAddress: trade.escrow.address,
				occupant: classified.occupant,
				escrow: classified.escrow,
				payout: payoutOf(classified.escrow),
				custody,
				mint
			},
			accounts: anchored.accounts
		};
	}
	read(binding, request, terms) {
		return this.#run(() => request.signal, async (context) => {
			const snapshot = deepFreeze((await this.#observe(binding, request, terms, context, false)).snapshot);
			SNAPSHOTS.add(snapshot);
			return snapshot;
		});
	}
	/**
	* The snapshot plus payout plans, all at slot S: 2 more keys for native (buyer, seller wallets), 3 for SPL
	* (Rent sysvar, buyer and seller canonical ATAs). The plans are advisory; the program enforces the rules.
	*/
	readPayout(binding, request, terms) {
		return this.#run(() => request.signal, async (context) => {
			const { trade, snapshot, accounts } = await this.#observe(binding, request, terms, context, true);
			const result = deepFreeze({
				snapshot,
				...payoutPlans(trade, snapshot, accounts)
			});
			SNAPSHOTS.add(snapshot);
			return result;
		});
	}
	/**
	* G08 port: the ChainObservation alone. A frozen SPL vault is reported like any other funded trade (review
	* C-L3): `release` and `refund` are state-only and still succeed, and only the payout waits for a thaw. The
	* flag is `read(…).custody.vaultFrozen` and `payoutBlockedBy` (`'vault-frozen'`); readPayout plans with it.
	*/
	async readValidated(binding, request, terms) {
		const result = await this.read(binding, request, terms);
		return result.ok ? {
			ok: true,
			value: result.value.observation
		} : result;
	}
	dispose() {
		if (this.#disposed) return;
		this.#disposed = true;
		for (const controller of this.#jobs) controller.abort();
	}
};
// packages/chain-solana/src/plan.ts
/**
* C-L2 message plans: the only way this package turns escrow instructions into a message.
*
* Integration review C-L2 overrides the D5 packet's "release and payout in one transaction" for the client: a
* failed payout leg (frozen destination, rent) would roll back the release with it. So a message carries exactly
* one escrow instruction. `fund`, `release` and `refund` messages hold that instruction alone; a payout message
* is `[CreateIdempotent ATA]? ‖ [System transfer rent top-up]? ‖ payout_*` and is planned only from a FINALIZED
* reader snapshot that shows `Released`/`Refunded` and an unpaid principal. There is no API that takes an
* instruction list, and `verifyPlanMessage` rebuilds the expected bytes and refuses anything else.
*/
const PLANS = /* @__PURE__ */ new WeakSet();
const TRUSTED = /* @__PURE__ */ new WeakSet();
const CORE_CAPABILITIES_HASH = hex$1(sha256(encodeCapabilities([])));
const isSolanaMessagePlan = (value) => typeof value === "object" && value !== null && PLANS.has(value);
const isTrustedSnapshot = (value) => typeof value === "object" && value !== null && TRUSTED.has(value);
const failure$3 = (code) => ({
	ok: false,
	error: createCoreError(code, {
		operationId: createOperationId(),
		readOnly: true
	})
});
function result$1(work) {
	try {
		return {
			ok: true,
			value: work()
		};
	} catch (error) {
		return failure$3(failureCode(error, "INVALID_INPUT"));
	}
}
const value$1 = (built) => built.ok ? built.value : fail$3(built.error.code);
/**
* A finalized read through a genuine `SolanaChainReader` (the prototype method, so a look-alike object or an own
* `read` property cannot inject a snapshot). Only snapshots returned here can be planned against.
*/
async function readTrustedSnapshot(reader, trade, request) {
	if (!isBoundSolanaTrade(trade)) return failure$3("INVALID_INPUT");
	let read;
	try {
		read = await SolanaChainReader.prototype.read.call(reader, trade.binding, request, trade.terms);
	} catch {
		return failure$3("INVALID_INPUT");
	}
	if (read.ok) TRUSTED.add(read.value);
	return read;
}
function roleKey(trade, role) {
	if (role === "seller") return trade.terms.seller;
	if (role === "buyer") return trade.terms.buyer;
	return fail$3("INVALID_INPUT");
}
/** Strict margins: exactly the two keys, as u64 decimal strings (the window helpers bound them). */
function parseMargins(input) {
	if (typeof input !== "object" || input === null || Array.isArray(input)) return fail$3("INVALID_INPUT");
	if (Reflect.ownKeys(input).length !== 2) return fail$3("INVALID_INPUT");
	const read = (key) => {
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field || !("value" in field)) return fail$3("INVALID_INPUT");
		decimalU64(field.value);
		return field.value;
	};
	return Object.freeze({
		submitMarginSeconds: read("submitMarginSeconds"),
		releaseMarginSeconds: read("releaseMarginSeconds")
	});
}
/** Snapshot of exactly this trade, read through `readTrustedSnapshot`, at finalized commitment. */
function checkedSnapshot(trade, snapshot) {
	if (!isBoundSolanaTrade(trade) || !isTrustedSnapshot(snapshot)) return fail$3("INVALID_INPUT");
	const binding = snapshot.observation.binding;
	if (snapshot.observation.finality !== "finalized" || snapshot.escrowAddress !== trade.escrow.address || binding.tradeId !== trade.binding.tradeId || binding.networkId !== trade.binding.networkId || binding.deploymentId !== trade.binding.deploymentId) return fail$3("INVALID_INPUT");
	return snapshot;
}
function payer(trade, role, allowed) {
	if (!allowed.includes(role)) return fail$3("UNAUTHORIZED");
	return roleKey(trade, role);
}
/** Instructions for one shape. Every message this package compiles comes from here. */
function shapeInstructions(trade, feePayer, shape) {
	switch (shape.action) {
		case "fund": return [trade.terms.assetKind === "native" ? value$1(buildFundNative(trade)) : value$1(buildFundSpl(trade, shape.sellerTokenAccount ?? fail$3("INVALID_INPUT")))];
		case "release": return [value$1(buildRelease(trade))];
		case "refund": return [value$1(buildRefund(trade))];
		case "payout": {
			const out = [];
			const recipient = shape.outcome === "released" ? trade.terms.buyer : trade.terms.seller;
			if (shape.createAta) {
				if (trade.terms.assetKind !== "spl") return fail$3("INVALID_INPUT");
				out.push(buildCreateAtaIdempotent(feePayer, recipient, trade.terms.mint));
			}
			if (shape.rentTopUpLamports !== null) {
				if (trade.terms.assetKind !== "native") return fail$3("INVALID_INPUT");
				out.push(buildSystemTransfer(feePayer, trade.escrow.address, decimalU64(shape.rentTopUpLamports)));
			}
			out.push(value$1(buildPayout(trade, shape.outcome)));
			return out;
		}
		default: return fail$3("INVALID_INPUT");
	}
}
function makePlan(trade, snapshot, role, feePayer, shape, expectedEscrowState) {
	const plan = Object.freeze({
		trade,
		action: shape.action,
		role,
		feePayer,
		shape: Object.freeze({ ...shape }),
		expectedEscrowState,
		instructions: Object.freeze(shapeInstructions(trade, feePayer, shape)),
		snapshotSlot: snapshot.live.height,
		snapshotBlockHeight: snapshot.live.blockHeight
	});
	PLANS.add(plan);
	return plan;
}
/** Seller funds an absent escrow while the funding window stays open for `submitMarginSeconds`. */
function planFund(trade, snapshot, role, margins, options = {}) {
	return result$1(() => {
		const read = checkedSnapshot(trade, snapshot), limits = parseMargins(margins);
		const feePayer = payer(trade, role, ["seller"]);
		if (read.escrow !== null || read.occupant === "escrow") return fail$3("CONFLICT");
		const terms = trade.terms;
		if (terms.capabilitiesHash !== CORE_CAPABILITIES_HASH) return fail$3("UNSUPPORTED_PROVIDER");
		if (value$1(fundingWindow(terms.acceptBeforeSeconds, terms.escrowExpirySeconds, read.live.timestampSeconds, limits.submitMarginSeconds)) !== "open") return fail$3("EXPIRED");
		return makePlan(trade, read, role, feePayer, {
			action: "fund",
			sellerTokenAccount: terms.assetKind === "spl" ? options.sellerTokenAccount ?? associatedTokenAddress(terms.seller, terms.mint).address : null
		}, "absent");
	});
}
/** Seller releases a `Funded` escrow strictly before `deadline - releaseMarginSeconds` (finalized Clock). */
function planRelease(trade, snapshot, role, margins) {
	return result$1(() => {
		const read = checkedSnapshot(trade, snapshot), limits = parseMargins(margins);
		const feePayer = payer(trade, role, ["seller"]);
		if (read.escrow?.state !== "funded") return fail$3("CONFLICT");
		if (!value$1(settlementWindow(read.escrow.deadlineSeconds, read.live.timestampSeconds, limits.releaseMarginSeconds)).releaseOpen) return fail$3("EXPIRED");
		return makePlan(trade, read, role, feePayer, { action: "release" }, "funded");
	});
}
/** Seller refunds a `Funded` escrow once the finalized Clock has reached the deadline. */
function planRefund(trade, snapshot, role, margins) {
	return result$1(() => {
		const read = checkedSnapshot(trade, snapshot), limits = parseMargins(margins);
		const feePayer = payer(trade, role, ["seller"]);
		if (read.escrow?.state !== "funded") return fail$3("CONFLICT");
		if (!value$1(settlementWindow(read.escrow.deadlineSeconds, read.live.timestampSeconds, limits.releaseMarginSeconds)).refundOpen) return fail$3("EXPIRED");
		return makePlan(trade, read, role, feePayer, { action: "refund" }, "funded");
	});
}
/** Native rent shortfall the payout needs topped up, or null; refused above the payer's limit. */
function rentTopUp(snapshot, maxTopUp) {
	const custody = snapshot.custody;
	if (custody?.kind !== "native" || !custody.payoutBlockedBy.includes("rent-shortfall")) return null;
	const shortfall = BigInt(custody.rentExemptMinimum) - (BigInt(custody.lamports) - BigInt(custody.principalHeld));
	if (shortfall < 1n) return fail$3("INTEGRITY_FAILURE");
	if (shortfall > maxTopUp) return fail$3("LIMIT_EXCEEDED");
	return shortfall.toString();
}
/** Anyone in the trade pays out after a FINALIZED `Released`/`Refunded` read with the principal unpaid. */
function planPayout(trade, snapshot, role, options = {}) {
	return result$1(() => {
		const read = checkedSnapshot(trade, snapshot), feePayer = payer(trade, role, ["seller", "buyer"]);
		const state = read.escrow?.state;
		if (state !== "released" && state !== "refunded" || read.escrow.paidOut || read.payout !== "pending") return fail$3("CONFLICT");
		if (read.custody?.kind === "spl" && read.custody.vaultFrozen) return fail$3("CONFLICT");
		const spl = trade.terms.assetKind === "spl";
		return makePlan(trade, read, role, feePayer, {
			action: "payout",
			outcome: state,
			createAta: spl && options.createAta !== false,
			rentTopUpLamports: spl ? null : rentTopUp(read, decimalU64(options.maxRentTopUpLamports ?? "0"))
		}, state);
	});
}
/** Legacy message bytes of a plan; re-checks the plan brand. */
function compilePlan(plan, recentBlockhash) {
	if (!isSolanaMessagePlan(plan)) return fail$3("INVALID_INPUT");
	return compileLegacyMessage(plan.feePayer, plan.instructions, recentBlockhash);
}
/** Reads the variable parts back from a message, then requires byte equality with the rebuilt message. */
function shapeOf(trade, action, expected, message) {
	const parsed = parseLegacyMessage(message), keys = parsed.accountKeys;
	const programs = parsed.instructions.map((instruction) => keys[instruction.programIdIndex]);
	if (action === "fund") {
		const fund = parsed.instructions[0];
		return {
			action,
			sellerTokenAccount: trade.terms.assetKind === "spl" && fund ? keys[fund.accounts[3] ?? 0] ?? null : null
		};
	}
	if (action === "release" || action === "refund") return { action };
	if (expected !== "released" && expected !== "refunded") return fail$3("INVALID_INPUT");
	const createAta = programs[0] === ATA_PROGRAM_ID;
	const transfer = parsed.instructions.find((_, index) => programs[index] === SYSTEM_PROGRAM_ID);
	return {
		action,
		outcome: expected,
		createAta,
		rentTopUpLamports: transfer && transfer.data.length === 12 ? readU64(transfer.data, 4).toString() : null
	};
}
/**
* Throws unless `message` is exactly what this package would compile for (trade, action, fee payer, blockhash):
* one escrow instruction, never a state instruction beside a payout, no foreign or durable-nonce instruction.
*/
function verifyPlanMessage(trade, action, expected, feePayer, message) {
	if (!isBoundSolanaTrade(trade)) return fail$3("INVALID_INPUT");
	const parsed = parseLegacyMessage(message);
	if (parsed.accountKeys[0] !== feePayer || parsed.header.numRequiredSignatures !== 1) return fail$3("INVALID_INPUT");
	let shape, rebuilt;
	try {
		shape = shapeOf(trade, action, expected, message);
		rebuilt = compileLegacyMessage(feePayer, shapeInstructions(trade, feePayer, shape), parsed.recentBlockhash);
	} catch {
		return fail$3("INVALID_INPUT");
	}
	if (!equalBytes(rebuilt, message)) return fail$3("INVALID_INPUT");
	return shape;
}
// packages/chain-solana/src/wallet.ts
/**
* Wallet permission port, modelled on the Wallet Standard (`standard:connect` from wallet-standard/wallet-standard
* @c49b56d6 packages/core/features/src/connect.ts; `solana:signTransaction` from anza-xyz/wallet-standard@c4d06f9f
* packages/core/features/src/signTransaction.ts). The port is injected; this module never looks for a wallet.
*
* - `connectWalletRole` is an explicit, user-triggered `connect()` (no `silent`). The account used must equal the
*   stored key of the role (seller or buyer), its `publicKey` bytes must match its address, and it must list the
*   configured chain and `solana:signTransaction`.
* - Sign-only: `signTransaction` returns signed bytes, so the signature (the transaction id) is known and durably
*   journaled before this client broadcasts. `solana:signAndSendTransaction` is deliberately not used.
* - The returned wire transaction must carry exactly one signature over exactly the message we built (so no fee
*   payer, instruction, account or blockhash substitution), and that signature must verify with Ed25519 (strict
*   RFC 8032 verification, `zip215: false`) for the session's key.
*/
const STANDARD_CONNECT = "standard:connect";
const SOLANA_SIGN_TRANSACTION = "solana:signTransaction";
const SESSIONS = /* @__PURE__ */ new WeakMap();
const CHAIN$1 = /^solana:[a-z0-9-]{1,32}$/;
function own$2(input, key) {
	try {
		if (typeof input !== "object" || input === null) return fail$3();
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field || !("value" in field)) return fail$3();
		return field.value;
	} catch {
		return fail$3();
	}
}
function strings(input, maximum) {
	if (!Array.isArray(input) || input.length > maximum) return fail$3();
	const out = [];
	for (let index = 0; index < input.length; index++) {
		const entry = own$2(input, String(index));
		if (typeof entry !== "string" || entry.length > 128) return fail$3();
		out.push(entry);
	}
	return out;
}
function bytesOf(input, maximum) {
	if (!(input instanceof Uint8Array) || input.length > maximum) return fail$3();
	return Uint8Array.from(input);
}
/** Strict canonical base58 of exactly 64 bytes (a transaction signature). */
function decodeSignature(input) {
	if (typeof input !== "string" || input.length < 64 || input.length > 88) return fail$3("INVALID_INPUT");
	let value = 0n;
	const alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
	for (const character of input) {
		const digit = alphabet.indexOf(character);
		if (digit < 0) return fail$3("INVALID_INPUT");
		value = value * 58n + BigInt(digit);
	}
	const out = /* @__PURE__ */ new Uint8Array(64);
	for (let index = 63; index >= 0; index--, value >>= 8n) out[index] = Number(value & 255n);
	if (value !== 0n || encodeBase58(out) !== input) return fail$3("INVALID_INPUT");
	return out;
}
/** Strict Ed25519 verification of a base58 signature over `message` for a base58 key. Never throws. */
function verifySignature(signature, message, key) {
	try {
		const bytes = decodeSignature(signature);
		if (bytes.every((byte) => byte === 0)) return false;
		return ed25519.verify(bytes, message, decodeKey(key), { zip215: false });
	} catch {
		return false;
	}
}
function account(entry, address, chain) {
	if (own$2(entry, "address") !== address) return null;
	if (!equalBytes(bytesOf(own$2(entry, "publicKey"), 32), decodeKey(address))) return fail$3("INTEGRITY_FAILURE");
	const chains = strings(own$2(entry, "chains"), 16), features = strings(own$2(entry, "features"), 64);
	if (!chains.includes(chain) || !features.includes("solana:signTransaction")) return fail$3("UNSUPPORTED_PROVIDER");
	return entry;
}
/** A Wallet Standard feature method; a wallet without it (or with accessors there) is unsupported. */
function feature(wallet, name, method) {
	let entry, call;
	try {
		entry = own$2(own$2(wallet, "features"), name);
		call = own$2(entry, method);
	} catch {
		return fail$3("UNSUPPORTED_PROVIDER");
	}
	if (typeof call !== "function") return fail$3("UNSUPPORTED_PROVIDER");
	return (...args) => Promise.resolve(Reflect.apply(call, entry, args));
}
const failure$2 = (code) => ({
	ok: false,
	error: createCoreError(code, {
		operationId: createOperationId(),
		readOnly: true
	})
});
/** Wallet errors are the wallet's claim; only their numeric/string code is read (4001 => USER_REJECTED). */
function walletError(error) {
	const code = failureCode(error, normalizeError(error, {
		operationId: createOperationId(),
		phase: "prepare"
	}).code);
	return failure$2(code);
}
/** Explicit connect for one role of one trade; refuses any account but the role's stored key. */
async function connectWalletRole(wallet, trade, role, chain) {
	try {
		if (!isBoundSolanaTrade(trade) || typeof chain !== "string" || !CHAIN$1.test(chain)) return failure$2("INVALID_INPUT");
		const address = roleKey(trade, role), connect = feature(wallet, STANDARD_CONNECT, "connect");
		feature(wallet, SOLANA_SIGN_TRANSACTION, "signTransaction");
		let output;
		try {
			output = await connect();
		} catch (error) {
			return walletError(error);
		}
		const accounts = own$2(output, "accounts");
		if (!Array.isArray(accounts) || accounts.length > 16) return failure$2("INTEGRITY_FAILURE");
		let chosen = null;
		for (let index = 0; index < accounts.length && chosen === null; index++) chosen = account(own$2(accounts, String(index)), address, chain);
		if (chosen === null) return failure$2("UNAUTHORIZED");
		const session = Object.freeze({
			role,
			address,
			chain,
			tradeId: trade.binding.tradeId
		});
		SESSIONS.set(session, {
			wallet,
			account: chosen
		});
		return {
			ok: true,
			value: session
		};
	} catch (error) {
		return failure$2(failureCode(error, "INTEGRITY_FAILURE"));
	}
}
const isWalletSession = (value) => typeof value === "object" && value !== null && SESSIONS.has(value);
/** Validates wallet output: one signature, our exact message bytes, a valid signature by the session key. */
function checkSignedTransaction(output, message, signer) {
	if (!Array.isArray(output) || output.length !== 1) return fail$3("INTEGRITY_FAILURE");
	const wire = bytesOf(own$2(own$2(output, "0"), "signedTransaction"), 1232);
	let decoded;
	try {
		decoded = decodeTransaction(wire);
	} catch {
		return fail$3("INTEGRITY_FAILURE");
	}
	if (decoded.signatures.length !== 1 || !equalBytes(decoded.message, message)) return fail$3("INTEGRITY_FAILURE");
	const signature = encodeBase58(decoded.signatures[0]);
	if (!verifySignature(signature, message, signer)) return fail$3("INTEGRITY_FAILURE");
	return Object.freeze({
		signature,
		wire
	});
}
/** One `signTransaction` call for our unsigned wire transaction; the wallet must not change a byte of the message. */
async function signWithWallet(session, message, assertActive) {
	try {
		const state = SESSIONS.get(session);
		if (!state) return failure$2("UNAUTHORIZED");
		assertActive?.();
		const sign = feature(state.wallet, SOLANA_SIGN_TRANSACTION, "signTransaction");
		const input = {
			account: state.account,
			transaction: unsignedTransaction(message),
			chain: session.chain
		};
		assertActive?.();
		let output;
		try {
			output = await sign(input);
		} catch (error) {
			return walletError(error);
		}
		return {
			ok: true,
			value: checkSignedTransaction(output, message, session.address)
		};
	} catch (error) {
		return failure$2(failureCode(error, "INTEGRITY_FAILURE"));
	}
}
// packages/chain-solana/src/intent.ts
/**
* Solana intent record: the journal entry for one signed escrow message, kept in the encrypted vault through an
* injected journal port. Restored or imported records are untrusted input: `parseSolanaIntent` checks every field
* and invariant, and `verifyIntentForTrade` binds a record to one trade, registry deployment and exact message.
*
* States (D9 semantics, Solana-native):
*   prepared  message built and journaled; nothing signed yet (signature null)
*   signed    wallet output validated; signature (= transaction id) known; not handed to any RPC by this client
*   sendMarked  durable send marker written (CAS, before the broadcast); never cleared
*   sent      the RPC accepted the broadcast and answered this signature (not evidence of landing)
*   unknown   the broadcast call threw, timed out or answered something else; outcome uncertain
*   finalized landed at finalized commitment without error (corroborated by a finalized escrow read)
*   failed    landed at finalized commitment with an error (`outcome.err`)
*   dropped   finalized block height > lastValidBlockHeight and no status: it can never land
*   cancelled never marked and known not sent by this profile (local cancel before the marker)
*/
const SOLANA_INTENT_FORMAT = "p2p-offramp/solana-intent/v1";
const TERMINAL_STATES = Object.freeze([
	"finalized",
	"failed",
	"dropped",
	"cancelled"
]);
/** Origin of a record imported from a format without provenance; never a real profile id. */
const UNKNOWN_ORIGIN = "0".repeat(32);
/** Allowed state changes; everything else in a record is immutable except as `transitionIntent` permits. */
const SOLANA_TRANSITIONS = Object.freeze({
	prepared: Object.freeze([
		"signed",
		"cancelled",
		"dropped"
	]),
	signed: Object.freeze([
		"sendMarked",
		"cancelled",
		"finalized",
		"failed",
		"dropped"
	]),
	sendMarked: Object.freeze([
		"sent",
		"unknown",
		"finalized",
		"failed",
		"dropped"
	]),
	sent: Object.freeze([
		"finalized",
		"failed",
		"dropped"
	]),
	unknown: Object.freeze([
		"finalized",
		"failed",
		"dropped"
	]),
	finalized: Object.freeze([]),
	failed: Object.freeze([]),
	dropped: Object.freeze([]),
	cancelled: Object.freeze([])
});
const STATES = Object.keys(SOLANA_TRANSITIONS);
const KEYS = Object.freeze([
	"format",
	"intentId",
	"binding",
	"genesisHash",
	"programId",
	"programDataSha256",
	"escrow",
	"action",
	"role",
	"feePayer",
	"expectedEscrowState",
	"message",
	"blockhash",
	"blockhashSlot",
	"lastValidBlockHeight",
	"signature",
	"state",
	"sendMarkedAt",
	"outcome",
	"replacementOf",
	"originProfileId",
	"createdAt",
	"updatedAt"
]);
const EXPECTED = Object.freeze({
	fund: ["absent"],
	release: ["funded"],
	refund: ["funded"],
	payout: ["released", "refunded"]
});
const ROLES = Object.freeze({
	fund: ["seller"],
	release: ["seller"],
	refund: ["seller"],
	payout: ["seller", "buyer"]
});
/** Compact transaction error label written by `summarizeTransactionError` (submit.ts). */
const ERROR_LABEL = /^[A-Za-z]{1,64}(?::[0-9]{1,3}:(?:Custom:[0-9]{1,10}|[A-Za-z]{1,64}))?$/;
const MAX_MESSAGE_BASE64 = Math.ceil(MAX_TRANSACTION_BYTES / 3) * 4;
/** Exactly `keys` as own data properties of a plain object, copied without invoking accessors. */
function exactData(input, keys) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail$3("INVALID_INPUT");
		const prototype = Object.getPrototypeOf(input);
		if (prototype !== Object.prototype && prototype !== null) return fail$3("INVALID_INPUT");
		const own = Reflect.ownKeys(input);
		if (own.length !== keys.length || own.some((key) => typeof key !== "string" || !keys.includes(key))) return fail$3("INVALID_INPUT");
		const copy = Object.create(null);
		for (const key of keys) {
			const field = Object.getOwnPropertyDescriptor(input, key);
			if (!field || !("value" in field)) return fail$3("INVALID_INPUT");
			copy[key] = field.value;
		}
		return copy;
	} catch {
		return fail$3("INVALID_INPUT");
	}
}
function choice(input, allowed) {
	if (typeof input !== "string" || !allowed.includes(input)) return fail$3("INVALID_INPUT");
	return input;
}
function counter(input) {
	if (typeof input !== "number" || !Number.isSafeInteger(input) || input < 0) return fail$3("INVALID_INPUT");
	return input;
}
function decimal(input) {
	decimalU64(input);
	return input;
}
function intentId(input) {
	try {
		return parseIntentId(input);
	} catch {
		return fail$3("INVALID_INPUT");
	}
}
function hash64(input) {
	if (typeof input !== "string" || !/^[0-9a-f]{64}$/.test(input)) return fail$3("INVALID_INPUT");
	return input;
}
function outcomeOf(input) {
	if (input === null) return null;
	const raw = exactData(input, ["slot", "err"]);
	if (raw.err !== null && (typeof raw.err !== "string" || !ERROR_LABEL.test(raw.err))) return fail$3("INVALID_INPUT");
	return Object.freeze({
		slot: decimal(raw.slot),
		err: raw.err
	});
}
function messageBytes(input) {
	try {
		return decodeBase64(input, MAX_MESSAGE_BASE64);
	} catch {
		return fail$3("INVALID_INPUT");
	}
}
/** Per-state invariants of signature, marker and outcome. */
function checkState(record) {
	const { state, signature, sendMarkedAt, outcome } = record;
	const signed = signature !== null, marked = sendMarkedAt !== null;
	if (!{
		prepared: !signed && !marked && outcome === null,
		signed: signed && !marked && outcome === null,
		sendMarked: signed && marked && outcome === null,
		sent: signed && marked && outcome === null,
		unknown: signed && marked && outcome === null,
		finalized: signed && outcome !== null && outcome.err === null,
		failed: signed && outcome !== null && outcome.err !== null,
		dropped: outcome === null,
		cancelled: !marked && outcome === null
	}[state]) return fail$3("INVALID_INPUT");
}
/** Structural and internal validation of one stored record (no registry or trade needed). */
function parseSolanaIntent(input) {
	const raw = exactData(input, KEYS);
	if (raw.format !== "p2p-offramp/solana-intent/v1") return fail$3("UNSUPPORTED_VERSION");
	let binding;
	try {
		binding = parseSolanaBinding(parseTradeBinding(raw.binding));
	} catch {
		return fail$3("INVALID_INPUT");
	}
	const action = choice(raw.action, [
		"fund",
		"release",
		"refund",
		"payout"
	]);
	const role = choice(raw.role, ROLES[action]);
	const expectedEscrowState = choice(raw.expectedEscrowState, EXPECTED[action]);
	const record = Object.freeze({
		format: SOLANA_INTENT_FORMAT,
		intentId: intentId(raw.intentId),
		binding,
		genesisHash: canonicalKey(raw.genesisHash, "INVALID_INPUT"),
		programId: canonicalKey(raw.programId, "INVALID_INPUT"),
		programDataSha256: hash64(raw.programDataSha256),
		escrow: canonicalKey(raw.escrow, "INVALID_INPUT"),
		action,
		role,
		feePayer: canonicalKey(raw.feePayer, "INVALID_INPUT"),
		expectedEscrowState,
		message: raw.message,
		blockhash: canonicalKey(raw.blockhash, "INVALID_INPUT"),
		blockhashSlot: decimal(raw.blockhashSlot),
		lastValidBlockHeight: decimal(raw.lastValidBlockHeight),
		signature: raw.signature === null ? null : encodeBase58(decodeSignature(raw.signature)),
		state: choice(raw.state, STATES),
		sendMarkedAt: raw.sendMarkedAt === null ? null : counter(raw.sendMarkedAt),
		outcome: outcomeOf(raw.outcome),
		replacementOf: raw.replacementOf === null ? null : intentId(raw.replacementOf),
		originProfileId: typeof raw.originProfileId === "string" && /^[0-9a-f]{32}$/.test(raw.originProfileId) ? raw.originProfileId : fail$3("INVALID_INPUT"),
		createdAt: counter(raw.createdAt),
		updatedAt: counter(raw.updatedAt)
	});
	if (record.signature !== raw.signature || record.replacementOf === record.intentId) return fail$3("INVALID_INPUT");
	if (record.updatedAt < record.createdAt) return fail$3("INVALID_INPUT");
	if (record.sendMarkedAt !== null && (record.sendMarkedAt < record.createdAt || record.sendMarkedAt > record.updatedAt)) return fail$3("INVALID_INPUT");
	checkState(record);
	const message = messageBytes(record.message);
	let parsed;
	try {
		parsed = parseLegacyMessage(message);
	} catch {
		return fail$3("INVALID_INPUT");
	}
	if (parsed.accountKeys[0] !== record.feePayer || parsed.recentBlockhash !== record.blockhash || parsed.header.numRequiredSignatures !== 1) return fail$3("INVALID_INPUT");
	if (record.signature !== null && !verifySignature(record.signature, message, record.feePayer)) return fail$3("INTEGRITY_FAILURE");
	return record;
}
/** Binds a parsed record to one trade: network, genesis, program, ProgramData pin, escrow, role and exact bytes. */
function verifyIntentForTrade(record, trade) {
	const binding = trade.binding;
	if (record.binding.networkId !== binding.networkId || record.binding.deploymentId !== binding.deploymentId || record.binding.tradeId !== binding.tradeId) return fail$3("CONFLICT");
	if (record.genesisHash !== trade.network.genesisHash || record.programId !== trade.deployment.address) return fail$3("WRONG_CHAIN");
	const runtime = trade.deployment.runtime;
	if (runtime.kind !== "solana-program" || record.programDataSha256 !== runtime.programDataSha256) return fail$3("WRONG_CHAIN");
	if (record.escrow !== trade.escrow.address || record.feePayer !== roleKey(trade, record.role)) return fail$3("INTEGRITY_FAILURE");
	verifyPlanMessage(trade, record.action, record.expectedEscrowState, record.feePayer, messageBytes(record.message));
}
const isTerminal = (record) => TERMINAL_STATES.includes(record.state);
/**
* The next record for one transition. Only `state`, `updatedAt` (never backwards) and, once each, `signature`
* (prepared -> signed), `sendMarkedAt` (signed -> sendMarked) and `outcome` (to finalized/failed) may change.
*/
function transitionIntent(current, state, now, changes = {}) {
	if (!SOLANA_TRANSITIONS[current.state].includes(state)) return fail$3("CONFLICT");
	const updatedAt = Math.max(counter(now), current.updatedAt);
	const signature = changes.signature ?? current.signature;
	if (changes.signature !== void 0 && (current.state !== "prepared" || state !== "signed")) return fail$3("CONFLICT");
	const sendMarkedAt = state === "sendMarked" ? updatedAt : current.sendMarkedAt;
	const outcome = changes.outcome ?? current.outcome;
	return parseSolanaIntent({
		...current,
		binding: { ...current.binding },
		state,
		signature,
		sendMarkedAt,
		outcome: outcome === null ? null : { ...outcome },
		updatedAt
	});
}
const CODES = [
	"INVALID_INPUT",
	"UNSUPPORTED_VERSION",
	"UNSUPPORTED_PROVIDER",
	"WRONG_CHAIN",
	"UNAUTHORIZED",
	"USER_REJECTED",
	"LOCKED",
	"CONFLICT",
	"UNAVAILABLE",
	"TIMEOUT",
	"CANCELLED",
	"LIMIT_EXCEEDED",
	"INTEGRITY_FAILURE",
	"BROADCAST_UNKNOWN",
	"EXPIRED"
];
const UNCERTAIN = [
	"UNAVAILABLE",
	"TIMEOUT",
	"CANCELLED",
	"BROADCAST_UNKNOWN"
];
/** Raised when a journal write may or may not have committed. */
var UncertainWrite = class extends SolanaFailure {
	constructor() {
		super("UNAVAILABLE");
		this.name = "UncertainWrite";
	}
};
function own$1(input, key) {
	try {
		if (typeof input !== "object" || input === null) return fail$3();
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field || !("value" in field)) return fail$3();
		return field.value;
	} catch {
		return fail$3();
	}
}
/** A CoreResult from injected code, read through own data properties; foreign error detail is dropped. */
function portValue(result) {
	const ok = own$1(result, "ok");
	if (ok === true) return own$1(result, "value");
	if (ok !== false) return fail$3();
	const code = own$1(own$1(result, "error"), "code");
	return fail$3(CODES.includes(code) ? code : "UNAVAILABLE");
}
function revisionOf(input) {
	if (typeof input !== "number" || !Number.isSafeInteger(input) || input < 0) return fail$3();
	return input;
}
function checkedProfileId(journal) {
	let id;
	try {
		id = journal.profileId();
	} catch {
		return fail$3("LOCKED");
	}
	if (typeof id !== "string" || !/^[0-9a-f]{32}$/.test(id) || id === UNKNOWN_ORIGIN) return fail$3("LOCKED");
	return id;
}
/** Reads, validates and binds every record of one trade; duplicates or foreign records fail closed. */
async function loadIntents(journal, trade, signal) {
	let raw;
	try {
		raw = portValue(await journal.read(trade.binding, signal));
	} catch (error) {
		if (error instanceof SolanaFailure) throw error;
		return fail$3("UNAVAILABLE");
	}
	const revision = revisionOf(own$1(raw, "revision")), list = own$1(raw, "records");
	if (!Array.isArray(list) || list.length > 32) return fail$3("INTEGRITY_FAILURE");
	const records = [], ids = /* @__PURE__ */ new Set();
	for (let index = 0; index < list.length; index++) {
		let record;
		try {
			record = parseSolanaIntent(own$1(list, String(index)));
		} catch (error) {
			return fail$3(error instanceof SolanaFailure && error.code === "UNSUPPORTED_VERSION" ? "UNSUPPORTED_VERSION" : "INTEGRITY_FAILURE");
		}
		verifyIntentForTrade(record, trade);
		if (ids.has(record.intentId)) return fail$3("INTEGRITY_FAILURE");
		ids.add(record.intentId);
		records.push(record);
	}
	return Object.freeze({
		revision,
		records: Object.freeze(records)
	});
}
/** One CAS write. CONFLICT means another writer won; an `UncertainWrite` means the outcome is unknown. */
async function storeIntent(journal, trade, expectedRevision, record, signal) {
	let raw;
	try {
		raw = await journal.write(trade.binding, expectedRevision, record, signal);
	} catch {
		throw new UncertainWrite();
	}
	let next;
	try {
		next = revisionOf(portValue(raw));
	} catch (error) {
		const code = error instanceof SolanaFailure ? error.code : "UNAVAILABLE";
		if (UNCERTAIN.includes(code)) throw new UncertainWrite();
		throw error;
	}
	if (next <= expectedRevision) return fail$3("INTEGRITY_FAILURE");
	return next;
}
/**
* A new intent may join a trade only when every stored record is terminal. A rebuild after a definitive drop must
* name the dropped intent of the same action (`replacementOf`), and each dropped intent has at most one successor.
*/
function admitIntent(records, next) {
	if (records.length >= 32) return fail$3("LIMIT_EXCEEDED");
	if (records.some((record) => !isTerminal(record) || record.intentId === next.intentId)) return fail$3("CONFLICT");
	const latest = records.filter((record) => record.action === next.action).sort((a, b) => a.createdAt - b.createdAt).at(-1);
	const successors = new Set(records.map((record) => record.replacementOf).filter((id) => id !== null));
	if (next.replacementOf !== null) {
		const original = records.find((record) => record.intentId === next.replacementOf);
		if (!original || original.state !== "dropped" || original.action !== next.action || successors.has(original.intentId)) return fail$3("CONFLICT");
	} else if (latest?.state === "dropped" && !successors.has(latest.intentId)) return fail$3("CONFLICT");
}
/** The one sendTransaction configuration this client uses. */
const SEND_CONFIG = Object.freeze({
	encoding: "base64",
	skipPreflight: true,
	maxRetries: 0
});
/** One RPC request with a timeout; the result is boxed so no `then` of provider data is ever looked up. */
async function call(context, method, params, signal) {
	if (signal?.aborted) return fail$3("CANCELLED");
	const controller = new AbortController();
	let timer, onAbort;
	const stop = new Promise((resolve) => {
		timer = setTimeout(() => {
			resolve({ stop: "TIMEOUT" });
			controller.abort();
		}, context.timeoutMs);
		onAbort = () => {
			resolve({ stop: "CANCELLED" });
			controller.abort();
		};
		signal?.addEventListener("abort", onAbort, { once: true });
	});
	const physical = Promise.resolve().then(() => {
		context.assertActive?.();
		const rpc = context.rpc, request = rpc.request;
		context.assertActive?.();
		return Reflect.apply(request, rpc, [{
			method,
			params,
			signal: controller.signal
		}]);
	}).then((value) => ({ boxed: { value } }), () => ({ stop: "UNAVAILABLE" }));
	try {
		const raced = await Promise.race([physical, stop]);
		if ("stop" in raced) return fail$3(raced.stop);
		return raced.boxed;
	} finally {
		clearTimeout(timer);
		if (onAbort) signal?.removeEventListener("abort", onAbort);
	}
}
function own(input, key) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail$3();
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field || !("value" in field)) return fail$3();
		return field.value;
	} catch {
		return fail$3();
	}
}
function optionalOwn(input, key) {
	try {
		const field = Object.getOwnPropertyDescriptor(input, key);
		if (!field) return void 0;
		return "value" in field ? field.value : fail$3();
	} catch {
		return fail$3();
	}
}
/** Plain dense array of at most `maximum` data elements. */
function ownArray(input, maximum) {
	try {
		if (!Array.isArray(input) || Object.getPrototypeOf(input) !== Array.prototype) return fail$3();
		const length = Object.getOwnPropertyDescriptor(input, "length")?.value;
		if (typeof length !== "number" || length > maximum || Reflect.ownKeys(input).length !== length + 1) return fail$3();
		return Array.from({ length }, (_, index) => {
			const field = Object.getOwnPropertyDescriptor(input, String(index));
			return field && "value" in field ? field.value : fail$3();
		});
	} catch {
		return fail$3();
	}
}
function safeInt(input) {
	if (typeof input !== "number" || !Number.isSafeInteger(input) || input < 0) return fail$3();
	return input;
}
function clockNow(context) {
	let now;
	try {
		now = context.clock.now();
	} catch {
		return fail$3("INVALID_INPUT");
	}
	if (typeof now !== "number" || !Number.isSafeInteger(now) || now < 0) return fail$3("INVALID_INPUT");
	return now;
}
function newIntentId(context) {
	let bytes;
	try {
		bytes = context.random(32);
	} catch {
		return fail$3("UNAVAILABLE");
	}
	if (!(bytes instanceof Uint8Array) || bytes.length !== 32 || bytes.every((byte) => byte === 0)) return fail$3();
	return encodeBase64(bytes).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}
function raiseFloor(context, binding, height) {
	if (height < (context.floors.get(binding.networkId) ?? 0)) return fail$3("INTEGRITY_FAILURE");
	context.floors.set(binding.networkId, height);
}
const NAME = /^[A-Za-z]{1,64}$/;
/** Compact label for a TransactionError (`InstructionError:<i>:Custom:<n>`, `<Name>`, or `Unrecognized`). */
function summarizeTransactionError(err) {
	try {
		if (typeof err === "string") return NAME.test(err) ? err : "Unrecognized";
		if (typeof err !== "object" || err === null || Array.isArray(err)) return "Unrecognized";
		const keys = Reflect.ownKeys(err), name = keys[0];
		if (keys.length !== 1 || typeof name !== "string" || !NAME.test(name)) return "Unrecognized";
		if (name !== "InstructionError") return name;
		const pair = ownArray(own(err, name), 2), index = pair[0], inner = pair[1];
		if (pair.length !== 2 || typeof index !== "number" || !Number.isInteger(index) || index < 0 || index > 255) return "Unrecognized";
		if (typeof inner === "string") return `InstructionError:${index}:${NAME.test(inner) ? inner : "Unrecognized"}`;
		const innerKeys = typeof inner === "object" && inner !== null ? Reflect.ownKeys(inner) : [];
		const custom = innerKeys.length === 1 && innerKeys[0] === "Custom" ? own(inner, "Custom") : void 0;
		if (typeof custom === "number" && Number.isInteger(custom) && custom >= 0 && custom <= 4294967295) return `InstructionError:${index}:Custom:${custom}`;
		return `InstructionError:${index}:Unrecognized`;
	} catch {
		return "Unrecognized";
	}
}
/**
* Finalized blockhash for a new message. getLatestBlockhash(finalized) must agree with getBlock at its context
* slot (same blockhash, lastValidBlockHeight = blockHeight + 150), be no older than the plan's snapshot, and the
* genesis hash must still match the registry.
*/
async function anchorBlockhash(context, trade, plan, signal) {
	const latest = (await call(context, "getLatestBlockhash", [{ commitment: "finalized" }], signal)).value;
	const slot = safeInt(own(own(latest, "context"), "slot")), value = own(latest, "value");
	const blockhash = canonicalKey(own(value, "blockhash")), lastValid = safeInt(own(value, "lastValidBlockHeight"));
	if (slot < Number(plan.snapshotSlot)) return fail$3();
	const block = (await call(context, "getBlock", [slot, {
		commitment: "finalized",
		transactionDetails: "none",
		rewards: false
	}], signal)).value;
	const height = safeInt(own(block, "blockHeight"));
	if (canonicalKey(own(block, "blockhash")) !== blockhash || height + 150 !== lastValid) return fail$3();
	if (height < Number(plan.snapshotBlockHeight)) return fail$3();
	if ((await call(context, "getGenesisHash", [], signal)).value !== trade.network.genesisHash) return fail$3("WRONG_CHAIN");
	raiseFloor(context, trade.binding, height);
	return {
		blockhash,
		slot,
		lastValidBlockHeight: lastValid
	};
}
/** Journals a `prepared` intent for a plan after the admission rule; nothing is signed yet. */
async function prepareIntent(context, trade, plan, replacementOf, signal) {
	const profile = checkedProfileId(context.journal);
	const loaded = await loadIntents(context.journal, trade, signal);
	const anchor = await anchorBlockhash(context, trade, plan, signal);
	const message = compilePlan(plan, anchor.blockhash), now = clockNow(context);
	const runtime = trade.deployment.runtime;
	if (runtime.kind !== "solana-program") return fail$3("UNSUPPORTED_PROVIDER");
	const record = parseSolanaIntent({
		format: SOLANA_INTENT_FORMAT,
		intentId: newIntentId(context),
		binding: { ...trade.binding },
		genesisHash: trade.network.genesisHash,
		programId: trade.deployment.address,
		programDataSha256: runtime.programDataSha256,
		escrow: trade.escrow.address,
		action: plan.action,
		role: plan.role,
		feePayer: plan.feePayer,
		expectedEscrowState: plan.expectedEscrowState,
		message: encodeBase64(message),
		blockhash: anchor.blockhash,
		blockhashSlot: String(anchor.slot),
		lastValidBlockHeight: String(anchor.lastValidBlockHeight),
		signature: null,
		state: "prepared",
		sendMarkedAt: null,
		outcome: null,
		replacementOf,
		originProfileId: profile,
		createdAt: now,
		updatedAt: now
	});
	verifyIntentForTrade(record, trade);
	admitIntent(loaded.records, record);
	context.assertActive?.();
	if (checkedProfileId(context.journal) !== profile) return fail$3("LOCKED");
	return {
		record,
		revision: await storeIntent(context.journal, trade, loaded.revision, record, signal)
	};
}
/**
* Validity of the ORIGINAL reviewed blockhash; this never requests a replacement blockhash or edits a message.
* Bracket the fresh finalized height and processed validity with genesis checks, and reject stale contexts.
*/
async function recheckPreparedBlockhash(context, trade, record, plan) {
	if (record.state !== "prepared" && record.state !== "signed" || record.sendMarkedAt !== null) return fail$3("CONFLICT");
	const genesis = async () => {
		if ((await call(context, "getGenesisHash", [])).value !== trade.network.genesisHash) return fail$3("WRONG_CHAIN");
	};
	await genesis();
	const height = safeInt((await call(context, "getBlockHeight", [{ commitment: "finalized" }])).value);
	if (height < Number(record.lastValidBlockHeight) - 150 || height < Number(plan.snapshotBlockHeight) || height < (context.floors.get(trade.binding.networkId) ?? 0)) return fail$3("INTEGRITY_FAILURE");
	if (height > Number(record.lastValidBlockHeight)) return fail$3("EXPIRED");
	const minimumSlot = Math.max(Number(record.blockhashSlot), Number(plan.snapshotSlot));
	const validity = (await call(context, "isBlockhashValid", [record.blockhash, {
		commitment: "processed",
		minContextSlot: minimumSlot
	}])).value;
	if (safeInt(own(own(validity, "context"), "slot")) < minimumSlot) return fail$3("INTEGRITY_FAILURE");
	const valid = own(validity, "value");
	if (typeof valid !== "boolean") return fail$3("INTEGRITY_FAILURE");
	await genesis();
	if (!valid) return fail$3("EXPIRED");
	context.assertActive?.();
	raiseFloor(context, trade.binding, height);
}
const MESSAGE_BASE64_CAP = Math.ceil(MAX_TRANSACTION_BYTES / 3) * 4;
const messageOf = (record) => decodeBase64(record.message, MESSAGE_BASE64_CAP);
/** Wallet signature for a `prepared` intent of this session, then the CAS to `signed`. */
async function signIntent(context, trade, stored, session) {
	const { record } = stored;
	if (record.state !== "prepared" || session.address !== record.feePayer || session.role !== record.role || session.tradeId !== trade.binding.tradeId) return fail$3("UNAUTHORIZED");
	const result = await signWithWallet(session, messageOf(record), context.assertActive);
	if (!result.ok) return fail$3(result.error.code);
	context.assertActive?.();
	const next = transitionIntent(record, "signed", clockNow(context), { signature: result.value.signature });
	return {
		record: next,
		revision: await storeIntent(context.journal, trade, stored.revision, next),
		signed: result.value
	};
}
/**
* Writes the durable marker, then sends exactly once. If the marker write fails or its outcome is unknown,
* nothing is sent (UNAVAILABLE; the stored record is `signed` or `sendMarked` and reconciles like any other).
* After the marker every send outcome is recorded as `sent` or `unknown`.
*/
async function markAndSend(context, trade, stored, signed) {
	const { record } = stored;
	if (record.state !== "signed" || record.signature !== signed.signature) return fail$3("CONFLICT");
	context.assertActive?.();
	const marked = transitionIntent(record, "sendMarked", clockNow(context));
	let revision;
	try {
		revision = await storeIntent(context.journal, trade, stored.revision, marked);
	} catch (error) {
		if (error instanceof UncertainWrite) return fail$3("UNAVAILABLE");
		throw error;
	}
	context.assertActive?.();
	let state = "unknown";
	try {
		if ((await call(context, "sendTransaction", [encodeBase64(signed.wire), SEND_CONFIG])).value === signed.signature) state = "sent";
	} catch {
		state = "unknown";
	}
	let after;
	try {
		after = transitionIntent(marked, state, clockNow(context));
		return {
			record: after,
			revision: await storeIntent(context.journal, trade, revision, after)
		};
	} catch {
		return {
			record: marked,
			revision
		};
	}
}
async function signatureStatus(context, record, signal, minimumSlot = Number(record.blockhashSlot)) {
	const raw = (await call(context, "getSignatureStatuses", [[record.signature], { searchTransactionHistory: true }], signal)).value;
	const contextSlot = safeInt(own(own(raw, "context"), "slot")), list = ownArray(own(raw, "value"), 1);
	if (list.length !== 1 || contextSlot < minimumSlot) return fail$3();
	const entry = list[0];
	if (entry === null) return null;
	const slot = safeInt(own(entry, "slot")), confirmations = own(entry, "confirmations");
	const level = optionalOwn(entry, "confirmationStatus");
	if (level !== "processed" && level !== "confirmed" && level !== "finalized") return fail$3();
	if (confirmations !== null) safeInt(confirmations);
	if (slot > contextSlot || slot <= Number(record.blockhashSlot)) return fail$3();
	if (level === "finalized" !== (confirmations === null)) return fail$3();
	return {
		finalized: level === "finalized",
		slot,
		err: own(entry, "err") === null ? null : summarizeTransactionError(own(entry, "err"))
	};
}
const fromStatus = (status) => status.finalized ? {
	kind: "landed",
	slot: String(status.slot),
	err: status.err
} : { kind: "open" };
/** Collects evidence without mutating the network height floor before its final identity check. */
async function observeEvidence(context, record, signal) {
	if (record.signature !== null) {
		const status = await signatureStatus(context, record, signal);
		if (status !== null) return {
			observation: fromStatus(status),
			height: null
		};
	}
	const height = safeInt((await call(context, "getBlockHeight", [{ commitment: "finalized" }], signal)).value);
	if (height < (context.floors.get(record.binding.networkId) ?? 0)) return fail$3("INTEGRITY_FAILURE");
	let evidenceHeight = height;
	const observed = (observation) => ({
		observation,
		height: evidenceHeight
	});
	if (BigInt(height) <= BigInt(record.lastValidBlockHeight)) return observed({ kind: "open" });
	const finalized = (await call(context, "isBlockhashValid", [record.blockhash, {
		commitment: "finalized",
		minContextSlot: Number(record.blockhashSlot)
	}], signal)).value;
	const finalizedSlot = safeInt(own(own(finalized, "context"), "slot"));
	if (finalizedSlot < Number(record.blockhashSlot) || own(finalized, "value") !== false) return fail$3();
	const block = (await call(context, "getBlock", [finalizedSlot, {
		commitment: "finalized",
		transactionDetails: "none",
		rewards: false
	}], signal)).value;
	evidenceHeight = safeInt(own(block, "blockHeight"));
	if (evidenceHeight < height || BigInt(evidenceHeight) <= BigInt(record.lastValidBlockHeight)) return fail$3();
	const validity = (await call(context, "isBlockhashValid", [record.blockhash, {
		commitment: "processed",
		minContextSlot: finalizedSlot
	}], signal)).value;
	if (safeInt(own(own(validity, "context"), "slot")) < finalizedSlot) return fail$3();
	if (own(validity, "value") !== false) return fail$3();
	if (safeInt((await call(context, "getFirstAvailableBlock", [], signal)).value) > Number(record.blockhashSlot)) return observed({ kind: "open" });
	if (record.signature !== null) {
		const status = await signatureStatus(context, record, signal, finalizedSlot);
		if (status !== null) return observed(fromStatus(status));
	}
	return observed({ kind: "dropped" });
}
/**
* Native reconciliation never sends. Genesis brackets every observation, including absence and failed statuses:
* switching networks must not turn uncertainty into a terminal record or poison the correct network's floor.
*/
async function observeIntent(context, trade, record, signal) {
	const identity = async () => {
		if ((await call(context, "getGenesisHash", [], signal)).value !== trade.network.genesisHash) fail$3("WRONG_CHAIN");
	};
	await identity();
	let evidence;
	try {
		evidence = await observeEvidence(context, record, signal);
	} catch (error) {
		await identity();
		throw error;
	}
	await identity();
	if (evidence.height !== null) raiseFloor(context, trade.binding, evidence.height);
	return evidence.observation;
}
/** CAS write of a terminal observation; an open observation changes nothing. */
async function applyObservation(context, trade, stored, observation) {
	if (observation.kind === "open") return stored;
	const now = clockNow(context);
	const next = observation.kind === "dropped" ? transitionIntent(stored.record, "dropped", now) : transitionIntent(stored.record, observation.err === null ? "finalized" : "failed", now, { outcome: {
		slot: observation.slot,
		err: observation.err
	} });
	return {
		record: next,
		revision: await storeIntent(context.journal, trade, stored.revision, next)
	};
}
/** Local cancel of a never-marked intent this profile wrote. */
async function cancelIntent(context, trade, stored) {
	const { record } = stored;
	if (record.state !== "prepared" && record.state !== "signed" || record.sendMarkedAt !== null || record.originProfileId !== checkedProfileId(context.journal)) return fail$3("CONFLICT");
	const next = transitionIntent(record, "cancelled", clockNow(context));
	return {
		record: next,
		revision: await storeIntent(context.journal, trade, stored.revision, next)
	};
}
// packages/chain-solana/src/compose.ts
/**
* Composition entry point for the Solana escrow client; wallet, RPC and encrypted journal are injected.
*
*   const client = createSolanaEscrowClient({ rpc, wallet, journal, registry, clock, margins, walletChain });
*   const trade = client.bind(binding, terms);              // G16 terms bound to one registry deployment
*   const seller = await client.connect(trade, 'seller');   // explicit, user-triggered wallet connect
*   const review = await client.prepare(trade, seller, 'release'); // journal exact bytes, no wallet prompt
*   await client.confirm(review.value, seller);             // explicit review confirmation, one-shot capability
*   await client.reconcile(trade);                          // poll until the intent is terminal
*   await client.payout(trade, seller);                     // only after a finalized Released/Refunded read
*
* Every action reads a fresh finalized snapshot, plans against it, journals `prepared`, has the wallet sign,
* journals the signature and the durable marker, then sends once. `recover` runs at startup: it cancels this
* profile's never-marked preparations and reconciles everything else from chain state. Nothing ever resends.
* `margins` are required: the default policy is chosen elsewhere, never here. A host MUST dispose this client
* synchronously on wallet account/chain/disconnect changes; Wallet Standard sessions cannot observe them here.
* A pending physical wallet prompt keeps its serial slot until it settles, even after cancellation/disposal.
*/
const failure$1 = (code) => ({
	ok: false,
	error: createCoreError(code, {
		operationId: createOperationId(),
		readOnly: false
	})
});
const value = (result) => result.ok ? result.value : fail$3(result.error.code);
const codeOf = (error) => error instanceof UncertainWrite ? "UNAVAILABLE" : error instanceof SolanaFailure ? error.code : "UNAVAILABLE";
const isLocalPreMarker = (record, profile) => (record.state === "prepared" || record.state === "signed") && record.sendMarkedAt === null && record.originProfileId === profile;
/** Capture user review options before the first await; no provider getter or later mutation can change them. */
function reviewOptions(input) {
	let raw;
	try {
		const keys = Reflect.ownKeys(input);
		if (keys.some((key) => typeof key !== "string" || ![
			"createAta",
			"maxRentTopUpLamports",
			"rebuildOf"
		].includes(key))) return fail$3("INVALID_INPUT");
		raw = exactData(input, keys);
	} catch {
		return fail$3("INVALID_INPUT");
	}
	const copy = {};
	if (raw.createAta !== void 0) {
		if (typeof raw.createAta !== "boolean") return fail$3("INVALID_INPUT");
		copy.createAta = raw.createAta;
	}
	if (raw.maxRentTopUpLamports !== void 0) {
		decimalU64(raw.maxRentTopUpLamports);
		copy.maxRentTopUpLamports = raw.maxRentTopUpLamports;
	}
	if (raw.rebuildOf !== void 0) {
		if (typeof raw.rebuildOf !== "string") return fail$3("INVALID_INPUT");
		copy.rebuildOf = raw.rebuildOf;
	}
	return Object.freeze(copy);
}
/** Capture the funding source and replacement identity before enqueueing any asynchronous work. */
function fundingReviewOptions(input) {
	try {
		const keys = Reflect.ownKeys(input);
		if (keys.length > 2 || keys.some((key) => typeof key !== "string" || !["sellerTokenAccount", "rebuildOf"].includes(key))) return fail$3("INVALID_INPUT");
		const raw = exactData(input, keys);
		const copy = {};
		if (raw.sellerTokenAccount !== void 0) copy.sellerTokenAccount = canonicalKey(raw.sellerTokenAccount, "INVALID_INPUT");
		if (raw.rebuildOf !== void 0) copy.rebuildOf = parseIntentId(raw.rebuildOf);
		return Object.freeze(copy);
	} catch {
		return fail$3("INVALID_INPUT");
	}
}
/** Ignore only fields a legitimate intent transition can change; all reviewed identity/bytes stay exact. */
function samePreparation(first, second) {
	const original = (record) => ({
		...record,
		state: "prepared",
		signature: null,
		sendMarkedAt: null,
		outcome: null,
		updatedAt: record.createdAt
	});
	return JSON.stringify(original(first)) === JSON.stringify(original(second));
}
/** The finalized effect a successful intent must have left (corroborates a "finalized, no error" status). */
function effectVisible(record, snapshot) {
	const escrow = snapshot.escrow;
	if (escrow === null) return false;
	if (record.action === "fund") return true;
	if (record.action === "release") return escrow.state === "released";
	if (record.action === "refund") return escrow.state === "refunded";
	return escrow.paidOut && escrow.state === record.expectedEscrowState;
}
function createSolanaEscrowClient(options) {
	const { rpc, wallet, journal, registry, clock, walletChain } = options;
	const margins = parseMargins(options.margins);
	const timeoutMs = options.timeoutMs ?? 1e4;
	if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 6e4) fail$3("INVALID_INPUT");
	const random = options.random ?? ((length) => crypto.getRandomValues(new Uint8Array(length)));
	const reader = new SolanaChainReader({
		rpc,
		registry,
		timeoutMs,
		now: () => clock.now(),
		freezeAuthorityPermits: options.freezeAuthorityPermits ?? []
	});
	let disposed = false, sequence = 0;
	const assertActive = () => {
		if (disposed) fail$3("CANCELLED");
		checkedProfileId(journal);
	};
	const context = {
		rpc,
		journal,
		clock,
		random,
		timeoutMs,
		floors: /* @__PURE__ */ new Map(),
		assertActive
	};
	const locks = /* @__PURE__ */ new Map();
	const sessions = /* @__PURE__ */ new WeakMap();
	const preparations = /* @__PURE__ */ new WeakMap();
	/** One operation per trade at a time in this instance; other tabs are fenced by the journal CAS. */
	function serialized(trade, work) {
		if (disposed) return Promise.resolve(failure$1("CANCELLED"));
		if (!isBoundSolanaTrade(trade)) return Promise.resolve(failure$1("INVALID_INPUT"));
		const key = `${trade.binding.networkId}:${trade.binding.deploymentId}:${trade.binding.tradeId}`;
		const run = (locks.get(key) ?? Promise.resolve()).then(async () => {
			if (disposed) return failure$1("CANCELLED");
			try {
				return {
					ok: true,
					value: await work()
				};
			} catch (error) {
				return failure$1(codeOf(error));
			}
		});
		locks.set(key, run.then(() => void 0));
		return run;
	}
	const request = () => ({
		generation: 0,
		requestSequence: ++sequence,
		signal: new AbortController().signal
	});
	const read = async (trade) => value(await readTrustedSnapshot(reader, trade, request()));
	async function cancelLocal(trade, original) {
		try {
			if (checkedProfileId(journal) !== original.originProfileId) return;
			const loaded = await loadIntents(journal, trade);
			const record = loaded.records.find((entry) => entry.intentId === original.intentId);
			if (record && samePreparation(record, original) && isLocalPreMarker(record, checkedProfileId(journal))) await cancelIntent(context, trade, {
				record,
				revision: loaded.revision
			});
		} catch {}
	}
	function checkSession(trade, session, own = false) {
		if (!isWalletSession(session) || session.tradeId !== trade.binding.tradeId) return fail$3("UNAUTHORIZED");
		if (session.chain !== walletChain) return fail$3("WRONG_CHAIN");
		if (own) {
			const connected = sessions.get(session);
			if (!connected || connected.binding.networkId !== trade.binding.networkId || connected.binding.deploymentId !== trade.binding.deploymentId || connected.binding.tradeId !== trade.binding.tradeId) return fail$3("UNAUTHORIZED");
			if (connected.profileId !== checkedProfileId(journal)) return fail$3("LOCKED");
		}
	}
	async function submitPrepared(trade, session, original, active, revalidate) {
		let stored = original, signed;
		try {
			active.assertActive?.();
			if (revalidate) stored = await revalidate(stored);
			active.assertActive?.();
			const result = await signIntent(active, trade, stored, session);
			stored = result;
			signed = result.signed;
			active.assertActive?.();
			if (revalidate) stored = await revalidate(stored);
			active.assertActive?.();
		} catch (error) {
			await cancelLocal(trade, original.record);
			throw error;
		}
		stored = await markAndSend(active, trade, stored, signed);
		return Object.freeze({
			intentId: stored.record.intentId,
			signature: signed.signature,
			state: stored.record.state
		});
	}
	async function act(trade, session, rebuildOf, plan) {
		checkSession(trade, session);
		const planned = value(plan(await read(trade)));
		if (planned.role !== session.role || planned.feePayer !== session.address) return fail$3("UNAUTHORIZED");
		const stored = await prepareIntent(context, trade, planned, rebuildOf ?? null);
		return submitPrepared(trade, session, stored, {
			...context,
			assertActive: () => {
				assertActive();
				if (checkedProfileId(journal) !== stored.record.originProfileId) fail$3("LOCKED");
			}
		});
	}
	async function prepareReview(trade, session, action, extra) {
		assertActive();
		checkSession(trade, session, true);
		const profile = checkedProfileId(journal);
		let preparation;
		const active = {
			...context,
			assertActive: () => {
				assertActive();
				if (checkedProfileId(journal) !== profile) fail$3("LOCKED");
				if (preparation?.revoked) fail$3("CANCELLED");
				checkSession(trade, session, true);
			}
		};
		const plan = (snapshot) => action === "fund" ? planFund(trade, snapshot, session.role, margins, extra) : action === "release" ? planRelease(trade, snapshot, session.role, margins) : action === "refund" ? planRefund(trade, snapshot, session.role, margins) : planPayout(trade, snapshot, session.role, extra);
		const planned = value(plan(await read(trade)));
		active.assertActive?.();
		if (planned.role !== session.role || planned.feePayer !== session.address) return fail$3("UNAUTHORIZED");
		const stored = await prepareIntent(active, trade, planned, extra.rebuildOf ?? null);
		try {
			active.assertActive?.();
		} catch (error) {
			await cancelLocal(trade, stored.record);
			throw error;
		}
		preparation = {
			trade,
			session,
			stored,
			plan,
			context: active,
			status: "prepared",
			revoked: false
		};
		const record = stored.record;
		const view = Object.freeze({
			intentId: record.intentId,
			action,
			role: record.role,
			feePayer: record.feePayer,
			binding: Object.freeze({ ...record.binding }),
			programId: record.programId,
			escrow: record.escrow,
			expectedEscrowState: record.expectedEscrowState,
			message: record.message,
			blockhash: record.blockhash,
			lastValidBlockHeight: record.lastValidBlockHeight,
			shape: Object.freeze({ ...planned.shape })
		});
		preparations.set(view, preparation);
		return view;
	}
	async function revalidateReview(preparation, stored) {
		const { trade, context: active } = preparation;
		active.assertActive?.();
		const loaded = await loadIntents(journal, trade);
		active.assertActive?.();
		const record = loaded.records.find((entry) => entry.intentId === stored.record.intentId);
		if (!record || !samePreparation(record, preparation.stored.record)) return fail$3("INTEGRITY_FAILURE");
		if (record.state !== stored.record.state || record.signature !== stored.record.signature || !isLocalPreMarker(record, preparation.stored.record.originProfileId)) return fail$3("CONFLICT");
		const planned = value(preparation.plan(await read(trade)));
		active.assertActive?.();
		if (planned.role !== record.role || planned.feePayer !== record.feePayer || planned.action !== record.action || planned.expectedEscrowState !== record.expectedEscrowState || encodeBase64(compilePlan(planned, record.blockhash)) !== record.message) return fail$3("CONFLICT");
		await recheckPreparedBlockhash(active, trade, record, planned);
		active.assertActive?.();
		return {
			record,
			revision: loaded.revision
		};
	}
	function confirm(prepared, session) {
		const preparation = preparations.get(prepared);
		if (!preparation) return Promise.resolve(failure$1("UNAUTHORIZED"));
		if (preparation.status !== "prepared" || preparation.revoked) return Promise.resolve(failure$1("CONFLICT"));
		preparation.status = "confirming";
		return serialized(preparation.trade, async () => {
			try {
				return await submitPrepared(preparation.trade, preparation.session, preparation.stored, preparation.context, (stored) => {
					if (session !== preparation.session) return Promise.reject(new SolanaFailure("UNAUTHORIZED"));
					return revalidateReview(preparation, stored);
				});
			} finally {
				preparation.status = "consumed";
			}
		});
	}
	function cancel(prepared) {
		const preparation = preparations.get(prepared);
		if (!preparation) return Promise.resolve(failure$1("UNAUTHORIZED"));
		if (preparation.status === "consumed" || preparation.revoked) return Promise.resolve(failure$1("CONFLICT"));
		preparation.revoked = true;
		return serialized(preparation.trade, async () => {
			try {
				assertActive();
				const original = preparation.stored.record;
				if (checkedProfileId(journal) !== original.originProfileId) return fail$3("LOCKED");
				const loaded = await loadIntents(journal, preparation.trade);
				const record = loaded.records.find((entry) => entry.intentId === original.intentId);
				if (!record || !samePreparation(record, original)) return fail$3("INTEGRITY_FAILURE");
				if (checkedProfileId(journal) !== original.originProfileId) return fail$3("LOCKED");
				if (record.state === "cancelled") return;
				if (!isLocalPreMarker(record, original.originProfileId)) return fail$3("CONFLICT");
				await cancelIntent(context, preparation.trade, {
					record,
					revision: loaded.revision
				});
			} finally {
				preparation.status = "consumed";
			}
		});
	}
	async function reconcileAll(trade) {
		const profile = checkedProfileId(journal);
		let loaded = await loadIntents(journal, trade), revision = loaded.revision;
		for (const record of loaded.records) {
			if (isTerminal(record) || isLocalPreMarker(record, profile)) continue;
			const observation = await observeIntent(context, trade, record);
			if (observation.kind === "landed" && observation.err === null) {
				const snapshot = await read(trade);
				if (BigInt(snapshot.live.height) < BigInt(observation.slot)) continue;
				if (!effectVisible(record, snapshot)) return fail$3("INTEGRITY_FAILURE");
			}
			revision = (await applyObservation(context, trade, {
				record,
				revision
			}, observation)).revision;
		}
		loaded = await loadIntents(journal, trade);
		return loaded.records;
	}
	return Object.freeze({
		bind: (binding, terms) => bindSolanaTrade(registry, binding, terms),
		connect: async (trade, role) => {
			try {
				assertActive();
				const profileId = checkedProfileId(journal);
				const result = await connectWalletRole(wallet, trade, role, walletChain);
				assertActive();
				if (checkedProfileId(journal) !== profileId) return failure$1("LOCKED");
				if (result.ok) sessions.set(result.value, {
					binding: trade.binding,
					profileId
				});
				return result;
			} catch (error) {
				return failure$1(codeOf(error));
			}
		},
		read: (trade) => serialized(trade, () => read(trade)),
		prepare: (trade, session, action, extra = {}) => {
			try {
				if (action !== "release" && action !== "refund" && action !== "payout") return Promise.resolve(failure$1("INVALID_INPUT"));
				const captured = reviewOptions(extra);
				return serialized(trade, () => prepareReview(trade, session, action, captured));
			} catch (error) {
				return Promise.resolve(failure$1(codeOf(error)));
			}
		},
		prepareFunding: (trade, session, extra = {}) => {
			try {
				const captured = fundingReviewOptions(extra);
				return serialized(trade, () => prepareReview(trade, session, "fund", captured));
			} catch (error) {
				return Promise.resolve(failure$1(codeOf(error)));
			}
		},
		confirm,
		cancel,
		fund: (trade, session, extra = {}) => serialized(trade, () => act(trade, session, extra.rebuildOf, (snapshot) => planFund(trade, snapshot, session.role, margins, extra))),
		release: (trade, session, extra = {}) => serialized(trade, () => act(trade, session, extra.rebuildOf, (snapshot) => planRelease(trade, snapshot, session.role, margins))),
		refund: (trade, session, extra = {}) => serialized(trade, () => act(trade, session, extra.rebuildOf, (snapshot) => planRefund(trade, snapshot, session.role, margins))),
		payout: (trade, session, extra = {}) => serialized(trade, () => act(trade, session, extra.rebuildOf, (snapshot) => planPayout(trade, snapshot, session.role, extra))),
		reconcile: (trade) => serialized(trade, () => reconcileAll(trade)),
		recover: (trade) => serialized(trade, async () => {
			const profile = checkedProfileId(journal), loaded = await loadIntents(journal, trade);
			let revision = loaded.revision;
			for (const record of loaded.records) {
				if (!isLocalPreMarker(record, profile)) continue;
				revision = (await cancelIntent(context, trade, {
					record,
					revision
				})).revision;
			}
			return reconcileAll(trade);
		}),
		intents: (trade) => serialized(trade, async () => (await loadIntents(journal, trade)).records),
		dispose: () => {
			if (!disposed) {
				disposed = true;
				reader.dispose();
			}
		}
	});
}
// packages/chain-solana/src/recovery.ts
/**
* Portable recovery for the original funded escrow (documented in the Solana RECOVERY.md). A self-contained document
* (`p2p-offramp/solana-escrow-recovery/v1`) holds only public data: network and deployment identity, the G16 terms
* with their bytes and hash, the escrow and vault PDAs, the two role keys and the asset. It holds no key, seed,
* signature, wallet data or private agreement content (only its hash, which is part of the terms).
*
* `parseRecoveryDocument` recomputes every derived value. `recoveryRegistry` turns the document into a one-network
* registry view, so the ordinary finalized reader (genesis, immutable program, ProgramData pin, Clock) checks the
* chain without the app's registry. `recoveryExits` lists the exits a fresh finalized snapshot allows, and
* `buildRecoveryMessage` plans and compiles the chosen exit with the same C-L2 rules as the client.
*/
const SOLANA_RECOVERY_FORMAT = "p2p-offramp/solana-escrow-recovery/v1";
const TERMS_KEYS$1 = [
	"acceptBeforeSeconds",
	"amountBaseUnits",
	"assetKind",
	"buyer",
	"capabilitiesHash",
	"escrowExpirySeconds",
	"genesisHash",
	"mint",
	"orderId",
	"privateAgreementHash",
	"programId",
	"revision",
	"seller",
	"sellerNonce",
	"tokenProgram"
];
const failure = (error) => ({
	ok: false,
	error: createCoreError(failureCode(error, "INVALID_INPUT"), {
		operationId: createOperationId(),
		readOnly: true
	})
});
function result(work) {
	try {
		return {
			ok: true,
			value: work()
		};
	} catch (error) {
		return failure(error);
	}
}
const text$1 = (input, pattern) => typeof input === "string" && pattern.test(input) ? input : fail$3("INVALID_INPUT");
const ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
const HEX64 = /^[0-9a-f]{64}$/;
const registryId$1 = (input) => {
	const id = text$1(input, ID);
	return id.includes("..") ? fail$3("INVALID_INPUT") : id;
};
/** Document for a bound trade, written when the trade is funded (or any time after). */
function createRecoveryDocument(trade) {
	return result(() => {
		if (!isBoundSolanaTrade(trade)) return fail$3("INVALID_INPUT");
		const runtime = trade.deployment.runtime;
		if (runtime.kind !== "solana-program") return fail$3("UNSUPPORTED_PROVIDER");
		const terms = Object.fromEntries(TERMS_KEYS$1.map((key) => [key, trade.terms[key]]));
		return parseRecoveryDocument({
			format: SOLANA_RECOVERY_FORMAT,
			network: {
				networkId: trade.network.id,
				environment: trade.network.environment,
				genesisHash: trade.network.genesisHash,
				deploymentId: trade.deployment.id,
				programId: trade.deployment.address,
				programDataAddress: trade.programDataAddress,
				programDataSha256: runtime.programDataSha256,
				artifactSha256: trade.deployment.artifactSha256
			},
			terms,
			termsBytesBase64: encodeBase64(encodeSolanaTerms(trade.terms)),
			termsHash: trade.termsHash,
			escrow: {
				address: trade.escrow.address,
				bump: trade.escrow.bump
			},
			vault: trade.vault === null ? null : {
				address: trade.vault.address,
				bump: trade.vault.bump
			},
			roles: {
				seller: trade.terms.seller,
				buyer: trade.terms.buyer
			},
			asset: {
				id: trade.asset.id,
				kind: trade.terms.assetKind,
				mint: trade.terms.mint,
				decimals: trade.asset.decimals
			}
		});
	});
}
function pda(input) {
	const raw = exactData(input, ["address", "bump"]);
	if (typeof raw.bump !== "number" || !Number.isInteger(raw.bump) || raw.bump < 0 || raw.bump > 255) return fail$3("INVALID_INPUT");
	return Object.freeze({
		address: canonicalKey(raw.address, "INVALID_INPUT"),
		bump: raw.bump
	});
}
/** Strict parse; every derived field (terms bytes, hash, PDAs, ProgramData address, roles, asset) is recomputed. */
function parseRecoveryDocument(input) {
	const raw = exactData(input, [
		"format",
		"network",
		"terms",
		"termsBytesBase64",
		"termsHash",
		"escrow",
		"vault",
		"roles",
		"asset"
	]);
	if (raw.format !== "p2p-offramp/solana-escrow-recovery/v1") return fail$3("UNSUPPORTED_VERSION");
	const net = exactData(raw.network, [
		"networkId",
		"environment",
		"genesisHash",
		"deploymentId",
		"programId",
		"programDataAddress",
		"programDataSha256",
		"artifactSha256"
	]);
	const network = Object.freeze({
		networkId: registryId$1(net.networkId),
		environment: [
			"local",
			"testnet",
			"mainnet"
		].includes(net.environment) ? net.environment : fail$3("INVALID_INPUT"),
		genesisHash: canonicalKey(net.genesisHash, "INVALID_INPUT"),
		deploymentId: registryId$1(net.deploymentId),
		programId: canonicalKey(net.programId, "INVALID_INPUT"),
		programDataAddress: canonicalKey(net.programDataAddress, "INVALID_INPUT"),
		programDataSha256: text$1(net.programDataSha256, HEX64),
		artifactSha256: text$1(net.artifactSha256, HEX64)
	});
	const termsRaw = exactData(raw.terms, TERMS_KEYS$1);
	const terms = Object.freeze(Object.fromEntries(TERMS_KEYS$1.map((key) => [key, termsRaw[key]])));
	let bytes;
	try {
		bytes = encodeSolanaTerms(terms);
	} catch {
		return fail$3("INVALID_INPUT");
	}
	if (!equalBytes(decodeBase64(raw.termsBytesBase64, 1024), bytes) || raw.termsHash !== hex$1(sha256(bytes))) return fail$3("INTEGRITY_FAILURE");
	const escrow = pda(raw.escrow), vault = raw.vault === null ? null : pda(raw.vault);
	const roles = exactData(raw.roles, ["seller", "buyer"]);
	const asset = exactData(raw.asset, [
		"id",
		"kind",
		"mint",
		"decimals"
	]);
	const derived = escrowAddress(network.programId, terms.seller, terms.sellerNonce);
	const derivedVault = terms.assetKind === "spl" ? vaultAddress(network.programId, derived.address) : null;
	if (terms.genesisHash !== network.genesisHash || terms.programId !== network.programId || programDataAddress(network.programId).address !== network.programDataAddress || derived.address !== escrow.address || derived.bump !== escrow.bump || vault === null !== (derivedVault === null) || vault !== null && (vault.address !== derivedVault.address || vault.bump !== derivedVault.bump) || roles.seller !== terms.seller || roles.buyer !== terms.buyer || asset.kind !== terms.assetKind || asset.mint !== terms.mint || typeof asset.decimals !== "number" || !Number.isInteger(asset.decimals) || asset.decimals < 0 || asset.decimals > 18) return fail$3("INTEGRITY_FAILURE");
	return deepFreeze({
		format: SOLANA_RECOVERY_FORMAT,
		network,
		terms,
		termsBytesBase64: raw.termsBytesBase64,
		termsHash: raw.termsHash,
		escrow,
		vault,
		roles: {
			seller: terms.seller,
			buyer: terms.buyer
		},
		asset: {
			id: registryId$1(asset.id),
			kind: terms.assetKind,
			mint: terms.mint,
			decimals: asset.decimals
		}
	});
}
// scripts/lib/solana-localnet-withheld-send.mjs
/** Fixture-only failed acknowledgment. The caller has observed the marker and withheld forwarding. */
function rejectWithheldSolanaSend(response, headers) {
	const body = "Acknowledgment unavailable.";
	response.writeHead(503, {
		...headers,
		"Content-Type": "text/plain",
		"Content-Length": Buffer.byteLength(body),
		"Cache-Control": "no-store"
	}).end(body);
}
// scripts/lib/solana-localnet-fixture.mjs
/** Real Agave fixture only. Starts ledger first, compiles its ACTUAL genesis, deploys/finalizes, then seeds native escrows. */
const ROOT = fileURLToPath(new URL("../../", import.meta.url));
const CHAIN = "solana:localnet";
const sha$1 = (bytes) => createHash("sha256").update(bytes).digest("hex");
const unwrap = (result) => {
	assert.equal(result.ok, true, JSON.stringify(result));
	return result.value;
};
async function waitSolana(check, label, timeoutMs = 12e4, intervalMs = 500) {
	const start = Date.now();
	for (;;) {
		if (await check()) return;
		if (Date.now() - start >= timeoutMs) throw Error(`Timed out: ${label}`);
		await sleep(intervalMs);
	}
}
function fixtureJournal() {
	const trades = /* @__PURE__ */ new Map();
	const entry = (b) => trades.get(b.tradeId) ?? {
		revision: 0,
		records: /* @__PURE__ */ new Map()
	};
	return {
		profileId: () => "a".repeat(32),
		async read(b) {
			const e = entry(b);
			return {
				ok: true,
				value: {
					revision: e.revision,
					records: [...e.records.values()].map((r) => structuredClone(r))
				}
			};
		},
		async write(b, revision, record) {
			const e = entry(b);
			if (e.revision !== revision) return {
				ok: false,
				error: { code: "CONFLICT" }
			};
			e.records.set(record.intentId, structuredClone(record));
			e.revision++;
			trades.set(b.tradeId, e);
			return {
				ok: true,
				value: e.revision
			};
		}
	};
}
async function startSolanaLocalnetFixture() {
	const tools = Object.fromEntries([
		"solana",
		"solana-test-validator",
		"cargo-build-sbf"
	].map((name) => [name, resolveTool(name)]));
	const work = await mkdtemp(join(tmpdir(), "p2p-solana-browser-")), logs = join(work, "logs");
	await mkdir(logs);
	const keys = Object.fromEntries([
		"payer",
		"authority",
		"program",
		"seller",
		"buyer"
	].map((name) => [name, generateKeypair()]));
	for (const [name, key] of Object.entries(keys)) writeKeypairFile(join(work, `${name}.json`), key);
	const validatorUrl = "http://127.0.0.1:19699/";
	const rpc = new Rpc(validatorUrl), children = /* @__PURE__ */ new Set();
	let validator, proxy, closed = false, beforeSend = null, withhold = false;
	const observed = [], summary = {
		genesisHash: null,
		programId: keys.program.address,
		programDataSha256: null,
		artifactSha256: null,
		validatorVersion: null,
		actualGenesisRpc: true,
		realClock: true,
		setupFunding: [],
		appSends: observed,
		fixtureErrors: []
	};
	const close = async () => {
		if (closed) return;
		closed = true;
		if (proxy) {
			proxy.closeAllConnections();
			await new Promise((resolve) => proxy.close(resolve));
		}
		for (const child of children) if (child.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
		await rm(work, {
			recursive: true,
			force: true
		});
	};
	const onExit = () => {
		for (const child of children) if (child.exitCode === null && child.signalCode === null) child.kill("SIGKILL");
	};
	process.once("exit", onExit);
	async function run(name, args, env = process.env, timeoutMs = 6e5) {
		const path = join(logs, `${name}-${Date.now()}.log`), fd = openSync(path, "w");
		const child = spawn(tools[name], args, {
			cwd: resolve(ROOT, "contracts/solana"),
			env,
			stdio: [
				"ignore",
				fd,
				fd
			]
		});
		closeSync(fd);
		children.add(child);
		const timer = setTimeout(() => child.kill("SIGKILL"), timeoutMs);
		try {
			const code = await new Promise((resolve, reject) => {
				child.once("error", reject);
				child.once("exit", resolve);
			});
			if (code !== 0) throw Error(`${name} failed (${code}): ${(await readFile(path, "utf8")).slice(-8e3)}`);
		} finally {
			clearTimeout(timer);
			children.delete(child);
		}
	}
	const cli = (args) => run("solana", [
		...args,
		"--url",
		validatorUrl,
		"--keypair",
		join(work, "payer.json"),
		"--commitment",
		"confirmed"
	]);
	const rpcPort = { request: ({ method, params }) => rpc.call(method, params ?? []) };
	function account(key) {
		return {
			address: key.address,
			publicKey: Uint8Array.from(key.publicKey),
			chains: [CHAIN],
			features: ["solana:signTransaction"]
		};
	}
	function sign(address, transaction) {
		const key = [keys.seller, keys.buyer].find((k) => k.address === address);
		assert.ok(key, "fixture signs only its test role keys");
		const wire = Uint8Array.from(transaction);
		assert.equal(wire[0], 1);
		assert.ok(wire.slice(1, 65).every((b) => b === 0));
		const message = wire.slice(65), signature = ed25519.sign(message, key.seed);
		return Uint8Array.from([
			1,
			...signature,
			...message
		]);
	}
	try {
		for (const port of [19699, 19700]) await new Promise((resolve, reject) => {
			const probe = createServer$1();
			probe.once("error", reject);
			probe.listen(port, "127.0.0.1", () => probe.close(resolve));
		});
		const out = openSync(join(logs, "validator.log"), "w");
		validator = spawn(tools["solana-test-validator"], [
			"--ledger",
			join(work, "ledger"),
			"--reset",
			"--quiet",
			"--bind-address",
			"127.0.0.1",
			"--rpc-port",
			"19699",
			"--faucet-port",
			"20700",
			"--gossip-port",
			"18801",
			"--dynamic-port-range",
			"18802-18830",
			"--mint",
			keys.payer.address
		], { stdio: [
			"ignore",
			out,
			out
		] });
		closeSync(out);
		children.add(validator);
		let startupError;
		validator.once("error", (error) => {
			startupError = error;
		});
		await waitSolana(async () => {
			if (startupError) throw startupError;
			if (validator.exitCode !== null || validator.signalCode !== null) throw Error(`Validator exited: ${(await readFile(join(logs, "validator.log"), "utf8")).slice(-6e3)}`);
			try {
				return await rpc.call("getHealth") === "ok" && await rpc.call("getSlot", [{ commitment: "finalized" }]) > 0 && validator.exitCode === null && validator.signalCode === null;
			} catch {
				return false;
			}
		}, "actual validator startup");
		const version = await rpc.call("getVersion");
		assert.equal(version["solana-core"], "4.1.2");
		summary.validatorVersion = version;
		const genesisHash = await rpc.call("getGenesisHash");
		summary.genesisHash = genesisHash;
		assert.notEqual(genesisHash, base58Encode(utf8$3(GENESIS_HASH_ASCII)), "no synthetic genesis substitution");
		const artifactDir = join(work, "artifacts");
		await mkdir(artifactDir);
		await run("cargo-build-sbf", [
			"--manifest-path",
			"programs/basic-escrow/Cargo.toml",
			"--features",
			"browser-localnet",
			"--arch",
			"v3",
			"--sbf-out-dir",
			artifactDir,
			"--",
			"--locked"
		], {
			...process.env,
			P2P_SOLANA_BROWSER_FIXTURE: "local-validator-only",
			P2P_SOLANA_BROWSER_GENESIS_HEX: Buffer.from(decodeKey$1(genesisHash)).toString("hex"),
			P2P_SOLANA_BROWSER_PROGRAM_ID: keys.program.address
		});
		const soPath = join(artifactDir, "basic_escrow.so"), so = new Uint8Array(await readFile(soPath));
		summary.artifactSha256 = sha$1(so);
		assert.ok(so.length > 0 && so.length <= 1048576, "program fits the native reader ProgramData bound");
		await cli([
			"program",
			"deploy",
			soPath,
			"--max-len",
			String(so.length),
			"--program-id",
			join(work, "program.json"),
			"--upgrade-authority",
			join(work, "authority.json")
		]);
		await cli([
			"program",
			"set-upgrade-authority",
			keys.program.address,
			"--final",
			"--upgrade-authority",
			join(work, "authority.json")
		]);
		let programData;
		await waitSolana(async () => {
			programData = await getAccount(rpc, programDataAddress$1(keys.program.address), "finalized");
			return programData !== null && decodeProgramDataHeader(programData.data).upgradeAuthority === null;
		}, "immutable deployed program at finalized");
		assert.equal(Buffer.from(programData.data.slice(45, 45 + so.length)).equals(Buffer.from(so)), true);
		summary.programDataSha256 = programDataSha256FromElf(so, programData.data.length);
		proxy = createServer(async (request, response) => {
			const cors = {
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "content-type",
				"Access-Control-Allow-Methods": "POST, OPTIONS"
			};
			if (request.method === "OPTIONS") {
				response.writeHead(204, cors).end();
				return;
			}
			try {
				let body = "";
				for await (const chunk of request) {
					body += chunk;
					if (body.length > 16384) throw Error("request bound");
				}
				const raw = JSON.parse(body);
				if (raw.method === "sendTransaction") {
					assert.ok(beforeSend, "independent marker observer must be installed before app sends");
					const proof = await beforeSend(raw.params[0]);
					assert.deepEqual(raw.params[1], {
						encoding: "base64",
						skipPreflight: true,
						maxRetries: 0
					});
					const withheld = withhold;
					withhold = false;
					observed.push({
						...proof,
						withheld
					});
					if (withheld) {
						rejectWithheldSolanaSend(response, cors);
						return;
					}
				}
				const answer = await fetch(validatorUrl, {
					method: "POST",
					body,
					headers: { "Content-Type": "application/json" }
				});
				const result = await answer.text();
				response.writeHead(answer.status, {
					...cors,
					"Content-Type": "application/json"
				}).end(result);
			} catch (error) {
				summary.fixtureErrors.push(error.message);
				response.writeHead(500, {
					...cors,
					"Content-Type": "text/plain"
				}).end("Fixture refused.");
				console.error(error);
			}
		});
		await new Promise((resolve, reject) => {
			proxy.once("error", reject);
			proxy.listen(0, "127.0.0.1", resolve);
		});
		const rpcUrl = `http://127.0.0.1:${proxy.address().port}/`;
		const network = {
			id: "solana-localnet",
			chain: "solana",
			chainIdentity: genesisHash,
			genesisHash,
			environment: "local",
			endpoints: [{
				id: "local-rpc",
				url: rpcUrl
			}],
			finality: {
				kind: "solana-commitment",
				commitment: "finalized"
			},
			assets: [{
				id: "sol",
				kind: "native",
				address: null,
				decimals: 9,
				transferPolicy: "exact-transfer"
			}],
			deployments: [{
				id: "escrow-v1",
				address: keys.program.address,
				protocolVersion: 1,
				artifactSha256: summary.artifactSha256,
				runtime: {
					kind: "solana-program",
					programDataSha256: summary.programDataSha256,
					upgradeAuthority: null
				},
				supportedAssetIds: ["sol"]
			}]
		};
		const registryJson = JSON.stringify({
			version: 1,
			releaseId: "solana-local-browser-fixture",
			networks: [network]
		});
		const view = {
			network: (id) => id === network.id ? network : null,
			deployment: (id, deployment) => id === network.id && deployment === "escrow-v1" ? network.deployments[0] : null
		};
		for (const key of [keys.seller, keys.buyer]) await waitForSignature(rpc, await rpc.call("requestAirdrop", [key.address, 1e10]), "finalized", 12e4);
		const client = createSolanaEscrowClient({
			rpc: rpcPort,
			registry: view,
			wallet: { features: {
				"standard:connect": {
					version: "1.0.0",
					async connect() {
						return { accounts: [account(keys.seller), account(keys.buyer)] };
					}
				},
				"solana:signTransaction": {
					version: "1.0.0",
					supportedTransactionVersions: ["legacy"],
					async signTransaction(input) {
						return [{ signedTransaction: sign(input.account.address, input.transaction) }];
					}
				}
			} },
			journal: fixtureJournal(),
			clock: { now: Date.now },
			margins: {
				submitMarginSeconds: "10",
				releaseMarginSeconds: "300"
			},
			walletChain: CHAIN
		});
		const documents = {};
		for (const name of [
			"refund",
			"release",
			"rebuild",
			"absent"
		]) {
			const now = (await readClock(rpc, "finalized")).unixTimestamp;
			const terms = {
				genesisHash,
				programId: keys.program.address,
				orderId: randomBytes(32).toString("hex"),
				seller: keys.seller.address,
				buyer: keys.buyer.address,
				assetKind: "native",
				mint: null,
				tokenProgram: null,
				amountBaseUnits: "100000000",
				privateAgreementHash: sha$1(Buffer.from(`fixture agreement ${name}`)),
				capabilitiesHash: sha$1(new Uint8Array([0])),
				sellerNonce: randomBytes(32).toString("hex"),
				revision: "1",
				acceptBeforeSeconds: String(now + 600),
				escrowExpirySeconds: String(now + (name === "refund" ? 1950 : 7200))
			};
			const binding = {
				chain: "solana",
				networkId: network.id,
				deploymentId: "escrow-v1",
				tradeId: sha$1(encodeSolanaTerms(terms))
			};
			const trade = unwrap(client.bind(binding, terms));
			if (name !== "absent") {
				const session = unwrap(await client.connect(trade, "seller"));
				const submitted = unwrap(await client.fund(trade, session));
				summary.setupFunding.push({
					name,
					signature: submitted.signature,
					deadline: terms.escrowExpirySeconds
				});
				await waitSolana(async () => {
					unwrap(await client.reconcile(trade));
					return unwrap(await client.read(trade)).escrow?.state === "funded";
				}, `${name} original funding`);
			}
			documents[name] = unwrap(createRecoveryDocument(trade));
		}
		client.dispose();
		return {
			documents,
			summary,
			rpcUrl,
			rpc,
			seller: keys.seller.address,
			buyer: keys.buyer.address,
			buildOption: {
				registryJson,
				registrySha256: sha$1(Buffer.from(registryJson)),
				rpcUrl,
				margins: {
					submitMarginSeconds: "300",
					releaseMarginSeconds: "300"
				}
			},
			account: () => account(keys.seller),
			sign: (transaction) => sign(keys.seller.address, Buffer.from(transaction, "base64")),
			observeSends(fn) {
				beforeSend = fn;
			},
			withholdNextSend() {
				withhold = true;
			},
			async close() {
				process.removeListener("exit", onExit);
				await close();
			}
		};
	} catch (error) {
		process.removeListener("exit", onExit);
		await close();
		throw error;
	}
}
// packages/security/src/release-proof.ts
const checks$1 = /* @__PURE__ */ new WeakMap();
/** Internal trusted-writer capability: register once, never replace a proof lease. */
function registerReleaseProof(value, check) {
	if (checks$1.has(value)) throw new TypeError("Release proof already registered.");
	checks$1.set(value, check);
}
// packages/security/src/release-manifest.ts
/** Bounded G15 offline verifier mechanics, not a release/install authority.
* No trust root, storage write, network, signing operation or application export.
* Non-empty deployment entries remain unsupported until their exact wire schema is reconciled.
* Locator verification is separate in release-locator.ts. Rotation/bootstrap/archive
* extraction, installation and independent enabled-build review remain gates.
*/
const RELEASE_LIMITS = Object.freeze({
	manifestBytes: 1048576,
	assets: 1e4,
	bundleBytes: 268435456,
	trustedKeys: 32
});
const proofs = /* @__PURE__ */ new WeakMap();
/** Separate lexical scope: the retained bridge callback cannot capture verification buffers. */
function registerLiveResult(value) {
	registerReleaseProof(value, () => {
		try {
			checkProof(proofs.get(value));
			return Object.freeze({
				ok: true,
				value
			});
		} catch (error) {
			return Object.freeze({
				ok: false,
				error: Object.freeze({ code: refusalCode(error, "UNAVAILABLE") })
			});
		}
	});
}
const nativeUtcSeconds = () => Math.floor(Date.now() / 1e3);
function isNativeDataError(error) {
	try {
		const getter = Object.getOwnPropertyDescriptor(DOMException.prototype, "name").get;
		return Reflect.apply(getter, error, []) === "DataError";
	} catch {
		return false;
	}
}
const refusalCodes = /* @__PURE__ */ new WeakMap();
var Rejected = class extends Error {
	code;
	constructor(code) {
		super("Release verification refused.");
		this.code = code;
		refusalCodes.set(this, code);
	}
};
const fail$2 = (code = "MANIFEST_UNSUPPORTED") => {
	throw new Rejected(code);
};
function refusalCode(error, fallback) {
	return typeof error === "object" && error !== null ? refusalCodes.get(error) ?? fallback : fallback;
}
function checkLifetime(signal, current) {
	const aborted = Object.getOwnPropertyDescriptor(AbortSignal.prototype, "aborted").get;
	try {
		if (signal !== void 0 && Reflect.apply(aborted, signal, []) === true || current && current() !== true) return fail$2("CANCELLED");
		if (signal !== void 0 && Reflect.apply(aborted, signal, []) === true) return fail$2("CANCELLED");
	} catch {
		return fail$2("CANCELLED");
	}
}
function checkProof(proof) {
	if (proof.failure) return fail$2(proof.failure);
	try {
		checkLifetime(proof.signal, proof.current);
		if (proof.failure) return fail$2(proof.failure);
		let now;
		try {
			now = proof.clock();
		} catch {
			if (!proof.failure) checkLifetime(proof.signal, proof.current);
			return fail$2("UNAVAILABLE");
		}
		if (proof.failure) return fail$2(proof.failure);
		checkLifetime(proof.signal, proof.current);
		if (proof.failure) return fail$2(proof.failure);
		if (typeof now !== "number" || !Number.isSafeInteger(now) || now < 0 || now < proof.lastTime) return fail$2("UNAVAILABLE");
		proof.lastTime = now;
		if (now >= proof.manifest.expiresAt) return fail$2("MANIFEST_EXPIRED");
		if (now < proof.manifest.createdAt) return fail$2();
	} catch (error) {
		let code = refusalCode(error, "UNAVAILABLE");
		if (!proof.failure) try {
			checkLifetime(proof.signal, proof.current);
		} catch {
			code = "CANCELLED";
		}
		code = proof.failure ?? code;
		proof.failure = code;
		return fail$2(code);
	}
}
function object(value, required, optional = [], code = "MANIFEST_UNSUPPORTED") {
	if (typeof value !== "object" || value === null || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) return fail$2(code);
	const keys = Reflect.ownKeys(value);
	if (keys.length > required.length + optional.length || keys.some((key) => typeof key !== "string" || !required.includes(key) && !optional.includes(key))) return fail$2(code);
	const result = Object.create(null);
	for (const key of [...required, ...optional]) {
		const descriptor = Object.getOwnPropertyDescriptor(value, key);
		if (!descriptor) {
			if (required.includes(key)) return fail$2(code);
			continue;
		}
		if (!("value" in descriptor) || !descriptor.enumerable) return fail$2(code);
		result[key] = descriptor.value;
	}
	return result;
}
function array(value, max, code = "MANIFEST_UNSUPPORTED") {
	if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype) return fail$2(code);
	const length = Object.getOwnPropertyDescriptor(value, "length")?.value;
	if (typeof length !== "number" || !Number.isSafeInteger(length) || length < 0 || length > max || Reflect.ownKeys(value).length !== length + 1) return fail$2(code);
	return Array.from({ length }, (_, index) => {
		const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
		if (!descriptor || !("value" in descriptor) || !descriptor.enumerable) return fail$2(code);
		return descriptor.value;
	});
}
function integer(value, min = 0, max = Number.MAX_SAFE_INTEGER) {
	if (typeof value !== "number" || !Number.isSafeInteger(value) || value < min || value > max) return fail$2();
	return value;
}
function wellFormed(value) {
	for (let i = 0; i < value.length; i++) {
		const unit = value.charCodeAt(i);
		if (unit >= 55296 && unit <= 56319) {
			const next = value.charCodeAt(++i);
			if (!(next >= 56320 && next <= 57343)) return false;
		} else if (unit >= 56320 && unit <= 57343) return false;
	}
	return true;
}
function text(value, max = 128) {
	if (typeof value !== "string" || value.length < 1 || value.length > max || !wellFormed(value)) return fail$2();
	return value;
}
function hex(value) {
	if (typeof value !== "string" || !/^[0-9a-f]{64}$/.test(value)) return fail$2();
	return value;
}
function path(value) {
	const result = text(value, 240);
	if (!/^[a-zA-Z0-9._/-]+$/.test(result) || result.startsWith("/") || result.split("/").some((part) => !part || part === "." || part === "..")) return fail$2();
	return result;
}
const typed$1 = Object.getPrototypeOf(Uint8Array.prototype);
const byteLength$1 = Object.getOwnPropertyDescriptor(typed$1, "byteLength").get;
const buffer = Object.getOwnPropertyDescriptor(typed$1, "buffer").get;
function bytes(value, max, code) {
	if (typeof value !== "object" || value === null || Object.getPrototypeOf(value) !== Uint8Array.prototype) return fail$2(code);
	const length = Reflect.apply(byteLength$1, value, []);
	if (!(Reflect.apply(buffer, value, []) instanceof ArrayBuffer) || length > max) return fail$2(code);
	const copy = new Uint8Array(length);
	Reflect.apply(Uint8Array.prototype.set, copy, [value]);
	return copy;
}
/** Only parsed JSON enters this function. It never calls a caller's toJSON/getters.
* Canonical byte equality also rejects duplicate keys/escapes/numeric aliases lost by JSON.parse.
* No normalization: property sorting uses ECMAScript UTF-16 order, as RFC8785 requires.
*/
function canonical(value, depth = 0, counter = { nodes: 0 }) {
	if (depth > 8 || ++counter.nodes > 7e4) return fail$2();
	if (typeof value === "string") {
		if (!wellFormed(value)) return fail$2();
		return JSON.stringify(value);
	}
	if (value === null || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
	if (Array.isArray(value)) return "[" + value.map((item) => canonical(item, depth + 1, counter)).join(",") + "]";
	if (typeof value !== "object") return fail$2();
	return "{" + Object.keys(value).sort().map((key) => {
		if (!wellFormed(key)) return fail$2();
		return JSON.stringify(key) + ":" + canonical(value[key], depth + 1, counter);
	}).join(",") + "}";
}
function manifest(raw) {
	const source = new TextDecoder("utf-8", {
		fatal: true,
		ignoreBOM: true
	}).decode(raw);
	let depth = 0, quoted = false, escaped = false;
	for (const char of source) if (quoted) {
		if (escaped) escaped = false;
		else if (char === "\\") escaped = true;
		else if (char === "\"") quoted = false;
	} else if (char === "\"") quoted = true;
	else if (char === "[" || char === "{") {
		if (++depth > 8) return fail$2();
	} else if (char === "]" || char === "}") depth--;
	const parsed = JSON.parse(source);
	if (canonical(parsed) !== source) return fail$2();
	const m = object(parsed, [
		"format",
		"version",
		"channel",
		"sequence",
		"releaseId",
		"sourceCommit",
		"buildRecipeDigest",
		"lockfileDigest",
		"sbomDigest",
		"createdAt",
		"expiresAt",
		"minStorageSchema",
		"maxStorageSchema",
		"assets",
		"deployments",
		"predecessorDigest"
	]);
	if (m.format !== "p2p-offramp-release" || m.version !== 1) return fail$2();
	const channel = text(m.channel, 64), sequence = integer(m.sequence, 1), releaseId = text(m.releaseId);
	const sourceCommit = text(m.sourceCommit, 64);
	if (!/^(?:[0-9a-f]{40}|[0-9a-f]{64})$/.test(sourceCommit)) return fail$2();
	const createdAt = integer(m.createdAt), expiresAt = integer(m.expiresAt);
	if (expiresAt <= createdAt || expiresAt - createdAt > 2592e3) return fail$2();
	const minStorageSchema = integer(m.minStorageSchema), maxStorageSchema = integer(m.maxStorageSchema, minStorageSchema);
	const seen = /* @__PURE__ */ new Set();
	let total = 0, previous = "";
	const assets = array(m.assets, RELEASE_LIMITS.assets).map((item) => {
		const asset = object(item, [
			"path",
			"bytes",
			"sha256"
		]), name = path(asset.path), length = integer(asset.bytes, 0, RELEASE_LIMITS.bundleBytes);
		if (name <= previous || seen.has(name.toLowerCase()) || (total += length) > RELEASE_LIMITS.bundleBytes) return fail$2();
		seen.add(name.toLowerCase());
		previous = name;
		return Object.freeze({
			path: name,
			bytes: length,
			sha256: hex(asset.sha256)
		});
	});
	if (array(m.deployments, RELEASE_LIMITS.assets).length) return fail$2();
	return Object.freeze({
		format: "p2p-offramp-release",
		version: 1,
		channel,
		sequence,
		releaseId,
		sourceCommit,
		buildRecipeDigest: hex(m.buildRecipeDigest),
		lockfileDigest: hex(m.lockfileDigest),
		sbomDigest: hex(m.sbomDigest),
		createdAt,
		expiresAt,
		minStorageSchema,
		maxStorageSchema,
		assets: Object.freeze(assets),
		deployments: Object.freeze([]),
		predecessorDigest: m.predecessorDigest === null ? null : hex(m.predecessorDigest)
	});
}
function publicKeys(input) {
	try {
		return array(input, RELEASE_LIMITS.trustedKeys, "KEY_UNTRUSTED").map((value) => {
			const key = object(value, [
				"kty",
				"crv",
				"x",
				"y",
				"key_ops",
				"ext"
			], [], "KEY_UNTRUSTED");
			const ops = array(key.key_ops, 1, "KEY_UNTRUSTED");
			if (key.kty !== "EC" || key.crv !== "P-256" || key.ext !== true || ops.length !== 1 || ops[0] !== "verify") return fail$2("KEY_UNTRUSTED");
			decodeBase64url(key.x, 32, 32);
			decodeBase64url(key.y, 32, 32);
			return {
				kty: "EC",
				crv: "P-256",
				x: key.x,
				y: key.y,
				key_ops: ["verify"],
				ext: true
			};
		});
	} catch {
		return fail$2("KEY_UNTRUSTED");
	}
}
function assetSnapshot(input) {
	try {
		const records = array(input, RELEASE_LIMITS.assets, "ASSET_MISMATCH");
		const result = /* @__PURE__ */ new Map(), folded = /* @__PURE__ */ new Set();
		let remaining = RELEASE_LIMITS.bundleBytes;
		for (const item of records) {
			const asset = object(item, ["path", "bytes"], [], "ASSET_MISMATCH"), name = path(asset.path);
			if (folded.has(name.toLowerCase())) return fail$2("ASSET_MISMATCH");
			const content = bytes(asset.bytes, remaining, "ASSET_MISMATCH");
			remaining -= content.length;
			result.set(name, content);
			folded.add(name.toLowerCase());
		}
		return result;
	} catch {
		return fail$2("ASSET_MISMATCH");
	}
}
const P256_ORDER = 115792089210356248762697446949407573529996955224135760342422259061068512044369n;
function signature(input) {
	try {
		const value = decodeBase64url(input, 64, 64);
		for (const start of [0, 32]) {
			let scalar = 0n;
			for (let i = start; i < start + 32; i++) scalar = scalar * 256n + BigInt(value[i]);
			if (scalar === 0n || scalar >= P256_ORDER) return fail$2("SIGNATURE_INVALID");
		}
		return new Uint8Array(value);
	} catch {
		return fail$2("SIGNATURE_INVALID");
	}
}
const encoder$1 = new TextEncoder();
const domain$1 = encoder$1.encode("p2p-offramp/release/v1\n");
/** Caller supplies the independently trusted key set, expected channel and retained sequence/digest.
* This function verifies only the supported offline manifest/asset profile. It never promotes/installs,
* persists rollback state, treats an adjacent key as trusted, or authenticates the initial JS host.
*/
async function verifyRelease(input, detached, trustedKeys, highestSequence, options) {
	let lifetime = () => void 0;
	try {
		const opts = object(options, ["channel", "assets"], [
			"nowSeconds",
			"signal",
			"isCurrent",
			"installedManifestSha256"
		]);
		const expectedChannel = text(opts.channel, 64), highest = integer(highestSequence);
		if (opts.nowSeconds !== void 0 && typeof opts.nowSeconds !== "function" || opts.isCurrent !== void 0 && typeof opts.isCurrent !== "function") return fail$2();
		const signal = opts.signal, current = opts.isCurrent;
		lifetime = () => checkLifetime(signal, current);
		lifetime();
		const raw = bytes(input, RELEASE_LIMITS.manifestBytes, "MANIFEST_UNSUPPORTED"), env = object(detached, [
			"v",
			"keyId",
			"alg",
			"manifestSha256",
			"signature"
		]);
		if (env.v !== 1 || env.alg !== "ES256-P1363") return fail$2();
		const keyId = hex(env.keyId), expectedDigest = hex(env.manifestSha256), sig = signature(env.signature);
		const keys = publicKeys(trustedKeys), actualAssets = assetSnapshot(opts.assets), m = manifest(raw);
		const installedDigest = opts.installedManifestSha256 === void 0 ? void 0 : hex(opts.installedManifestSha256);
		const clock = opts.nowSeconds ?? nativeUtcSeconds;
		let lastTime = -1;
		const guard = () => {
			lifetime();
			let now;
			try {
				now = clock();
			} catch {
				lifetime();
				return fail$2("UNAVAILABLE");
			}
			lifetime();
			if (typeof now !== "number" || !Number.isSafeInteger(now) || now < 0 || now < lastTime) return fail$2("UNAVAILABLE");
			lastTime = now;
			if (now >= m.expiresAt) return fail$2("MANIFEST_EXPIRED");
			if (now < m.createdAt || m.channel !== expectedChannel) return fail$2();
		};
		guard();
		const subtle = globalThis.crypto?.subtle;
		if (!subtle) return fail$2("UNAVAILABLE");
		const hash = async (value) => {
			let digest;
			try {
				digest = await subtle.digest("SHA-256", value);
			} catch {
				lifetime();
				return fail$2("UNAVAILABLE");
			}
			guard();
			if (!(digest instanceof ArrayBuffer) || digest.byteLength !== 32) return fail$2("UNAVAILABLE");
			return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
		};
		const digest = await hash(raw);
		if (digest !== expectedDigest) return fail$2("SIGNATURE_INVALID");
		if (m.sequence < highest || m.sequence === highest && digest !== installedDigest) return fail$2("RELEASE_ROLLBACK");
		let selected;
		for (const key of keys) if (await hash(encoder$1.encode(JSON.stringify({
			crv: key.crv,
			kty: key.kty,
			x: key.x,
			y: key.y
		}))) === keyId) {
			selected = key;
			break;
		}
		if (!selected) return fail$2("KEY_UNTRUSTED");
		let key;
		try {
			key = await subtle.importKey("jwk", selected, {
				name: "ECDSA",
				namedCurve: "P-256"
			}, false, ["verify"]);
		} catch (error) {
			lifetime();
			return fail$2(isNativeDataError(error) ? "KEY_UNTRUSTED" : "UNAVAILABLE");
		}
		guard();
		const payload = new Uint8Array(domain$1.length + raw.length);
		payload.set(domain$1);
		payload.set(raw, domain$1.length);
		let valid;
		try {
			valid = await subtle.verify({
				name: "ECDSA",
				hash: "SHA-256"
			}, key, sig, payload);
		} catch {
			lifetime();
			return fail$2("UNAVAILABLE");
		}
		guard();
		if (!valid) return fail$2("SIGNATURE_INVALID");
		if (actualAssets.size !== m.assets.length) return fail$2("ASSET_MISMATCH");
		for (const asset of m.assets) {
			const content = actualAssets.get(asset.path);
			if (!content || content.length !== asset.bytes || await hash(content) !== asset.sha256) return fail$2("ASSET_MISMATCH");
		}
		guard();
		const value = Object.freeze({
			manifest: m,
			manifestSha256: digest,
			keyId,
			assetsVerified: true,
			deploymentsVerified: false,
			releaseEnabled: false
		});
		proofs.set(value, {
			manifest: m,
			manifestSha256: digest,
			signal,
			current,
			clock,
			lastTime,
			failure: void 0
		});
		registerLiveResult(value);
		return Object.freeze({
			ok: true,
			value
		});
	} catch (error) {
		let code = refusalCode(error, "MANIFEST_UNSUPPORTED");
		try {
			lifetime();
		} catch {
			code = "CANCELLED";
		}
		return Object.freeze({
			ok: false,
			error: Object.freeze({ code })
		});
	}
}
/** Wrap in a separate scope: retain parsed public registry data and the small lease, never raw assets. */
function guardedRegistry(service, proof, registryPath) {
	return Object.freeze({
		releaseId: proof.manifest.releaseId,
		manifestSha256: proof.manifestSha256,
		registryPath,
		liveValidated: false,
		releaseEnabled: false,
		network(id) {
			try {
				checkProof(proof);
				const value = service.network(id);
				checkProof(proof);
				return value;
			} catch {
				return null;
			}
		},
		deployment(networkId, deploymentId) {
			try {
				checkProof(proof);
				const value = service.deployment(networkId, deploymentId);
				checkProof(proof);
				return value;
			} catch {
				return null;
			}
		}
	});
}
/** G15→G11 offline composition. registryPath is the composition root's expected artifact location,
* not an automatically selected/scanned JSON file. Only the exact in-memory verifier value is accepted;
* serialized/cloned projections have no authority. Callers must recheck current lookups before use and
* invalidate their proof context when trust/channel/update authority changes. No live-chain grant exists.
*/
async function createReleaseRegistry(verified, registryPath, input) {
	let proof;
	try {
		if (typeof verified !== "object" || verified === null || !(proof = proofs.get(verified))) return fail$2();
		checkProof(proof);
		let name;
		try {
			name = path(registryPath);
		} catch {
			return fail$2("ASSET_MISMATCH");
		}
		const expected = proof.manifest.assets.find((asset) => asset.path === name);
		if (!expected) return fail$2("ASSET_MISMATCH");
		const raw = bytes(input, MAX_REGISTRY_BYTES, "ASSET_MISMATCH");
		if (raw.length !== expected.bytes) return fail$2("ASSET_MISMATCH");
		const service = new RegistryService(), loaded = await service.load(raw, expected.sha256);
		checkProof(proof);
		if (!loaded.ok) return fail$2(loaded.error.code === "INTEGRITY_FAILURE" ? "ASSET_MISMATCH" : loaded.error.code === "UNAVAILABLE" ? "UNAVAILABLE" : "MANIFEST_UNSUPPORTED");
		if (loaded.value.releaseId !== proof.manifest.releaseId) return fail$2();
		return Object.freeze({
			ok: true,
			value: guardedRegistry(service, proof, name)
		});
	} catch (error) {
		let code = refusalCode(error, "UNAVAILABLE");
		if (proof) try {
			checkProof(proof);
		} catch (guardError) {
			code = refusalCode(guardError, "UNAVAILABLE");
		}
		return Object.freeze({
			ok: false,
			error: Object.freeze({ code })
		});
	}
}
Object.freeze({
	locatorBytes: 4096,
	cidCharacters: 128,
	trustedKeys: 32,
	archiveBytes: 268435456
});
new TextEncoder().encode("p2p-offramp/release-locator/v1\n");
const typed = Object.getPrototypeOf(Uint8Array.prototype);
Object.getOwnPropertyDescriptor(typed, "byteLength").get;
Object.getOwnPropertyDescriptor(typed, "buffer").get;
Object.freeze({
	records: 128,
	requirements: 128,
	targets: 32,
	testCases: 256,
	digests: 256,
	textUnits: 2097152,
	nodes: 6e4,
	findings: 4096
});
Object.getOwnPropertyDescriptor(AbortSignal.prototype, "aborted").get;
EventTarget.prototype.addEventListener;
EventTarget.prototype.removeEventListener;
// apps/web/src/testnet/sepolia-network.ts
const SEPOLIA_NETWORK = Object.freeze({
	id: "sepolia",
	chain: "evm",
	chainIdentity: "11155111",
	genesisHash: "0x25a5cc106eea7138acab33231d7160d69cb777ee0c2c553fcddf5138993e6dd9",
	environment: "testnet"
});
/** G15 channel of the Sepolia testnet release. */
const SEPOLIA_RELEASE_CHANNEL = "sepolia-testnet";
/**
* The exact asset set of the Sepolia testnet G15 release (D3 Option A, PROPOSED and pending owner approval): one signed
* manifest covers the registry and the canonical escrow ABI, and every verifier (owner signing, sepolia:verify, the trade
* tool, the testnet build, the app runtime and the maintained recovery builder) supplies exactly these two assets. A
* registry-only manifest therefore fails every verifier with ASSET_MISMATCH. Paths are relative to the checkout root.
*/
const SEPOLIA_RELEASE_ASSETS = Object.freeze({
	abi: "contracts/evm/abi/BasicEscrow.json",
	registry: "registry/testnet/sepolia.registry.json"
});
/** True only for a well-formed keyId equal to an independently configured nonnull pin. */
function isPinnedReleaseKey(keyId, pinned = null) {
	return typeof pinned === "string" && /^[0-9a-f]{64}$/.test(pinned) && keyId === pinned;
}
/** `genesisHash` is overridable only by local proofs on a node started with Sepolia's chain id. */
function isSepolia(network, genesisHash = SEPOLIA_NETWORK.genesisHash) {
	return network !== null && network !== void 0 && network.id === SEPOLIA_NETWORK.id && network.chain === SEPOLIA_NETWORK.chain && network.chainIdentity === SEPOLIA_NETWORK.chainIdentity && network.genesisHash === genesisHash && network.environment === SEPOLIA_NETWORK.environment;
}
/** True only for a registry whose single network is exactly Sepolia. */
function isSepoliaOnly(registry, genesisHash) {
	return registry.networks.length === 1 && isSepolia(registry.networks[0], genesisHash);
}
// apps/web/scripts/testnet-trust.mjs
/**
* Build-time loader for the Sepolia testnet trust bundle (testnet build only). Reads the owner's public testnet key,
* the registry, the canonical escrow ABI and their signed G15 manifest from the repository, verifies them with the app's
* own verifier before the build starts, and returns the bundle the build embeds. Missing or invalid inputs stop the build
* (fail closed). `verifyTestnetTrust` is the single verifier shared with scripts/sepolia (sepolia:verify and the trade
* tool): the signature, the independently pinned keyId (an unset pin refuses verification), the exact two-asset set
* (registry and ABI, D3 Option A), the canonical ABI and the Sepolia-only network rule are checked the same way everywhere.
*/
/**
* Embedded bundle format. PROPOSAL pending owner approval (D3 leaves the name to the owner): v2 adds the signed ABI bytes
* so that one two-asset manifest verifies at build time and at runtime. Registry-only v1 bundles are refused; none was
* ever committed or shipped. Must equal TESTNET_TRUST_FORMAT in apps/web/src/testnet/sepolia-source.ts.
*/
const TESTNET_TRUST_FORMAT = "p2p-offramp/testnet-trust/v2";
const TESTNET_TRUST_FILES = Object.freeze({
	key: "security/testnet-trust/sepolia-release-key.pub.json",
	registry: SEPOLIA_RELEASE_ASSETS.registry,
	abi: SEPOLIA_RELEASE_ASSETS.abi,
	manifest: "registry/testnet/sepolia.release.json",
	envelope: "registry/testnet/sepolia.release.sig.json"
});
/** Optional record of the last accepted release ({sequence, manifestSha256}); written by `sepolia:verify -- --accept`. */
const TESTNET_ACCEPTED_FILE = "registry/testnet/sepolia.accepted.json";
/** The ABI committed in this checkout. The maintained recovery builder packages only this ABI, so a release must sign it. */
const CANONICAL_ABI = new URL("../../../contracts/evm/abi/BasicEscrow.json", import.meta.url);
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
/** The recorded accepted release, null when none was recorded yet; throws on a malformed record. */
async function acceptedRelease(root) {
	let text;
	try {
		text = await readFile(resolve(root, TESTNET_ACCEPTED_FILE), "utf8");
	} catch (error) {
		if (error?.code === "ENOENT") return null;
		throw error;
	}
	const value = JSON.parse(text);
	if (typeof value !== "object" || value === null || Object.keys(value).sort().join() !== "manifestSha256,sequence" || !Number.isSafeInteger(value.sequence) || value.sequence < 1 || !/^[0-9a-f]{64}$/.test(value.manifestSha256)) throw new Error("ACCEPTED_INVALID");
	return value;
}
/**
* Verifies the trust files under `root`: G15 signature by the independently pinned key, its keyId, the exact asset set
* {registry, ABI}, the canonical ABI, then the Sepolia-only rule. When a release was accepted before (TESTNET_ACCEPTED_FILE),
* a lower sequence, or another manifest at the accepted sequence, is RELEASE_ROLLBACK (G25 §4.3). Never throws for bad
* input; failure codes are KEY_UNPINNED, MISSING, JSON, ACCEPTED_INVALID, KEY_ID, NETWORK or a G15 code (a registry-only
* manifest, a manifest naming an unsupplied asset, edited bytes or a non-canonical ABI are ASSET_MISMATCH).
* `genesisHash` is overridable only by local proofs on a node started with Sepolia's chain id.
*/
async function verifyTestnetTrust(root, { nowSeconds = () => Math.floor(Date.now() / 1e3), highestSequence = 0, genesisHash, pinnedKeyId = null } = {}) {
	const failed = (code) => ({
		ok: false,
		error: { code }
	});
	if (pinnedKeyId === null) return failed("KEY_UNPINNED");
	if (!isPinnedReleaseKey(pinnedKeyId, pinnedKeyId)) return failed("KEY_ID");
	let key, registry, abi, manifest, envelope;
	try {
		[key, registry, abi, manifest, envelope] = await Promise.all([
			TESTNET_TRUST_FILES.key,
			TESTNET_TRUST_FILES.registry,
			TESTNET_TRUST_FILES.abi,
			TESTNET_TRUST_FILES.manifest,
			TESTNET_TRUST_FILES.envelope
		].map((path) => readFile(resolve(root, path))));
	} catch {
		return failed("MISSING");
	}
	let trusted, signature, accepted;
	try {
		trusted = JSON.parse(key.toString("utf8"));
		signature = JSON.parse(envelope.toString("utf8"));
	} catch {
		return failed("JSON");
	}
	try {
		accepted = await acceptedRelease(root);
	} catch {
		return failed("ACCEPTED_INVALID");
	}
	const highest = Math.max(highestSequence, accepted?.sequence ?? 0);
	const verified = await verifyRelease(new Uint8Array(manifest), signature, [trusted?.publicKey], highest, {
		channel: SEPOLIA_RELEASE_CHANNEL,
		assets: [{
			path: TESTNET_TRUST_FILES.registry,
			bytes: new Uint8Array(registry)
		}, {
			path: TESTNET_TRUST_FILES.abi,
			bytes: new Uint8Array(abi)
		}],
		nowSeconds,
		...accepted && accepted.sequence === highest ? { installedManifestSha256: accepted.manifestSha256 } : {}
	});
	if (!verified.ok) return failed(verified.error.code);
	if (typeof trusted.keyId !== "string" || !/^[0-9a-f]{64}$/.test(trusted.keyId) || verified.value.keyId !== trusted.keyId) return failed("KEY_ID");
	if (!isPinnedReleaseKey(verified.value.keyId, pinnedKeyId)) return failed("KEY_ID");
	if (!abi.equals(await readFile(CANONICAL_ABI))) return failed("ASSET_MISMATCH");
	const bound = await createReleaseRegistry(verified.value, TESTNET_TRUST_FILES.registry, new Uint8Array(registry));
	if (!bound.ok) return failed(bound.error.code);
	let parsed;
	try {
		parsed = parseRegistryBytes(new Uint8Array(registry));
	} catch {
		return failed("NETWORK");
	}
	if (!isSepoliaOnly(parsed, genesisHash)) return failed("NETWORK");
	return {
		ok: true,
		value: {
			keyPinned: pinnedKeyId !== null,
			trusted,
			signature,
			registryBytes: registry,
			abiBytes: abi,
			manifestBytes: manifest,
			verified: verified.value,
			registry: bound.value
		}
	};
}
async function loadTestnetTrust(root, { nowSeconds = () => Math.floor(Date.now() / 1e3), pinnedKeyId = null } = {}) {
	const checked = await verifyTestnetTrust(root, {
		nowSeconds,
		pinnedKeyId
	});
	if (!checked.ok) throw new Error(checked.error.code === "MISSING" ? "TESTNET_TRUST_MISSING" : `TESTNET_TRUST_INVALID: ${checked.error.code}`);
	const { keyPinned, trusted, signature, registryBytes: registry, abiBytes: abi, manifestBytes: manifest, verified: { manifest: signed, manifestSha256 } } = checked.value;
	return {
		bundle: {
			format: TESTNET_TRUST_FORMAT,
			keyId: trusted.keyId,
			publicKey: trusted.publicKey,
			registry: registry.toString("base64url"),
			abi: abi.toString("base64url"),
			manifest: manifest.toString("base64url"),
			envelope: signature
		},
		summary: {
			keyId: trusted.keyId,
			keyPinned,
			sequence: signed.sequence,
			expiresAt: signed.expiresAt,
			registrySha256: sha(registry),
			abiSha256: sha(abi),
			manifestSha256
		}
	};
}
// scripts/lib/is-main.mjs
/** Node-only entry detection shared by importable tools. No wallet, network or application imports. */
/** Eval/print modes can put an imported module in argv[1]; that does not make it the entrypoint.
* Ordinary script invocation can retain a symlink in argv while Node canonicalizes its module URL.
*/
function isMain(moduleUrl) {
	if (process.execArgv.some((arg) => /^(?:-(?:e|p|pe)$|--(?:eval|print)(?:=|$))/.test(arg))) return false;
	if (!process.argv[1]) return false;
	try {
		const source = new URL(moduleUrl);
		if (source.search || source.hash) return false;
		return realpathSync(process.argv[1]) === realpathSync(fileURLToPath(source));
	} catch {
		return false;
	}
}
// apps/web/src/localnet/config.ts
/**
* Localnet build profile configuration (A3). Library-only: apps/web/scripts/build.mjs accepts it solely as an explicit
* `buildWeb({ delivery: 'localnet', localnet })` option from a test harness; no CLI argument or environment variable
* reaches it. The same strict validator runs at build time (Node) and again at runtime on the embedded frozen JSON
* (`__P2P_LOCALNET_CONFIG__`), so a hand-edited artifact fails closed instead of widening anything.
*
* What it admits: exactly one EVM network with chain id 31337 labelled `local`, whose RPC endpoints are loopback HTTP;
* the exact registry bytes bound to an independently supplied SHA-256; a trusted escrow layout policy whose keys are
* exactly the registry deployments' runtime Keccak values (computed by the caller from the forge artifact's
* deployedBytecode, never from eth_getCode on the same RPC) and whose values are `canonical-get-trade-v1`; and one
* plain-WebSocket loopback relay URL. `ReleaseEnabled` is the literal 0 and is checked, not defaulted.
* Nothing here grants a network permission, signs, sends, or contacts a chain or relay.
*/
const LOCALNET_CONFIG_FORMAT = "p2p-offramp/localnet-config/v1";
/** Visible test-funds marker; the localnet artifact scan requires it and every other artifact scan refuses it. */
const LOCALNET_BANNER = "Local test network — test funds only";
var LocalnetConfigError = class extends Error {
	code;
	constructor(code) {
		super(code);
		this.name = "LocalnetConfigError";
		this.code = code;
	}
};
const fail$1 = (code = "LOCALNET_CONFIG_INVALID") => {
	throw new LocalnetConfigError(code);
};
/** Own data properties of a plain object; inherited, accessor, symbol and unexpected keys fail closed. */
function fields$1(input, allowed, code = "LOCALNET_CONFIG_INVALID") {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail$1(code);
		const prototype = Object.getPrototypeOf(input);
		if (prototype !== Object.prototype && prototype !== null) return fail$1(code);
		const copy = Object.create(null);
		for (const key of Reflect.ownKeys(input)) {
			if (typeof key !== "string" || !allowed.includes(key)) return fail$1(code);
			const descriptor = Object.getOwnPropertyDescriptor(input, key);
			if (!descriptor || !("value" in descriptor)) return fail$1(code);
			copy[key] = descriptor.value;
		}
		return copy;
	} catch (error) {
		if (error instanceof LocalnetConfigError) throw error;
		return fail$1(code);
	}
}
/**
* `ws://127.0.0.1:PORT/` or `ws://[::1]:PORT/`: explicit non-default port, root path, no credentials, query or fragment,
* already in canonical URL form. `localhost` is refused (it is a name, resolvable elsewhere). Chromium 153's CSP parser
* ignores an IPv6-literal source (`ws://[::1]:PORT`), which leaves connect-src empty: such a build fails closed (the relay
* is blocked), so harnesses should use 127.0.0.1.
*/
function parseLocalnetRelayUrl(input) {
	if (typeof input !== "string" || input.length > 64 || input.includes("?") || input.includes("#") || input.includes("@")) return fail$1("LOCALNET_RELAY_URL");
	let url;
	try {
		url = new URL(input);
	} catch {
		return fail$1("LOCALNET_RELAY_URL");
	}
	if (url.href !== input || url.protocol !== "ws:" || url.hostname !== "127.0.0.1" && url.hostname !== "[::1]" || url.username || url.password || url.search || url.hash || url.pathname !== "/" || !/^[1-9][0-9]{0,4}$/.test(url.port) || Number(url.port) > 65535) return fail$1("LOCALNET_RELAY_URL");
	return Object.freeze({
		url: input,
		origin: `ws://${url.hostname}:${url.port}`
	});
}
function layoutPolicy(input) {
	let keys;
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return fail$1("LOCALNET_ESCROW_LAYOUTS");
		keys = Reflect.ownKeys(input).map((key) => typeof key === "string" ? key : fail$1("LOCALNET_ESCROW_LAYOUTS"));
	} catch (error) {
		if (error instanceof LocalnetConfigError) throw error;
		return fail$1("LOCALNET_ESCROW_LAYOUTS");
	}
	if (keys.length === 0 || keys.length > 16 || keys.some((key) => !/^[0-9a-f]{64}$/.test(key))) return fail$1("LOCALNET_ESCROW_LAYOUTS");
	const raw = fields$1(input, keys, "LOCALNET_ESCROW_LAYOUTS");
	const policy = {};
	for (const key of keys.sort()) {
		if (raw[key] !== "canonical-get-trade-v1") return fail$1("LOCALNET_ESCROW_LAYOUTS");
		policy[key] = "canonical-get-trade-v1";
	}
	return Object.freeze(policy);
}
function digest$2(input) {
	if (typeof input !== "string" || !/^[0-9a-f]{64}$/.test(input)) return fail$1("LOCALNET_REGISTRY");
	return input;
}
/** Build time: turns the library-only option into the exact embedded document (shape checks; network checks are async). */
function localnetConfigDocument(option) {
	const raw = fields$1(option, [
		"registryBytes",
		"registryJson",
		"registrySha256",
		"escrowLayouts",
		"relayUrl"
	]);
	const hasBytes = raw.registryBytes !== void 0;
	if (hasBytes === (raw.registryJson !== void 0)) return fail$1();
	let bytes;
	if (hasBytes) {
		if (!(raw.registryBytes instanceof Uint8Array)) return fail$1();
		bytes = Uint8Array.from(raw.registryBytes);
	} else {
		if (typeof raw.registryJson !== "string") return fail$1();
		bytes = new TextEncoder().encode(raw.registryJson);
	}
	if (bytes.length === 0 || bytes.length > 1048576) return fail$1("LOCALNET_REGISTRY");
	return Object.freeze({
		format: LOCALNET_CONFIG_FORMAT,
		ReleaseEnabled: 0,
		registry: encodeBase64url(bytes),
		registrySha256: digest$2(raw.registrySha256),
		escrowLayouts: layoutPolicy(raw.escrowLayouts),
		relayUrl: parseLocalnetRelayUrl(raw.relayUrl).url
	});
}
const loopbackRpc = (value) => {
	try {
		const url = new URL(value);
		return url.protocol === "http:" && (url.hostname === "127.0.0.1" || url.hostname === "[::1]");
	} catch {
		return false;
	}
};
/** Build time and runtime: the full strict check of an embedded document. Throws LocalnetConfigError (fail closed). */
async function parseLocalnetConfig(input) {
	const raw = fields$1(input, [
		"format",
		"ReleaseEnabled",
		"registry",
		"registrySha256",
		"escrowLayouts",
		"relayUrl"
	]);
	if (raw.format !== "p2p-offramp/localnet-config/v1" || raw.ReleaseEnabled !== 0 || Object.keys(raw).length !== 6) return fail$1();
	const registrySha256 = digest$2(raw.registrySha256);
	const layouts = layoutPolicy(raw.escrowLayouts);
	const relay = parseLocalnetRelayUrl(raw.relayUrl);
	let registryBytes;
	try {
		registryBytes = decodeBase64url(raw.registry, 1, MAX_REGISTRY_BYTES);
	} catch {
		return fail$1("LOCALNET_REGISTRY");
	}
	const registry = new RegistryService();
	const loaded = await registry.load(registryBytes, registrySha256);
	if (!loaded.ok) return fail$1("LOCALNET_REGISTRY");
	const networks = loaded.value.networks;
	const network = networks[0];
	if (networks.length !== 1 || !network || network.chain !== "evm" || network.chainIdentity !== "31337" || network.environment !== "local" || network.endpoints.some((endpoint) => !loopbackRpc(endpoint.url)) || network.deployments.length === 0) return fail$1("LOCALNET_NETWORK");
	const runtimes = new Set(network.deployments.map((deployment) => deployment.runtime.kind === "evm-code" ? deployment.runtime.keccak256 : fail$1("LOCALNET_NETWORK")));
	const keys = Object.keys(layouts);
	if (keys.length !== runtimes.size || keys.some((key) => !runtimes.has(key))) return fail$1("LOCALNET_ESCROW_LAYOUTS");
	const document = Object.freeze({
		format: LOCALNET_CONFIG_FORMAT,
		ReleaseEnabled: 0,
		registry: raw.registry,
		registrySha256,
		escrowLayouts: layouts,
		relayUrl: relay.url
	});
	return Object.freeze({
		document,
		ReleaseEnabled: 0,
		registryBytes,
		registrySha256,
		registry,
		registryValue: loaded.value,
		network,
		escrowLayouts: layouts,
		relayUrl: relay.url,
		relayOrigin: relay.origin
	});
}
// apps/web/src/solana-localnet/config.ts
/** Library-only, local validator recovery profile. Explicit registry digest, original program and actual genesis. */
const SOLANA_LOCALNET_FORMAT = "p2p-offramp/solana-localnet-config/v1";
const SOLANA_LOCALNET_BANNER = "Solana local recovery — test funds only";
const failConfig = () => {
	throw Error("SOLANA_LOCALNET_CONFIG_INVALID");
};
function dataFields(input, keys) {
	try {
		if (typeof input !== "object" || input === null || Array.isArray(input)) return failConfig();
		const proto = Object.getPrototypeOf(input);
		if (proto !== null && proto !== Object.prototype) return failConfig();
		const copy = Object.create(null);
		for (const key of Reflect.ownKeys(input)) {
			if (typeof key !== "string" || !keys.includes(key)) return failConfig();
			const field = Object.getOwnPropertyDescriptor(input, key);
			if (!field || !("value" in field)) return failConfig();
			copy[key] = field.value;
		}
		return copy;
	} catch {
		return failConfig();
	}
}
function parseSolanaRpcUrl(input) {
	if (typeof input !== "string" || !/^http:\/\/127\.0\.0\.1:[1-9][0-9]{0,4}\/$/.test(input)) return failConfig();
	const url = new URL(input);
	if (url.href !== input || !url.port || Number(url.port) > 65535) return failConfig();
	return Object.freeze({
		url: input,
		origin: url.origin
	});
}
function margins(input) {
	const raw = dataFields(input, ["submitMarginSeconds", "releaseMarginSeconds"]);
	const parse = (key, max) => {
		const value = raw[key];
		if (typeof value !== "string" || !/^(0|[1-9][0-9]{0,5})$/.test(value) || BigInt(value) > max) return failConfig();
		return value;
	};
	return Object.freeze({
		submitMarginSeconds: parse("submitMarginSeconds", 3600n),
		releaseMarginSeconds: parse("releaseMarginSeconds", 604800n)
	});
}
function digest$1(input) {
	return typeof input === "string" && /^[0-9a-f]{64}$/.test(input) ? input : failConfig();
}
function solanaLocalnetConfigDocument(input) {
	const raw = dataFields(input, [
		"registryJson",
		"registryBytes",
		"registrySha256",
		"rpcUrl",
		"margins"
	]);
	if (raw.registryJson !== void 0 === (raw.registryBytes !== void 0)) return failConfig();
	let bytes;
	if (raw.registryJson !== void 0) {
		if (typeof raw.registryJson !== "string") return failConfig();
		bytes = new TextEncoder().encode(raw.registryJson);
	} else {
		if (!(raw.registryBytes instanceof Uint8Array)) return failConfig();
		bytes = Uint8Array.from(raw.registryBytes);
	}
	if (!bytes.byteLength || bytes.byteLength > 1048576) return failConfig();
	return Object.freeze({
		format: SOLANA_LOCALNET_FORMAT,
		ReleaseEnabled: 0,
		registry: encodeBase64url(bytes),
		registrySha256: digest$1(raw.registrySha256),
		rpcUrl: parseSolanaRpcUrl(raw.rpcUrl).url,
		margins: margins(raw.margins)
	});
}
async function parseSolanaLocalnetConfig(input) {
	const raw = dataFields(input, [
		"format",
		"ReleaseEnabled",
		"registry",
		"registrySha256",
		"rpcUrl",
		"margins"
	]);
	if (Object.keys(raw).length !== 6 || raw.format !== "p2p-offramp/solana-localnet-config/v1" || raw.ReleaseEnabled !== 0) return failConfig();
	const registrySha256 = digest$1(raw.registrySha256), rpc = parseSolanaRpcUrl(raw.rpcUrl), limits = margins(raw.margins);
	let bytes;
	try {
		bytes = decodeBase64url(raw.registry, 1, MAX_REGISTRY_BYTES);
	} catch {
		return failConfig();
	}
	const registry = new RegistryService(), loaded = await registry.load(bytes, registrySha256);
	if (!loaded.ok) return failConfig();
	const network = loaded.value.networks[0];
	if (loaded.value.networks.length !== 1 || !network || network.chain !== "solana" || network.environment !== "local" || network.endpoints.length !== 1 || network.endpoints[0]?.url !== rpc.url || network.assets.length !== 1 || network.assets[0]?.kind !== "native" || network.assets[0].decimals !== 9 || network.deployments.length !== 1 || network.finality.kind !== "solana-commitment" || network.finality.commitment !== "finalized") return failConfig();
	const deployment = network.deployments[0];
	if (deployment.runtime.kind !== "solana-program" || deployment.runtime.upgradeAuthority !== null || deployment.supportedAssetIds.length !== 1 || deployment.supportedAssetIds[0] !== network.assets[0].id) return failConfig();
	const document = Object.freeze({
		format: SOLANA_LOCALNET_FORMAT,
		ReleaseEnabled: 0,
		registry: raw.registry,
		registrySha256,
		rpcUrl: rpc.url,
		margins: limits
	});
	return Object.freeze({
		document,
		ReleaseEnabled: 0,
		registry,
		network,
		registrySha256,
		rpcUrl: rpc.url,
		rpcOrigin: rpc.origin,
		margins: limits
	});
}
// apps/web/scripts/build.mjs
/** Local development artifact, never a signed release or deployment attestation. */
const root = fileURLToPath(new URL("../", import.meta.url));
/** Vite's document license report excludes dependencies bundled only in a native Worker. */
async function completeWorkerLicenses(directory) {
	const graph = JSON.parse(await readFile(resolve(directory, "core-graph-worker.json"), "utf8"));
	const inventoryPath = resolve(directory, "third-party-licenses.json");
	const inventory = JSON.parse(await readFile(inventoryPath, "utf8"));
	if (!Array.isArray(graph.modules) || !Array.isArray(inventory)) throw new Error("LICENSE_ATTRIBUTION_MISSING");
	const names = /* @__PURE__ */ new Set();
	for (const module of graph.modules) {
		if (typeof module.path !== "string" || !module.path.startsWith("node_modules/")) continue;
		const match = /^node_modules\/(@noble\/(?:curves|hashes|ciphers)|react|react-dom|scheduler)\//.exec(module.path);
		if (!match) throw new Error("UNREVIEWED_DEPENDENCY");
		names.add(match[1]);
	}
	for (const name of [...names].sort()) {
		const packageRoot = resolve(root, "../../node_modules", name);
		const manifest = JSON.parse(await readFile(resolve(packageRoot, "package.json"), "utf8"));
		const license = await readFile(resolve(packageRoot, "LICENSE"), "utf8");
		if (manifest.name !== name || typeof manifest.version !== "string" || manifest.license !== "MIT" || !license.includes("Permission is hereby granted")) throw new Error("LICENSE_ATTRIBUTION_MISSING");
		const existing = inventory.find((item) => item.name === name && item.version === manifest.version);
		if (existing) {
			if (existing.identifier !== "MIT" || !existing.text?.includes("Permission is hereby granted")) throw new Error("LICENSE_ATTRIBUTION_MISSING");
		} else inventory.push({
			name,
			version: manifest.version,
			identifier: manifest.license,
			text: license
		});
	}
	await completeQrWorkerLicense(directory, inventory, resolve(root, "../../node_modules"));
	inventory.sort((a, b) => a.name.localeCompare(b.name, "en") || a.version.localeCompare(b.version, "en"));
	await writeFile(inventoryPath, JSON.stringify(inventory, null, 2) + "\n");
}
/** Strings that only the synthetic demo module contains (registry release ID and pinned registry digest). */
const SYNTHETIC_MARKERS = Object.freeze(["test-local-only", "14e7ecfb5aff74253affe0d2e8560728763f01db405bcc7efdca964ef103ca6a"]);
/** Strings only the localnet artifact carries (embedded config format and the visible test-funds banner). */
const LOCALNET_MARKERS = Object.freeze([LOCALNET_CONFIG_FORMAT, LOCALNET_BANNER]);
/** Module paths only the localnet build may contain (mirrors static-build-plugin.mjs localnet admissions). */
const LOCALNET_GRAPH_MODULE = /^(?:apps\/web\/src\/localnet\/|packages\/(?:wallet|domain|chain-evm)\/localnet\.ts$|packages\/(?:chain-evm|relay|exchange)\/|packages\/wallet\/src\/evm-|node_modules\/@noble\/)/;
const SOLANA_LOCALNET_MARKERS = Object.freeze([SOLANA_LOCALNET_FORMAT, SOLANA_LOCALNET_BANNER]);
const SOLANA_LOCALNET_GRAPH_MODULE = /^(?:apps\/web\/src\/solana-localnet\/|packages\/chain-solana\/)/;
const decodeAttribute = (value) => value.replaceAll("&#39;", "'").replaceAll("&quot;", "\"").replaceAll("&lt;", "<").replaceAll("&amp;", "&");
/**
* Localnet-only evidence: the artifact must carry the markers, the exact relay-only CSP (document meta, content-policy.json
* and _headers), ReleaseEnabled 0 wherever it is stated, and MIT credits for every bundled @noble package.
*/
function checkLocalnetArtifact(files, graphPaths, relayOrigin) {
	if (!LOCALNET_MARKERS.every((marker) => Object.entries(files).some(([path, text]) => path.endsWith(".js") && text.includes(marker))) || !graphPaths.includes("apps/web/src/localnet/LocalnetRoot.tsx")) throw new Error("LOCALNET_DATA_MISSING");
	const policy = JSON.parse(files["content-policy.json"] ?? "null");
	if (policy?.ReleaseEnabled !== 0 || policy.releaseAcceptance !== false) throw new Error("LOCALNET_RELEASE_ENABLED");
	const stated = Object.entries(files).filter(([path]) => path.endsWith(".js")).flatMap(([, text]) => [...text.matchAll(/["']?\bReleaseEnabled["']?\s*:\s*([^,}\s]+)/g)].map((match) => match[1]));
	if (stated.length === 0 || stated.some((value) => value !== "0")) throw new Error("LOCALNET_RELEASE_ENABLED");
	let meta, header;
	try {
		meta = buildLocalnetContentPolicy({
			version: 1,
			releaseId: "local-development",
			delivery: "meta",
			relayOrigin
		});
		header = buildLocalnetContentPolicy({
			version: 1,
			releaseId: "local-development",
			delivery: "header",
			relayOrigin
		});
	} catch {
		throw new Error("LOCALNET_POLICY_MISMATCH");
	}
	const documentPolicies = [...(files["index.html"] ?? "").matchAll(/<meta\s+http-equiv="Content-Security-Policy"\s+content="([^"]*)"/gi)].map((match) => decodeAttribute(match[1]));
	const headerPolicies = [...(files._headers ?? "").matchAll(/^\s*Content-Security-Policy: (.*)$/gm)].map((match) => match[1]);
	if (policy.csp !== meta.csp || JSON.stringify(policy.manifest?.connectOrigins) !== JSON.stringify([relayOrigin]) || policy.manifest?.profile !== "localnet" || documentPolicies.length !== 1 || documentPolicies[0] !== meta.csp || headerPolicies.length !== 1 || headerPolicies[0] !== header.csp) throw new Error("LOCALNET_POLICY_MISMATCH");
	const licenses = JSON.parse(files["third-party-licenses.json"] ?? "null");
	const noble = new Set(graphPaths.filter((path) => path.startsWith("node_modules/@noble/")).map((path) => path.split("/").slice(1, 3).join("/")));
	for (const name of noble) if (!licenses.some((item) => item.name === name && item.identifier === "MIT" && typeof item.text === "string" && item.text.includes("Permission is hereby granted"))) throw new Error("LICENSE_ATTRIBUTION_MISSING");
	return {
		relayOrigin,
		testFundsOnly: true,
		connectOrigins: [relayOrigin]
	};
}
function checkSolanaLocalnetArtifact(files, graphPaths, rpcOrigin) {
	if (!SOLANA_LOCALNET_MARKERS.every((marker) => Object.entries(files).some(([path, value]) => path.endsWith(".js") && value.includes(marker))) || !graphPaths.includes("apps/web/src/solana-localnet/SolanaLocalnetRoot.tsx") || !graphPaths.includes("apps/web/src/solana-localnet/rpc.ts")) throw new Error("SOLANA_LOCALNET_DATA_MISSING");
	const policy = JSON.parse(files["content-policy.json"] ?? "null");
	const make = (delivery) => buildSolanaLocalnetContentPolicy({
		version: 1,
		releaseId: "local-development",
		delivery,
		rpcOrigin
	});
	const meta = make("meta"), header = make("header");
	const documentPolicies = [...(files["index.html"] ?? "").matchAll(/<meta\s+http-equiv="Content-Security-Policy"\s+content="([^"]*)"/gi)].map((match) => decodeAttribute(match[1]));
	const headerPolicies = [...(files._headers ?? "").matchAll(/^\s*Content-Security-Policy: (.*)$/gm)].map((match) => match[1]);
	if (policy?.ReleaseEnabled !== 0 || policy.releaseAcceptance !== false || policy.manifest?.profile !== "solana-localnet" || policy.csp !== meta.csp || JSON.stringify(policy.manifest?.connectOrigins) !== JSON.stringify([rpcOrigin]) || documentPolicies.length !== 1 || documentPolicies[0] !== meta.csp || headerPolicies.length !== 1 || headerPolicies[0] !== header.csp) throw new Error("SOLANA_LOCALNET_POLICY_MISMATCH");
	const stated = Object.entries(files).filter(([path]) => path.endsWith(".js")).flatMap(([, value]) => [...value.matchAll(/["']?\bReleaseEnabled["']?\s*:\s*([^,}\s]+)/g)].map((match) => match[1]));
	if (!stated.length || stated.some((value) => value !== "0")) throw new Error("SOLANA_LOCALNET_RELEASE_ENABLED");
	const licenses = JSON.parse(files["third-party-licenses.json"] ?? "null");
	for (const path of graphPaths.filter((path) => path.startsWith("node_modules/@noble/"))) {
		const name = path.split("/").slice(1, 3).join("/");
		if (!licenses.some((item) => item.name === name && item.identifier === "MIT" && item.text?.includes("Permission is hereby granted"))) throw new Error("LICENSE_ATTRIBUTION_MISSING");
	}
	return {
		rpcOrigin,
		testFundsOnly: true,
		connectOrigins: [rpcOrigin]
	};
}
/**
* `localnet` ({ relayOrigin }) is passed only for the library-only localnet artifact. Every other scan refuses any localnet
* marker, module, `ws://` string or localnet policy, so default/demo/testnet artifacts cannot carry localnet data.
*/
async function scanBuild(directory, { syntheticDemo = false, testnet = false, localnet = null, solanaLocalnet = null } = {}) {
	const files = Object.create(null), identities = Object.create(null);
	async function walk(path) {
		for (const item of await readdir(path, { withFileTypes: true })) {
			const target = resolve(path, item.name), stat = await lstat(target);
			if (stat.isSymbolicLink()) throw new Error("ARTIFACT_SYMLINK");
			const artifactPath = safeArtifactPath(relative(directory, target).split(sep).join("/"));
			if (stat.isDirectory()) await walk(target);
			else if (stat.isFile()) {
				if (Object.hasOwn(identities, artifactPath)) throw new Error("ARTIFACT_POLICY: paths");
				const bytes = await readFile(target);
				identities[artifactPath] = {
					path: artifactPath,
					bytes: bytes.length,
					sha256: createHash("sha256").update(bytes).digest("hex")
				};
				files[artifactPath] = bytes.toString("utf8");
			} else throw new Error("ARTIFACT_TYPE");
		}
	}
	await walk(directory);
	const assets = Object.keys(files).sort().map((path) => identities[path]);
	const inspection = {
		...inspectArtifactFiles(files),
		bytes: assets.reduce((total, asset) => total + asset.bytes, 0)
	};
	const workers = assets.filter((item) => /^assets\/(?:vault|localnet|solana-localnet)\.worker-[A-Za-z0-9_-]+\.js$/.test(item.path));
	if (workers.length !== 1) throw new Error("NATIVE_WORKER_ASSET_MISSING");
	const licenses = JSON.parse(files["third-party-licenses.json"] ?? "null");
	if (!Array.isArray(licenses) || [
		"react",
		"react-dom",
		"scheduler"
	].some((name) => !licenses.some((item) => item.name === name && item.identifier === "MIT" && typeof item.text === "string" && item.text.includes("Permission is hereby granted")))) throw new Error("LICENSE_ATTRIBUTION_MISSING");
	for (const graph of ["core-graph-document.json", "core-graph-worker.json"]) if (!files[graph]) throw new Error("CORE_GRAPH_MISSING");
	const qr = inspectQrArtifact(files, JSON.parse(files["core-graph-document.json"]).modules, JSON.parse(files["core-graph-worker.json"]).modules);
	if (localnet && (syntheticDemo || testnet || solanaLocalnet) || solanaLocalnet && (syntheticDemo || testnet)) throw new Error("LOCALNET_PROFILE_EXCLUSIVE");
	const graphPaths = ["core-graph-document.json", "core-graph-worker.json"].flatMap((graph) => {
		const modules = JSON.parse(files[graph]).modules;
		return Array.isArray(modules) ? modules.map((module) => module?.path).filter((path) => typeof path === "string") : [];
	});
	if (((() => {
		try {
			return JSON.parse(files["content-policy.json"] ?? "null")?.manifest?.profile === "localnet";
		} catch {
			return false;
		}
	})() || graphPaths.some((path) => LOCALNET_GRAPH_MODULE.test(path) && !(solanaLocalnet && path.startsWith("node_modules/@noble/"))) || Object.values(files).some((text) => text.includes("ws://") || LOCALNET_MARKERS.some((marker) => text.includes(marker)))) !== Boolean(localnet)) throw new Error(localnet ? "LOCALNET_DATA_MISSING" : "LOCALNET_DATA_IN_NON_LOCALNET_BUILD");
	if ((graphPaths.some((path) => SOLANA_LOCALNET_GRAPH_MODULE.test(path)) || Object.values(files).some((value) => SOLANA_LOCALNET_MARKERS.some((marker) => value.includes(marker))) || JSON.parse(files["content-policy.json"] ?? "null")?.manifest?.profile === "solana-localnet") !== Boolean(solanaLocalnet)) throw new Error(solanaLocalnet ? "SOLANA_LOCALNET_DATA_MISSING" : "SOLANA_DATA_IN_NON_SOLANA_BUILD");
	if (!workers[0].path.startsWith(solanaLocalnet ? "assets/solana-localnet.worker-" : localnet ? "assets/localnet.worker-" : "assets/vault.worker-")) throw new Error("WORKER_PROFILE_MISMATCH");
	const localnetEvidence = localnet ? checkLocalnetArtifact(files, graphPaths, localnet.relayOrigin) : null;
	const solanaEvidence = solanaLocalnet ? checkSolanaLocalnetArtifact(files, graphPaths, solanaLocalnet.rpcOrigin) : null;
	if ((["core-graph-document.json", "core-graph-worker.json"].some((graph) => JSON.parse(files[graph]).modules?.some((module) => typeof module.path === "string" && module.path.startsWith("apps/web/src/demo/"))) || Object.values(files).some((text) => SYNTHETIC_MARKERS.some((marker) => text.includes(marker)))) !== syntheticDemo) throw new Error(syntheticDemo ? "SYNTHETIC_DEMO_DATA_MISSING" : "SYNTHETIC_DATA_IN_DEFAULT_BUILD");
	if ((["core-graph-document.json", "core-graph-worker.json"].some((graph) => JSON.parse(files[graph]).modules?.some((module) => typeof module.path === "string" && module.path.startsWith("apps/web/src/testnet/"))) || Object.values(files).some((text) => text.includes("p2p-offramp/testnet-trust/"))) !== testnet) throw new Error(testnet ? "TESTNET_TRUST_DATA_MISSING" : "TESTNET_DATA_IN_NON_TESTNET_BUILD");
	return {
		version: 1,
		ReleaseEnabled: 0,
		syntheticDemo,
		testnet,
		signedRelease: false,
		releaseAcceptance: false,
		framingAttestation: false,
		inspection,
		assets,
		...localnetEvidence ? { localnet: localnetEvidence } : {},
		...solanaEvidence ? { solanaLocalnet: solanaEvidence } : {},
		...qr ? { qr } : {}
	};
}
/**
* `demo` is a meta-delivery build that additionally includes the synthetic local registry and samples. `testnet` is a
* meta-delivery build that embeds the owner-signed Sepolia registry, verified here first (fail closed) and again at
* runtime. `trustRoot` (testnet only) is the directory holding the trust files; it defaults to the repository root.
* `testOnlyLocalProof` is a library-only fixture seam requiring explicit paths and an independently supplied pin;
* its artifacts are labelled unapproved local proofs and keep every trading/network permission disabled.
*/
async function buildWeb({ delivery = "meta", outDir, trustRoot, nowSeconds, testOnlyLocalProof, localnet, solanaLocalnet } = {}) {
	if (![
		"meta",
		"header",
		"demo",
		"testnet",
		"localnet",
		"solana-localnet"
	].includes(delivery)) throw new Error("UNSUPPORTED_BUILD_PROFILE");
	if (localnet !== void 0 && delivery !== "localnet") throw new Error("LOCALNET_PROFILE_ONLY");
	if (delivery === "localnet" && localnet === void 0) throw new Error("LOCALNET_CONFIG_REQUIRED");
	if (solanaLocalnet !== void 0 && delivery !== "solana-localnet") throw new Error("SOLANA_LOCALNET_PROFILE_ONLY");
	if (delivery === "solana-localnet" && solanaLocalnet === void 0) throw new Error("SOLANA_LOCALNET_CONFIG_REQUIRED");
	const syntheticDemo = delivery === "demo", testnet = delivery === "testnet";
	if (testOnlyLocalProof !== void 0 && (!testnet || !outDir || !trustRoot || typeof testOnlyLocalProof?.pinnedKeyId !== "string" || !/^[0-9a-f]{64}$/.test(testOnlyLocalProof.pinnedKeyId))) throw new Error("TESTNET_LOCAL_PROOF_INVALID");
	if (delivery === "localnet") return buildLocalnet(outDir, localnet);
	if (delivery === "solana-localnet") return buildSolanaLocalnet(outDir, solanaLocalnet);
	const trust = testnet ? await loadTestnetTrust(trustRoot ?? resolve(root, "../.."), {
		...nowSeconds ? { nowSeconds } : {},
		...testOnlyLocalProof ? { pinnedKeyId: testOnlyLocalProof.pinnedKeyId } : {}
	}) : null;
	outDir ??= resolve(root, syntheticDemo ? "dist-demo" : testnet ? "dist-testnet" : "dist");
	await build({
		configFile: resolve(root, "vite.config.ts"),
		mode: delivery,
		build: { outDir },
		...trust ? { define: {
			__P2P_TESTNET_TRUST__: JSON.stringify(trust.bundle),
			__P2P_TESTNET_LOCAL_PROOF_KEY_ID__: JSON.stringify(testOnlyLocalProof?.pinnedKeyId ?? null)
		} } : {}
	});
	await completeWorkerLicenses(outDir);
	const evidence = {
		...await scanBuild(outDir, {
			syntheticDemo,
			testnet
		}),
		...trust ? { testnetTrust: {
			...trust.summary,
			localProof: testOnlyLocalProof !== void 0,
			ownerApproved: testOnlyLocalProof === void 0
		} } : {}
	};
	await writeFile(resolve(outDir, "local-build-evidence.json"), JSON.stringify(evidence, null, 2) + "\n");
	return evidence;
}
/**
* Library-only localnet profile (A3): `localnet` is { registryBytes | registryJson, registrySha256, escrowLayouts, relayUrl }
* (see apps/web/src/localnet/config.ts). It is validated strictly before the build, embedded as frozen JSON, and the CSP
* connect-src names only its loopback relay origin. Output goes only to an explicit outDir (there is no default, because
* the repository ignores only the ordinary output directories) that is neither inside nor an ancestor of dist, dist-demo or
* dist-testnet, after resolving symlinks. Nothing here reads the environment or the command line.
*/
async function buildLocalnet(outDir, localnet) {
	const document = localnetConfigDocument(localnet);
	const config = await parseLocalnetConfig(document);
	outDir = await localOutputDirectory(outDir);
	const { createViteConfig } = await import("./vite.config-NZSJF527.js");
	const viteConfig = createViteConfig("localnet", {
		document,
		relayOrigin: config.relayOrigin
	});
	await build({
		...viteConfig,
		configFile: false,
		mode: "localnet",
		build: {
			...viteConfig.build,
			outDir
		}
	});
	await completeWorkerLicenses(outDir);
	const scanned = await scanBuild(outDir, { localnet: { relayOrigin: config.relayOrigin } });
	const evidence = {
		...scanned,
		localnet: {
			...scanned.localnet,
			registrySha256: config.registrySha256,
			escrowLayouts: { ...config.escrowLayouts },
			chainId: config.network.chainIdentity
		}
	};
	await writeFile(resolve(outDir, "local-build-evidence.json"), JSON.stringify(evidence, null, 2) + "\n");
	return evidence;
}
async function buildSolanaLocalnet(outDir, option) {
	const document = solanaLocalnetConfigDocument(option), config = await parseSolanaLocalnetConfig(document);
	outDir = await localOutputDirectory(outDir);
	const { createViteConfig } = await import("./vite.config-NZSJF527.js");
	const viteConfig = createViteConfig("solana-localnet", null, {
		document,
		rpcOrigin: config.rpcOrigin
	});
	await build({
		...viteConfig,
		configFile: false,
		mode: "solana-localnet",
		build: {
			...viteConfig.build,
			outDir
		}
	});
	await completeWorkerLicenses(outDir);
	const scanned = await scanBuild(outDir, { solanaLocalnet: { rpcOrigin: config.rpcOrigin } });
	const evidence = {
		...scanned,
		solanaLocalnet: {
			...scanned.solanaLocalnet,
			registrySha256: config.registrySha256,
			genesisHash: config.network.genesisHash
		}
	};
	await writeFile(resolve(outDir, "local-build-evidence.json"), JSON.stringify(evidence, null, 2) + "\n");
	return evidence;
}
async function localOutputDirectory(outDir) {
	if (outDir === void 0) throw new Error("LOCALNET_OUTPUT_DIR_REQUIRED");
	if (typeof outDir !== "string" || outDir.length === 0) throw new Error("LOCALNET_OUTPUT_DIR");
	const realRoot = await realpath(root);
	const ordinary = [
		"dist",
		"dist-demo",
		"dist-testnet"
	].flatMap((name) => [resolve(root, name), resolve(realRoot, name)]);
	outDir = resolve(outDir);
	const candidates = [outDir, await resolveExistingAncestor(outDir)];
	const inside = (parent, child) => {
		const path = relative(parent, child);
		return path === "" || path !== ".." && !path.startsWith(`..${sep}`) && !isAbsolute(path);
	};
	if (ordinary.some((directory) => candidates.some((candidate) => inside(directory, candidate) || inside(candidate, directory)))) throw new Error("LOCALNET_OUTPUT_DIR");
	return outDir;
}
/** `path` with symlinks resolved in its deepest existing ancestor; a dangling link on the way fails closed. */
async function resolveExistingAncestor(path) {
	const missing = [];
	for (let current = path;;) {
		try {
			return resolve(await realpath(current), ...missing);
		} catch (error) {
			if (error?.code !== "ENOENT") throw new Error("LOCALNET_OUTPUT_DIR");
		}
		let present = true;
		try {
			await lstat(current);
		} catch (error) {
			if (error?.code !== "ENOENT") throw new Error("LOCALNET_OUTPUT_DIR");
			present = false;
		}
		if (present) throw new Error("LOCALNET_OUTPUT_DIR");
		const parent = dirname(current);
		if (parent === current) throw new Error("LOCALNET_OUTPUT_DIR");
		missing.unshift(basename(current));
		current = parent;
	}
}
const LOCALNET_CLI_REFUSAL = "LOCALNET_CONFIG_REQUIRED: the localnet build profile is library-only. Call buildWeb({ delivery: 'localnet', outDir, localnet: { registryBytes, registrySha256, escrowLayouts, relayUrl } }) from a test harness; no command-line argument or environment variable enables it.";
if (isMain(import.meta.url)) {
	if (process.argv.length > 3) throw new Error("BUILD_ARGUMENTS");
	if (process.argv[2] === "localnet") {
		console.error(LOCALNET_CLI_REFUSAL);
		process.exit(1);
	}
	if (process.argv[2] === "solana-localnet") throw new Error("SOLANA_LOCALNET_CONFIG_REQUIRED: library-only explicit local validator fixture");
	const evidence = await buildWeb({ delivery: process.argv[2] ?? "meta" });
	console.log(JSON.stringify({
		localStaticBuild: true,
		syntheticDemo: evidence.syntheticDemo,
		...evidence.inspection,
		signedRelease: false,
		releaseAcceptance: false
	}));
}
// packages/storage/src/vault-crypto.ts
/** Storage-internal G02 operations. UI uses VaultService, never these key handles. */
var VaultCryptoError = class extends Error {
	code;
	constructor(code) {
		super(code === "AUTHENTICATION_FAILED" ? "Vault authentication failed." : "Vault operation unavailable.");
		this.name = "VaultCryptoError";
		this.code = code;
	}
};
const materials = /* @__PURE__ */ new WeakMap();
const utf8$1 = new TextEncoder();
function owned(bytes, secrets) {
	const copy = new Uint8Array(bytes);
	secrets?.push(copy);
	return copy;
}
function requireProvider(provider) {
	try {
		if (!provider || typeof provider.getRandomValues !== "function" || !provider.subtle || [
			"importKey",
			"deriveKey",
			"encrypt",
			"decrypt"
		].some((name) => typeof Reflect.get(provider.subtle, name) !== "function")) throw new Error();
	} catch {
		throw new VaultCryptoError("UNSUPPORTED_ENVIRONMENT");
	}
}
function unsupported(error) {
	try {
		return error instanceof DOMException && error.name === "NotSupportedError";
	} catch {
		return false;
	}
}
const aad = (values) => utf8$1.encode(JSON.stringify(values));
function wrapAAD(envelope) {
	return aad([
		"p2p-offramp",
		"vault-key",
		1,
		envelope.profileId,
		envelope.keyId,
		"PBKDF2-SHA256",
		6e5,
		envelope.wrappedKey.salt
	]);
}
function snapshotAAD(snapshot) {
	return aad([
		"p2p-offramp",
		"vault-snapshot",
		1,
		snapshot.profileId,
		snapshot.keyId,
		snapshot.revision
	]);
}
async function kek(provider, passphrase, salt) {
	const passwordCopy = owned(passphrase);
	try {
		const source = await provider.subtle.importKey("raw", passwordCopy, "PBKDF2", false, ["deriveKey"]);
		return await provider.subtle.deriveKey({
			name: "PBKDF2",
			hash: "SHA-256",
			salt: owned(salt),
			iterations: 6e5
		}, source, {
			name: "AES-GCM",
			length: 256
		}, false, ["encrypt", "decrypt"]);
	} finally {
		passwordCopy.fill(0);
	}
}
function material(envelope, key, provider, attempts) {
	const handle = Object.freeze({
		profileId: envelope.profileId,
		keyId: envelope.keyId
	});
	materials.set(handle, {
		key,
		provider,
		envelope: parseVaultEnvelope(envelope),
		attempts
	});
	return handle;
}
function disposeMaterial(handle) {
	materials.delete(handle);
}
async function openEnvelope(input, passphrase, provider = globalThis.crypto) {
	const envelope = parseVaultEnvelope(input);
	requireProvider(provider);
	const password = encodePassphrase(passphrase), secrets = [];
	let rawKey, plain;
	try {
		const wrappingKey = await kek(provider, password, decodeBase64url(envelope.wrappedKey.salt, 32, 32));
		rawKey = new Uint8Array(await provider.subtle.decrypt({
			name: "AES-GCM",
			iv: owned(decodeBase64url(envelope.wrappedKey.nonce, 12, 12)),
			additionalData: wrapAAD(envelope),
			tagLength: 128
		}, wrappingKey, owned(decodeBase64url(envelope.wrappedKey.ciphertext, 48, 48))));
		if (rawKey.length !== 32) throw new Error();
		const key = await provider.subtle.importKey("raw", owned(rawKey, secrets), { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
		plain = new Uint8Array(await provider.subtle.decrypt({
			name: "AES-GCM",
			iv: owned(decodeBase64url(envelope.snapshot.nonce, 12, 12)),
			additionalData: snapshotAAD(envelope),
			tagLength: 128
		}, key, owned(decodeBase64url(envelope.snapshot.ciphertext, 4112, 8388624))));
		const snapshot = decodeSnapshot(plain);
		if (snapshot.profileId !== envelope.profileId || snapshot.keyId !== envelope.keyId || snapshot.revision !== envelope.revision) throw new Error();
		return {
			snapshot,
			material: material(envelope, key, provider, 0)
		};
	} catch (error) {
		throw new VaultCryptoError(unsupported(error) ? "UNSUPPORTED_ENVIRONMENT" : "AUTHENTICATION_FAILED");
	} finally {
		password.fill(0);
		rawKey?.fill(0);
		plain?.fill(0);
		secrets.forEach((copy) => copy.fill(0));
	}
}
// scripts/lib/chromium-path.mjs
const bundledRoot = "/opt/pw-browsers";
/**
* Resolve the Chromium executable for the browser fixtures. Order: P2P_CHROMIUM, the system
* package path, then the newest bundled Playwright Chromium. Undefined lets playwright-core choose.
*/
function resolveChromiumPath(env = process.env) {
	if (env.P2P_CHROMIUM) return env.P2P_CHROMIUM;
	if (existsSync("/usr/bin/chromium")) return "/usr/bin/chromium";
	let builds;
	try {
		builds = readdirSync(bundledRoot).filter((name) => /^chromium-\d+$/.test(name)).sort((a, b) => Number(b.slice(9)) - Number(a.slice(9)));
	} catch {
		return;
	}
	for (const build of builds) {
		let dirs;
		try {
			dirs = readdirSync(join(bundledRoot, build)).filter((name) => name.startsWith("chrome-linux"));
		} catch {
			continue;
		}
		for (const dir of dirs) {
			const candidate = join(bundledRoot, build, dir, "chrome");
			if (existsSync(candidate)) return candidate;
		}
	}
}
// apps/web/src/solana-localnet/validation.ts
var SolanaUiFailure = class extends Error {
	code;
	constructor(code) {
		super(code);
		this.code = code;
	}
};
function fail(code = "INVALID_INPUT") {
	throw new SolanaUiFailure(code);
}
function fields(input, required, optional = []) {
	let copy;
	try {
		copy = dataFields(input, [...required, ...optional]);
	} catch {
		return fail();
	}
	if (required.some((key) => !Object.hasOwn(copy, key))) return fail();
	return copy;
}
Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint8Array.prototype), "byteLength").get;
// apps/web/src/solana-localnet/funding-proposal.ts
/** Inactive local-SOL proposal data. Parsing or retaining it grants no acceptance or funding authority. */
const SOLANA_FUNDING_PROPOSAL_FORMAT = "p2p-offramp/solana-local-funding-proposal/v1";
const SOLANA_FUNDING_PROPOSAL_RECORD_FORMAT = "p2p-offramp/solana-local-funding-proposal-record/v1";
const MAX_SOLANA_FUNDING_PROPOSAL_RECORD_BYTES = 8192;
const TERMS_KEYS = [
	"acceptBeforeSeconds",
	"amountBaseUnits",
	"assetKind",
	"buyer",
	"capabilitiesHash",
	"escrowExpirySeconds",
	"genesisHash",
	"mint",
	"orderId",
	"privateAgreementHash",
	"programId",
	"revision",
	"seller",
	"sellerNonce",
	"tokenProgram"
];
const utf8 = new TextEncoder();
const digest = (input) => typeof input === "string" && /^[0-9a-f]{64}$/.test(input) ? input : fail();
const registryId = (input) => typeof input === "string" && /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(input) && !input.includes("..") ? input : fail();
function origin(input) {
	return typeof input === "string" && /^[0-9a-f]{32}$/.test(input) && !/^0{32}$/.test(input) ? input : fail();
}
function proposalValue(input) {
	const raw = fields(input, ["format", "terms"]);
	if (raw.format !== "p2p-offramp/solana-local-funding-proposal/v1") return fail("UNSUPPORTED_VERSION");
	const captured = fields(raw.terms, TERMS_KEYS);
	if (captured.assetKind !== "native" || captured.mint !== null || captured.tokenProgram !== null) return fail();
	const terms = Object.freeze(Object.fromEntries(TERMS_KEYS.map((key) => [key, captured[key]])));
	const message = encodeSolanaTerms(terms);
	return {
		document: Object.freeze({
			format: SOLANA_FUNDING_PROPOSAL_FORMAT,
			terms
		}),
		message
	};
}
function margin(input, maximum) {
	return typeof input === "string" && /^(0|[1-9][0-9]{0,5})$/.test(input) && BigInt(input) <= maximum ? input : fail();
}
function rpcUrl(input) {
	try {
		return parseSolanaRpcUrl(input).url;
	} catch {
		return fail();
	}
}
function configuration(input) {
	const raw = fields(input, [
		"registrySha256",
		"programDataSha256",
		"artifactSha256",
		"assetId",
		"rpcUrl",
		"margins"
	]);
	const limits = fields(raw.margins, ["submitMarginSeconds", "releaseMarginSeconds"]);
	return Object.freeze({
		registrySha256: digest(raw.registrySha256),
		programDataSha256: digest(raw.programDataSha256),
		artifactSha256: digest(raw.artifactSha256),
		assetId: registryId(raw.assetId),
		rpcUrl: rpcUrl(raw.rpcUrl),
		margins: Object.freeze({
			submitMarginSeconds: margin(limits.submitMarginSeconds, 3600n),
			releaseMarginSeconds: margin(limits.releaseMarginSeconds, 604800n)
		})
	});
}
function binding(input) {
	const parsed = parseTradeBinding(input);
	if (parsed.chain !== "solana") return fail();
	return Object.freeze({
		chain: "solana",
		networkId: registryId(parsed.networkId),
		deploymentId: registryId(parsed.deploymentId),
		tradeId: digest(parsed.tradeId)
	});
}
async function recordId(value) {
	return (await sha256Hex(utf8.encode(JSON.stringify([
		SOLANA_FUNDING_PROPOSAL_RECORD_FORMAT,
		value.chain,
		value.networkId,
		value.deploymentId,
		value.tradeId
	])))).slice(0, 32);
}
/** Retain historical provenance verbatim as validated data; the caller must compare independently installed pins later. */
async function decodeSolanaFundingProposalRecord(record) {
	const outer = fields(record, [
		"id",
		"kind",
		"schemaVersion",
		"payload"
	]);
	if (outer.kind !== "trade" || typeof outer.id !== "string" || !/^[0-9a-f]{32}$/.test(outer.id)) return fail();
	if (outer.schemaVersion !== 1) return fail("UNSUPPORTED_VERSION");
	const raw = fields(parseStrictJsonBytes(decodeBase64url(outer.payload, 1, MAX_SOLANA_FUNDING_PROPOSAL_RECORD_BYTES), MAX_SOLANA_FUNDING_PROPOSAL_RECORD_BYTES), [
		"format",
		"proposal",
		"binding",
		"role",
		"originProfileId",
		"configuration"
	]);
	if (raw.format !== "p2p-offramp/solana-local-funding-proposal-record/v1") return fail("UNSUPPORTED_VERSION");
	if (raw.role !== "seller") return fail();
	const captured = proposalValue(raw.proposal), retained = binding(raw.binding);
	const value = Object.freeze({
		format: SOLANA_FUNDING_PROPOSAL_RECORD_FORMAT,
		proposal: captured.document,
		binding: retained,
		role: "seller",
		originProfileId: origin(raw.originProfileId),
		configuration: configuration(raw.configuration)
	});
	if (retained.tradeId !== await sha256Hex(captured.message) || outer.id !== await recordId(retained)) return fail("INTEGRITY_FAILURE");
	return value;
}
// scripts/lib/solana-localnet-send-evidence.mjs
/** Fixture-only oracle: runs in Node against the ACTUAL encrypted IndexedDB row before the proxy forwards a send. */
function readSolanaVaultRecords(snapshot) {
	const intents = [], documents = [];
	for (const record of snapshot.records) {
		if (record.kind !== "journal" && record.kind !== "trade") continue;
		const raw = parseStrictJsonBytes(decodeBase64url(record.payload, 1, 262144), 262144);
		assert.equal(record.schemaVersion, 1);
		if (record.kind === "journal") {
			assert.equal(raw.format, "p2p-offramp/solana/vault-journal/v1");
			const expectedId = createHash("sha256").update(JSON.stringify([
				raw.format,
				raw.binding.chain,
				raw.binding.networkId,
				raw.binding.deploymentId,
				raw.binding.tradeId
			])).digest("hex").slice(0, 32);
			assert.equal(record.id, expectedId);
			assert.ok(raw.records.length > 0);
			assert.ok(Number.isSafeInteger(raw.revision) && raw.revision >= raw.records.length);
			for (const input of raw.records) {
				const intent = parseSolanaIntent(input);
				assert.equal(sameBinding(raw.binding, intent.binding), true);
				intents.push(intent);
			}
		} else {
			assert.equal(raw.format, "p2p-offramp/solana-local-recovery/v1");
			const document = parseRecoveryDocument(raw.document);
			const expectedId = createHash("sha256").update(`${raw.format}\0${document.termsHash}`).digest("hex").slice(0, 32);
			assert.equal(record.id, expectedId);
			assert.match(raw.originProfileId, /^[0-9a-f]{32}$/);
			assert.ok(["seller", "buyer"].includes(raw.role));
			documents.push({
				document,
				role: raw.role,
				originProfileId: raw.originProfileId
			});
		}
	}
	assert.equal(new Set(intents.map((r) => r.intentId)).size, intents.length);
	return {
		intents,
		documents
	};
}
/** Only fully validated proposal records leave the unchanged strict legacy oracle's input. */
async function readSolanaBrowserVaultRecords(snapshot) {
	const records = [], proposals = [];
	for (const record of snapshot.records) {
		if (record.kind === "trade") {
			if (parseStrictJsonBytes(decodeBase64url(record.payload, 1, 262144), 262144)?.format === "p2p-offramp/solana-local-funding-proposal-record/v1") {
				const retained = Object.freeze({ ...record });
				const value = await decodeSolanaFundingProposalRecord(retained);
				proposals.push({
					record: retained,
					value
				});
				continue;
			}
		}
		records.push(record);
	}
	return {
		...readSolanaVaultRecords({ records }),
		proposals
	};
}
function assertSolanaSendMarked(intents, base64Wire, profileId, pins, seenSignatures) {
	assert.equal(typeof base64Wire, "string");
	assert.ok(base64Wire.length <= 1644);
	const wire = Buffer.from(base64Wire, "base64");
	assert.equal(wire.toString("base64"), base64Wire);
	assert.ok(wire.length <= 1232 && wire.length > 100);
	assert.equal(wire[0], 1, "one legacy signature");
	const signatureBytes = wire.subarray(1, 65), message = wire.subarray(65), signature = base58Encode(signatureBytes);
	const matching = intents.filter((record) => record.state === "sendMarked" && record.signature === signature && record.message === message.toString("base64"));
	assert.equal(matching.length, 1, "exactly one durable marker precedes these exact signed bytes");
	const marker = parseSolanaIntent(matching[0]);
	assert.equal(marker.originProfileId, profileId, "the current profile owns the new physical broadcast");
	assert.equal(marker.genesisHash, pins.genesisHash);
	assert.equal(marker.programId, pins.programId);
	assert.equal(marker.programDataSha256, pins.programDataSha256);
	assert.ok(Number.isSafeInteger(marker.sendMarkedAt) && marker.sendMarkedAt >= marker.createdAt && marker.sendMarkedAt <= marker.updatedAt);
	assert.equal(marker.outcome, null);
	assert.ok([
		"release",
		"refund",
		"payout"
	].includes(marker.action), "browser never funds");
	const publicKey = createPublicKey({
		key: Buffer.concat([Buffer.from("302a300506032b6570032100", "hex"), Buffer.from(decodeKey$1(marker.feePayer))]),
		type: "spki",
		format: "der"
	});
	assert.equal(verify(null, message, publicKey, signatureBytes), true, "physical transaction has the recorded role signature");
	assert.equal(seenSignatures.has(signature), false, "one physical attempt per signed transaction; no retries or resends");
	seenSignatures.add(signature);
	return {
		intentId: marker.intentId,
		tradeId: marker.binding.tradeId,
		action: marker.action,
		signature,
		profileId,
		originProfileId: marker.originProfileId,
		durableState: marker.state,
		sendMarkedAt: marker.sendMarkedAt,
		messageSha256: createHash("sha256").update(message).digest("hex"),
		replacementOf: marker.replacementOf
	};
}
// scripts/lib/solana-localnet-browser-fixture.mjs
/** Real browser fixture: emitted module Worker + IndexedDB. External wallet test keys remain in Node. */
async function waitSolanaBrowser(check, label, timeoutMs = 45e3, intervalMs = 100) {
	const start = Date.now();
	for (;;) {
		if (await check()) return;
		if (Date.now() - start >= timeoutMs) throw Error(`Timed out: ${label}`);
		await new Promise((resolve) => setTimeout(resolve, intervalMs));
	}
}
const profileId = (page) => page.locator("main[data-profile-id]").getAttribute("data-profile-id");
async function encryptedRow(page, id) {
	return page.evaluate((profile) => new Promise((resolve, reject) => {
		const request = indexedDB.open("p2p-offramp-vault", 1);
		request.onerror = () => reject(Error("Fixture encrypted profile inspection failed."));
		request.onsuccess = () => {
			const db = request.result, tx = db.transaction("vaults", "readonly"), get = tx.objectStore("vaults").get(profile);
			get.onsuccess = () => resolve(get.result);
			get.onerror = () => reject(Error("Fixture encrypted profile read failed."));
			tx.oncomplete = () => db.close();
			tx.onabort = () => db.close();
		};
	}), id);
}
async function startSolanaBrowserFixture() {
	let chain, browser, server, temporary, page, context, passphrase, closed = false, heldSign = null, holdNext = false;
	const unexpected = [], errors = [], prompts = [], workers = [], seen = /* @__PURE__ */ new Set();
	let walletConnects = 0;
	const close = async () => {
		if (closed) return;
		closed = true;
		heldSign?.resolve();
		await browser?.close();
		if (server) {
			server.closeAllConnections();
			await new Promise((resolve) => server.close(resolve));
		}
		await chain?.close();
		if (temporary) await rm(temporary, {
			recursive: true,
			force: true
		});
	};
	async function vault() {
		const id = await profileId(page);
		assert.match(id, /^[0-9a-f]{32}$/);
		assert.equal(typeof passphrase, "string");
		const row = await encryptedRow(page, id), opened = await openEnvelope(row, passphrase, crypto);
		try {
			return {
				id,
				row,
				snapshot: opened.snapshot,
				...await readSolanaBrowserVaultRecords(opened.snapshot)
			};
		} finally {
			disposeMaterial(opened.material);
		}
	}
	try {
		chain = await startSolanaLocalnetFixture();
		temporary = await mkdtemp(join(tmpdir(), "p2p-solana-browser-artifact-"));
		const outDir = join(temporary, "app"), evidence = await buildWeb({
			delivery: "solana-localnet",
			outDir,
			solanaLocalnet: chain.buildOption
		});
		assert.equal(evidence.ReleaseEnabled, 0);
		const files = new Map(await Promise.all(evidence.assets.map(async (asset) => [asset.path, await readFile(join(outDir, asset.path))])));
		const headers = buildSolanaLocalnetContentPolicy({
			version: 1,
			releaseId: "local-development",
			delivery: "header",
			rpcOrigin: new URL(chain.rpcUrl).origin
		}).headers;
		server = createServer((request, response) => {
			const path = request.url === "/" ? "index.html" : request.url?.slice(1), bytes = files.get(path);
			if (!bytes) {
				response.writeHead(404).end();
				return;
			}
			const type = path.endsWith(".html") ? "text/html" : path.endsWith(".js") ? "text/javascript" : path.endsWith(".css") ? "text/css" : "application/json";
			response.writeHead(200, {
				...headers,
				"Content-Type": type,
				"Cache-Control": "no-store"
			}).end(bytes);
		});
		await new Promise((resolve, reject) => {
			server.once("error", reject);
			server.listen(0, "127.0.0.1", resolve);
		});
		const origin = `http://127.0.0.1:${server.address().port}`, rpcOrigin = new URL(chain.rpcUrl).origin;
		browser = await chromium.launch({
			executablePath: resolveChromiumPath(),
			args: ["--no-sandbox"]
		});
		context = await browser.newContext({
			serviceWorkers: "block",
			acceptDownloads: true
		});
		await context.route("**/*", (route) => {
			const url = new URL(route.request().url());
			if ([origin, rpcOrigin].includes(url.origin)) return route.continue();
			unexpected.push(url.href);
			return route.abort();
		});
		await context.routeWebSocket(() => true, (socket) => {
			unexpected.push(socket.url());
			socket.close();
		});
		await context.exposeBinding("__solanaFixtureConnect", async () => {
			walletConnects++;
		});
		await context.exposeBinding("__solanaFixtureSign", async (_source, request) => {
			assert.equal(request.account, chain.seller);
			assert.equal(request.chain, "solana:localnet");
			const wire = Buffer.from(request.transaction, "base64");
			assert.equal(wire[0], 1);
			assert.ok(wire.subarray(1, 65).every((byte) => byte === 0));
			const review = page.locator("[data-review-id]");
			assert.equal(await review.count(), 1);
			const displayedMessage = await review.locator("dt").filter({ hasText: /^Message \(base64\)$/ }).evaluate((node) => node.nextElementSibling.textContent);
			assert.equal(wire.subarray(65).toString("base64"), displayedMessage, "wallet receives exactly the message reviewed by the person");
			const stored = await vault(), matching = stored.intents.filter((record) => record.state === "prepared" && record.message === displayedMessage && record.originProfileId === stored.id);
			assert.equal(matching.length, 1, "the reviewed intent is durable before the external wallet prompt");
			prompts.push({
				intentId: matching[0].intentId,
				profileId: stored.id,
				action: matching[0].action,
				messageSha256: createHash("sha256").update(wire.subarray(65)).digest("hex")
			});
			if (holdNext) {
				holdNext = false;
				await new Promise((resolve) => {
					heldSign = { resolve };
				});
				heldSign = null;
			}
			return Buffer.from(chain.sign(request.transaction)).toString("base64");
		});
		const account = chain.account();
		await context.addInitScript(({ address, publicKey }) => {
			const listeners = /* @__PURE__ */ new Set();
			const wallet = {
				name: "Local fixture sign-only wallet",
				version: "1.0.0",
				chains: ["solana:localnet"],
				accounts: [{
					address,
					publicKey: new Uint8Array(publicKey),
					chains: ["solana:localnet"],
					features: ["solana:signTransaction"]
				}],
				features: {
					"standard:connect": {
						version: "1.0.0",
						async connect() {
							await window.__solanaFixtureConnect();
							return { accounts: wallet.accounts };
						}
					},
					"standard:events": {
						version: "1.0.0",
						on(event, listener) {
							if (event !== "change") throw Error("Wrong event");
							listeners.add(listener);
							return () => listeners.delete(listener);
						}
					},
					"solana:signTransaction": {
						version: "1.0.0",
						supportedTransactionVersions: ["legacy"],
						async signTransaction(...inputs) {
							if (inputs.length !== 1) throw Error("Single transaction only");
							const input = inputs[0];
							const transaction = btoa(String.fromCharCode(...input.transaction));
							const wire = await window.__solanaFixtureSign({
								account: input.account.address,
								chain: input.chain,
								transaction
							});
							return [{ signedTransaction: Uint8Array.from(atob(wire), (c) => c.charCodeAt(0)) }];
						}
					},
					"solana:signAndSendTransaction": {
						version: "1.0.0",
						async signAndSendTransaction() {
							throw Error("Forbidden sign-and-send wallet method");
						}
					}
				}
			};
			window.__solanaFixtureWalletChange = () => {
				for (const listener of listeners) listener({ accounts: wallet.accounts });
			};
			window.addEventListener("wallet-standard:app-ready", (event) => event.detail.register(wallet));
			window.dispatchEvent(new CustomEvent("wallet-standard:register-wallet", { detail: (api) => api.register(wallet) }));
		}, {
			address: account.address,
			publicKey: [...account.publicKey]
		});
		chain.observeSends(async (wire) => {
			const stored = await vault();
			const proof = assertSolanaSendMarked(stored.intents, wire, stored.id, chain.summary, seen);
			assert.equal(JSON.stringify(stored.row).includes(stored.intents.find((r) => r.intentId === proof.intentId).message), false, "signed message is encrypted at rest");
			return proof;
		});
		page = await context.newPage();
		page.setDefaultTimeout(45e3);
		page.on("worker", (worker) => workers.push(worker.url()));
		page.on("pageerror", (error) => errors.push(error.message));
		await page.goto(origin);
		await page.getByRole("heading", { name: "Choose your wallet" }).waitFor();
		await page.getByLabel("Wallet Standard wallet").selectOption({ label: "Local fixture sign-only wallet" });
		await page.getByRole("button", {
			name: "Use selected wallet",
			exact: true
		}).click();
		await page.getByRole("heading", { name: "Your encrypted recovery profile" }).waitFor();
		await waitSolanaBrowser(() => workers.some((url) => /solana-localnet\.worker-/.test(url)), "actual native module Worker");
		return {
			page,
			context,
			chain,
			evidence,
			unexpected,
			errors,
			workers,
			prompts,
			vault,
			get walletConnects() {
				return walletConnects;
			},
			profileId: () => profileId(page),
			setPassphrase(value) {
				passphrase = value;
			},
			holdNextSign() {
				assert.equal(holdNext, false);
				holdNext = true;
			},
			get signPending() {
				return heldSign !== null;
			},
			settleSign() {
				assert.ok(heldSign);
				heldSign.resolve();
			},
			close
		};
	} catch (error) {
		await close();
		throw error;
	}
}
// scripts/test-solana-localnet-browser.mjs
/** Actual built Solana application/Worker/IndexedDB/Agave gate. No mock, genesis shim, clock warp or refund skip. */
const PASS = "synthetic local Solana browser profile passphrase";
const NEW_PASS = "fresh synthetic Solana recovery profile passphrase";
const checks = [];
const began = Date.now();
const pass = (name) => {
	checks.push(name);
	console.log(`ok - ${name}`);
};
let fixture;
const card = (id) => fixture.page.locator(`[data-trade-id="${id}"]`);
const proposalCard = (id) => fixture.page.locator(`[data-proposal-id="${id}"]`);
const review = () => fixture.page.locator("[data-review-id]");
const idle = () => waitSolanaBrowser(async () => await fixture.page.locator("main").getAttribute("aria-busy") === "false", "acknowledged UI command completion");
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function refresh() {
	await fixture.page.getByRole("button", {
		name: "Refresh finalized state",
		exact: true
	}).click();
	await pause(200);
	await idle();
}
async function unlock(id, passphrase) {
	fixture.setPassphrase(passphrase);
	await fixture.page.getByLabel("Profile", { exact: true }).selectOption(id);
	await fixture.page.getByLabel("Profile passphrase", { exact: true }).fill(passphrase);
	await fixture.page.getByRole("button", {
		name: "Unlock recovery profile",
		exact: true
	}).click();
	await waitSolanaBrowser(async () => await fixture.profileId() === id, "explicit profile unlock");
	await idle();
	assert.equal(await fixture.page.getByLabel("Recovery JSON", { exact: true }).inputValue(), "", "lock/switch clears prior profile recovery input");
	assert.equal(await fixture.page.getByLabel("Funding proposal JSON", { exact: true }).inputValue(), "", "lock/switch clears prior profile proposal input");
}
async function connect(id) {
	await card(id).getByRole("button", {
		name: "Connect seller wallet",
		exact: true
	}).click();
	await waitSolanaBrowser(async () => await fixture.page.locator("main").getAttribute("data-wallet-trade") === id, "explicit role wallet connection");
	await idle();
}
async function prepare(id, action, rebuild = false) {
	if (action === "release") await card(id).getByRole("checkbox").check();
	const name = rebuild ? `Review a new ${action} after this definitive drop` : action === "payout" ? "Review separate payout" : `Review ${action}`;
	const before = fixture.chain.summary.appSends.length, prompts = fixture.prompts.length;
	await card(id).getByRole("button", {
		name,
		exact: true
	}).click();
	await review().waitFor();
	await idle();
	assert.equal(fixture.chain.summary.appSends.length, before);
	assert.equal(fixture.prompts.length, prompts);
	const field = (label) => review().locator("dt").filter({ hasText: new RegExp(`^${label}$`) }).evaluate((node) => node.nextElementSibling.textContent);
	assert.equal(await field("Network genesis"), fixture.chain.summary.genesisHash);
	assert.equal(await field("Immutable program"), fixture.chain.summary.programId);
	assert.equal(await field("ProgramData SHA-256"), fixture.chain.summary.programDataSha256);
	assert.equal(await field("Terms SHA-256"), id);
	assert.equal(await field("Fee payer"), fixture.chain.seller);
}
async function confirm() {
	await fixture.page.getByRole("button", {
		name: "Confirm and sign in wallet",
		exact: true
	}).click();
	await review().waitFor({ state: "hidden" });
	await idle();
}
async function settled(id, state, paidOut) {
	await waitSolanaBrowser(async () => {
		await refresh();
		return await card(id).getAttribute("data-chain-state") === state && await card(id).getAttribute("data-paid-out") === String(paidOut);
	}, `finalized ${state} paidOut=${paidOut}`, 15e4, 1e3);
}
async function noAutomaticSend(beforeSends, beforePrompts) {
	await refresh();
	assert.equal(fixture.chain.summary.appSends.length, beforeSends);
	assert.equal(fixture.prompts.length, beforePrompts);
}
try {
	fixture = await startSolanaBrowserFixture();
	const { page, chain } = fixture, ids = Object.fromEntries(Object.entries(chain.documents).map(([name, document]) => [name, document.termsHash]));
	fixture.setPassphrase(PASS);
	await page.getByLabel("Profile passphrase", { exact: true }).fill(PASS);
	await page.getByRole("button", {
		name: "Create recovery profile",
		exact: true
	}).click();
	await waitSolanaBrowser(async () => /^[0-9a-f]{32}$/.test(await fixture.profileId()), "encrypted profile created");
	await idle();
	const originalProfile = await fixture.profileId();
	for (const document of [chain.documents.absent, {
		...chain.documents.release,
		network: {
			...chain.documents.release.network,
			programDataSha256: "ef".repeat(32)
		}
	}]) {
		await page.getByLabel("Recovery JSON", { exact: true }).fill(JSON.stringify(document));
		await page.getByRole("button", {
			name: "Verify and save recovery document",
			exact: true
		}).click();
		await page.getByRole("alert").waitFor();
		await idle();
		assert.equal(await page.locator("[data-trade-id]").count(), 0);
	}
	const beforeProposal = await fixture.vault();
	const publicProposal = {
		format: "p2p-offramp/solana-local-funding-proposal/v1",
		terms: chain.documents.absent.terms
	};
	const proposalJson = JSON.stringify(publicProposal), connectsBeforeProposal = fixture.walletConnects;
	const promptsBeforeProposal = fixture.prompts.length, sendsBeforeProposal = chain.summary.appSends.length;
	await page.getByLabel("Funding proposal JSON", { exact: true }).fill(proposalJson);
	await page.getByRole("button", {
		name: "Save seller funding proposal",
		exact: true
	}).click();
	await page.locator("[data-proposal-id]").waitFor();
	await idle();
	const proposalVault = await fixture.vault();
	assert.equal(proposalVault.proposals.length, 1);
	const savedProposal = proposalVault.proposals[0];
	assert.deepEqual(savedProposal.value.proposal, publicProposal);
	assert.deepEqual(savedProposal.value.binding, {
		chain: "solana",
		networkId: chain.documents.absent.network.networkId,
		deploymentId: chain.documents.absent.network.deploymentId,
		tradeId: ids.absent
	});
	assert.equal(savedProposal.value.originProfileId, originalProfile);
	assert.equal(savedProposal.value.role, "seller");
	assert.deepEqual(savedProposal.value.configuration, {
		registrySha256: chain.buildOption.registrySha256,
		programDataSha256: chain.summary.programDataSha256,
		artifactSha256: chain.summary.artifactSha256,
		assetId: chain.documents.absent.asset.id,
		rpcUrl: chain.buildOption.rpcUrl,
		margins: chain.buildOption.margins
	});
	assert.equal(proposalVault.snapshot.revision, beforeProposal.snapshot.revision + 1, "one explicit proposal admission commits once");
	assert.deepEqual(proposalVault.intents, beforeProposal.intents, "saving creates no prepared journal intent");
	assert.equal(JSON.stringify(proposalVault.row).includes(ids.absent), false);
	assert.equal(JSON.stringify(proposalVault.row).includes(savedProposal.record.payload), false, "private proposal payload is encrypted at rest");
	await proposalCard(savedProposal.record.id).getByText("Saved proposal", { exact: true }).waitFor();
	assert.equal(await card(ids.absent).count(), 0, "a saved proposal is not a funded recovery card");
	assert.equal(fixture.walletConnects, connectsBeforeProposal);
	assert.equal(fixture.prompts.length, promptsBeforeProposal);
	assert.equal(chain.summary.appSends.length, sendsBeforeProposal);
	pass("explicit seller proposal admission encrypts complete fixed terms without wallet, prepared intent or send");
	for (const name of [
		"release",
		"rebuild",
		"refund"
	]) {
		await page.getByLabel("Recovery JSON", { exact: true }).fill(JSON.stringify(chain.documents[name]));
		await page.getByRole("button", {
			name: "Verify and save recovery document",
			exact: true
		}).click();
		await card(ids[name]).waitFor();
		await idle();
	}
	const stored = await fixture.vault();
	assert.equal(stored.documents.length, 3);
	for (const name of [
		"release",
		"rebuild",
		"refund"
	]) {
		assert.deepEqual(stored.documents.find((r) => r.document.termsHash === ids[name]).document, chain.documents[name]);
		assert.equal(JSON.stringify(stored.row).includes(ids[name]), false);
	}
	assert.equal(chain.summary.appSends.length, 0);
	assert.equal(fixture.prompts.length, 0);
	pass("actual module Worker refuses absent or wrong-pinned escrows and encrypts three complete original funded receipts");
	const publicDownloadEvent = page.waitForEvent("download");
	await card(ids.release).getByRole("button", {
		name: "Export public recovery JSON",
		exact: true
	}).click();
	const publicDownload = await publicDownloadEvent;
	assert.equal(publicDownload.suggestedFilename(), `solana-escrow-${ids.release}.recovery.json`);
	const publicBytes = await readFile(await publicDownload.path());
	await idle();
	assert.ok(publicBytes.length <= 16384);
	assert.deepEqual(JSON.parse(publicBytes.toString("utf8")), chain.documents.release);
	assert.equal(fixture.walletConnects, 0);
	assert.equal(fixture.prompts.length, 0);
	assert.equal(chain.summary.appSends.length, 0);
	pass("explicit public recovery download preserves the original document without a wallet connection or transaction");
	await connect(ids.release);
	assert.equal(await card(ids.release).getByRole("button", {
		name: "Review release",
		exact: true
	}).isEnabled(), false);
	await prepare(ids.release, "release");
	await page.getByRole("button", {
		name: "Cancel transaction review",
		exact: true
	}).click();
	await review().waitFor({ state: "hidden" });
	await waitSolanaBrowser(async () => (await fixture.vault()).intents.every((r) => r.state === "cancelled"), "durable pre-sign cancellation");
	await idle();
	assert.equal(chain.summary.appSends.length, 0);
	assert.equal(fixture.prompts.length, 0);
	await prepare(ids.release, "release");
	fixture.holdNextSign();
	await page.getByRole("button", {
		name: "Confirm and sign in wallet",
		exact: true
	}).click();
	await waitSolanaBrowser(() => fixture.signPending, "external physical signer pending");
	await page.evaluate(() => window.__solanaFixtureWalletChange());
	await waitSolanaBrowser(async () => await page.locator("main").getAttribute("data-wallet-account") === "", "wallet event synchronously revokes document authority");
	assert.equal(await card(ids.release).getByRole("button", {
		name: "Connect seller wallet",
		exact: true
	}).isEnabled(), false, "reconnection remains blocked while the original physical signer is pending");
	fixture.settleSign();
	await waitSolanaBrowser(() => !fixture.signPending, "original physical signer settled");
	await idle();
	assert.equal(chain.summary.appSends.length, 0, "late signed result after the wallet event never broadcasts");
	if (!await fixture.profileId()) await unlock(originalProfile, PASS);
	await connect(ids.release);
	pass("explicit cancellation and a wallet change during an actual sign-only prompt both send zero transactions");
	const buyerBefore = await getBalance(chain.rpc, chain.buyer, "finalized");
	await prepare(ids.release, "release");
	await confirm();
	await settled(ids.release, "released", false);
	assert.equal(await getBalance(chain.rpc, chain.buyer, "finalized"), buyerBefore, "release alone changes state without paying");
	await prepare(ids.release, "payout");
	await confirm();
	await settled(ids.release, "released", true);
	assert.equal(await getBalance(chain.rpc, chain.buyer, "finalized"), buyerBefore + 1e8);
	assert.equal(chain.summary.appSends.length, 2);
	pass("reviewed release finalizes alone, then a separate reviewed payout transfers exact principal to the original buyer");
	await connect(ids.rebuild);
	await prepare(ids.rebuild, "release");
	chain.withholdNextSend();
	await confirm();
	const uncertain = (await fixture.vault()).intents.find((r) => r.binding.tradeId === ids.rebuild && r.state === "unknown");
	assert.ok(uncertain?.signature);
	assert.notEqual(uncertain.sendMarkedAt, null);
	assert.equal(chain.summary.appSends.length, 3);
	const sendsBeforeRestore = chain.summary.appSends.length, promptsBeforeRestore = fixture.prompts.length, connectsBeforeRestore = fixture.walletConnects;
	const downloadEvent = page.waitForEvent("download");
	await page.getByRole("button", {
		name: "Export encrypted backup",
		exact: true
	}).click();
	const download = await downloadEvent, backup = await readFile(await download.path());
	await idle();
	await page.getByLabel("Funding proposal JSON", { exact: true }).fill(proposalJson);
	await page.getByRole("button", {
		name: "Lock profile",
		exact: true
	}).click();
	await waitSolanaBrowser(async () => await fixture.profileId() === "", "profile lock");
	await idle();
	assert.equal(await page.locator("[data-trade-id]").count(), 0);
	assert.equal(await page.locator("[data-proposal-id]").count(), 0, "lock redacts saved proposals");
	await page.getByLabel("Encrypted backup", { exact: true }).setInputFiles({
		name: "local-recovery.backup",
		mimeType: "application/octet-stream",
		buffer: backup
	});
	await page.getByLabel("Backup passphrase", { exact: true }).fill(PASS);
	await page.getByLabel("New profile passphrase", { exact: true }).fill(NEW_PASS);
	fixture.setPassphrase(NEW_PASS);
	await page.getByRole("button", {
		name: "Restore with a fresh key",
		exact: true
	}).click();
	await waitSolanaBrowser(async () => /^[0-9a-f]{32}$/.test(await fixture.profileId()) && await fixture.profileId() !== originalProfile, "fresh-key encrypted restore");
	await idle();
	const freshProfile = await fixture.profileId();
	assert.equal(await page.getByLabel("Recovery JSON", { exact: true }).inputValue(), "", "fresh restore does not retain the prior profile input");
	assert.equal(await page.getByLabel("Funding proposal JSON", { exact: true }).inputValue(), "", "fresh restore clears the prior proposal input");
	assert.equal(chain.summary.appSends.length, sendsBeforeRestore, "the entire export/lock/restore sequence performs no physical send");
	assert.equal(fixture.prompts.length, promptsBeforeRestore, "restore opens no sign prompt");
	assert.equal(fixture.walletConnects, connectsBeforeRestore, "restore never reconnects the external wallet");
	let restored = await fixture.vault(), old = restored.intents.find((r) => r.intentId === uncertain.intentId);
	assert.equal(old.originProfileId, originalProfile);
	assert.equal(old.signature, uncertain.signature);
	assert.equal(old.sendMarkedAt, uncertain.sendMarkedAt);
	for (const receipt of restored.documents) assert.equal(receipt.originProfileId, originalProfile);
	assert.deepEqual(restored.proposals, [savedProposal], "fresh-key restore preserves exact proposal payload, binding and original provenance");
	await proposalCard(savedProposal.record.id).getByText("Original provenance preserved after restore", { exact: true }).waitFor();
	assert.equal(await card(ids.absent).count(), 0, "restore never promotes an unfunded proposal to recovery");
	await noAutomaticSend(sendsBeforeRestore, promptsBeforeRestore);
	await connect(ids.rebuild);
	await waitSolanaBrowser(async () => {
		await refresh();
		return (await fixture.vault()).intents.find((r) => r.intentId === uncertain.intentId).state === "dropped";
	}, "definitive original blockhash expiry from finalized ledger history", 24e4, 1500);
	await noAutomaticSend(sendsBeforeRestore, promptsBeforeRestore);
	await prepare(ids.rebuild, "release", true);
	await confirm();
	await settled(ids.rebuild, "released", false);
	restored = await fixture.vault();
	const replacement = restored.intents.find((r) => r.replacementOf === uncertain.intentId);
	assert.equal(replacement.originProfileId, freshProfile);
	assert.notEqual(replacement.signature, uncertain.signature);
	assert.notEqual(replacement.message, uncertain.message);
	assert.equal(restored.intents.find((r) => r.intentId === uncertain.intentId).originProfileId, originalProfile);
	await prepare(ids.rebuild, "payout");
	await confirm();
	await settled(ids.rebuild, "released", true);
	assert.equal(chain.summary.appSends.length, 5);
	pass("fresh-key restore preserves the unknown marker without resending; only finalized expiry and a new explicit review permit replacement");
	const deadline = Number(chain.documents.refund.terms.escrowExpirySeconds);
	console.log(`Waiting for the real finalized Clock to reach refund deadline ${deadline}; no warp or skip is available.`);
	let reported = 0;
	await waitSolana(async () => {
		const now = (await readClock(chain.rpc, "finalized")).unixTimestamp;
		if (Date.now() - reported > 6e4) {
			reported = Date.now();
			console.log(`refund: ${Math.max(0, deadline - now)} real chain seconds remaining`);
		}
		return now >= deadline;
	}, "real minimum-duration refund deadline", 21e5, 15e3);
	assert.equal(await fixture.profileId(), "", "the real idle interval locks the profile while waiting for chain time");
	await unlock(freshProfile, NEW_PASS);
	await connect(ids.refund);
	await refresh();
	assert.deepEqual((await fixture.vault()).proposals, [savedProposal], "real idle lock and explicit unlock retain the original proposal");
	const sellerBefore = await getBalance(chain.rpc, chain.seller, "finalized");
	await prepare(ids.refund, "refund");
	await confirm();
	await settled(ids.refund, "refunded", false);
	await prepare(ids.refund, "payout");
	await confirm();
	await settled(ids.refund, "refunded", true);
	const refundSends = chain.summary.appSends.filter((r) => r.tradeId === ids.refund);
	assert.equal(refundSends.length, 2);
	let fees = 0;
	for (const send of refundSends) {
		const transaction = await chain.rpc.call("getTransaction", [send.signature, {
			commitment: "finalized",
			encoding: "json",
			maxSupportedTransactionVersion: 0
		}]);
		assert.equal(transaction.meta.err, null);
		fees += transaction.meta.fee;
	}
	assert.equal(await getBalance(chain.rpc, chain.seller, "finalized"), sellerBefore + 1e8 - fees);
	assert.equal(chain.summary.appSends.length, 7);
	assert.equal(chain.summary.appSends.filter((r) => r.withheld).length, 1);
	assert.equal(new Set(chain.summary.appSends.map((r) => r.signature)).size, 7);
	assert.equal(fixture.prompts.length, 8, "one revoked prompt plus seven separately confirmed transaction messages");
	assert.deepEqual(fixture.unexpected, []);
	assert.deepEqual(fixture.errors, []);
	assert.deepEqual(chain.summary.fixtureErrors, []);
	pass("real chain time opens refund; separate reviewed refund and payout return original seller principal minus actual fees");
	await page.getByRole("button", {
		name: "Lock profile",
		exact: true
	}).click();
	await waitSolanaBrowser(async () => await fixture.profileId() === "", "final profile lock");
	console.log(JSON.stringify({
		ok: true,
		kind: "SOLANA_LOCAL_BROWSER_PROOF",
		checks,
		durationSeconds: Math.round((Date.now() - began) / 1e3),
		ReleaseEnabled: 0,
		actualModuleWorker: true,
		encryptedIndexedDB: true,
		genesisRpcRewritten: false,
		clockWarped: false,
		originalProfile,
		freshProfile,
		walletConnects: fixture.walletConnects,
		walletPrompts: fixture.prompts,
		...chain.summary,
		publicNetworkQualification: false,
		freshNegotiationQualification: false
	}, null, 2));
} finally {
	await fixture?.close();
}
export {};
