import { c as buildLocalnetContentPolicy, d as inspectApplicationSource, f as inspectArtifactFiles, i as assertQrDecoderModule, l as buildOfflineContentPolicy, n as QR_DECODER_GRAPH, p as safeArtifactPath, r as assertNotQrDecoderModule, s as qrDecoderGraph, u as buildSolanaLocalnetContentPolicy } from "./qr-build-policy-0fAj4LOV.js";
import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import { relative } from "node:path";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
// apps/web/scripts/static-build-plugin.mjs
const escapeAttribute = (value) => value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
function offlinePolicy(delivery) {
	return buildOfflineContentPolicy({
		version: 1,
		releaseId: "local-development",
		delivery
	});
}
/** Localnet build profile only: the offline policy with connect-src naming exactly the injected loopback relay origin. */
function localnetPolicy(delivery, relayOrigin) {
	return buildLocalnetContentPolicy({
		version: 1,
		releaseId: "local-development",
		delivery,
		relayOrigin
	});
}
function policyMarkup(policy) {
	return policy.meta.map((record) => "httpEquiv" in record ? `<meta http-equiv="${record.httpEquiv}" content="${escapeAttribute(record.content)}">` : `<meta name="${record.name}" content="${record.content}">`).join("\n    ");
}
/**
* Module admission (A3). The localnet profile is the ONLY profile with exceptions: the reviewed EVM wallet modules,
* chain-evm, relay (its WebSocket( token only in packages/relay/src/pool.ts), exchange, the three localnet facades, the
* apps/web/src/localnet subtree and the @noble/{curves,hashes,ciphers} dependencies. Every other profile keeps the prior
* rules and additionally refuses each localnet-only module, so a default/demo/testnet build that reached one fails.
*/
const LOCALNET_WALLET_MODULES = /^packages\/wallet\/src\/evm-(?:adapter|terms|submit|escrow|payment-preflight|peer-acceptance|peer-envelope|peer-replay|peer-verifier|peer-port)\.ts$/;
const LOCALNET_ONLY_MODULES = [
	LOCALNET_WALLET_MODULES,
	/^packages\/(?:wallet|domain|chain-evm)\/localnet\.ts$/,
	/^packages\/(?:chain-evm|relay|exchange)\//,
	/^apps\/web\/src\/localnet\//
];
const LOCALNET_DEPENDENCIES = /^node_modules\/@noble\/(?:curves|hashes|ciphers)\//;
const PERSONALIZATION_WORKER_MODULES = /* @__PURE__ */ new Set([
	"packages/personalization/favorites.ts",
	"packages/personalization/src/favorites.ts",
	"packages/personalization/templates.ts",
	"packages/personalization/src/trade-draft-store.ts"
]);
/** Throws NON_CORE_MODULE / UNREVIEWED_DEPENDENCY for a repository-relative module path the profile does not admit. */
function assertModuleAdmitted(path, localnet = false, solanaLocalnet = false, privateWorker = false) {
	assertNotQrDecoderModule(path);
	if (localnet && solanaLocalnet) throw new Error("LOCALNET_PROFILE_EXCLUSIVE");
	if (/(?:^|\/)packages\/personalization(?:\/|$)/.test(path) && (!privateWorker || !PERSONALIZATION_WORKER_MODULES.has(path))) throw new Error("NON_CORE_MODULE");
	if (solanaLocalnet) {
		if (path.startsWith("../") || /(?:^|\/)(?:test|tests|fixtures)(?:\/|$)/.test(path) || /(?:^|\/)packages\/(?:extensions|chain-evm|relay|exchange|wallet)(?:\/|$)|(?:^|\/)(?:05_ADVANCED|06_)/i.test(path) || /^apps\/web\/src\/localnet\//.test(path)) throw new Error("NON_CORE_MODULE");
		if (/(?:^|\/)packages\/chain-solana\//.test(path) && !/^packages\/chain-solana\//.test(path)) throw new Error("NON_CORE_MODULE");
		if (/^packages\/[^/]+\/localnet\.ts$/.test(path) && path !== "packages/chain-solana/localnet.ts") throw new Error("NON_CORE_MODULE");
		if (path.startsWith("node_modules/") && !/^node_modules\/(?:react|react-dom|scheduler)\//.test(path) && !LOCALNET_DEPENDENCIES.test(path)) throw new Error(`UNREVIEWED_DEPENDENCY: ${path}`);
		return;
	}
	if (/^apps\/web\/src\/solana-localnet\//.test(path)) throw new Error("NON_CORE_MODULE");
	if (localnet) {
		if (/^packages\/wallet\/src\/evm-/.test(path) && !LOCALNET_WALLET_MODULES.test(path)) throw new Error("NON_CORE_MODULE");
		const evmOrRelay = /(?:^|\/)packages\/(?:chain-evm|relay)(?:\/|$)/.test(path) && !/^packages\/(?:chain-evm|relay)\//.test(path);
		if (path.startsWith("../") || /(?:^|\/)(?:test|tests|fixtures)(?:\/|$)/.test(path) || evmOrRelay || /(?:^|\/)packages\/(?:extensions|chain-solana)(?:\/|$)|(?:^|\/)(?:05_ADVANCED|06_)/i.test(path)) throw new Error("NON_CORE_MODULE");
		if (/^packages\/[^/]+\/localnet\.ts$/.test(path) && !LOCALNET_ONLY_MODULES[1].test(path)) throw new Error("NON_CORE_MODULE");
		if (path.startsWith("node_modules/") && !/^node_modules\/(?:react|react-dom|scheduler)\//.test(path) && !LOCALNET_DEPENDENCIES.test(path)) throw new Error(`UNREVIEWED_DEPENDENCY: ${path}`);
		return;
	}
	if (LOCALNET_ONLY_MODULES.some((pattern) => pattern.test(path))) throw new Error("NON_CORE_MODULE");
	if (/^packages\/wallet\/src\/evm-(?:execution|adapter|terms)\.ts$/.test(path)) throw new Error("NON_CORE_MODULE");
	if (path.startsWith("../") || /(?:^|\/)(?:test|tests|fixtures)(?:\/|$)/.test(path) || /(?:^|\/)packages\/(?:extensions|chain-evm|chain-solana|relay)(?:\/|$)|(?:^|\/)(?:05_ADVANCED|06_)/i.test(path)) throw new Error("NON_CORE_MODULE");
	if (path.startsWith("node_modules/") && !/^node_modules\/(?:react|react-dom|scheduler)\//.test(path)) throw new Error(`UNREVIEWED_DEPENDENCY: ${path}`);
}
function localnetProfile(localnet) {
	if (localnet === null || localnet === void 0) return null;
	if (typeof localnet !== "object" || Object.getPrototypeOf(localnet) !== Object.prototype || Object.keys(localnet).join() !== "relayOrigin") throw new Error("LOCALNET_PROFILE_INVALID");
	return Object.freeze({ relayOrigin: localnet.relayOrigin });
}
/**
* Runs for document and native Worker builds; records real bundler module graphs. `localnet` ({ relayOrigin }) is set
* only by the library-only localnet build (apps/web/vite.config.ts createViteConfig); every other build omits it.
*/
function staticBuildPlugin(repositoryRoot, delivery = "meta", worker = false, localnet = null, solanaLocalnet = null) {
	const profile = localnetProfile(localnet);
	if (profile && solanaLocalnet) throw new Error("LOCALNET_PROFILE_EXCLUSIVE");
	if (solanaLocalnet !== null && (typeof solanaLocalnet !== "object" || Object.getPrototypeOf(solanaLocalnet) !== Object.prototype || Object.keys(solanaLocalnet).join() !== "rpcOrigin")) throw new Error("SOLANA_LOCALNET_PROFILE_INVALID");
	const solanaPolicy = (level) => buildSolanaLocalnetContentPolicy({
		version: 1,
		releaseId: "local-development",
		delivery: level,
		rpcOrigin: solanaLocalnet.rpcOrigin
	});
	const policy = solanaLocalnet ? solanaPolicy(delivery) : profile ? localnetPolicy(delivery, profile.relayOrigin) : offlinePolicy(delivery);
	return {
		name: `p2p-offline-static-${worker ? "worker" : "document"}`,
		apply: "build",
		enforce: "post",
		transformIndexHtml: {
			order: "post",
			handler(html) {
				if (!html.includes("<!-- OFFLINE_CONTENT_POLICY -->")) throw new Error("POLICY_PLACEHOLDER_MISSING");
				const protectedHtml = html.replace("<!-- OFFLINE_CONTENT_POLICY -->", policyMarkup(policy));
				if (delivery === "meta" && protectedHtml.indexOf("http-equiv=\"Content-Security-Policy\"") > protectedHtml.search(/<(?:script|link|img)\b/i)) throw new Error("POLICY_ORDER");
				return protectedHtml;
			}
		},
		async generateBundle(_options, bundle) {
			const modules = [];
			const repositoryPath = (id) => typeof id === "string" ? relative(repositoryRoot, id.split("?")[0]).replaceAll("\\", "/") : "";
			const qrDecoder = worker && [...this.getModuleIds()].some((id) => repositoryPath(id) === "apps/web/src/qr/decode.worker.ts");
			if (qrDecoder && (profile !== null || solanaLocalnet !== null)) throw new Error("QR_DECODER_SCOPE");
			for (const id of this.getModuleIds()) {
				const info = this.getModuleInfo(id);
				if (!info || info.isExternal) throw new Error("EXTERNAL_MODULE");
				if (id.startsWith("\0") || id.startsWith("vite/") || id.startsWith("rolldown:")) continue;
				const clean = id.split("?")[0];
				const path = relative(repositoryRoot, clean).replaceAll("\\", "/");
				if (qrDecoder) assertQrDecoderModule(path);
				else assertModuleAdmitted(path, profile !== null, solanaLocalnet !== null, worker);
				if (!/\.(?:[cm]?[jt]sx?|css|html)$/.test(clean)) throw new Error("UNREVIEWED_MODULE_TYPE");
				const source = await readFile(clean, "utf8");
				if ((!path.startsWith("node_modules/") || qrDecoder) && /\.[jt]sx?$/.test(clean)) inspectApplicationSource(path, source, {
					allowWebSocketConstructor: profile !== null && path === "packages/relay/src/pool.ts",
					allowFetch: solanaLocalnet !== null && worker && path === "apps/web/src/solana-localnet/rpc.ts"
				});
				modules.push({
					path,
					sha256: createHash("sha256").update(source).digest("hex")
				});
			}
			modules.sort((a, b) => a.path.localeCompare(b.path, "en"));
			const graph = qrDecoder ? qrDecoderGraph(modules, bundle, repositoryPath) : {
				version: 1,
				scope: worker ? "native-worker" : "document",
				modules,
				frameworkDomInternals: "React DOM contains internal HTML sink code. Application token checks and browser hostile-text probes are separate evidence.",
				completeXssProof: false
			};
			this.emitFile({
				type: "asset",
				fileName: qrDecoder ? QR_DECODER_GRAPH : worker ? "core-graph-worker.json" : "core-graph-document.json",
				source: JSON.stringify(graph, null, 2) + "\n"
			});
			if (!worker) {
				this.emitFile({
					type: "asset",
					fileName: "content-policy.json",
					source: JSON.stringify({
						...policy,
						releaseAcceptance: false,
						ReleaseEnabled: 0
					}, null, 2) + "\n"
				});
				const headerPolicy = solanaLocalnet ? solanaPolicy("header") : profile ? localnetPolicy("header", profile.relayOrigin) : offlinePolicy("header");
				this.emitFile({
					type: "asset",
					fileName: "_headers",
					source: "/*\n" + Object.entries(headerPolicy.headers).map(([name, value]) => `  ${name}: ${value}`).join("\n") + "\n"
				});
			}
			inspectArtifactFiles(Object.fromEntries(Object.entries(bundle).map(([name, file]) => [safeArtifactPath(name), file.type === "chunk" ? file.code : typeof file.source === "string" ? file.source : Buffer.from(file.source).toString("utf8")])));
		}
	};
}
// apps/web/src/ui/locale/catalog.ts
/** Plain-text source profile: {name}, count-only {name|one text|other text}, or named
* count branches {name|zero=text|one=text|two=text|few=text|many=text|other=text}.
* No nesting, escapes, markup, arbitrary formatter, full ICU grammar or executable translations.
* This module formats display text only. Canonical amounts, signed bytes and stored data never enter it for parsing.
*/
const LOCALE_TARGETS = Object.freeze([
	"en",
	"fr",
	"es",
	"pt-BR",
	"de",
	"it",
	"nl",
	"ar",
	"hi",
	"zh-Hans",
	"zh-Hant",
	"ja",
	"ko",
	"id",
	"tr",
	"ru",
	"uk",
	"vi",
	"th"
]);
function localeDirection(locale) {
	if (!LOCALE_TARGETS.includes(locale)) throw new LocaleError("LOCALE_INCOMPLETE");
	return locale === "ar" ? "rtl" : "ltr";
}
var LocaleError = class extends Error {
	code;
	constructor(code) {
		super("The message or locale is unavailable.");
		this.name = "LocaleError";
		this.code = code;
	}
};
const refuse = (code = "MESSAGE_VARIABLE_MISMATCH") => {
	throw new LocaleError(code);
};
const purposes = [
	"text",
	"identifier",
	"count",
	"date",
	"base-unit amount",
	"currency",
	"chain",
	"duration",
	"address"
];
const names = /^[A-Za-z][A-Za-z0-9]*$/;
const identifiers = /^[A-Za-z0-9][A-Za-z0-9._:/-]*$/;
const unsafe = /[\u0000-\u0008\u000b-\u001f\u007f-\u009f\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069\ud800-\udfff]/u;
const visible = /(?![\p{Default_Ignorable_Code_Point}\u2800])[\p{L}\p{N}\p{P}\p{S}]/u;
const lettered = /(?![\p{Default_Ignorable_Code_Point}\u2800])[\p{L}\p{N}]/u;
/**
* Visibility is judged on the message's own text, never on placeholder syntax ({, |, =) or variable values: every
* count branch must be visible, and every rendering must show `test` either in the literal text or in a count part
* whose branches all pass it. So `{x}`, `{n|one=\u200b|other=\u200b}` and invisible literals are refused.
*/
function ownText(compiledParts, test) {
	const literals = compiledParts.filter((part) => typeof part === "string").join("");
	return test.test(literals) || compiledParts.some((part) => typeof part !== "string" && part.forms !== void 0 && Object.values(part.forms).every((form) => test.test(form)));
}
/** Explicit numeral policy for the bundled Arabic display profile. Canonical numeric parsing never uses it. */
function localeFormattingTag(locale) {
	if (!LOCALE_TARGETS.includes(locale)) return refuse("LOCALE_INCOMPLETE");
	return locale === "ar" ? "ar-u-nu-arab" : locale;
}
const compiled = /* @__PURE__ */ new WeakMap();
function data(value, keys, code = "MESSAGE_VARIABLE_MISMATCH") {
	if (!value || typeof value !== "object" || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) return refuse(code);
	const own = Reflect.ownKeys(value);
	if (own.length !== keys.length || own.some((key) => typeof key !== "string" || !keys.includes(key))) return refuse(code);
	const copy = Object.create(null);
	for (const key of keys) {
		const d = Object.getOwnPropertyDescriptor(value, key);
		if (!d || !d.enumerable || !("value" in d)) return refuse(code);
		copy[key] = d.value;
	}
	return copy;
}
function plain(value, max = 8192) {
	return typeof value === "string" && value.length <= max && !unsafe.test(value);
}
function parts(source, variables) {
	const result = [], used = /* @__PURE__ */ new Set();
	let from = 0;
	for (const match of source.matchAll(/\{([^{}]*)\}/g)) {
		const literal = source.slice(from, match.index);
		if (/[{}]/.test(literal)) return refuse();
		result.push(literal);
		const tokens = match[1].split("|"), name = tokens[0];
		if (!names.test(name) || !Object.hasOwn(variables, name) || tokens.length > 7 || tokens.length > 1 && variables[name] !== "count") return refuse();
		used.add(name);
		if (tokens.length === 1) result.push(Object.freeze({ name }));
		else {
			const forms = Object.create(null);
			if (tokens.length === 3 && !tokens[1].includes("=") && !tokens[2].includes("=")) {
				forms.one = tokens[1];
				forms.other = tokens[2];
			} else for (const branch of tokens.slice(1)) {
				const match = /^(zero|one|two|few|many|other)=(.+)$/s.exec(branch);
				if (!match || Object.hasOwn(forms, match[1])) return refuse();
				forms[match[1]] = match[2];
			}
			if (!forms.other) return refuse();
			result.push(Object.freeze({
				name,
				forms: Object.freeze(forms)
			}));
		}
		from = match.index + match[0].length;
	}
	const tail = source.slice(from);
	if (/[{}]/.test(tail) || used.size !== Object.keys(variables).length) return refuse();
	result.push(tail);
	return Object.freeze(result);
}
/** Constructs a detached frozen entry; foreign accessors/toJSON are never evaluated. */
function createMessage(input) {
	try {
		const raw = data(input, [
			"key",
			"source",
			"context",
			"severity",
			"variables",
			"reviewRequired",
			"docsAnchor"
		]);
		if (!plain(raw.key, 160) || !/^[A-Za-z][A-Za-z0-9]*(?:\.[A-Za-z][A-Za-z0-9_]*)+$/.test(raw.key) || !plain(raw.source) || !visible.test(raw.source) || /[<>]/.test(raw.source) || !plain(raw.context, 500) || !raw.context || ![
			"information",
			"warning",
			"critical"
		].includes(raw.severity) || typeof raw.reviewRequired !== "boolean" || !plain(raw.docsAnchor, 500) || !/^[A-Za-z0-9_./-]+\.md(?:#[A-Za-z0-9-]+)?$/.test(raw.docsAnchor)) return refuse();
		if (!raw.variables || typeof raw.variables !== "object") return refuse();
		const keys = Reflect.ownKeys(raw.variables);
		if (keys.length > 8 || keys.some((key) => typeof key !== "string" || !names.test(key))) return refuse();
		const values = data(raw.variables, keys), variables = Object.create(null);
		for (const key of keys) {
			if (!purposes.includes(values[key])) return refuse();
			variables[key] = values[key];
		}
		const entry = Object.freeze({
			key: raw.key,
			source: raw.source,
			context: raw.context,
			severity: raw.severity,
			variables: Object.freeze(variables),
			reviewRequired: raw.reviewRequired,
			docsAnchor: raw.docsAnchor
		});
		const compiledParts = parts(entry.source, entry.variables);
		if (compiledParts.some((part) => typeof part !== "string" && part.forms !== void 0 && Object.values(part.forms).some((form) => !visible.test(form))) || !ownText(compiledParts, visible) || entry.severity === "critical" && !ownText(compiledParts, lettered)) return refuse();
		compiled.set(entry, compiledParts);
		return entry;
	} catch {
		return refuse();
	}
}
function displayValue(purpose, value) {
	if (purpose === "count") return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 ? String(value) : refuse();
	if (purpose === "date") return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && value <= 864e13 ? new Date(value).toISOString() : refuse();
	if (!plain(value, 4096)) return refuse();
	if (purpose === "base-unit amount" || purpose === "duration") {
		if (!/^(0|[1-9][0-9]{0,77})$/.test(value)) return refuse();
	} else if (purpose === "currency") {
		if (!/^[A-Z]{3}$/.test(value)) return refuse();
	} else if (purpose === "address") {
		if (!/^(?:0x[0-9a-fA-F]{40}|[1-9A-HJ-NP-Za-km-z]{32,44})$/.test(value)) return refuse();
	} else if (purpose === "identifier" || purpose === "chain") {
		if (!identifiers.test(value)) return refuse();
	}
	return value;
}
function formatMessage(entry, values, options) {
	try {
		const tokens = compiled.get(entry);
		if (!tokens) return refuse();
		const raw = data(values, Object.keys(entry.variables)), display = Object.create(null);
		const locale = options?.locale ?? "en", tag = localeFormattingTag(locale);
		const number = new Intl.NumberFormat(tag, {
			useGrouping: false,
			maximumFractionDigits: 0
		});
		const plural = new Intl.PluralRules(tag);
		for (const name of Object.keys(entry.variables)) {
			const purpose = entry.variables[name], checked = displayValue(purpose, raw[name]);
			const machine = [
				"identifier",
				"base-unit amount",
				"currency",
				"chain",
				"duration",
				"address"
			].includes(purpose);
			display[name] = purpose === "count" ? number.format(raw[name]) : purpose === "date" && locale !== "en" ? new Intl.DateTimeFormat(tag, {
				year: "numeric",
				month: "short",
				day: "numeric",
				hour: "2-digit",
				minute: "2-digit",
				second: "2-digit",
				timeZone: "UTC",
				timeZoneName: "short",
				hourCycle: "h23"
			}).format(raw[name]) : localeDirection(locale) === "rtl" && machine ? `\u2066${checked}\u2069` : checked;
		}
		const text = tokens.map((part) => typeof part === "string" ? part : part.forms === void 0 ? display[part.name] : part.forms[plural.select(raw[part.name])] ?? part.forms.other).join("");
		if (text.length > 16384) return refuse();
		return text;
	} catch {
		return refuse();
	}
}
// apps/web/src/ui/locale/en.ts
/** Single English source. Every entry requires translation review; this is draft source copy, not a published safety locale. */
const definitions = {
	"updates": {
		"title": "Signed asset updates",
		"intro": "A release check prepares a review of signed public assets. Opening a different origin is a separate, explicit confirmation.",
		"unconfigured": "Update checking is not configured in this build. No distribution key, discovery source or destination is selected by this page.",
		"configuredScope": "This page uses the update controller supplied by this build. Its trust, transport, backup and wallet checks must all succeed before an origin transition.",
		"check": "Check for a signed update",
		"cancel": "Discard update review",
		"backupAction": "Open backup and recovery tools",
		"checking": "Checking the configured signed release and its assets…",
		"accepting": "Rechecking the candidate, current backup and wallet before the origin transition…",
		"none": "No newer verified candidate was found for the configured release.",
		"untrusted": "The update could not be authenticated against this build’s trusted release identities.",
		"stale": "The release is expired or older than the accepted release sequence. The installed client remains available.",
		"unreachable": "The update check is unavailable or timed out. The installed client remains available; no automatic retry is scheduled.",
		"cancelled": "The local update review was discarded. Start a new check before confirming a transition.",
		"accepted": "The origin transition was requested. This page cannot confirm that the destination loaded; recovery there requires an explicit restore.",
		"failed": "The update check did not complete. No candidate is available to confirm.",
		"acceptFailed": "The origin transition was not confirmed. Its accepted sequence may already be stored. A new check is required before another confirmation.",
		"backupRequired": "Verify the current unlocked profile’s backup file in the recovery tools. Acceptance checks the current persisted revision again; a displayed receipt alone is insufficient.",
		"busy": "Another update or wallet operation is still pending. Finish or cancel it, then request a new check.",
		"routeBlocked": "The configured transport policy does not allow this update operation. This page does not choose a fallback route or gateway.",
		"schemaBlocked": "The candidate does not support this build’s storage schema.",
		"storageBlocked": "The accepted release sequence could not be safely read or committed. The stored record is not reset by this page.",
		"originBlocked": "The candidate destination does not match the supported configured origin profile.",
		"limitExceeded": "The update exceeded the supported size or operation limits.",
		"reviewTitle": "Review the verified public release identities",
		"currentTitle": "Installed release",
		"candidateTitle": "Candidate release",
		"releaseId": "Release ID",
		"sequence": "Release sequence",
		"manifestDigest": "Manifest SHA-256",
		"keyFingerprint": "Distribution key fingerprint",
		"sourceCommit": "Source commit",
		"predecessor": "Predecessor manifest SHA-256",
		"noPredecessor": "No predecessor declared",
		"minSchema": "Minimum supported storage schema",
		"maxSchema": "Maximum supported storage schema",
		"destination": "Full destination origin",
		"changesAbsent": "The signed manifest supplies asset identities. It does not supply signed human release notes or a description of changes.",
		"freshOrigin": "No accepted release record was present on this origin. Local state cannot establish a maximum sequence accepted on another origin or before storage was cleared.",
		"assetsSummary": {
			"source": "Inspect {count} verified {count|asset|assets}",
			"variables": { "count": "count" }
		},
		"assetPath": "Asset path",
		"assetBytes": "Exact byte length",
		"assetDigest": "Asset SHA-256",
		"recoveryRequired": "The new origin has separate local storage. Keep a verified current backup and restore it explicitly there with fresh vault keys. No profile, passphrase, session or backup is transferred by this transition.",
		"disabled": "This review does not enable trading, approve deployments or qualify a production release.",
		"consent": "I reviewed the destination, release identities, assets, schema range and recovery requirement. I want a fresh backup check, wallet disconnection and profile lock before opening this destination.",
		"accept": "Confirm this reviewed origin transition"
	},
	"qr": {
		"title": "Public QR tools",
		"intro": "Display or inspect a public code locally. Confirming a review does not connect a wallet, negotiate a trade, prepare a payment or restore a backup.",
		"physical": "Physical phone, camera and printed-code support is not yet qualified. Exact text and local file input remain available.",
		"chainScope": "Chain-bound codes are accepted only for networks in your current registry-reviewed terms. This page does not authenticate a counterparty or establish a trade session.",
		"captureTitle": "Read a code",
		"cameraStart": "Start camera",
		"cameraCapture": "Scan one camera frame",
		"cameraStop": "Stop camera",
		"cameraPreview": "Local camera preview",
		"cameraPending": "Waiting for the camera permission request to finish…",
		"cameraHelp": "Camera access starts only after you choose it. Scanning a frame stops the preview. Leaving, hiding or changing this profile stops every camera track.",
		"imageFile": "PNG or JPEG containing one public code",
		"imageRead": "Read selected image",
		"imageLimits": "PNG or JPEG only: at most 2 MiB and 2 million pixels. Animated images and SVG are refused.",
		"text": "Exact public QR text",
		"textRead": "Review exact text",
		"textHelp": "Paste the complete P2POFFRAMP code without trimming spaces or adding line breaks.",
		"publicFile": "Public QR text file",
		"publicFileRead": "Read selected public text file",
		"fileLimits": "Public text files are limited to 64 KiB; the decoded envelope is limited to 2,048 bytes.",
		"fingerprintTitle": "Create a file fingerprint",
		"fingerprintFile": "Local encrypted backup or private reference file",
		"fingerprintFormat": "Selected file format",
		"formatBackup": "Encrypted backup v1",
		"formatReferences": "Offline recovery references v1",
		"fingerprintCreate": "Review a fingerprint of this file",
		"fingerprintHelp": "Only the exact byte length, file format and SHA-256 appear in the public code. The file contents and filename are excluded. A fingerprint does not authenticate the file or prove that recovery will work.",
		"busy": "Checking local QR data…",
		"cancel": "Discard QR data and stop capture",
		"reviewTitle": "Review the full public code",
		"unauthenticated": "Unauthenticated public data",
		"signatureAbsent": "No signature",
		"signatureUnverified": "Signature present, not verified",
		"inviteOpen": "The invite signing-key profile is unresolved. This code cannot create an authenticated trade session or replace accepted terms.",
		"confirm": "Confirm this local review",
		"confirmed": "Reviewed locally. No wallet, trade or recovery authority is granted.",
		"display": "Display reviewed QR symbol",
		"symbolLabel": "Reviewed public QR symbol with a four-module quiet zone",
		"generationTarget": "Large codes may be difficult to scan. Use exact text if a device cannot read this symbol.",
		"copy": "Copy reviewed public text",
		"copied": "Reviewed public text copied.",
		"copyUnavailable": "Clipboard access is unavailable. Download the exact public text instead.",
		"download": "Download reviewed public text",
		"compareTitle": "Compare a local file",
		"compareFile": "File to compare with the reviewed fingerprint",
		"compare": "Compare exact file bytes",
		"compareHelp": "Comparison reads the selected file locally and checks its byte length and SHA-256. It never decrypts, imports, restores or sends the file.",
		"match": "File length and SHA-256 match. Authenticity, content and recovery status remain unverified.",
		"different": "The file length or SHA-256 differs from the reviewed public code.",
		"noExpiry": "No expiry",
		"expiryAdvisory": "Expiry is advisory because this code is unauthenticated.",
		"origin": "Untrusted origin hint, displayed only"
	},
	"qrTypes": {
		"public_address": "Public address",
		"payment_request": "Payment request",
		"trade_invite": "Trade invite",
		"release_fingerprint": "Release fingerprint",
		"recovery_fingerprint": "Recovery-file fingerprint"
	},
	"qrFields": {
		"type": "Code type",
		"authentication": "Authentication",
		"signature": "Signature state",
		"signature_profile": "Unverified signature profile",
		"request_id": "Request ID",
		"created_at": "Created at (Unix seconds)",
		"expires_at": "Expires at (Unix seconds)",
		"chain": "Chain identity",
		"address": "Full public address",
		"recipient": "Full recipient address",
		"asset": "Asset",
		"amount_base_units": "Exact amount in base units",
		"advertisement_author": "Advertisement author",
		"order_id": "Order ID",
		"terms_hash": "Terms hash",
		"channel": "Release channel",
		"release_id": "Release ID",
		"sequence": "Release sequence",
		"manifest_sha256": "Manifest SHA-256",
		"format": "File format",
		"byte_length": "Exact file byte length",
		"sha256": "File SHA-256",
		"payload_sha256": "Payload SHA-256 (integrity only)"
	},
	"qrWarnings": {
		"unauthenticated": "The code is unauthenticated.",
		"unsigned_invite": "This invite has no signature.",
		"no_invite_verifier": "No accepted invite signature verifier is configured.",
		"signature_profile_unknown": "The signature profile is unknown.",
		"expiry_advisory": "The sender chose this unauthenticated expiry.",
		"origin_hint_display_only": "The origin hint is text only; it is not a trusted destination.",
		"payload_hash_is_not_authentication": "A matching payload hash does not authenticate its author.",
		"invite_requires_terms_revalidation": "An invite cannot replace a fresh check of authenticated terms.",
		"payment_request_is_not_escrow_funding": "A payment request does not authorize escrow funding.",
		"address_ownership_unverified": "Ownership of this address is unverified.",
		"release_fingerprint_requires_release_verification": "A release fingerprint does not verify a release signature.",
		"recovery_fingerprint_is_not_a_download": "A recovery fingerprint cannot download or restore a file."
	},
	"qrErrors": {
		"BUSY": "An earlier camera, file or decoder operation is still finishing. Wait before trying again.",
		"CANCELLED": "The local QR operation was discarded.",
		"CONTEXT_CHANGED": "The profile or trusted network context changed. Read the code again.",
		"REVIEW_REQUIRED": "Read and confirm a fresh local review first.",
		"FILE_TOO_LARGE": "The selected file exceeds its local size limit.",
		"FILE_FORMAT": "The file does not match the selected backup or recovery-reference format.",
		"IMAGE_TOO_LARGE": "The image exceeds the local byte or pixel limit.",
		"IMAGE_FORMAT": "Use one complete, non-animated PNG or JPEG image.",
		"NO_CODE": "No readable QR code was found. Try a clearer image or exact text.",
		"MULTIPLE_CODES": "More than one code was detected. Select an image containing only the intended code.",
		"CAMERA_UNAVAILABLE": "Camera access or preview is unavailable. Use a selected image, exact text or public file.",
		"DECODE_TIMEOUT": "Image decoding exceeded its time limit and was stopped. Try a smaller, clearer image or exact text.",
		"DECODER_PROTOCOL": "The local decoder returned an invalid response and was stopped.",
		"QR_TOO_LARGE": "The public code exceeds the QR envelope size limit.",
		"FORMAT_UNSUPPORTED": "This is not a supported P2POFFRAMP public code.",
		"URL_REFUSED": "A URL cannot be imported as a public QR envelope.",
		"WALLET_SESSION_REFUSED": "Wallet-session codes are not accepted here.",
		"SECRET_REFUSED": "Secret-bearing content is refused.",
		"VERSION_UNSUPPORTED": "This QR version is unsupported.",
		"INVALID_ENCODING": "The exact QR text encoding is invalid.",
		"INVALID_UNICODE": "The input contains invalid text encoding.",
		"INVALID_JSON": "The public envelope is not valid strict JSON.",
		"NON_CANONICAL": "The envelope is not in the required canonical form.",
		"PROTOCOL_UNSUPPORTED": "The envelope names an unsupported protocol.",
		"TYPE_UNSUPPORTED": "The public code type is unsupported.",
		"FIELD_UNSUPPORTED": "The envelope contains an unsupported field.",
		"INVALID_ENVELOPE": "The public envelope is invalid.",
		"INVALID_PAYLOAD": "The public payload is invalid.",
		"CHAIN_UNSUPPORTED": "This chain is not in the current trusted review context.",
		"CHAIN_MISMATCH": "This code is for a different selected chain.",
		"HASH_MISMATCH": "The payload hash does not match.",
		"SIGNATURE_UNSUPPORTED": "This signature form is unsupported.",
		"SIGNATURE_INVALID": "The signature check failed.",
		"SIGNATURE_REQUIRED": "A required signature is missing.",
		"PROFILE_UNSUPPORTED": "The signature profile is unsupported.",
		"EXPIRED": "The code has expired or is too close to expiry. Obtain a new code.",
		"NOT_YET_VALID": "The code is dated too far in the future.",
		"LIFETIME_EXCEEDED": "The code has an unsupported lifetime.",
		"INVALID_INPUT": "The local QR input is invalid.",
		"UNAVAILABLE": "The local QR check is unavailable.",
		"REPLAYED": "This request was already confirmed in this page session.",
		"REPLAY_LEDGER_FULL": "The local replay ledger is full. No further confirmation was recorded.",
		"LOCAL_LIMIT_REACHED": "The local candidate limit was reached. Wait one minute before trying again."
	},
	compatibility: {
		readOnlyTitle: "Read-only browser mode",
		readOnlyHelp: "A required browser feature is missing or blocked. Local private operations cannot start here.",
		missingFeatures: {
			source: "Missing or unavailable: {features}.",
			variables: { features: "text" }
		},
		secureContext: "secure browser context",
		encryption: "browser encryption",
		processing: "isolated local processing",
		storage: "encrypted local storage",
		fileImport: "file import",
		fileExport: "encrypted file download",
		recoveryTitle: "Recovery remains available",
		runtimeFailure: "The browser exposes the required features, but local services could not start. Follow the operation error and recovery guidance.",
		recoveryHelp: "Preserve this browser’s encrypted data and any backup. Read recovery guidance before changing browser, device or origin.",
		recoveryLink: "Read recovery guidance",
		qualificationWarning: "This local feature check does not verify wallet or device support. Browser storage can still be blocked or lost."
	},
	privacy: {
		policyTitle: "Transport policy for brokered app connections",
		policyIntro: "Choose a policy for the app connections listed below.",
		policyOrdinary: "Ordinary",
		policyStrict: "Strict",
		policyApply: "Apply policy",
		policyRelaxConsent: "I choose Ordinary and understand that explicitly permitted direct connections may be used.",
		policySelected: "Selected policy",
		policyUnavailable: "No transport policy is available from this connection owner.",
		policyLoading: "Reading the current transport policy…",
		policyBusy: "Applying the selected transport policy…",
		policyChanged: "The connection owner or policy changed. Read the current policy before trying again.",
		policyUnknownCoverage: "Selecting Strict does not prove private routing. RPC and external wallet routing remain unknown unless separately observed.",
		policyChannels: "Connections controlled by this policy",
		policyNoChannels: "No brokered connections are configured.",
		policyBytesSent: "A policy change cannot retract bytes already sent. Existing connections may still be closing.",
		policyRetry: "Read current policy",
		"detailsTitle": "Configured endpoint origins",
		"detailsIntro": "Configuration identifies a destination. It does not verify private routing.",
		"detailsUnknown": "No current trusted endpoint configuration is available.",
		"configuredOrigin": "Configured origin",
		"connectionOrigin": "Browser connection origin",
		"endpointId": "Endpoint identifier",
		"endpointSource": "Bundled connection configuration",
		"endpointGeneration": "Configuration generation",
		"endpointExpiry": "Configuration expiry on this session’s monotonic clock",
		"walletUnknown": "External wallet routing is unknown and may use connections outside this app.",
		"signingTitle": "Review the actual wallet request",
		"signingIntro": "Confirm this current request before the app asks the wallet to sign or send. Privacy observations do not authorize spending.",
		"signingAction": "Requested action",
		"signingProvider": "Selected wallet provider",
		"signingRole": "Signing role",
		"signingDestination": "Request destination",
		"signingValue": "Native value in canonical base units",
		"signingSpender": "Token allowance spender",
		"signingExtensions": "Agreed extensions",
		"signingNoExtensions": "No optional extensions",
		"signingProfile": "Current local profile",
		"signingExpiry": "Review expiry on this session’s monotonic clock",
		"signingConfirm": "Confirm the reviewed wallet request",
		"signingDiscard": "Discard this review",
		"signingExpired": "This wallet-request review expired. Review the current request again.",
		"signingReview": "Review privacy and the wallet request",
		"signingChanged": "The wallet-request review changed or was revoked. Review it again before confirming.",
		title: "Independent privacy observations",
		intro: "These local observations do not verify anonymity, encrypted messaging or payment settlement.",
		selected: "Selected policy",
		observed: "Observed state",
		source: "Evidence source",
		reason: "Observation reason",
		noPolicy: "No network policy selected",
		none: "No trusted observation",
		unknown: "Unknown",
		unavailable: "Unavailable",
		unsupported: "Unsupported",
		ordinary: "Ordinary",
		strict: "Strict",
		direct: "Direct connection",
		privateRoute: "Verified private route",
		blocked: "Blocked by policy",
		rpc: "RPC channel",
		relay: "Relay channel",
		map: "Map channel",
		proofChannel: "Proof channel",
		update: "Update channel",
		wallet: "Wallet channel",
		vault: "Local vault",
		messaging: "Message encryption",
		proof: "Proof availability",
		locked: "Locked",
		unlocked: "Unlocked",
		authenticated: "Authenticated encryption observed",
		available: "Available",
		localVault: "Local vault service inspection",
		transport: "Live transport policy inspection",
		messagingProvider: "Trusted messaging service",
		proofProvider: "Trusted proof service",
		notObserved: "Not observed",
		observedReason: "Fresh observation",
		expired: "Observation expired",
		invalid: "Observation rejected",
		scopeChanged: "Local scope changed",
		clockReversed: "Monotonic clock reversed",
		policyBlocked: "Selected or observed policy blocks direct transport",
		chainTitle: "Public chain visibility",
		chainWarning: "Public chain transactions reveal metadata. Local vault encryption and private routing do not make chain activity anonymous.",
		fiatTitle: "Manual fiat settlement",
		fiatWarning: "Fiat receipt depends on seller attestation. Proof availability does not prove that a payment is irreversible.",
		authorityWarning: "Display only. These observations cannot enable trading, prepare transactions or authorize spending.",
		time: {
			source: "Inspected at {milliseconds} milliseconds on this session’s monotonic clock. This is not a wall-clock timestamp.",
			variables: { milliseconds: "text" }
		},
		refresh: "The local vault is inspected again when its observation expires, vault status or selection changes, or this page becomes visible again. Network, messaging and proof services are not connected in this shell.",
		noTime: "No evidence timestamp is available.",
		error: "Privacy observations are unavailable. No privacy coverage or transaction authority is established."
	},
	analytics: {
		"title": "Local screen counts",
		"help": "These optional counts stay in this page’s memory and describe screen views, not completed trades or payments. They include no route IDs, amounts or timestamps. Locking, leaving or reloading clears them. Export only if you want to keep a copy.",
		"off": "Screen counts are off.",
		"on": "Screen counts are on for this page session.",
		"unavailable": "Screen counting is unavailable.",
		"optIn": "Start local screen counts",
		"optOut": "Stop and clear screen counts",
		"clear": "Clear counts and stop",
		"reviewExport": "Review counts for export",
		"previewTitle": "Review local screen counts",
		"download": "Download reviewed counts",
		"exportUnavailable": "The counts changed or the page session ended. Review the current counts again before downloading.",
		"screenColumn": "Screen category",
		"countColumn": "Foreground entries"
	},
	analyticsCategories: {
		"home": "Home",
		"offers": "Offers",
		"trade": "Trade review",
		"recovery": "Recovery",
		"settings": "Settings"
	},
	drafts: {
		"previewPut": "Store or replace reusable template defaults",
		"previewDefault": "Change repeat default selection",
		"previewExpires": "This preview expires after five minutes. Confirm only the change shown here.",
		"none": "None",
		"chainId": "EVM chain ID",
		"nativeAsset": "Native asset",
		"assetDecimals": "Asset decimals",
		"repeatSelected": "Repeat default",
		"title": "New local draft",
		"help": "Reuse amounts only. Enter parties, instructions and deadlines again, then review exact current terms. Trading remains disabled.",
		"locked": "Unlock a profile to edit a private draft or manage encrypted templates.",
		"unavailable": "No current registry choices are available for this draft.",
		"templatesTitle": "Encrypted templates and repeat defaults",
		"templatesEmpty": "No templates are saved in this profile.",
		"loadTemplates": "Load templates",
		"newBlank": "Start blank draft",
		"useTemplate": "Use template",
		"useRepeatDefault": "New draft from repeat defaults",
		"saveTemplate": "Save amounts as template",
		"removeTemplate": "Remove template",
		"setRepeatDefault": "Use for repeat defaults",
		"clearRepeatDefault": "Clear repeat defaults",
		"slotLabel": "Template slot",
		"review": "Review fresh draft",
		"cancel": "Cancel",
		"previewTitle": "Review local template change",
		"reviewChange": "I reviewed these local changes and understand backup copies are unaffected.",
		"confirmChange": "Confirm local change",
		"backupLimits": "Changes affect this encrypted profile only. Older backups can restore removed templates. Saved trade reviews and recovery records are retained.",
		"savedAmountsNeedReview": "Saved amounts need checking. No current quote or counterparty acceptance is implied.",
		"confirmAmounts": "I rechecked the exact crypto and fiat amounts for this draft.",
		"confirmIdentities": "I checked the current chain, escrow, asset and full party addresses.",
		"confirmEmptyInstructions": "I intentionally leave draft payment instructions empty.",
		"busy": "Checking this local operation…",
		"saved": "The local template change is saved.",
		"choose": "Choose",
		"identityTitle": "Current registry identities",
		"invalid": "Enter complete canonical values.",
		"oldValues": "Previous values",
		"newValues": "New values",
		"repeatDefaultRemoved": "Removing this template also clears repeat defaults.",
		"operationFailed": "The draft operation did not complete. Correct entered fields or reload templates before retrying a change; a write may have committed.",
		"templateName": {
			"source": "Template {slot}",
			"variables": { "slot": "count" }
		},
		"affectedTemplates": {
			"source": "Affected local templates: {count}.",
			"variables": { "count": "count" }
		}
	},
	draftFields: {
		"networkId": "Network",
		"deploymentId": "Escrow deployment",
		"assetId": "Asset",
		"amountBaseUnits": "Crypto amount in base units",
		"fiatCurrency": "Fiat currency code",
		"fiatMinorUnits": "Fiat amount in minor units",
		"fiatScale": "Fiat decimal scale",
		"seller": "Full seller address",
		"buyer": "Full buyer address",
		"paymentInstructions": "New private draft instructions",
		"acceptBeforeSeconds": "New acceptance deadline (Unix seconds)",
		"escrowExpirySeconds": "New escrow expiry (Unix seconds)"
	},
	favorites: {
		title: "Favorite saved reviews",
		help: "Favorites stay in this encrypted profile. Opening a favorite checks its saved terms against the current registry again.",
		locked: "Unlock a profile to view favorites.",
		load: "Load favorites",
		empty: "No saved reviews are starred.",
		star: "Star saved review",
		unstar: "Unstar saved review",
		open: "Open with a fresh review",
		unavailable: "This saved review is no longer available for the current registry.",
		busy: "Updating favorites…",
		failed: "The favorite operation did not return a confirmed result. Reload favorites before trying again; a write may have committed.",
		retained: "The retention tool conservatively keeps all history while a favorites preference record is present. Existing backups keep earlier copies."
	},
	help: {
		profile: "A profile ID locates local encrypted data on this origin. It is not a wallet address or counterparty authentication.",
		unlock: "Unlocking exposes local plaintext to this browser session. It grants no wallet or transaction permission.",
		create: "Use a unique secret you can retain. This local operation creates storage keys, not external-wallet spending keys.",
		file: "Select your own encrypted backup. File names and checksums cannot establish that its contents are authentic.",
		restore: "The new passphrase seals a separate profile with fresh keys. Keep the original file and its old passphrase until recovery is verified.",
		export: "Downloading ciphertext does not test its passphrase or restore it. Keep the exported file private and retain its passphrase separately.",
		createConsent: "Consent applies only to creating this local profile. There is no server account or administrator able to reset its passphrase.",
		restoreConsent: "A successful local restore is not confirmation that a referenced transaction failed or that it is safe to submit again.",
		label: "Help",
		show: {
			source: "Help for {control}",
			variables: { control: "text" }
		}
	},
	"shell": {
		shareAppTitle: "Share this app",
		shareAppHelp: "Share a generic app address without the current page’s query or fragment. This address does not verify the app or its release.",
		shareAppUrl: "App address",
		shareAppCopy: "Copy app address",
		shareAppCopied: "App address copied.",
		shareAppCopyUnavailable: "Copying is unavailable. Select and copy the address above.",
		shareAppUnavailable: "A generic app address is unavailable. Use an independently verified app address.",
		"appName": "P2P Off-ramp",
		"development": "Development shell",
		"skip": "Skip to main content",
		"navLabel": "Primary navigation",
		"home": "Home",
		"offers": "Offers",
		"recovery": "Recovery",
		"settings": "Settings",
		"fundsDisabled": "Funds disabled",
		"networkDisabled": "Network access disabled",
		"offline": "Browser offline",
		"online": "Browser online",
		"networkHelp": "This shell makes no RPC, relay, or wallet connections. Browser connectivity does not verify private routing.",
		"locked": "Vault locked",
		"unlocked": "Vault unlocked",
		"sessionLabel": "Local session",
		"lock": "Lock vault",
		"refresh": "Refresh vault status",
		"starting": "Opening local services…",
		"unavailable": "Local private operations are unavailable. Recovery guidance remains available.",
		"localOnly": "Local only",
		"homeTitle": "Your local workspace",
		"homeIntro": "A recoverable static client under development. You can create, restore, or open a local encrypted profile. Trading is unavailable.",
		"readyTitle": "What is available",
		"readyText": "Local encrypted profile creation, unlock, session lock, encrypted file export, and fresh-key restore on this browser origin. Trade terms can be checked read-only on the Offers page when a network registry is loaded.",
		"disabledTitle": "Trading is not enabled",
		"disabledText": "Offer discovery, wallet connections, signing, escrow, messaging, and payments are unavailable in this build.",
		"openOffers": "Review trade terms",
		"unlock": "Unlock existing profile",
		"unlockHelp": "Use the ID and passphrase of a profile already stored on this exact browser origin. This does not connect a wallet or authorize a payment.",
		"profile": "Profile ID",
		"profileHelp": "Enter the exact 32-character lowercase hexadecimal ID. It is never added to a URL.",
		"passphrase": "Passphrase",
		"passphraseHelp": "Used only for this unlock attempt. The field is cleared when submitted, cancelled, or closed. Browser extensions and compromised code can still read unlocked memory.",
		"submitUnlock": "Unlock local vault",
		"cancel": "Cancel",
		"unlocking": "Unlocking local vault…",
		"unlockedHelp": "The local vault session is open. Private records appear only when you explicitly load or review them. Trading remains disabled. Lock the vault when you finish.",
		"offersTitle": "Offers",
		"offersIntro": "Offer discovery is unavailable.",
		"offersHelp": "No relay is connected and no live offers have been loaded. This page does not show example prices or counterparties.",
		"tradeTitle": "Trade review",
		"syntheticDemo": "SYNTHETIC DEMO · test-only data",
		"testnet": "SEPOLIA TESTNET · owner-signed registry",
		"testnetLocalProof": "SEPOLIA LOCAL PROOF · unapproved fixture key",
		"tradeIntro": "This local trade cannot be resolved in this build.",
		"tradeHelp": "A route is not proof of a trade, payment, approved contract, or chain state. No transaction will be replayed from this link.",
		"recoveryTitle": "Recovery",
		"recoveryIntro": "Keep an encrypted copy before changing browser, device, or origin.",
		"originTitle": "Local storage belongs to this origin",
		"originHelp": "A new domain, gateway, or CID origin can have a different IndexedDB vault. An empty browser does not establish that your keys or funds are gone. A changed path on the same origin does not isolate storage.",
		"retentionTitle": "Review local data retention",
		"retentionHelp": "This offline preview suggests archive review for local transaction history labeled finalized or failed and stored chat records that are at least 30 days old. Saved terms without a stored timestamp receive no age-based suggestion. Thirty days is a project review default, never an automatic deletion deadline.",
		"retentionLimits": "This preview leaves all stored records, backups and remote copies unchanged.",
		"retentionRestoreWarning": "Restoring an older backup can bring back records that you previously deleted. Restored recovery labels are unverified until fresh native reconciliation.",
		"retentionConsent": "I reviewed this exact revision and understand that deletion is logical, affects this complete eligible group, and leaves backups and remote copies unchanged.",
		"retentionPlan": "Preview local records offline",
		"retentionReview": "Check native deletion eligibility",
		"retentionDelete": "Delete the reviewed eligible group",
		"retentionCancel": "Cancel preview",
		"retentionBusy": "Previewing the selected profile…",
		"retentionCancelled": "Preview cancelled. Local records, backups and remote copies are unchanged.",
		"retentionLocked": "Unlock a local profile to review its retained records. Locking clears this preview and keeps recovery data.",
		"retentionUnavailable": "This build cannot verify whether trades or conversations are safe to delete. All records remain protected in this preview; archive-review suggestions never approve deletion.",
		"retentionProtected": "Unrecognized records, identity records and unresolved trade history stay protected. A saved transaction label or restored backup does not prove that a trade or conversation is complete.",
		"retentionTooLarge": "This complete eligible group exceeds the 256-record atomic limit. It remains protected; the app will not split it into implicit batches.",
		"retentionManageSaved": "Manage saved reviews on Offers",
		"retentionCounts": {
			"source": "{archive} {archive|record|records} suggested for archive review; {reviewed} {reviewed|record|records} approved for deletion by this preview; {protected} {protected|record|records} protected. Local revision {revision}.",
			"variables": {
				"archive": "count",
				"reviewed": "count",
				"protected": "count",
				"revision": "count"
			}
		},
		"retentionSnapshot": "Archive-review suggestions are included in the protected count. These counts describe one local revision; run a new preview after changes.",
		"retentionDeleted": {
			"source": "Logically deleted {count} {count|record|records} from local revision {revision}. Backups and remote copies remain unchanged.",
			"variables": {
				"count": "count",
				"revision": "count"
			}
		},
		"backupVerifyTitle": "Authenticate a backup file against this profile",
		"backupVerifyHelp": "Unlock the profile to check a selected backup file and its passphrase against that exact committed revision. Exporting, downloading, unlocking or restoring another profile does not perform this check.",
		"backupVerifyScope": "This covers every encrypted local record in one profile, including opaque records. It does not cover external-wallet spending keys, complete relay history, chain truth or file retention on another device. A result is a point-in-time check; recheck before relying on its revision.",
		"backupVerifyFile": "Backup file to authenticate",
		"backupVerifyPassphrase": "Passphrase for this backup file",
		"backupVerify": "Verify this backup file",
		"backupVerifyCheck": "Recheck verified revision",
		"backupVerifying": "Authenticating the file and checking the committed profile…",
		"backupVerifyChecking": "Checking the selected profile revision…",
		"backupVerifyNone": "No authenticated backup verification is held for this profile selection.",
		"backupVerifyLocked": "Unlock the matching local profile before verifying its backup. A restored fresh-key profile needs its own exported file and verification.",
		"backupVerifyMismatch": "The file does not match the open profile’s committed revision, or the stored profile changed. Export the latest profile and verify its file again.",
		"backupVerifyFileRequired": "Choose the encrypted backup file to authenticate.",
		"backupVerifyCancelled": "Verification cancelled. No backup verification was established; profile data was not changed.",
		"backupVerifyCancel": "Cancel verification",
		"backupVerifyEnvelopeDigest": "Authenticated encrypted envelope SHA-256",
		"backupVerifyFileDigest": "Verified file SHA-256",
		"backupVerified": {
			source: "Backup file authenticated against profile {profileId}, revision {revision}. This result is local to this profile selection and check.",
			variables: {
				profileId: "identifier",
				revision: "count"
			}
		},
		"backupTitle": "Export an encrypted file",
		"backupHelp": "Export reads committed ciphertext for a known local profile. It does not include external-wallet spending keys. Keep the file private and retain its passphrase separately.",
		"unchecked": "Authentication not checked",
		"uncheckedHelp": "Every export in this shell is labelled unchecked, even after unlock. A checksum detects accidental corruption; it does not prove authenticity or a successful recovery.",
		"consent": "I understand this encrypted export is unchecked and saving it may expose the file to other software on this device.",
		"export": "Download unchecked encrypted backup",
		"exporting": "Preparing encrypted file…",
		"exported": "Unchecked encrypted file prepared. Your browser controls whether it is saved. This is not a verified recovery test.",
		"restoreTitle": "Restore an encrypted file",
		"restoreHelp": "Restore decrypts the file inside the local Worker and writes a separate new profile with fresh keys. Your existing profiles are never replaced or deleted. Do not send a passphrase through a link, clipboard, or support request.",
		"restoreFile": "Encrypted backup file",
		"restoreFileHelp": "Choose a file exported by this app. Files larger than 12 MiB are refused before reading.",
		"sourcePassphrase": "Backup passphrase",
		"restorePassphraseHelp": "The restored profile is sealed with this new passphrase. It may match the old one, but its keys are always fresh.",
		"restoreConsent": "I understand the file content is untrusted until it authenticates, its age is unknown, and any trade it references must be reconciled on-chain before economic actions.",
		"restoreConsentRequired": "Read and accept the restore notice before continuing.",
		"restoreFileRequired": "Choose an encrypted backup file.",
		"submitRestore": "Restore as new profile",
		"restoring": "Authenticating and restoring locally…",
		"openRestored": "Open restored profile",
		"lockToOpenRestored": "A profile is already unlocked. Use Lock vault before unlocking the restored profile; opening this page does not switch sessions.",
		"create": "Create new profile",
		"createHelp": "Creates an empty encrypted profile on this browser origin. No wallet, account, or server is involved. Only you hold the passphrase.",
		"newPassphrase": "New passphrase",
		"newPassphraseHelp": "At least 12 UTF-8 bytes. A password-manager-generated secret or a long multiword passphrase is best; length alone is not strength.",
		"confirmPassphrase": "Confirm new passphrase",
		"passphraseMismatch": "The passphrases do not match. Both fields were cleared.",
		"createConsent": "I understand there is no passphrase reset. Losing the passphrase and every encrypted backup means this local data is unrecoverable.",
		"createConsentRequired": "Read and accept the passphrase notice before creating a profile.",
		"submitCreate": "Create encrypted profile",
		"creating": "Creating encrypted profile locally…",
		"inventoryEmpty": "No local profiles exist on this origin yet. Create or restore one first.",
		"inventoryUnavailable": "The local profile list is unavailable. You can still type a known profile ID.",
		"inventoryTruncated": "More rows exist than this build lists. Keep your data and use recovery guidance.",
		"restoreUncertain": "The restore was interrupted and may have completed. Check local profiles before trying again; do not restore the same file twice without checking.",
		"reconcile": "Check local profiles",
		"recoveryRisk": "Without a usable backup and passphrase, local messaging and history data may be permanently lost. This shell cannot recover on-chain funds or confirm payment state.",
		"settingsTitle": "Settings",
		"settingsIntro": "Current capabilities and trust limits",
		"privacyTitle": "Privacy and connectivity",
		"privacyHelp": "RPC, relay, wallet, update discovery, and analytics connections are disabled. No service worker is installed by this client. Offline use is limited to an already loaded shell; fresh chain state is unavailable.",
		"trustTitle": "Executable trust",
		"trustHelp": "Static hosting and IPFS content addressing do not authenticate a first visit. Verify release artifacts and the distribution key through an independent trusted channel. The default shell has no configured release trust or origin-transition controller.",
		"framingTitle": "Framing protection unverified",
		"framingHelp": "A CSP meta tag cannot enforce frame-ancestors. Host response headers require a separate deployment check; this shell does not claim clickjacking protection.",
		"localeTitle": "Language and compatibility",
		"localeHelp": "English source copy only. Browser capability checks are not device certification. Wallet support, physical device tests, translation review, and accessibility acceptance remain pending.",
		"localeFallback": "The requested language is unavailable or incomplete. The complete English source is shown. Funds remain disabled.",
		"localeUseSource": "Use English source",
		"localeChoose": "Display language",
		"localeChooseHelp": "Changes display text only. Addresses, amounts and signed data are never translated.",
		"localeFixture": "Development language fixture. This is formatting and layout test data, not a reviewed translation. Funds remain disabled.",
		"unknownTitle": "Page unavailable",
		"unknownHelp": "This route is not supported. Return home or open recovery guidance. Link contents are not used as commands.",
		"returnHome": "Return home",
		"openRecovery": "Open recovery",
		"footer": "Development build · No real-funds readiness claimed",
		"locking": "Locking local vault…",
		"refreshing": "Checking local vault status…",
		"profileInvalid": "Enter an exact 32-character lowercase hexadecimal profile ID.",
		"consentRequired": "Read and accept the unchecked export notice before downloading.",
		"restored": {
			"source": "Restored as a new locked profile {id} with {records} {records|record|records}. Unlock it from Home.",
			"variables": {
				"id": "identifier",
				"records": "count"
			}
		},
		"restoredSelection": {
			"source": "Restored profile {id} is selected for unlock in this page only. Enter its new passphrase to open it.",
			"variables": { "id": "identifier" }
		},
		"created": {
			"source": "Profile {id} was created and unlocked. Note this ID and export an encrypted backup from Recovery.",
			"variables": { "id": "identifier" }
		},
		"capacityReached": {
			"source": "This origin already holds the maximum of {max} local profiles. Restore or create is refused; existing profiles are kept.",
			"variables": { "max": "count" }
		},
		"inventoryTitle": {
			"source": "Profiles on this origin ({count} of {max})",
			"variables": {
				"count": "count",
				"max": "count"
			}
		},
		"useProfile": {
			"source": "Use profile {id}",
			"variables": { "id": "identifier" }
		},
		"reconciledTitle": {
			"source": "Profiles on this origin now ({count}). A new profile here may be from the interrupted restore; nothing was deleted.",
			"variables": { "count": "count" }
		}
	},
	"shellErrors": {
		"INVALID_INPUT": "The local operation could not use this input. Check the profile ID and passphrase requirements.",
		"UNSUPPORTED_ENVIRONMENT": "This browser cannot open the encrypted local service. Use a supported secure browser context and keep your existing data.",
		"UNSUPPORTED_VERSION": "This local data version is unsupported. Keep the original data and use compatible recovery software.",
		"NOT_FOUND": "No profile was found for that ID on this origin. Check the ID and your original browser origin.",
		"AUTHENTICATION_FAILED": "The vault could not be authenticated. Check the passphrase and keep the original data.",
		"LOCKED": "The local session is locked. Unlock the existing profile again if needed.",
		"CONFLICT": "Local data changed. Keep the original data and check its status before trying again.",
		"LIMIT_EXCEEDED": "A local safety limit was reached. Keep the original data and use recovery guidance.",
		"QUOTA_EXCEEDED": "Browser storage for this origin is full. Nothing was saved. Free space or export a backup, then try again; existing profiles are kept.",
		"STORAGE_UNAVAILABLE": "Local storage is unavailable. Check browser storage permissions and keep your original data.",
		"CANCELLED": "The local operation was cancelled. No success is confirmed.",
		"BUSY": "Another local operation is running. Wait for it to finish before trying again.",
		"PROTOCOL_ERROR": "The local service could not complete this operation safely. Keep your data and open recovery guidance.",
		"TIMEOUT": "The local operation timed out. Check local status before trying again.",
		"NATIVE_PROOF_REQUIRED": "These records are protected. Review deletion in Settings; a current native dependency check and explicit consent are required."
	},
	"trade": {
		"versionPrefix": "v",
		"banner": "Preview only. Trading is disabled in this build.",
		"title": "Trade terms review",
		"intro": "Read-only terms as supplied. Nothing here can be accepted, signed, funded or sent.",
		"sourceFile": "Source: a local file you selected. Its contents were checked against the loaded registry; that does not make the counterparty trustworthy.",
		sourceDraft: "Source: newly entered local draft. No acceptance is authenticated.",
		"sourceSynthetic": "Source: SYNTHETIC test-only sample built into this demo. Never use these addresses or amounts on a real network.",
		"sourceSaved": "Source: an encrypted review loaded from this profile and checked against the current registry.",
		"network": "Network",
		"chainId": "Chain ID",
		"environment": "Registry environment",
		"deployment": "Escrow deployment",
		"contract": "Escrow contract",
		"orderId": "Order ID",
		"revision": "Revision",
		"sellerNonce": "Seller nonce",
		"seller": "Crypto seller (funds escrow, confirms fiat receipt)",
		"buyer": "Crypto buyer (pays fiat, receives crypto)",
		"asset": "Asset",
		"assetNative": "native coin",
		"assetToken": "ERC-20 token",
		"tokenAddress": "Token contract",
		"amount": "Crypto amount",
		"fiat": "Fiat amount",
		"instructions": "Payment instructions (from the counterparty, exactly as agreed)",
		"instructionsEmpty": "None supplied.",
		"instructionsHidden": "Hidden: the text contains characters that can disguise its meaning. Ask the counterparty for plain text.",
		"mixedScript": "Warning: some words mix Latin with Cyrillic or Greek letters, which can imitate other words.",
		"capabilities": "Optional capabilities",
		"capabilitiesNone": "None (core manual trade).",
		"versionHidden": "version hidden: it contains characters that can disguise text",
		"capabilityUnsupported": "Not supported by this build. Terms that require it cannot be used here.",
		"acceptBefore": "Accept before",
		"escrowExpiry": "Escrow expiry",
		"unixSeconds": "Unix seconds",
		"clockNote": "Remaining time uses this device’s clock for display only. Chain time decides funding, release and refund.",
		"hashes": "Integrity checks",
		"agreementHash": "Private agreement SHA-256 (recomputed and matched)",
		"capabilitiesHash": "Capabilities SHA-256 (recomputed and matched)",
		"termsDigest": "Signed terms digest (EIP-712)",
		"termsDigestUnavailable": "Not computed in this build because signing is disabled.",
		"riskTitle": "Manual settlement risk",
		"risk": "The seller releases crypto only after confirming fiat receipt. A dishonest seller can withhold release after you pay; at expiry the escrowed crypto refunds to the seller. This app cannot verify fiat payments or make them reversible.",
		"blockedTitle": "Why these terms cannot be accepted here",
		"blockedTrading": "Trading, wallet connections, signing and funding are disabled in this build.",
		"blockedExpired": "The acceptance deadline has passed by this device’s clock.",
		"blockedCapabilities": "The terms require optional capabilities this build does not support.",
		"addressHelp": "Full addresses are shown in both forms and never shortened. Compare every character.",
		"groupedLabel": "Grouped for reading",
		"invalid": "Not displayable: the supplied value is not in canonical form.",
		"baseUnits": {
			"source": "{units} base units at {decimals} decimals",
			"variables": {
				"units": "base-unit amount",
				"decimals": "count"
			}
		}
	},
	"tradePage": {
		"syntheticBadge": " (synthetic)",
		"discoveryTitle": "Offer discovery is unavailable",
		"discoveryHelp": "No relay is connected and no live offers have been loaded. This page does not show example prices or counterparties.",
		"reviewTitle": "Review trade terms locally",
		"reviewHelp": "Check a trade-terms file against the network registry loaded in this build. Checking is read-only and offline: nothing is accepted, signed, funded or sent.",
		"registryLoading": "Loading the network registry…",
		"registryUnavailable": "No approved network registry is loaded in this build, so trade terms cannot be checked. Registry and release trust (G11/G15) await an owner decision.",
		"registryFailed": "The network registry failed its integrity check and was not used. Terms cannot be checked.",
		"demoBanner": "SYNTHETIC LOCAL DEMO: test-only registry for local chain 31337. Not a trust root; never use these values with real funds.",
		"fileLabel": "Trade-terms file (JSON, at most 64 KiB)",
		"fileHelp": "The file is read locally. Larger files are refused before reading.",
		"fileRequired": "Choose a trade-terms file first.",
		"check": "Check terms",
		"cancel": "Cancel check",
		"samplesTitle": "Synthetic samples",
		"samplesHelp": "Built-in test-only samples. They go through the same checks as a file.",
		"reading": "Reading the file…",
		"checking": "Checking the terms against the registry…",
		"cancelled": "Check cancelled. Nothing was stored.",
		"accepted": "Terms checked. The review is open below and in this session list.",
		"openReview": "Open review",
		"sessionTitle": "Reviewed in this session",
		"sessionEmpty": "No terms reviewed yet in this session.",
		"sessionHelp": "Up to 8 unsaved reviews are kept in memory, alongside saved reviews from the open profile. Locking or reloading clears this list. Removing an entry does not delete its encrypted saved copy.",
		"save": "Save encrypted review",
		"persistenceHelp": "Unlock a profile to save or load reviews. Each profile can hold up to 8 saved reviews. Use Delete from profile on a saved review to remove its encrypted copy; Remove from session only clears the session entry. Saved original terms include private payment instructions. Loading checks every document against the current registry again. If a save or deletion is interrupted by locking, cancellation or a timeout, unlock and load saved reviews to check whether it committed before retrying.",
		"persistenceBusy": "Working with encrypted reviews…",
		"persistenceSaved": "Review saved encrypted in this profile.",
		"persistenceLoaded": "Saved reviews loaded and checked against the current registry.",
		"persistenceFailed": "The review operation did not complete with a confirmed result. A save may have committed even after cancellation, locking or a timeout. Unlock and load saved reviews to check. Existing profile data was retained.",
		"persistenceInvalid": "Saved reviews could not be checked against the current registry. The session list was retained and profile data was not changed.",
		"persistenceQuota": "The browser storage quota was exceeded. Existing profile data was retained. Free storage before retrying.",
		"cancelPersistence": "Cancel review operation",
		"remove": "Remove from session",
		"tradeMissingTitle": "Review not in this session",
		"tradeMissing": "This review is not in the current session. Reviews are kept in memory only and are cleared on reload. A link is not proof of a trade and nothing is replayed from it.",
		"backToOffers": "Back to offers",
		"savedTitle": "Saved in this profile",
		"savedHelp": "Saving stores only the original terms file, encrypted in the open profile (at most 8). Loading checks every saved file again against the registry in this build. Locking clears all reviews from memory. An interrupted save or deletion may have committed; unlock and load before retrying.",
		"savedLocked": "Unlock a profile to save reviews or load saved ones.",
		"loadSaved": "Load saved reviews",
		"saveToProfile": "Save to profile",
		"deleteFromProfile": "Delete from profile",
		"savedBadge": "Saved in profile",
		"favoritesTitle": "Favorite saved reviews",
		"favoritesHelp": "Load favorites to add or remove stars on saved reviews. Up to 8 references are encrypted in this profile. Opening a favorite loads the saved terms and checks them against the current registry again. Deleting a review leaves its favorite reference until you remove it.",
		"loadFavorites": "Load favorites",
		"addFavorite": "Add favorite",
		"removeFavorite": "Remove favorite",
		"openFavorite": "Open and recheck favorite",
		"favoritesBusy": "Working with encrypted favorites…",
		"cancelFavorites": "Cancel favorite operation",
		"favoritesEmpty": "No favorite saved reviews in this profile.",
		"favoritesFailed": "The favorite operation was not confirmed. The profile may have changed, or the change may have committed before interruption. Unlock if needed and load favorites before trying again. No automatic retry was made.",
		"favoriteItem": {
			"source": "Favorite saved record {record}…",
			"variables": { "record": "identifier" }
		},
		"savedFailedOther": "The saved-review operation did not complete with a confirmed result. A save or deletion may have committed. Unlock and load saved reviews before retrying.",
		"unreviewableTitle": "Saved files that no longer pass review",
		"testnetLocalProofBanner": {
			"source": "SEPOLIA LOCAL PROOF: this registry uses fixture key {key}… (manifest {sequence}, valid until {expires}). This key is not an owner-approved trust root. Trading, wallet connections, signing and funding stay disabled.",
			"variables": {
				"key": "identifier",
				"sequence": "count",
				"expires": "date"
			}
		},
		"testnetBanner": {
			"source": "SEPOLIA TESTNET: the network registry is signed by the owner's testnet-only key {key}… (manifest {sequence}, valid until {expires}). Test network only: never use real funds. Trading stays disabled in this build.",
			"variables": {
				"key": "identifier",
				"sequence": "count",
				"expires": "date"
			}
		},
		"sessionItem": {
			"source": "Order {orderId} revision {revision}",
			"variables": {
				"orderId": "identifier",
				"revision": "identifier"
			}
		},
		"savedSkipped": {
			"source": "{count} other {count|trade record was|trade records were} not a readable saved review and {count|was|were} left unchanged.",
			"variables": { "count": "count" }
		},
		"unreviewableItem": {
			"source": "Saved record {record}…",
			"variables": { "record": "identifier" }
		}
	},
	"tradePageSavedBusy": {
		"save": "Saving to the profile…",
		"load": "Loading saved reviews…",
		"delete": "Deleting from the profile…"
	},
	"tradePageSavedDone": {
		"save": "Saved in the open profile.",
		"load": "Saved reviews loaded and checked again.",
		"delete": "Deleted from the open profile."
	},
	"tradePageSavedFailed": {
		"LOCKED": "The profile is locked. Unlock it and try again.",
		"LIMIT_EXCEEDED": "The profile already holds 8 saved reviews. Load saved reviews and use Delete from profile for a copy you choose to remove, then retry saving. Saved reviews are never evicted automatically. If deletion is interrupted, unlock and load saved reviews to check before retrying.",
		"NOT_FOUND": "That saved review is no longer in the profile.",
		"CONFLICT": "The profile changed in another tab. Unlock again and retry.",
		"QUOTA_EXCEEDED": "Browser storage is full. Nothing was saved.",
		"REGISTRY_NOT_READY": "Saved reviews cannot be checked because no registry is loaded.",
		"INVALID_SAVED_REVIEW": "Some saved reviews could not be checked against the current registry. Valid reviews may have loaded; encrypted data was retained.",
		"UNKNOWN_OUTCOME": "The operation was interrupted and may have committed. Unlock and load saved reviews to check.",
		"BUSY": "Another profile operation is running. Try again shortly."
	},
	"tradePageRejected": {
		"LOCAL_LIMIT_REACHED": "Another file import is still running. Wait for it to finish or cancel it.",
		"TOO_LARGE": "Refused: the file or one of its fields is larger than allowed.",
		"MALFORMED": "Refused: the file is not a valid trade-terms document.",
		"UNSUPPORTED_FORMAT": "Refused: this trade-terms format or version is not supported.",
		"INVALID_TERMS": "Refused: the public terms are not in canonical form.",
		"INVALID_AGREEMENT": "Refused: the private agreement is not valid.",
		"AGREEMENT_MISMATCH": "Refused: the private agreement belongs to a different order or revision.",
		"AGREEMENT_HASH_MISMATCH": "Refused: the private agreement does not match the hash in the public terms.",
		"CAPABILITIES_HASH_MISMATCH": "Refused: the capabilities do not match the hash in the public terms.",
		"UNKNOWN_NETWORK": "Refused: the network is not in the loaded registry.",
		"NOT_EVM_NETWORK": "Refused: the network is not an EVM network.",
		"UNKNOWN_DEPLOYMENT": "Refused: the escrow deployment is not in the loaded registry.",
		"UNSUPPORTED_ASSET": "Refused: the asset is not supported by this escrow deployment.",
		"UNFUNDABLE_WINDOW": "Refused: no chain time could satisfy the funding window for these deadlines.",
		"UNAVAILABLE": "The local hash check is unavailable in this browser. Nothing was stored.",
		"FILE_UNREADABLE": "The file could not be read. Nothing was stored.",
		"REGISTRY_NOT_READY": "Terms cannot be checked because no registry is loaded."
	},
	"diagnostics": {
		"title": "Local diagnostics",
		"help": "Review a limited local record of typed errors. Nothing is uploaded automatically.",
		"privacy": "Events exclude wallet and trade identifiers, addresses, amounts, endpoint details, private content, keys, exact timestamps and raw error messages. The remaining combination may still identify a pattern of use.",
		"unconfigured": "Collection unavailable: this unsigned development shell has no authenticated release context. No events are collected, and diagnostic data from an unavailable release context is discarded. Clearing remains available without unlocking the vault.",
		"retention": "At most 500 events or 1 MiB are retained for seven days. Events from unsupported or unauthenticated release contexts are discarded. This is not a durable audit record.",
		"refresh": "Refresh diagnostics",
		"clear": "Clear local diagnostics",
		"cleared": "Local diagnostics cleared. No vault passphrase was needed.",
		"empty": "No local diagnostic events are available.",
		"select": "Select the events to include",
		"preview": "Preview selected diagnostic export",
		"previewTitle": "Diagnostic export preview",
		"sharing": "These are the final fields and bytes. Download only if you are comfortable sharing this combination. Sharing the file is a separate action outside this app. Support never needs your seed, private key or passphrase.",
		"exactBytes": "Exact export text (UTF-8 JSON)",
		"download": "Download the previewed diagnostics",
		"downloaded": "The previewed file was prepared for your browser. Nothing was uploaded.",
		"event": {
			"source": "Event {index}",
			"variables": { "index": "count" }
		},
		"byteCount": {
			"source": "{bytes} UTF-8 bytes; no events are included unless you selected them.",
			"variables": { "bytes": "count" }
		}
	},
	"diagnosticErrors": {
		"RELEASE_UNAVAILABLE": "The authenticated release context is unavailable or expired. Collection and export are blocked; clearing remains available.",
		"STORAGE_UNAVAILABLE": "Local diagnostic storage is unavailable. No successful clear or export is confirmed.",
		"REDACTION_FAILED": "This diagnostic selection could not be exported safely. Refresh the list and select the events again.",
		"REPORT_TOO_LARGE": "The diagnostic selection is too large. Select fewer events."
	},
	"diagnosticWarnings": {
		"DISCARDED_INVALID": "Invalid or unsupported diagnostic entries were discarded.",
		"DISCARDED_EXPIRED": "Expired or future-dated diagnostic entries were discarded.",
		"CAP_REACHED": "The local event limit was reached; older entries may have been discarded."
	},
	"recovery": {
		"title": "Offline transaction recovery references",
		"help": "Inspect the open profile’s stored journal references without connecting a wallet, relay or node. This view makes no writes and cannot retry or clear a transaction. Native Solana journals show the current recovery hint for each trade; the complete intent history remains in your encrypted backup.",
		"unverified": "Every entry is an unverified offline reference. A stored label such as finalized does not prove current chain state, receipt, payment or safe resubmission. Reconcile against the original network and escrow using compatible recovery software.",
		"private": "This view and its export contain wallet, trade and transaction identifiers. Keep the file private; these fields can link your activity. No spending key, prepared calldata or signing authorization is exported.",
		"locked": "Unlock the local profile to inspect its recovery references. Locking or changing profile clears this view.",
		"load": "Inspect recovery references",
		"loading": "Reading unverified local references…",
		"refresh": "Restart reference inspection",
		"previous": "Previous reference page",
		"next": "Next reference page",
		"empty": "No supported journal references exist on this page. Unknown or future records are retained in the encrypted profile and backup.",
		"select": "Select references for a private recovery file",
		"consent": "I understand the selected file contains private recovery metadata, remains unverified and cannot authorize a transaction.",
		"preview": "Preview selected private references",
		"previewTitle": "Private recovery-reference preview",
		"exact": "Exact private recovery export (UTF-8 JSON)",
		"previewHelp": "These are the exact selected fields and bytes. Only the current page is exported; the full encrypted backup preserves all records. Sharing is a separate action outside this app.",
		"download": "Download previewed private recovery file",
		"downloaded": "The previewed private file was prepared for your browser. No network request or transaction was made.",
		"storedLabel": "Stored label (unverified)",
		"transaction": "Public chain transaction reference (unverified)",
		"nonce": "Recorded EVM nonce",
		"unknown": "Not recorded",
		"page": {
			"source": "Journal records {start}–{end} of {total}; local snapshot revision {revision}. This is not a chain height.",
			"variables": {
				"start": "count",
				"end": "count",
				"total": "count",
				"revision": "count"
			}
		},
		"unsupported": {
			"source": "{count} {count|record|records} on this page could not be interpreted. Nothing was deleted or rewritten. Keep a complete encrypted backup for compatible recovery software.",
			"variables": { "count": "count" }
		},
		"reference": {
			"source": "Reference {index}",
			"variables": { "index": "count" }
		}
	},
	"display": {
		"expired": "Expired",
		"remaining": {
			"source": "{duration} remaining",
			"variables": { "duration": "text" }
		},
		"day": "d",
		"hour": "h",
		"minute": "min",
		"second": "s"
	},
	"labels": {
		"networkDeployment": "Network / deployment",
		"tradeId": "Trade ID",
		"walletAccount": "Wallet account",
		"intentId": "Intent ID"
	},
	"document": {
		"title": "P2P Off-ramp — local development shell",
		"loading": "Loading the local workspace. If resources are unavailable, reload this same address after restoring the app files. Your encrypted local data is not reset.",
		"noscript": "This workspace needs JavaScript and a supported secure browser. Preserve your encrypted backup and use an independently verified recovery bundle.",
		"policyNotice": "Framing protection is unverified. This development shell is not an authenticated release. Funds remain disabled."
	},
	"samples": {
		"freshNative": "Core native sample (deadlines from now)",
		"frozenNative": "Frozen scenario: native (expired, has capability)",
		"frozenErc20": "Frozen scenario: ERC-20 (expired, has capability)"
	}
};
const contexts = {
	updates: "Optional signed public-asset review and explicit origin transition; no default trust or navigation authority",
	qr: "Explicit local public QR capture and complete review; no authentication, negotiation, wallet or recovery authority",
	qrTypes: "Five public QR envelope type labels",
	qrFields: "Exact public QR identities, amounts, hashes and expiry labels",
	qrWarnings: "Unauthenticated public QR interpretation limits and required external verification",
	qrErrors: "Fixed bounded local QR input and capture refusal reasons",
	analytics: "Explicit optional memory-only screen aggregates and reviewed export; no routes, identities, payment or event authority",
	analyticsCategories: "Five fixed display labels for local foreground screen counts",
	drafts: "Local draft inputs and encrypted reusable amount preferences; no acceptance, signing or transaction authority",
	draftFields: "Canonical local draft field labels; exact money and identities are never locale parsed",
	favorites: "Local encrypted saved-review favorites; opening always requires a fresh current-registry review",
	compatibility: "Local browser feature availability and blocked startup recovery; no wallet or device qualification",
	privacy: "Independent local privacy observations; no anonymity, settlement or economic authority",
	help: "Local accessible control guidance; no private input or authority",
	shell: "Local profile, recovery and offline application shell",
	shellErrors: "Fixed local operation errors and recovery guidance",
	trade: "Read-only canonical trade terms and seller-withholding disclosure",
	tradePage: "Offline trade-terms review and encrypted saved copies",
	tradePageSavedBusy: "Pending encrypted review operation",
	tradePageSavedDone: "Confirmed encrypted review operation",
	tradePageSavedFailed: "Unconfirmed or refused encrypted review operation",
	tradePageRejected: "Fixed rejection reason for a hostile terms file",
	diagnostics: "Explicit review and download of allowlisted local diagnostics",
	diagnosticErrors: "Local diagnostics refusal",
	diagnosticWarnings: "Discarded or bounded local diagnostic metadata",
	recovery: "Unverified private journal reference inspection and export",
	display: "Display-only deadline duration units",
	labels: "Scalar unverified offline recovery fields",
	document: "Static document title, loading, scriptless recovery and unauthenticated release notice",
	samples: "Synthetic built-in trade-terms sample button labels"
};
const docsAnchor = "00_PLANNING_AND_THREAT_MODELING/feature_0.12_product_completion/module_0.12.3_localization/spec-natural-language-localization-tooltips-and-accessibility.md";
const critical = /* @__PURE__ */ new Set([
	"shell.createConsent",
	"shell.restoreConsent",
	"shell.uncheckedHelp",
	"shell.backupVerifyScope",
	"shell.retentionConsent",
	"shell.retentionLimits",
	"shell.retentionRestoreWarning",
	"trade.risk",
	"recovery.unverified",
	"recovery.private",
	"diagnostics.privacy",
	"privacy.policyRelaxConsent",
	"privacy.policyUnknownCoverage",
	"drafts.confirmAmounts",
	"drafts.confirmIdentities",
	"drafts.confirmEmptyInstructions",
	"drafts.backupLimits",
	"analytics.help",
	"shell.shareAppHelp"
]);
for (const key of [
	"updates.consent",
	"updates.recoveryRequired",
	"updates.freshOrigin",
	"updates.disabled",
	"updates.acceptFailed"
]) critical.add(key);
for (const key of [
	"qr.intro",
	"qr.chainScope",
	"qr.fingerprintHelp",
	"qr.unauthenticated",
	"qr.inviteOpen",
	"qr.confirmed",
	"qr.compareHelp",
	"qr.match"
]) critical.add(key);
const groups = Object.create(null);
const catalog = Object.create(null);
for (const group of Object.keys(definitions)) {
	const entries = Object.create(null);
	for (const [name, value] of Object.entries(definitions[group])) {
		const key = `${group}.${name}`, dynamic = typeof value === "string" ? {
			source: value,
			variables: {}
		} : value;
		const severity = critical.has(key) ? "critical" : /Errors|Warnings|Failed|Rejected/.test(group) || /consent|risk|warning|unverified|uncertain/i.test(name) ? "warning" : "information";
		const entry = createMessage({
			key,
			...dynamic,
			context: `${contexts[group]}: ${name}`,
			severity,
			reviewRequired: true,
			docsAnchor
		});
		entries[name] = entry;
		catalog[key] = entry;
	}
	groups[group] = Object.freeze(entries);
}
const entries = Object.freeze(groups);
Object.freeze(catalog);
/** Pure source metadata. Runtime display selection never changes source or grants translation/security approval. */
const SOURCE_LOCALE = Object.freeze({
	locale: "en",
	direction: "ltr",
	revision: 3,
	translator: null,
	reviewer: null,
	status: "draft"
});
function english(group, key, values) {
	return formatMessage(entries[group][key], values);
}
/** Compatibility views contain only static strings. Dynamic messages use the typed english() boundary. */
function englishGroup(group) {
	const result = Object.create(null);
	for (const [key, value] of Object.entries(definitions[group])) if (typeof value === "string") result[key] = english(group, key, {});
	return Object.freeze(result);
}
// apps/web/scripts/source-locale.mjs
/** Build/dev HTML copy shares the app's draft English catalog. No runtime locale fetch or authority. */
const escapeHtml = (value) => value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
function localizeShellHtml(template) {
	const copy = englishGroup("document");
	const values = {
		LANG: SOURCE_LOCALE.locale,
		DIRECTION: SOURCE_LOCALE.direction,
		TITLE: copy.title,
		LOADING: copy.loading,
		NOSCRIPT: copy.noscript,
		POLICY_NOTICE: copy.policyNotice
	};
	let output = template;
	for (const [key, value] of Object.entries(values)) {
		const marker = `__P2P_SOURCE_${key}__`;
		if (output.split(marker).length !== 2) throw new Error("SOURCE_LOCALE_PLACEHOLDER");
		output = output.replace(marker, () => escapeHtml(value));
	}
	if (output.includes("__P2P_SOURCE_")) throw new Error("SOURCE_LOCALE_PLACEHOLDER");
	return output;
}
function sourceLocalePlugin() {
	return {
		name: "p2p-source-locale",
		transformIndexHtml: {
			order: "pre",
			handler: localizeShellHtml
		}
	};
}
// apps/web/vite.config.ts
const root = fileURLToPath(new URL("./", import.meta.url));
const repositoryRoot = fileURLToPath(new URL("../../", import.meta.url));
/**
* Only the explicit `demo` mode includes the synthetic local registry and samples; only `testnet` includes the
* Sepolia registry source. The testnet trust bundle itself is injected by apps/web/scripts/build.mjs after it has
* verified it (a bare `vite build --mode testnet` embeds null and the registry fails closed). Neither mode changes a
* runtime permission: ReleaseEnabled stays 0 and connectOrigins stays empty in every mode.
* `localnet` exists only with an explicit `localnet` input from buildWeb (a bare `vite build --mode localnet` throws);
* its single connect origin is the injected loopback relay, and ReleaseEnabled stays 0.
*/
function createViteConfig(mode, localnet = null, solanaLocalnet = null) {
	if (![
		"production",
		"meta",
		"header",
		"development",
		"demo",
		"testnet",
		"localnet",
		"solana-localnet"
	].includes(mode)) throw new Error("UNSUPPORTED_BUILD_PROFILE");
	if (mode === "localnet" && localnet === null) throw new Error("LOCALNET_CONFIG_REQUIRED");
	if (mode !== "localnet" && localnet !== null) throw new Error("LOCALNET_PROFILE_ONLY");
	if (mode === "solana-localnet" && solanaLocalnet === null) throw new Error("SOLANA_LOCALNET_CONFIG_REQUIRED");
	if (mode !== "solana-localnet" && solanaLocalnet !== null) throw new Error("SOLANA_LOCALNET_PROFILE_ONLY");
	const delivery = mode === "header" ? "header" : "meta";
	const profile = localnet ? { relayOrigin: localnet.relayOrigin } : null;
	const solanaProfile = solanaLocalnet ? { rpcOrigin: solanaLocalnet.rpcOrigin } : null;
	return {
		root,
		base: "./",
		envPrefix: [],
		publicDir: false,
		define: {
			__P2P_SYNTHETIC_DEMO__: JSON.stringify(mode === "demo"),
			__P2P_TESTNET__: JSON.stringify(mode === "testnet"),
			__P2P_TESTNET_TRUST__: "null",
			__P2P_TESTNET_LOCAL_PROOF_KEY_ID__: "null",
			__P2P_LOCALNET__: JSON.stringify(localnet !== null),
			__P2P_LOCALNET_CONFIG__: localnet ? JSON.stringify(localnet.document) : "null",
			__P2P_SOLANA_LOCALNET__: JSON.stringify(solanaLocalnet !== null),
			__P2P_SOLANA_LOCALNET_CONFIG__: solanaLocalnet ? JSON.stringify(solanaLocalnet.document) : "null"
		},
		plugins: [
			react(),
			sourceLocalePlugin(),
			staticBuildPlugin(repositoryRoot, delivery, false, profile, solanaProfile)
		],
		build: {
			outDir: "dist",
			emptyOutDir: true,
			sourcemap: false,
			assetsInlineLimit: 0,
			modulePreload: false,
			target: "es2023",
			reportCompressedSize: false,
			license: { fileName: "third-party-licenses.json" }
		},
		worker: {
			format: "es",
			plugins: () => [staticBuildPlugin(repositoryRoot, delivery, true, profile, solanaProfile)]
		},
		server: { host: "127.0.0.1" },
		preview: { host: "127.0.0.1" }
	};
}
defineConfig(({ mode }) => createViteConfig(mode));
export { createViteConfig };
