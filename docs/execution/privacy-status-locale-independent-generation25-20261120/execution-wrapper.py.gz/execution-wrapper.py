import datetime
import gzip
import hashlib
import json
import pathlib
import re
import shlex
import subprocess
import sys
import time

label, cwd, expected_exit, timeout, *command = sys.argv[1:]
base = pathlib.Path('/workspace/scratch/dcf03ef9bee8')
raw_dir = base / 'privacy-locale-review-g25-raw'
evidence_dir = base / 'p2p-privacy-locale-review-g25/docs/execution/privacy-status-locale-independent-generation25-20261120'
raw_dir.mkdir(exist_ok=True)
evidence_dir.mkdir(parents=True, exist_ok=True)
def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()
started = utc()
started_clock = time.monotonic()
head = git('rev-parse', 'HEAD')
tree = git('rev-parse', 'HEAD^{tree}')
timed_out = False
try:
    result = subprocess.run(command, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=float(timeout))
    raw, exit_code = result.stdout, result.returncode
except subprocess.TimeoutExpired as error:
    raw, exit_code, timed_out = error.stdout or b'', 124, True
ended = utc()
elapsed = time.monotonic() - started_clock
raw_path = raw_dir / (label + '.log')
raw_path.write_bytes(raw)
compressed = gzip.compress(raw, mtime=0)
log_path = evidence_dir / (label + '.log.gz')
log_path.write_bytes(compressed)
decoded = raw.decode('utf-8', errors='replace')
summary = {key: int(value) for key, value in re.findall(r'^(?:#|ℹ) (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$', decoded, re.MULTILINE)}
record = {
    'label': label, 'cwd': cwd, 'sourceCommit': head, 'sourceTree': tree,
    'command': command, 'shellCommand': shlex.join(command), 'startedAt': started, 'endedAt': ended,
    'elapsedSeconds': round(elapsed, 6), 'timeoutSeconds': float(timeout), 'timedOut': timed_out,
    'expectedExitCode': int(expected_exit), 'exitCode': exit_code, 'expectationMet': exit_code == int(expected_exit),
    'summary': summary,
    'log': str(log_path.relative_to(base / 'p2p-privacy-locale-review-g25')),
    'rawBytes': len(raw), 'compressedBytes': len(compressed),
    'decodedSha256': hashlib.sha256(raw).hexdigest(), 'compressedSha256': hashlib.sha256(compressed).hexdigest(),
}
(raw_dir / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
print('\n'.join(decoded.splitlines()[-14:]))
sys.exit(0 if record['expectationMet'] else 1)
