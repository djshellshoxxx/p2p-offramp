import datetime
import hashlib
import json
import pathlib
import subprocess

cwd = pathlib.Path('/workspace/scratch/dcf03ef9bee8/p2p-privacy-locale-review-g25')
base = '477777dc152cd3148ba7f25a75ce8f00dc1b03b5'
red = 'cc395f47cd4db5f5e15eba54fd1cce00b95c65af'
source = 'ad7d5bb1487f6ce612a8ac2a69058e21b27aec1b'
panel = 'apps/web/src/ui/PrivacyStatusPanel.tsx'
test = 'apps/web/test/privacy-status-locale.test.mjs'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=cwd)
def rev(value):
    return git('rev-parse', value).decode().strip()
def tree(value):
    return {row.split(b'\t', 1)[1].decode(): row.split(b'\t', 1)[0].decode() for row in git('ls-tree', '-rz', value).split(b'\0') if row}
def blob(commit, path):
    return git('show', commit + ':' + path)
base_entries, source_entries = tree(base), tree(source)
changed = sorted(path for path in set(base_entries) | set(source_entries) if base_entries.get(path) != source_entries.get(path))
assert changed == [panel, test], changed
assert rev(red + '^') == base
assert rev(source + '^') == red
assert blob(base, panel) == blob(red, panel)
assert blob(red, test) == blob(source, test)
assert rev(source + '^{tree}') == 'a47ce1cb2d5803d799e82c8d54e71621a38559ce'
def lifecycle(text):
    return text[text.index(b'export type PrivacyStatusTransport'):text.index(b'  function indicator(')]
unchanged_lifecycle = lifecycle(blob(source, panel))
assert unchanged_lifecycle == lifecycle(blob(base, panel))
assert git('diff', '--name-only').decode().strip() == ''
for path in changed:
    assert (cwd / path).read_bytes() == blob(source, path)
dependencies = cwd / 'node_modules'
assert dependencies.is_dir() and not dependencies.is_symlink()
node_modules_red = cwd.parent / 'p2p-privacy-locale-review-red-g25/node_modules'
assert node_modules_red.is_dir() and not node_modules_red.is_symlink()
non_docs = sorted((path, entry) for path, entry in source_entries.items() if not path.startswith('docs/'))
unchanged_count = sum(1 for path, entry in base_entries.items() if source_entries.get(path) == entry)
record = {
    'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'baseCommit': base, 'baseTree': rev(base + '^{tree}'),
    'redCommit': red, 'redTree': rev(red + '^{tree}'),
    'sourceCommit': source, 'sourceTree': rev(source + '^{tree}'),
    'baseEntries': len(base_entries), 'sourceEntries': len(source_entries),
    'unchangedExistingEntries': unchanged_count,
    'changedEntries': [{'path': path, 'baseEntry': base_entries.get(path), 'sourceEntry': source_entries.get(path),
        'sha256': hashlib.sha256(blob(source, path)).hexdigest()} for path in changed],
    'redIsTestOnlyChildOfBase': True, 'repairIsDirectChildOfRed': True,
    'redPanelExactlyEqualsBase': True, 'redAndGreenTestExactlyEqual': True,
    'unchangedLifecycleBlock': {'from': 'export type PrivacyStatusTransport', 'untilExclusive': '  function indicator(',
        'bytes': len(unchanged_lifecycle), 'sha256': hashlib.sha256(unchanged_lifecycle).hexdigest()},
    'nonDocumentationEntries': len(non_docs),
    'nonDocumentationEntriesSha256': hashlib.sha256(json.dumps(non_docs, separators=(',', ':')).encode()).hexdigest(),
    'dependencyCopy': {'mode': 'physical copies', 'source': str(cwd.parent / 'p2p-privacy-locale-g25/node_modules'),
        'reviewRootIsSymlink': False, 'redRootIsSymlink': False},
    'nodeVersion': subprocess.check_output(['node', '--version'], text=True).strip(),
    'pythonVersion': subprocess.check_output(['python', '--version'], text=True).strip(),
    'packageLockSha256': hashlib.sha256((cwd / 'package-lock.json').read_bytes()).hexdigest(),
    'installedVersions': {package: json.loads((dependencies / package / 'package.json').read_text())['version']
        for package in ['react', 'react-dom', 'vite', 'typescript']},
    'trackedWorktreeMatchesSource': True,
}
path = cwd.parent / 'privacy-locale-review-g25-raw/source-scope-data.json'
path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
