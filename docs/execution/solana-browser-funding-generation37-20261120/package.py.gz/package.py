import datetime,gzip,hashlib,json,os,pathlib,re,subprocess,tempfile
root=pathlib.Path('/workspace/scratch/dcf03ef9bee8')
raw=root/'g37-funding-author'; repo=root/'p2p-browser-funding-flow-author-g37'
source=json.loads((raw/'source.json').read_text())
def git(*args,env=None,data=None):return subprocess.check_output(['git',*args],cwd=repo,env=env,input=data)
def sha(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source['source']
assert not git('status','--porcelain')
target=repo/'docs/execution/solana-browser-funding-generation37-20261120'; assert not target.exists()
target.mkdir(parents=True)
executions=[]; originals=[]
for path in sorted(raw.glob('[0-9][0-9]-*.json')):
 receipt=json.loads(path.read_text()); name=receipt['name']; log=(raw/(name+'.log')).read_bytes(); patch=(raw/(name+'.patch')).read_bytes()
 assert len(log)==receipt['bytes'] and sha(log)==receipt['sha256']
 assert sha(patch)==receipt['patchSha256']
 assert receipt['head']==receipt['finalHead']
 with tempfile.TemporaryDirectory() as temp:
  env={**os.environ,'GIT_INDEX_FILE':str(pathlib.Path(temp)/'index')}
  git('read-tree',receipt['head'],env=env)
  if patch:git('apply','--cached','--binary','-',env=env,data=patch)
  assert git('write-tree',env=env).decode().strip()==receipt['tree']
 counts={}
 for label in ['tests','pass','fail','cancelled','skipped','todo']:
  match=re.search(r'(?:ℹ|#) '+label+r' (\d+)',log.decode())
  if match:counts[label]=int(match.group(1))
 executions.append({**receipt,'counts':counts,'snapshotReconstructed':True})
 originals += [path,raw/(name+'.log'),raw/(name+'.patch')]
assert len(executions)==9
assert executions[6]['counts']=={'tests':208,'pass':208,'fail':0,'cancelled':0,'skipped':0,'todo':0}
assert executions[6]['tree']==source['tree']
assert executions[7]['committedSource'] and executions[8]['committedSource']
assert executions[7]['exitCode']==0 and executions[8]['exitCode']==0
patch=git('diff','--binary',source['parent'],source['source']); (raw/'frozen-source.patch').write_bytes(patch)
subprocess.run(['git','diff','--check','8e836baa877b676a863c877003e277b638fc5061',source['source']],cwd=repo,check=True)
entries={}
for row in git('ls-tree','-r','-z',source['source']).split(b'\0'):
 if row:
  meta,path=row.split(b'\t',1)
  if not path.startswith(b'docs/'):entries[path.decode()]=meta.decode()
assert len(entries)==1042
verification={'source':source['source'],'tree':source['tree'],'nonDocumentationEntries':len(entries),'reconstructedExecutionTrees':9,'fullMainBaselineWhitespace':'pass','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourcePaths':{}}
for path in source['paths']:
 data=git('show',source['source']+':'+path)
 verification['sourcePaths'][path]={'gitEntry':entries[path],'bytes':len(data),'sha256':sha(data)}
(raw/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
originals += [raw/'execute.py',raw/'source.json',raw/'frozen-source.patch',raw/'verification.json',raw/'package.py',root/'g37-browser-funding-contract.md']
artifacts=[]
for original in originals:
 data=original.read_bytes(); packed=gzip.compress(data,mtime=0)
 destination=target/(original.name+'.gz'); assert not destination.exists()
 destination.write_bytes(packed); assert gzip.decompress(packed)==data and packed[4:8]==bytes(4)
 artifacts.append({'originalPath':str(original),'storedPath':str(destination.relative_to(repo)),'decodedBytes':len(data),'compressedBytes':len(packed),'decodedSha256':sha(data),'compressedSha256':sha(packed)})
receipt={'schema':'p2p-offramp.solana-browser-funding-generation37.v1','source':source,'executions':executions,'verification':verification,'artifacts':artifacts,'sourceUntouchedAfterEvidence':True,'nativeExecuted':False,'fullSuiteExecuted':False,'ReleaseEnabled':0}
(target/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'artifacts':len(artifacts),'executions':len(executions),'source':source,'nonDocumentationEntries':len(entries)},indent=2))
