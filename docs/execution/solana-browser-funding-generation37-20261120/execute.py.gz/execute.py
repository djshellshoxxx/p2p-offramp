import datetime,hashlib,json,pathlib,subprocess,sys
repo=pathlib.Path('/workspace/scratch/dcf03ef9bee8/p2p-browser-funding-flow-author-g37')
out=pathlib.Path(__file__).parent
name=sys.argv[1]; command=sys.argv[2:]
def git(*a):return subprocess.check_output(['git',*a],cwd=repo)
def sha(b):return hashlib.sha256(b).hexdigest()
assert not (out/(name+'.json')).exists()
subprocess.run(['git','add','--all'],cwd=repo,check=True)
head=git('rev-parse','HEAD').decode().strip()
tree=git('write-tree').decode().strip()
patch=git('diff','--binary','HEAD'); (out/(name+'.patch')).write_bytes(patch)
receipt={'name':name,'command':command,'head':head,'tree':tree,'committedSource':not patch,'patchSha256':sha(patch),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (out/(name+'.log')).open('wb') as f:result=subprocess.run(command,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
data=(out/(name+'.log')).read_bytes()
receipt.update(completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=result.returncode,bytes=len(data),sha256=sha(data),finalHead=git('rev-parse','HEAD').decode().strip())
assert git('diff','--binary','HEAD')==patch,'source changed during execution'
(out/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
print(data.decode(errors='replace')[-3500:])
sys.exit(result.returncode)
