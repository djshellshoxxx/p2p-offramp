import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/dcf03ef9bee8')
REPO = ROOT / 'p2p-funding-admission-review-g36'
OUT = ROOT / 'g36-admission-review'
DEST = Path('docs/execution/independent-solana-funding-admission-composition-generation36-20261120')
INDEX = Path('docs/engineering/solana-funding-admission-composition-review-generation36.json')
REPORT = Path('docs/engineering/INDEPENDENT_SOLANA_FUNDING_ADMISSION_COMPOSITION_REVIEW_GENERATION36_20261120.md')
PARENT = '97a9112848f6f1365392f252a39084a591ac36ff'
MAPPED_REVIEW = 'cad6ba13246284a6cb5c267bd84957bd2ef0c0a5'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git('rev-parse', 'HEAD').decode().strip() == PARENT
receipt = json.loads((REPO / INDEX).read_text())
assert len(receipt['retainedArtifacts']) == 52
prior_tree = git('write-tree').decode().strip()
prior_patch = git('diff', '--cached', '--binary', '--full-index')
changed = git('diff', '--cached', '--name-only').decode().splitlines()
assert len(changed) == 54 and all(p.startswith('docs/') for p in changed)
assert git('diff').strip() == b''
old_mapping = next(a for a in receipt['retainedArtifacts'] if a['storedPath'].endswith('/root-integrated-evidence.json.gz'))
old_bytes = gzip.decompress((REPO / old_mapping['storedPath']).read_bytes())
mapping_path = ROOT / 'g36-integrated-evidence.json'
current_bytes = mapping_path.read_bytes()
old, current = json.loads(old_bytes), json.loads(current_bytes)
assert len(old) == 2 and len(current) == 3 and current[:2] == old
assert current[-1]['original'] == PARENT and current[-1]['integrated'] == MAPPED_REVIEW
review_patch = git('diff', '--binary', '--full-index', PARENT + '^', PARENT)
assert review_patch == git('diff', '--binary', '--full-index', MAPPED_REVIEW + '^', MAPPED_REVIEW)
assert len(git('diff', '--name-only', MAPPED_REVIEW + '^', MAPPED_REVIEW).decode().splitlines()) == 23
failure_output = '''{
  "index": "docs/engineering/solana-funding-admission-composition-review-generation36.json",
  "report": "docs/engineering/INDEPENDENT_SOLANA_FUNDING_ADMISSION_COMPOSITION_REVIEW_GENERATION36_20261120.md",
  "retainedArtifacts": 52,
  "documentationPaths": 54,
  "source": "b785a01ffc54a75d497641d0e758d077adff41d0",
  "tree": "f6cad0ba726fc8a077a54cb5610f2032e3cd0242"
}
Traceback (most recent call last):
  File "<stdin>", line 11, in <module>
AssertionError
'''.encode()
failure_script = OUT / 'packaging-check-attempt01.py'
failure = {
    'schema': 'p2p-offramp.g36-packaging-verifier-attempt.v1',
    'command': ['python', '-'], 'exitCode': 1,
    'reviewSource': PARENT, 'qualifiedSource': receipt['source'], 'qualifiedTree': receipt['tree'],
    'exactStagedExecutionTree': prior_tree,
    'exactStagedPatchSha256': sha(prior_patch),
    'stdinScriptSha256': sha(failure_script.read_bytes()),
    'outputSha256': sha(failure_output), 'outputBytes': len(failure_output),
    'recordedAfterExecutionAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exactStartedAtUnavailable': True,
    'captureMethod': 'Executed stdin source and complete combined output copied verbatim from the original tool call; no failed command rerun.',
    'failure': 'Packaging assumed every original coordinator metadata file would remain unchanged after its capture. Root appended the independently reviewed documentation mapping concurrently.',
    'capturedMappingSha256': sha(old_bytes), 'laterMappingSha256': sha(current_bytes),
    'capturedEntriesPreserved': True,
}
proof = {'capturedMappingSha256': sha(old_bytes), 'laterMappingSha256': sha(current_bytes),
         'capturedEntries': 2, 'laterEntries': 3, 'capturedPrefixUnchanged': True,
         'addedSourceReview': current[-1], 'completeSourceReviewPatchSha256': sha(review_patch),
         'exactMappedDocumentationPatch': True, 'sourceReviewDocumentationPaths': 23,
         'qualifiedReceiptLogsAndOutputsUnchanged': True}
for artifact in receipt['retainedArtifacts']:
    compressed = (REPO / artifact['storedPath']).read_bytes()
    raw = gzip.decompress(compressed)
    assert len(raw) == artifact['decodedBytes'] and len(compressed) == artifact['compressedBytes']
    assert sha(raw) == artifact['decodedSha256'] and sha(compressed) == artifact['compressedSha256']
    assert gzip.compress(raw, mtime=0) == compressed
    original = artifact.get('originalPath')
    if original and original != str(mapping_path):
        assert Path(original).read_bytes() == raw
    if artifact.get('scratchPath'):
        assert Path(artifact['scratchPath']).read_bytes() == compressed
new_files = {
    'packaging-check-attempt01.py': failure_script.read_bytes(),
    'packaging-check-attempt01.log': failure_output,
    'packaging-check-attempt01.json': (json.dumps(failure, indent=2) + '\n').encode(),
    'packaging-check-attempt01.patch': prior_patch,
    'root-integrated-evidence-after-source-review.json': current_bytes,
    'coordinator-index-append-verification.json': (json.dumps(proof, indent=2) + '\n').encode(),
    'finalize-composition-review.py': (OUT / 'finalize-composition-review.py').read_bytes(),
}
result = {'schema': 'p2p-offramp.g36-packaging-final-verification.v1',
          'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'qualifiedSource': receipt['source'], 'qualifiedTree': receipt['tree'],
          'capturedArtifactCountVerified': 52, 'capturedMappingPrefixPreserved': True,
          'laterSourceReviewMappingPatchVerified': True, 'sourceTestsOrBuildsRerun': False,
          'allVerified': True}
new_files['packaging-final-verification.json'] = (json.dumps(result, indent=2) + '\n').encode()
for name, raw in new_files.items():
    original = OUT / name
    if original.exists():
        assert original.read_bytes() == raw
    else:
        original.write_bytes(raw)
    compressed = gzip.compress(raw, mtime=0)
    stored = DEST / (name + '.gz')
    assert not (REPO / stored).exists()
    (REPO / stored).write_bytes(compressed)
    receipt['retainedArtifacts'].append({'originalPath': str(original), 'storedPath': str(stored),
        'decodedBytes': len(raw), 'decodedSha256': sha(raw),
        'compressedBytes': len(compressed), 'compressedSha256': sha(compressed), 'gzipMtime': 0})
receipt['packagingVerification'] = {'initialAttempt': failure, 'coordinatorIndexAppend': proof,
                                   'correctedResult': result}
assert len(receipt['retainedArtifacts']) == 60
(REPO / INDEX).write_text(json.dumps(receipt, indent=2) + '\n')
text = (REPO / REPORT).read_text()
addition = '''## Concurrent documentation-index append

A final packaging check initially required every original scratch metadata file to remain unchanged after capture. Root had meanwhile appended the completed source-review mapping (`97a9112` to `cad6ba1`) to its coordinator index. The captured two component entries remain byte-for-byte intact as the prefix of the later three-entry index. The newly appended mapping's complete 23-path documentation patch also matches exactly. All original qualification logs, receipts and output files remain unchanged.

The initial packaging stdin script, complete output, exact staged tree/binary patch and failure metadata are retained, together with both index snapshots and the successful append-verification proof. The failed command's precise start time was not captured and is not invented. The captured index was not rewritten to describe a later moment. This is a concurrent documentation bookkeeping change; it does not alter qualified source or test attribution.

'''
assert '## Concurrent documentation-index append' not in text
(REPO / REPORT).write_text(text.replace('## Retention and scope\n', addition + '## Retention and scope\n'))
print(json.dumps({'source': receipt['source'], 'artifacts': 60,
                  'documentationPaths': 62, 'allVerified': True}, indent=2))
