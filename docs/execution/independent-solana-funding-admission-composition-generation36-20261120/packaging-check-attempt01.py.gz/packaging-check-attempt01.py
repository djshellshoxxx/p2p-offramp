from pathlib import Path
import json,subprocess,gzip,hashlib
p=Path('docs/engineering/solana-funding-admission-composition-review-generation36.json');d=json.loads(p.read_text())
changed=subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines()
assert len(changed)==54 and all(x.startswith('docs/') for x in changed)
for a in d['retainedArtifacts']:
 b=Path(a['storedPath']).read_bytes();r=gzip.decompress(b)
 assert len(b)==a['compressedBytes'] and len(r)==a['decodedBytes']
 assert hashlib.sha256(b).hexdigest()==a['compressedSha256'] and hashlib.sha256(r).hexdigest()==a['decodedSha256']
 assert gzip.compress(r,mtime=0)==b
 if a.get('originalPath'):assert Path(a['originalPath']).read_bytes()==r
 staged=a.get('scratchPath')
 if staged:assert Path(staged).read_bytes()==b
s=subprocess.check_output(['git','write-tree'],text=True).strip()
def non_doc(ref):
 return {p:h for l in subprocess.check_output(['git','ls-tree','-r',ref],text=True).splitlines() for h,p in [l.split('\t',1)] if not p.startswith('docs/')}
assert non_doc(s)==non_doc('d36be3c5348b94d39836b73a3e0b9e864ff0a669')
assert len(non_doc(s))==1038
print(json.dumps({'documentationOnlyPaths':len(changed),'artifactsVerified':len(d['retainedArtifacts']),'nonDocumentationEntriesUnchanged':1038}))
