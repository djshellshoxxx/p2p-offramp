import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path('/workspace/scratch/dcf03ef9bee8/g36-admission-review')
REPO = HERE.parent / 'p2p-funding-admission-review-g36'
name = 'root-composition-verification-attempt02'
log, receipt = HERE / (name + '.log'), HERE / (name + '.json')
script = HERE / 'verify-root-composition.py'
snapshot = HERE / 'verify-root-composition-attempt02.py'
assert not any(p.exists() for p in [log, receipt, snapshot])
snapshot.write_bytes(script.read_bytes())
command = [sys.executable, str(script)]
metadata = {
    'schema': 'p2p-offramp.g36-composition-verifier-attempt.v1',
    'name': name, 'command': command,
    'source': 'b785a01ffc54a75d497641d0e758d077adff41d0',
    'tree': 'f6cad0ba726fc8a077a54cb5610f2032e3cd0242',
    'reviewCheckout': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'script': {'path': str(snapshot), 'sha256': hashlib.sha256(snapshot.read_bytes()).hexdigest()},
    'scope': 'Read-only source/artifact verification. No source tests or builds are run.',
}
with log.open('xb') as stream:
    result = subprocess.run(command, cwd=REPO, stdout=stream, stderr=subprocess.STDOUT)
raw = log.read_bytes()
metadata.update(completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                exitCode=result.returncode,
                log={'path': str(log), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
receipt.write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2))
sys.exit(result.returncode)
