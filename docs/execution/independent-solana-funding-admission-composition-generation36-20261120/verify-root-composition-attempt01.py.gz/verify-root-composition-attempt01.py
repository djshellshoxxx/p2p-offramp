import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess

WORKSPACE = Path('/workspace/scratch/dcf03ef9bee8')
REVIEW = WORKSPACE / 'p2p-funding-admission-review-g36'
ROOT = WORKSPACE / 'p2p-continuation-g36'
OUT = WORKSPACE / 'g36-admission-review/composition'
INPUT = WORKSPACE / 'p2p-g36-qualification/qualification.json'
DEST = Path('docs/execution/independent-solana-funding-admission-composition-generation36-20261120')
SOURCE = 'b785a01ffc54a75d497641d0e758d077adff41d0'
TREE = 'f6cad0ba726fc8a077a54cb5610f2032e3cd0242'
FEATURE = '54fb841a5d182da2929d71cbde087adea55e115f'
COMPONENT_PARENT = '98f75c23fe0db47f28fa5d7221048b631bc68b96'
G35 = 'ea3ee7f5b5d36456616bd9fef893257327560a10'
AUTHOR = '3283940bae1a2d4e7baabed66878ecb5d977bfb1'
DRIVER = 'd36be3c5348b94d39836b73a3e0b9e864ff0a669'
PR241 = '29491c2842e0aedcb00a674cbfffb9edc2424013'
REVIEW_HEAD = '97a9112848f6f1365392f252a39084a591ac36ff'
MAIN = '8e836baa877b676a863c877003e277b638fc5061'
OUT.mkdir(exist_ok=True)


def git(*args, repo=REVIEW):
    return subprocess.check_output(['git', *args], cwd=repo)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def entries(ref):
    return {p: h for row in git('ls-tree', '-r', ref).decode().splitlines()
            for h, p in [row.split('\t', 1)]}


def nondoc(ref):
    return {p: h for p, h in entries(ref).items() if not p.startswith('docs/')}


def preserve(name, data, original=None):
    compressed = gzip.compress(data, mtime=0)
    target = OUT / 'retained' / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == compressed, 'Refusing to overwrite differing retained evidence'
    else:
        target.write_bytes(compressed)
    return {'storedPath': str(DEST / (name + '.gz')), 'scratchPath': str(target),
            'originalPath': str(original) if original else None,
            'decodedBytes': len(data), 'decodedSha256': sha(data),
            'compressedBytes': len(compressed), 'compressedSha256': sha(compressed),
            'gzipMtime': 0}


assert git('rev-parse', 'HEAD').decode().strip() == REVIEW_HEAD
assert not git('status', '--porcelain')
assert git('rev-parse', SOURCE + '^{tree}').decode().strip() == TREE
assert git('rev-parse', SOURCE + '^').decode().strip() == FEATURE
assert git('rev-parse', FEATURE + '^').decode().strip() == COMPONENT_PARENT
assert git('rev-parse', G35 + '^').decode().strip() == PR241
git('merge-base', '--is-ancestor', PR241, SOURCE)
assert nondoc(COMPONENT_PARENT) == nondoc(G35)
assert nondoc(FEATURE) == nondoc(AUTHOR)
assert nondoc(SOURCE) == nondoc(DRIVER) == nondoc(REVIEW_HEAD)
assert len(nondoc(SOURCE)) == 1038
assert sum(x.startswith('160000 commit ') for x in nondoc(SOURCE).values()) == 2
root_head = git('rev-parse', 'HEAD', repo=ROOT).decode().strip()
assert nondoc(root_head) == nondoc(SOURCE)
source_entries, published_entries = entries(SOURCE), entries(PR241)
published_docs = {p: h for p, h in published_entries.items() if p.startswith('docs/')}
assert all(source_entries[p] == h for p, h in published_docs.items())
changed = git('diff', '--name-status', COMPONENT_PARENT, SOURCE).decode().splitlines()
assert len(changed) == 12
assert sum(x.startswith('M\t') for x in changed) == 9
assert sum(x.startswith('A\t') for x in changed) == 3
assert not any(x.startswith('D\t') for x in changed)
retained = []
patches = []
for label, parent_a, original, parent_b, combined in [
    ('admission', G35, AUTHOR, COMPONENT_PARENT, FEATURE),
    ('companion', AUTHOR, DRIVER, FEATURE, SOURCE),
]:
    patch_a = git('diff', '--binary', '--full-index', parent_a, original)
    patch_b = git('diff', '--binary', '--full-index', parent_b, combined)
    assert patch_a == patch_b
    artifact = preserve('source-' + label + '.patch', patch_a)
    retained.append(artifact)
    patches.append({'component': label, 'authorParent': parent_a, 'authorSource': original,
                    'combinedParent': parent_b, 'combinedSource': combined,
                    'completeBinaryPatchSha256': sha(patch_a), 'bytes': len(patch_a),
                    'exactPatch': True, 'retainedPath': artifact['storedPath']})
retained.append(preserve('source-combined.patch', git('diff', '--binary', '--full-index', COMPONENT_PARENT, SOURCE)))
for base in [PR241, MAIN]:
    assert git('diff', '--check', base + '..' + SOURCE) == b''

integrated_evidence_path = WORKSPACE / 'g36-integrated-evidence.json'
integrated_evidence_bytes = integrated_evidence_path.read_bytes()
integrated_evidence = json.loads(integrated_evidence_bytes)
for row in integrated_evidence:
    original, integrated = row['original'], row['integrated']
    assert git('diff', '--binary', '--full-index', original + '^', original) == git('diff', '--binary', '--full-index', integrated + '^', integrated)
    paths = git('diff', '--name-only', integrated + '^', integrated).decode().splitlines()
    assert len(paths) == row['paths'] and all(p.startswith('docs/') for p in paths)
    assert nondoc(integrated) == nondoc(SOURCE)
retained.append(preserve('root-integrated-evidence.json', integrated_evidence_bytes, integrated_evidence_path))
for name in ['g36-combined-source.json', 'g36-feature-source.json']:
    raw = (WORKSPACE / name).read_bytes()
    retained.append(preserve('root-' + name, raw, WORKSPACE / name))

receipt_bytes = INPUT.read_bytes()
receipt = json.loads(receipt_bytes)
assert receipt.get('completedAt'), 'Incomplete root qualification is not accepted'
assert receipt['source'] == receipt['finalSource'] == SOURCE and receipt['tree'] == TREE
assert receipt['nativeExecuted'] is False and receipt['cleanTrackedWorktree'] is True
assert receipt['startedAt'] == '2026-11-20T20:40:35.918385+00:00'
assert receipt['completedAt'] == '2026-11-20T20:42:30.030745+00:00'
retained.append(preserve('root-qualification.json', receipt_bytes, INPUT))
expected = [
    ('full-node', ['npm', 'test']), ('typecheck', ['npm', 'run', 'typecheck']),
    ('build-policy', ['npm', 'run', 'test:build-policy']),
    ('boundaries', ['npm', 'run', 'check:boundaries']),
    ('default-build', ['node', 'apps/web/scripts/build.mjs']),
    ('demo-build', ['node', 'apps/web/scripts/build.mjs', 'demo']),
    ('native-fixture-preparation', ['node', 'scripts/test-update-runtime-browser.mjs', '--build-only']),
]
assert [(x['name'], x['command']) for x in receipt['commands']] == expected
commands = []
last_time = receipt['startedAt']
for row in receipt['commands']:
    assert row['source'] == SOURCE and row['tree'] == TREE and row['exitCode'] == 0
    assert last_time <= row['startedAt'] <= row['completedAt'] <= receipt['completedAt']
    last_time = row['completedAt']
    raw = Path(row['log']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    counts = {}
    for label in ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']:
        matches = re.findall(r'^[#ℹ]\s+' + label + r'\s+(\d+)\s*$', raw.decode(), re.M)
        if matches:
            assert len(matches) == 1
            counts[label] = int(matches[0])
    assert counts == row['counts']
    if counts:
        assert counts['tests'] == counts['pass']
        assert all(counts[k] == 0 for k in ['fail', 'cancelled', 'skipped', 'todo'])
    retained_log = preserve('root-' + row['name'] + '.log', raw, row['log'])
    retained.append(retained_log)
    commands.append({**row, 'rawLogVerified': True, 'retainedLog': retained_log['storedPath']})
assert commands[0]['counts']['tests'] == 2864
assert commands[0]['sha256'] == 'd7848eb158610f183e7be22060490860ae940ff4d292b47c349b584e627244c1'
assert commands[2]['counts']['tests'] == 58
assert '244 production source files; core entry graph visited 157 module(s)' in Path(commands[3]['log']).read_text()
assert all(p in Path(commands[1]['log']).read_text() for p in ['tsc --noEmit', 'tsconfig.runtime.json', 'tsconfig.worker.json', 'tsconfig.ui.json'])
previous_path = 'docs/engineering/evidence/solana-funding-proposal-composition-independent-review-generation35/root-qualification.json.gz'
previous_bytes = gzip.decompress(git('show', COMPONENT_PARENT + ':' + previous_path))
previous = json.loads(previous_bytes)
assert previous['source'] == previous['finalSource'] == G35 and previous.get('completedAt')
assert previous['commands'][0]['counts']['tests'] == 2817
assert commands[0]['counts']['tests'] - previous['commands'][0]['counts']['tests'] == 47
retained.append(preserve('previous-g35-qualification.json', previous_bytes))

artifacts = []
module_references = 0
source_module_references = 0
dependency_module_references = 0
assert set(receipt['artifacts']) == {'default', 'demo'}
for mode, recorded in receipt['artifacts'].items():
    assert recorded == previous['artifacts'][mode]
    directory = ROOT / 'apps/web' / ('dist' if mode == 'default' else 'dist-demo')
    evidence_bytes = (directory / 'local-build-evidence.json').read_bytes()
    evidence = json.loads(evidence_bytes)
    assert evidence == recorded['evidence']
    assert evidence['ReleaseEnabled'] == 0 and evidence['syntheticDemo'] == (mode == 'demo')
    assert all(evidence[k] is False for k in ['testnet', 'signedRelease', 'releaseAcceptance', 'framingAttestation'])
    assert not evidence['inspection']['completeXssProof'] and 'testnetTrust' not in evidence
    listed = set()
    for asset in evidence['assets']:
        path = Path(asset['path'])
        assert not path.is_absolute() and '..' not in path.parts and str(path) not in listed
        listed.add(str(path))
        raw = (directory / path).read_bytes()
        assert len(raw) == asset['bytes'] and sha(raw) == asset['sha256']
    actual = {str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()}
    assert actual == listed | {'local-build-evidence.json'}
    assert len(listed) == evidence['inspection']['files']
    assert sum(a['bytes'] for a in evidence['assets']) == evidence['inspection']['bytes']
    policy = json.loads((directory / 'content-policy.json').read_bytes())
    assert policy['ReleaseEnabled'] == 0 and policy['releaseAcceptance'] is False
    assert policy['manifest']['connectOrigins'] == [] and "connect-src 'none'" in policy['csp']
    graphs = []
    for path, graph_record in recorded['graphs'].items():
        raw = (directory / path).read_bytes()
        graph = json.loads(raw)
        assert sha(raw) == graph_record['sha256'] and graph == graph_record['graph']
        modules = graph['modules']
        paths = {m['path'] for m in modules}
        assert len(paths) == len(modules)
        assert not any(p.startswith(('apps/web/src/solana-localnet/', 'packages/chain-solana/')) for p in paths)
        assert not any(re.search(r'packages/security/src/release-update(?:-http|-store)?\.ts$', p) for p in paths)
        for module in modules:
            relative = Path(module['path'])
            assert not relative.is_absolute() and '..' not in relative.parts
            raw_module = (ROOT / relative).read_bytes()
            assert sha(raw_module) == module['sha256']
            assert sha((REVIEW / relative).read_bytes()) == module['sha256']
            module_references += 1
            if module['path'].startswith('node_modules/'):
                dependency_module_references += 1
            else:
                source_module_references += 1
                assert git('show', SOURCE + ':' + module['path']) == raw_module
        if path == 'core-graph-document.json':
            assert {'apps/web/src/ui/StartupCompatibilityNotice.tsx', 'apps/web/src/ui/RetentionPreviewPanel.tsx',
                    'apps/web/src/ui/GenericAppShare.tsx', 'apps/web/src/sharing/generic-app-link.ts'} <= paths
            assert 'packages/storage/src/retention-service.ts' not in paths
        if path == 'core-graph-worker.json':
            assert 'packages/storage/src/retention-service.ts' in paths
            assert not {'apps/web/src/ui/StartupCompatibilityNotice.tsx', 'apps/web/src/ui/GenericAppShare.tsx',
                        'apps/web/src/sharing/generic-app-link.ts'} & paths
        graphs.append({'path': path, 'sha256': sha(raw), 'modules': len(modules),
                       'actualAndFrozenSourceHashesVerified': True})
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            relative = path.relative_to(directory)
            raw = path.read_bytes()
            # Compare complete current files with the prior generation's
            # retained actual bytes, including the evidence manifest itself.
            old_path = 'docs/engineering/evidence/solana-funding-proposal-composition-independent-review-generation35/outputs/' + mode + '/' + relative.as_posix() + '.gz'
            assert gzip.decompress(git('show', COMPONENT_PARENT + ':' + old_path)) == raw
            retained.append(preserve('outputs/' + mode + '/' + relative.as_posix(), raw, path))
    artifacts.append({'profile': mode, 'assets': len(listed), 'assetBytes': evidence['inspection']['bytes'],
                      'actualFilesIncludingEvidence': len(actual), 'allActualFilesAccountedFor': True,
                      'allActualBytesEqualGeneration35': True, 'evidenceSha256': sha(evidence_bytes),
                      'graphs': graphs, 'ReleaseEnabled': 0, 'connectOrigins': []})
assert module_references == 274 and source_module_references == 252 and dependency_module_references == 22
entry = next(a for a in receipt['artifacts']['default']['evidence']['assets']
             if re.fullmatch(r'assets/index-[A-Za-z0-9_-]+\.js', a['path']))
main = (ROOT / 'apps/web/dist' / entry['path']).read_text()
captures = list(re.finditer(r'(?:,|var )([\w$]+)=import\.meta\.url,', main))
assert len(captures) == 1 and '{entryModuleUrl:' + captures[0].group(1) + '}' in main
assert 'import(`./OfflineRoot-' in main
full_log = Path(commands[0]['log']).read_text()
assert re.search(r'^✔ emitted native Worker artifact requires its own library profile, exact CSP and unchanged release refusal \(', full_log, re.M)
assert 'vite v8.3.5 building client environment for solana-localnet...' in full_log

preparations = [json.loads(line) for line in Path(commands[-1]['log']).read_text().splitlines()
                if line.startswith('{"fixture":')]
assert len(preparations) == 1 and preparations[0] == commands[-1]['preparation']
preparation = preparations[0]
assert preparation['nativeExecuted'] is False and preparation['strictFixtureCompilation'] is True
assert preparation['defaultUpdaterIncluded'] is False and preparation['ReleaseEnabled'] == 0
assert preparation['fixtureModules'] == 37
assert preparation == previous['commands'][-1]['preparation']
default = receipt['artifacts']['default']
worker = next(a for a in default['evidence']['assets'] if a['path'] == preparation['emittedWorker']['path'])
assert worker['sha256'] == preparation['emittedWorker']['sha256']
for graph in preparation['defaultGraphs']:
    actual = default['graphs'][graph['path']]
    assert graph['sha256'] == actual['sha256'] and graph['modules'] == len(actual['graph']['modules'])

result = {
    'schema': 'p2p-offramp.g36-independent-composition-verification.v1',
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': SOURCE, 'tree': TREE, 'componentParent': COMPONENT_PARENT,
    'qualifiedG35Source': G35, 'reviewedCombinedSource': DRIVER,
    'independentReviewEvidenceParent': REVIEW_HEAD, 'observedRootDocumentationHead': root_head,
    'publishedAncestor': {'pr': 241, 'head': PR241, 'localAncestryVerified': True, 'liveRemoteRefreshed': False},
    'sourceProof': {'nonDocumentationEntries': 1038, 'gitlinksPreserved': 2,
                    'allReviewedNonDocumentationEntriesExact': True,
                    'publishedDocumentationEntriesPreserved': len(published_docs),
                    'changes': changed, 'patchMappings': patches,
                    'integratedComponentEvidence': integrated_evidence,
                    'fullWhitespaceBaselines': [PR241, MAIN]},
    'qualificationStartedAt': receipt['startedAt'], 'qualificationCompletedAt': receipt['completedAt'],
    'commands': commands, 'artifacts': artifacts, 'retainedArtifacts': retained,
    'totalActualOutputFiles': sum(x['actualFilesIncludingEvidence'] for x in artifacts),
    'totalAssetsVerified': sum(x['assets'] for x in artifacts),
    'totalGraphsVerified': sum(len(x['graphs']) for x in artifacts),
    'graphModuleReferencesVerified': module_references,
    'frozenRepositoryModuleReferences': source_module_references,
    'physicalDependencyModuleReferences': dependency_module_references,
    'nativeProfileBuildCoveredByMaintainedNodeCase': True,
    'nativeFixturePreparation': preparation,
    'limits': {'reviewerReranTestsOrBuilds': False, 'nativeBrowserExecuted': False,
               'nativeValidatorExecuted': False, 'financialJourneyExecuted': False,
               'temporaryPreparationModulesRetainedOrIndependentlyRecompiled': False,
               'preparationLogAndActualDefaultWorkerGraphsVerified': True,
               'remoteActionsPerformed': False, 'mergeAuthorizationClaimed': False,
               'ReleaseEnabled': 0},
    'allVerified': True,
}
assert result['totalActualOutputFiles'] == 27 and result['totalAssetsVerified'] == 25
assert result['totalGraphsVerified'] == 6
target = OUT / 'root-composition-verification.json'
assert not target.exists()
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['source', 'tree', 'qualificationCompletedAt',
                                       'totalActualOutputFiles', 'totalAssetsVerified',
                                       'totalGraphsVerified', 'graphModuleReferencesVerified',
                                       'allVerified']}, indent=2))
