import{a as e,i as t,n,r,t as i}from"./OfflineRoot-DZJg4sm1.js";var a=`{
  "version": 1,
  "releaseId": "test-local-only",
  "networks": [
    {
      "id": "local-evm",
      "chain": "evm",
      "chainIdentity": "31337",
      "genesisHash": "0x3131313131313131313131313131313131313131313131313131313131313131",
      "endpoints": [
        {
          "id": "local-node",
          "url": "http://127.0.0.1:8545/"
        }
      ],
      "finality": {
        "kind": "evm-finalized-tag"
      },
      "assets": [
        {
          "id": "native",
          "kind": "native",
          "address": null,
          "decimals": 18,
          "transferPolicy": "exact-transfer"
        },
        {
          "id": "test-usd",
          "kind": "erc20",
          "address": "0x7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a",
          "decimals": 6,
          "transferPolicy": "exact-transfer"
        }
      ],
      "deployments": [
        {
          "id": "escrow-local-v1",
          "address": "0x5e5e5e5e5e5e5e5e5e5e5e5e5e5e5e5e5e5e5e5e",
          "protocolVersion": 1,
          "artifactSha256": "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
          "runtime": {
            "kind": "evm-code",
            "keccak256": "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
            "upgradeable": false
          },
          "supportedAssetIds": [
            "native",
            "test-usd"
          ]
        }
      ],
      "environment": "local"
    }
  ]
}
`,o=`14e7ecfb5aff74253affe0d2e8560728763f01db405bcc7efdca964ef103ca6a`,s=`{
  "format": "p2p-offramp/local-terms-review/v1",
  "terms": {
    "orderId": "a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1",
    "revision": "1",
    "networkId": "local-evm",
    "deploymentId": "escrow-local-v1",
    "seller": "0xacf7b7c8271e99b3be70c3f476c7c20963e06b8e",
    "buyer": "0x3b0d3efcce062566bd2a28c2f2bba7e1d1504ee5",
    "assetKind": "native",
    "asset": "0x0000000000000000000000000000000000000000",
    "amountBaseUnits": "1000000000000000000",
    "privateAgreementHash": "972459f32afc027880b2e4910469dbce213ed14e19e7273412fb8bed0fa83605",
    "capabilitiesHash": "6a53056d4685133d77cb26b16b7c5c281581a414b586337e0314a5296280e2e4",
    "sellerNonce": "3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c",
    "acceptBeforeSeconds": "1700000000",
    "escrowExpirySeconds": "1700086400"
  },
  "privateAgreement": {
    "v": 1,
    "orderId": "a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1",
    "revision": "1",
    "fiatCurrency": "USD",
    "fiatMinorUnits": "5000",
    "fiatScale": 2,
    "paymentInstructions": "SYNTHETIC test payment note A",
    "capabilities": [
      {
        "id": "local-test-cap",
        "version": "1",
        "policyHash": "9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c"
      }
    ],
    "agreementSalt": "1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a"
  }
}
`,c=`{
  "format": "p2p-offramp/local-terms-review/v1",
  "terms": {
    "orderId": "b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2",
    "revision": "1",
    "networkId": "local-evm",
    "deploymentId": "escrow-local-v1",
    "seller": "0xacf7b7c8271e99b3be70c3f476c7c20963e06b8e",
    "buyer": "0x3b0d3efcce062566bd2a28c2f2bba7e1d1504ee5",
    "assetKind": "erc20",
    "asset": "0x7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a7a",
    "amountBaseUnits": "25000000",
    "privateAgreementHash": "346b2013fd019f7d9b9e2f789e458940e5c990d9fc540c7d871a6023acc9fbab",
    "capabilitiesHash": "6a53056d4685133d77cb26b16b7c5c281581a414b586337e0314a5296280e2e4",
    "sellerNonce": "4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d4d",
    "acceptBeforeSeconds": "1700000000",
    "escrowExpirySeconds": "1700086400"
  },
  "privateAgreement": {
    "v": 1,
    "orderId": "b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2",
    "revision": "1",
    "fiatCurrency": "USD",
    "fiatMinorUnits": "2500",
    "fiatScale": 2,
    "paymentInstructions": "SYNTHETIC test payment note B",
    "capabilities": [
      {
        "id": "local-test-cap",
        "version": "1",
        "policyHash": "9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c9c"
      }
    ],
    "agreementSalt": "2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b"
  }
}
`,l=new TextEncoder,u=e(`samples`),d=`0xacf7b7c8271e99b3be70c3f476c7c20963e06b8e`,f=`0x3b0d3efcce062566bd2a28c2f2bba7e1d1504ee5`;async function p(e){let t=`c3`.repeat(32),a={v:1,orderId:t,revision:`1`,fiatCurrency:`EUR`,fiatMinorUnits:`12345`,fiatScale:2,paymentInstructions:`SYNTHETIC demo instructions.
Do not send real money.`,capabilities:[],agreementSalt:`5d`.repeat(32)},o=e+3600n,s={orderId:t,revision:`1`,networkId:`local-evm`,deploymentId:`escrow-local-v1`,seller:d,buyer:f,assetKind:`native`,asset:`0x${`0`.repeat(40)}`,amountBaseUnits:`250000000000000000`,privateAgreementHash:await r(n(a)),capabilitiesHash:await r(i([])),sellerNonce:`6e`.repeat(32),acceptBeforeSeconds:o.toString(),escrowExpirySeconds:(o+86400n).toString()};return l.encode(JSON.stringify({format:`p2p-offramp/local-terms-review/v1`,terms:s,privateAgreement:a},null,2)+`
`)}var m=Object.freeze([Object.freeze({id:`fresh-native`,label:u.freshNative,load:e=>p(e)}),Object.freeze({id:`frozen-native`,label:u.frozenNative,load:async()=>l.encode(s)}),Object.freeze({id:`frozen-erc20`,label:u.frozenErc20,load:async()=>l.encode(c)})]),h=async()=>{let e=new t,n=await e.load(l.encode(a),o);return!n.ok||n.value.networks.some(e=>e.environment!==`local`)?{kind:`failed`}:{kind:`ready`,label:`synthetic-demo`,registry:e,samples:m}};export{h as syntheticDemoSource};