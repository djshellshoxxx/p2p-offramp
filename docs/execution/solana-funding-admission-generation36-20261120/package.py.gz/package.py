import datetime,gzip,hashlib,json,os,subprocess,tempfile
from pathlib import Path
repo=Path('/workspace/scratch/dcf03ef9bee8/p2p-funding-admission-g36'); raw=Path(__file__).parent
source=json.loads((raw/'source.json').read_text()); destination=repo/'docs/execution/solana-funding-admission-generation36-20261120'
assert not destination.exists(); destination.mkdir(parents=True)
def digest(b):return hashlib.sha256(b).hexdigest()
def git(*a,env=None):return subprocess.check_output(['git',*a],cwd=repo,env=env)
assert git('rev-parse','HEAD').decode().strip()==source['source'] and not git('status','--porcelain').strip()
artifacts=[]
def retain(path,name=None):
    data=path.read_bytes(); target=destination/((name or path.name)+'.gz'); compressed=gzip.compress(data,mtime=0)
    assert not target.exists() and gzip.decompress(compressed)==data and compressed[4:8]==bytes(4);target.write_bytes(compressed)
    artifacts.append({'originalPath':str(path),'storedPath':str(target.relative_to(repo)),'decodedBytes':len(data),'compressedBytes':len(compressed),'decodedSha256':digest(data),'compressedSha256':digest(compressed)})
    return str(target.relative_to(repo))
commands=[];snapshots=[]
for path in sorted(raw.glob('[0-9][0-9]-*.json')):
    command=json.loads(path.read_text()); assert command['unchangedExecutionTree'] and command['executionTreeAfter']==command['executionTree']
    log=Path(command['log']); patch=Path(command['patch']); assert len(log.read_bytes())==command['bytes'] and digest(log.read_bytes())==command['sha256']; assert digest(patch.read_bytes())==command['patchSha256']
    fd,index=tempfile.mkstemp(prefix='g36-reconstruction-');os.close(fd);os.unlink(index);env=dict(os.environ,GIT_INDEX_FILE=index)
    try:
        git('read-tree',command['head'],env=env)
        if patch.stat().st_size:subprocess.run(['git','apply','--cached','--binary',str(patch)],cwd=repo,env=env,check=True)
        tree=git('write-tree',env=env).decode().strip();assert tree==command['executionTree']
    finally:
        if os.path.exists(index):os.unlink(index)
    snapshots.append({'name':command['name'],'head':command['head'],'executionTree':tree,'patchSha256':command['patchSha256'],'exactReconstruction':True,'matchesFrozenSource':tree==source['tree']})
    command.update(retainedLog=retain(log),retainedExecutionPatch=retain(patch),retainedOriginalReceipt=retain(path),patchBytes=patch.stat().st_size,cwd=str(repo))
    commands.append(command)
assert len(commands)==7 and commands[0]['counts']=={'tests':26,'pass':0,'fail':26,'cancelled':0,'skipped':0,'todo':0}
assert commands[0]['exitCode']==1 and all(c['exitCode']==0 for c in commands[1:])
assert commands[3]['counts']=={'tests':153,'pass':153,'fail':0,'cancelled':0,'skipped':0,'todo':0}
for name in ['run.py','package.py']:retain(raw/name)
patch=raw/'frozen-source.patch'; assert not patch.exists();patch.write_bytes(git('diff','--binary','--full-index',source['parent'],source['source']));retain(patch)
rows=git('ls-tree','-r','-z',source['source']).split(b'\0');entries={r.split(b'\t',1)[1].decode():r.split(b'\t',1)[0].decode() for r in rows if r}
verification={'schema':'p2p-offramp.g36-author-execution-snapshots.v1','source':source['source'],'tree':source['tree'],'snapshots':snapshots,'allVerified':True}
(destination/'execution-snapshot-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
receipt={'schema':'p2p-offramp.solana-funding-admission-generation36.v1','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':source['parent'],'source':source['source'],'tree':source['tree'],'worktree':str(repo),'branch':'codex/funding-admission-g36-20261120','changedPaths':source['paths'],'sourceScope':{'added':[p for p in source['paths'] if p in ['apps/web/test/solana-funding-admission-ui.test.mjs','apps/web/test/solana-localnet-funding-admission.test.mjs']],'modified':[p for p in source['paths'] if p not in ['apps/web/test/solana-funding-admission-ui.test.mjs','apps/web/test/solana-localnet-funding-admission.test.mjs']],'deleted':[],'nonDocumentationEntries':1037,'gitlinksIncluded':True},'sourceBlobs':{p:{'gitEntry':entries[p],'sha256':digest(git('show',source['source']+':'+p))} for p in source['paths']},'commands':commands,'executionSnapshotVerification':'docs/execution/solana-funding-admission-generation36-20261120/execution-snapshot-verification.json','artifacts':artifacts,'limits':['Only the five local-profile production paths, two new focused tests and one synthetic snapshot fixture changed.','The baseline stops at missing-command/inventory assertions; the final153-case selection has40newcases and113existing adjacent cases. Counts overlap earlier selections.','All seven execution snapshots are exact uncommitted trees; the final four match the later frozen source tree.','No full repository suite, build, browser, native validator, financial run, external action or dependency mutation was performed.','In-memory encrypted vault/scripted RPC and controlled TSX/Worker delivery do not establish hosted/native/browser acceptance.','Native browser acceptance companion, independent review, combined qualification and Tier C merge gates remain separate. ReleaseEnabled=0.']}
(destination/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
report=repo/'docs/engineering/SOLANA_FUNDING_ADMISSION_GENERATION36_20261120.md';assert not report.exists();report.write_bytes((raw/'REPORT.md').read_bytes())
for entry in artifacts:
    data=(repo/entry['storedPath']).read_bytes();assert digest(data)==entry['compressedSha256'];decoded=gzip.decompress(data);assert digest(decoded)==entry['decodedSha256'];assert len(decoded)==entry['decodedBytes']
print(json.dumps({'source':source['source'],'tree':source['tree'],'artifacts':len(artifacts),'snapshots':len(snapshots),'documents':len(list(destination.iterdir()))+1,'verified':True}))
