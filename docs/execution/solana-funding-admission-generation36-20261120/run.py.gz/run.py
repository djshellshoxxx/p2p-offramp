import datetime,hashlib,json,os,re,subprocess,sys,tempfile
from pathlib import Path
repo=Path('/workspace/scratch/dcf03ef9bee8/p2p-funding-admission-g36'); root=Path(__file__).parent
name=sys.argv[1]; command=sys.argv[2:]; path=root/(name+'.log'); receipt=root/(name+'.json'); patch=root/(name+'.patch')
assert name and command and not path.exists() and not receipt.exists() and not patch.exists()
def git(*args,env=None): return subprocess.check_output(['git',*args],cwd=repo,env=env)
def snapshot():
    fd,index=tempfile.mkstemp(prefix='g36-index-'); os.close(fd); os.unlink(index); env=dict(os.environ,GIT_INDEX_FILE=index)
    try:
        git('read-tree','HEAD',env=env); git('add','-A',env=env)
        return git('write-tree',env=env).decode().strip(),git('diff','--cached','--binary','--full-index','HEAD',env=env)
    finally:
        if os.path.exists(index):os.unlink(index)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
head=git('rev-parse','HEAD').decode().strip(); tree,diff=snapshot(); patch.write_bytes(diff)
r={'name':name,'head':head,'executionTree':tree,'command':command,'startedAt':now(),'patch':str(patch),'patchSha256':hashlib.sha256(diff).hexdigest(),'statusBefore':git('status','--porcelain').decode()}
receipt.write_text(json.dumps(r,indent=2)+'\n')
with path.open('xb') as output: process=subprocess.run(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
data=path.read_bytes(); counts={}
for key,value in re.findall(r'^[#ℹ]\s+(tests|pass|fail|cancelled|skipped|todo)\s+(\d+)',data.decode(errors='replace'),re.M):counts[key]=int(value)
endtree,enddiff=snapshot(); r.update(completedAt=now(),exitCode=process.returncode,counts=counts,log=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),executionTreeAfter=endtree,unchangedExecutionTree=endtree==tree,statusAfter=git('status','--porcelain').decode())
receipt.write_text(json.dumps(r,indent=2)+'\n'); print(json.dumps(r)); sys.exit(process.returncode)
