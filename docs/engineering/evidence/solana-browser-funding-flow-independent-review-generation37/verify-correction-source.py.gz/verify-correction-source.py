import hashlib
import json
import subprocess
from pathlib import Path

REPO = Path('/workspace/scratch/dcf03ef9bee8/p2p-browser-funding-flow-review-g37')
BEFORE = 'cbda12a11c24014e2a791d058460e642bad9f995'
SOURCE = '28fa8516d2e1f26740a5370077f9b2fdbaa2c086'
CORRECTION = '3ccf809e01e729980b3ab5fbe12ba3993fbe9982'
NATIVE_EVIDENCE = '3be8f3e439ab8101bfd0545774dfb4461a924cdd'
NATIVE_RECEIPT = 'docs/execution/solana-browser-funding-native-generation37-20261120/receipt.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def entries(ref):
    return {path: entry for entry, path in (item.split(b'\t', 1)
            for item in git('ls-tree', '-rz', '--full-tree', ref).split(b'\0') if item)
            if not path.startswith(b'docs/')}


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert git('rev-parse', SOURCE + '^').decode().strip() == BEFORE
paths = git('diff', '--name-only', BEFORE, SOURCE).decode().splitlines()
assert paths == ['apps/web/src/solana-localnet/controller.ts', 'apps/web/test/solana-funding-flow-support.mjs',
                 'apps/web/test/solana-localnet-funding-flow.test.mjs']
patch = git('diff', '--binary', BEFORE, SOURCE)
assert patch == git('diff', '--binary', CORRECTION + '^', CORRECTION)
expected = entries(BEFORE)
corrected = entries(CORRECTION)
for path in paths:
    expected[path.encode()] = corrected[path.encode()]
assert expected == entries(SOURCE) and len(expected) == 1043
native = json.loads(git('show', NATIVE_EVIDENCE + ':' + NATIVE_RECEIPT))
for item in native['compilation']['inputs']:
    assert sha(git('show', SOURCE + ':' + item['path'])) == item['sha256']
git('diff', '--check', '8e836baa877b676a863c877003e277b638fc5061', SOURCE)
result = {
    'source': SOURCE, 'tree': git('rev-parse', SOURCE + '^{tree}').decode().strip(),
    'previousReviewedSource': BEFORE, 'originalCorrection': CORRECTION,
    'originalCorrectionParent': git('rev-parse', CORRECTION + '^').decode().strip(),
    'changedPaths': paths, 'binaryPatchExact': True, 'patchSha256': sha(patch),
    'nonDocumentationEntries': 1043, 'allOtherNonDocumentationEntriesUnchanged': True,
    'nativeCompilationInputsStillExact': len(native['compilation']['inputs']),
    'nativeCodeAndOracleUnchanged': True, 'fullMainBaselineWhitespace': 'pass',
    'authorityReview': 'Snapshot uses the pure reference predicate after one currentness admission; every economic ownership path still calls #current(owner.epoch) and the same exact reference tuple.',
    'reviewScriptSha256': sha(Path(__file__).read_bytes()),
}
Path(__file__).with_name('correction-source-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
