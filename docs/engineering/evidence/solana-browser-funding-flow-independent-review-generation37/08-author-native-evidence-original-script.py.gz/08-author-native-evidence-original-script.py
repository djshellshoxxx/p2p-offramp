import gzip
import hashlib
import json
import os
import re
import subprocess
import tempfile
from pathlib import Path

REPO = Path('/workspace/scratch/dcf03ef9bee8/p2p-browser-funding-flow-review-g37')
OUT = Path(__file__).resolve().parent
BASE = 'b785a01ffc54a75d497641d0e758d077adff41d0'
APP = '107ce93d030298f2668285067e156979c883184d'
NATIVE = 'd8dbf9e82743fd670c7d3af80a024720cbfb0538'
COMBINED = 'cbda12a11c24014e2a791d058460e642bad9f995'
APP_DOCS = 'cc144c69b7ee190880aff7f51a86d74fde863522'
NATIVE_DOCS = '3be8f3e439ab8101bfd0545774dfb4461a924cdd'
APP_RECEIPT = 'docs/execution/solana-browser-funding-generation37-20261120/receipt.json'
NATIVE_RECEIPT = 'docs/execution/solana-browser-funding-native-generation37-20261120/receipt.json'


def git(*args, env=None, input=None):
    return subprocess.check_output(['git', *args], cwd=REPO, env=env, input=input)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(ref, path):
    return git('show', f'{ref}:{path}')


def tree(ref, nondoc=False):
    entries = {}
    for item in git('ls-tree', '-rz', '--full-tree', ref).split(b'\0'):
        if not item:
            continue
        entry, path = item.split(b'\t', 1)
        if not nondoc or not path.startswith(b'docs/'):
            entries[path] = entry
    return entries


def counts(raw):
    return {name: int(number) for name, number in re.findall(
        r'^[#ℹ]\s+(tests|pass|fail|cancelled|skipped|todo)\s+(\d+)\s*$', raw.decode(), re.M)}


def reconstruct(head, patch, expected):
    with tempfile.TemporaryDirectory(prefix='g37-independent-evidence-index-') as temporary:
        env = {**os.environ, 'GIT_INDEX_FILE': str(Path(temporary) / 'index')}
        git('read-tree', head, env=env)
        if patch:
            git('apply', '--cached', '--binary', '--whitespace=nowarn', '-', env=env, input=patch)
        assert git('write-tree', env=env).decode().strip() == expected


def artifacts(ref, receipt):
    values = {}
    for item in receipt['artifacts']:
        path = item.get('storedPath', item.get('path'))
        compressed = blob(ref, path)
        assert len(compressed) == item['compressedBytes'] and sha(compressed) == item['compressedSha256']
        assert int.from_bytes(compressed[4:8], 'little') == 0
        raw = gzip.decompress(compressed)
        assert len(raw) == item.get('decodedBytes', item.get('rawBytes'))
        assert sha(raw) == item.get('decodedSha256', item.get('rawSha256'))
        name = Path(item['originalPath']).name
        assert name not in values
        values[name] = raw
    return values


assert git('rev-parse', 'HEAD').decode().strip() == COMBINED
app_receipt_bytes = blob(APP_DOCS, APP_RECEIPT)
native_receipt_bytes = blob(NATIVE_DOCS, NATIVE_RECEIPT)
app = json.loads(app_receipt_bytes)
native = json.loads(native_receipt_bytes)
app_artifacts = artifacts(APP_DOCS, app)
native_artifacts = artifacts(NATIVE_DOCS, native)
assert len(app_artifacts) == 33 and len(native_artifacts) == 42
assert git('rev-parse', APP_DOCS + '^').decode().strip() == APP
assert git('rev-parse', NATIVE_DOCS + '^').decode().strip() == native['combined']['source']
assert tree(APP_DOCS, True) == tree(APP, True)
assert tree(NATIVE_DOCS, True) == tree(COMBINED, True)
assert git('rev-parse', COMBINED + '^{tree}').decode().strip() == native['combined']['tree']
assert native['combined']['tree'] == '1549b5ba9077244e43720edbb1072eceeb6abb60'
assert tree(native['combined']['source']) == tree(COMBINED)
for ref in [APP, NATIVE]:
    assert git('rev-parse', ref + '^').decode().strip() == BASE
expected = tree(BASE)
changes = {}
for label, ref in [('application', APP), ('native', NATIVE)]:
    paths = git('diff', '--name-only', BASE, ref).decode().splitlines()
    changes[label] = paths
    current = tree(ref)
    for path in paths:
        assert not path.startswith('docs/')
        expected[path.encode()] = current[path.encode()]
assert expected == tree(COMBINED)
assert len(tree(COMBINED, True)) == 1043

app_snapshots = []
for execution in app['executions']:
    name = execution['name']
    raw = app_artifacts[name + '.log']
    patch = app_artifacts[name + '.patch']
    assert len(raw) == execution['bytes'] and sha(raw) == execution['sha256']
    assert sha(patch) == execution['patchSha256']
    assert counts(raw) == execution['counts']
    reconstruct(execution['head'], patch, execution['tree'])
    app_snapshots.append({'name': name, 'head': execution['head'], 'executionTree': execution['tree'],
                          'exitCode': execution['exitCode'], 'counts': execution['counts'],
                          'logSha256': execution['sha256'], 'reconstructed': True})
assert len(app_snapshots) == 9
assert app_snapshots[6]['counts'] == {'tests': 208, 'pass': 208, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}
assert app_snapshots[6]['executionTree'] == app['source']['tree']
assert [item['exitCode'] for item in app_snapshots] == [1, 1, 1, 0, 0, 1, 0, 0, 0]
assert app_snapshots[5]['counts'] == {'tests': 41, 'pass': 37, 'fail': 4, 'cancelled': 0, 'skipped': 0, 'todo': 0}

native_snapshots = []
for execution in native['commands']:
    name = execution['name']
    raw = native_artifacts[name + '.log']
    assert len(raw) == execution['bytes'] and sha(raw) == execution['sha256']
    assert counts(raw) == execution['counts']
    for phase in ['before', 'after']:
        snapshot = execution[phase]
        patch = native_artifacts[Path(snapshot['patch']).name]
        assert len(patch) == snapshot['patchBytes'] and sha(patch) == snapshot['patchSha256']
        reconstruct(snapshot['head'], patch, snapshot['executionTree'])
        native_snapshots.append({'name': name, 'phase': phase, 'head': snapshot['head'],
                                'executionTree': snapshot['executionTree'], 'reconstructed': True})
    assert execution['before']['executionTree'] == execution['after']['executionTree']
assert len(native_snapshots) == 14
assert native['commands'][0]['exitCode'] == 1
assert all(item['exitCode'] == 0 for item in native['commands'][1:])
assert native['commands'][4]['counts'] == {'tests': 19, 'pass': 19, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}

compile = native['compilation']
assert compile['inputCount'] == len(compile['inputs']) == 70
assert len({entry['path'] for entry in compile['inputs']}) == 70
for entry in compile['inputs']:
    assert sha(blob(COMBINED, entry['path'])) == entry['sha256']
for entry in compile['outputs']:
    raw = native_artifacts[entry['file'].removesuffix('.gz')]
    assert len(raw) == entry['rawBytes'] and sha(raw) == entry['rawSha256']
assert len(compile['outputs']) == 3 and sum(item['rawBytes'] for item in compile['outputs']) == 429784
assert compile['warnings'] == []
assert compile['compiledOutputExecuted'] is False and compile['nativeBrowserExecuted'] is False
assert compile['nativeValidatorExecuted'] is False and compile['ReleaseEnabled'] == 0
git('diff', '--check', '8e836baa877b676a863c877003e277b638fc5061', COMBINED)
summary = {
    'source': COMBINED, 'tree': native['combined']['tree'], 'baseline': BASE,
    'applicationSource': APP, 'nativeSource': NATIVE, 'changedPaths': changes,
    'sourceCompositionExact': True, 'nonDocumentationEntries': 1043,
    'authorEvidence': {'commit': APP_DOCS, 'receiptPath': APP_RECEIPT, 'receiptSha256': sha(app_receipt_bytes),
                       'artifactsVerified': len(app_artifacts), 'snapshots': app_snapshots},
    'nativeEvidence': {'commit': NATIVE_DOCS, 'receiptPath': NATIVE_RECEIPT, 'receiptSha256': sha(native_receipt_bytes),
                       'artifactsVerified': len(native_artifacts), 'snapshots': native_snapshots},
    'allGzipMtimeZero': True, 'dualHashesAndDecodedLengthsVerified': True,
    'compileProvenance': {'inputCount': 70, 'allInputHashesMatchCombinedTree': True, 'chunks': 3,
                         'rawBytes': 429784, 'warnings': [], 'outputsVerified': True,
                         'outputExecuted': False, 'nativeAcceptanceClaimed': False},
    'fullMainBaselineWhitespace': 'pass', 'reviewScriptSha256': sha(Path(__file__).read_bytes()),
    'limits': 'Evidence and source verification only; no suite/build/browser/native/validator execution in this command.',
}
(OUT / 'author-native-verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
