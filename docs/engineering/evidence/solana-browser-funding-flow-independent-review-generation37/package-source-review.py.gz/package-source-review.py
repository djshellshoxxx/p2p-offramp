import datetime
import gzip
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/workspace/scratch/dcf03ef9bee8')
REPO = ROOT / 'p2p-browser-funding-flow-review-g37'
OUT = Path(__file__).resolve().parent
BASE = 'b785a01ffc54a75d497641d0e758d077adff41d0'
APP = '107ce93d030298f2668285067e156979c883184d'
NATIVE = 'd8dbf9e82743fd670c7d3af80a024720cbfb0538'
INITIAL = 'cbda12a11c24014e2a791d058460e642bad9f995'
CORRECTION = '3ccf809e01e729980b3ab5fbe12ba3993fbe9982'
SOURCE = '28fa8516d2e1f26740a5370077f9b2fdbaa2c086'
INDEX = 'docs/engineering/browser-funding-flow-independent-review-generation37.json'
REPORT = 'docs/engineering/SOLANA_BROWSER_FUNDING_FLOW_INDEPENDENT_REVIEW_GENERATION37_20261120.md'
ARTIFACT_DIR = 'docs/engineering/evidence/solana-browser-funding-flow-independent-review-generation37'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def keep(path, raw):
    if path.exists():
        assert path.read_bytes() == raw, f'Existing immutable artifact differs: {path}'
    else:
        path.write_bytes(raw)


def non_docs(ref):
    return {path: entry for entry, path in (item.split(b'\t', 1)
            for item in git('ls-tree', '-rz', '--full-tree', ref).split(b'\0') if item)
            if not path.startswith(b'docs/')}


def identity(ref):
    return {'source': ref, 'tree': git('rev-parse', ref + '^{tree}').decode().strip()}


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('diff', '--binary', 'HEAD').strip()
assert not (REPO / INDEX).exists()
assert (REPO / REPORT).is_file()
records = []
record_files = sorted(OUT.glob('[0-9][0-9]-*.json'))
assert len(record_files) == 13
for path in record_files:
    record = json.loads(path.read_text())
    assert record['source'] == record['finalSource']
    assert record['cleanTrackedWorktree'] is True and record['probeUnchanged'] is True
    assert record['tree'] == identity(record['source'])['tree']
    materials = [record['sourceTreeSnapshot'], record['log'], *record['independentProbeSnapshots'].values()]
    for material in materials:
        raw = Path(material['path']).read_bytes()
        compressed = Path(material['gzipPath']).read_bytes()
        assert len(raw) == material['bytes'] and sha(raw) == material['sha256']
        assert len(compressed) == material['gzipBytes'] and sha(compressed) == material['gzipSha256']
        assert int.from_bytes(compressed[4:8], 'little') == 0 and gzip.decompress(compressed) == raw
    assert Path(record['sourceTreeSnapshot']['path']).read_bytes() == git('ls-tree', '-rz', '--full-tree', record['source'])
    log = Path(record['log']['path']).read_text()
    parsed_counts = {key: int(number) for key, number in re.findall(
        r'^[#ℹ]\s+(tests|suites|pass|fail|cancelled|skipped|todo)\s+(\d+)\s*$', log, re.M)}
    assert parsed_counts == record['counts']
    records.append({'name': path.stem, **record})
assert [record['exitCode'] for record in records] == [1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0]
assert records[10]['source'] == SOURCE and records[10]['counts']['pass'] == records[10]['counts']['tests'] == 38
assert records[9]['source'] == INITIAL and records[9]['counts']['fail'] == 1
expected = non_docs(BASE)
component_paths = {}
for label, ref in [('application', APP), ('native', NATIVE)]:
    paths = git('diff', '--name-only', BASE, ref).decode().splitlines()
    component_paths[label] = paths
    current = non_docs(ref)
    for path in paths:
        assert not path.startswith('docs/')
        expected[path.encode()] = current[path.encode()]
assert expected == non_docs(INITIAL) and len(expected) == 1043
assert identity(INITIAL)['tree'] == identity('b695834c35e458ef36dd711ab82938d2eaf3f248')['tree']
correction_paths = git('diff', '--name-only', CORRECTION + '^', CORRECTION).decode().splitlines()
assert len(correction_paths) == 3
for path in correction_paths:
    expected[path.encode()] = non_docs(CORRECTION)[path.encode()]
assert expected == non_docs(SOURCE) and len(expected) == 1043
assert git('diff', '--binary', CORRECTION + '^', CORRECTION) == git('diff', '--binary', INITIAL, SOURCE)
source_mapping = {
    'baseline': identity(BASE), 'application': identity(APP), 'native': identity(NATIVE),
    'initialReviewedComposition': identity(INITIAL), 'correction': identity(CORRECTION),
    'correctedReviewedComposition': identity(SOURCE), 'sourcePaths': component_paths,
    'correctionPaths': correction_paths, 'nonDocumentationEntries': len(expected),
    'initialDisjointUnionExact': True, 'correctedUnionExact': True, 'correctionBinaryPatchExact': True,
    'nativeCompileInputsStillExact': 70,
}
keep(OUT / 'reviewed-source-mapping.json', (json.dumps(source_mapping, indent=2) + '\n').encode())
for name, before, after in [('reviewed-application.patch', BASE, APP), ('reviewed-native.patch', BASE, NATIVE),
                            ('reviewed-correction.patch', CORRECTION + '^', CORRECTION)]:
    keep(OUT / name, git('diff', '--binary', before, after))
keep(OUT / 'accepted-contract.md', (ROOT / 'g37-browser-funding-contract.md').read_bytes())
for probe in sorted(REPO.glob('independent-*.g37.mjs')):
    latest = records[-1]['independentProbeSnapshots'][probe.name]
    assert sha(probe.read_bytes()) == latest['sha256']
    keep(OUT / ('final-' + probe.name), probe.read_bytes())

artifact_folder = REPO / ARTIFACT_DIR
artifact_folder.mkdir(parents=True, exist_ok=False)
artifacts = []
for path in sorted(OUT.iterdir()):
    if not path.is_file() or path.suffix == '.gz' or path.name == 'source-review-package-result.json':
        continue
    raw = path.read_bytes()
    original_gzip = Path(str(path) + '.gz')
    compressed = original_gzip.read_bytes() if original_gzip.exists() else gzip.compress(raw, mtime=0)
    assert gzip.decompress(compressed) == raw and int.from_bytes(compressed[4:8], 'little') == 0
    stored = artifact_folder / (path.name + '.gz')
    stored.write_bytes(compressed)
    artifacts.append({'originalPath': str(path), 'storedPath': str(stored.relative_to(REPO)),
                      'decodedBytes': len(raw), 'decodedSha256': sha(raw),
                      'compressedBytes': len(compressed), 'compressedSha256': sha(compressed), 'gzipMtime': 0})
artifact_names = {Path(item['originalPath']).name for item in artifacts}
for record in records:
    assert record['name'] + '.json' in artifact_names
    for material in [record['log'], record['sourceTreeSnapshot'], *record['independentProbeSnapshots'].values()]:
        assert Path(material['path']).name in artifact_names
assert {'07-author-native-evidence-original-script.py', '08-author-native-evidence-original-script.py',
        'capture-check.py', 'package-source-review.py', 'verify-correction-evidence.py'} <= artifact_names

upstream = json.loads((OUT / 'author-native-verification.json').read_text())
correction_evidence = json.loads((OUT / 'correction-evidence-verification.json').read_text())
correction_source = json.loads((OUT / 'correction-source-verification.json').read_text())
assert upstream['authorEvidence']['artifactsVerified'] + upstream['nativeEvidence']['artifactsVerified'] + correction_evidence['artifactsVerified'] == 98
assert len(upstream['authorEvidence']['snapshots']) + len(upstream['nativeEvidence']['snapshots']) + len(correction_evidence['snapshots']) == 27
report = (REPO / REPORT).read_bytes()
index = {
    'schema': 'p2p-offramp.browser-funding-flow-independent-review-generation37.v1',
    'reviewer': 'browser_funding_flow_review_g37',
    'verdict': 'accepted-after-G37-R1-correction',
    'openBlockers': [],
    'reviewedSource': SOURCE,
    'reviewedTree': identity(SOURCE)['tree'],
    'sourceMapping': source_mapping,
    'report': {'path': REPORT, 'bytes': len(report), 'sha256': sha(report)},
    'resolvedFindings': [{
        'id': 'G37-R1', 'severity': 'P2', 'status': 'fixed-and-independently-verified',
        'summary': 'A second mutating ownership check revoked the session midway through a snapshot and caused a null-profile TypeError.',
        'originalReproductionSource': INITIAL, 'originalReproduction': '10-snapshot-ownership-expiry',
        'correctionSource': CORRECTION, 'reviewedCorrectionMapping': SOURCE,
        'verification': '11-corrected-ownership-and-probes',
        'authorityPreserved': 'Pure projection predicate after initial admission; economic paths retain #current(owner.epoch) plus the complete original reference tuple.',
    }],
    'executions': records,
    'coverage': {
        'oracleDistinctCasesAcrossOriginalRuns': 19,
        'applicationDistinctCasesAcrossOriginalRuns': 120,
        'correctedExactSourceSelectedCases': 38,
        'correctedMaintainedControllerCases': 27,
        'independentFlowCases': 11,
        'independentOracleCases': 2,
        'overlappingSelectionsSummed': False,
        'singleAllPassingOriginalOracleOrApplicationInvocationClaimed': False,
    },
    'upstreamEvidence': {'application': upstream['authorEvidence'], 'native': upstream['nativeEvidence'],
                         'correction': correction_evidence, 'artifactsVerified': 98, 'snapshotsReconstructed': 27},
    'nativeBuildOnlyEvidence': upstream['compileProvenance'],
    'correctionSourceVerification': correction_source,
    'retention': {'allFailuresPreserved': True, 'allExecutionProbeVersionsPreserved': True,
                  'completeSourceTreeManifestPerExecution': True, 'allGzipMtimeZero': True,
                  'rawAndCompressedHashesVerified': True, 'reviewerProductionEdits': False},
    'artifacts': artifacts,
    'artifactCount': len(artifacts),
    'scope': {'fullSuiteExecutedByReviewer': False, 'buildExecutedByReviewer': False,
              'nativeBrowserExecuted': False, 'nativeValidatorExecuted': False,
              'financialTransactionExecuted': False, 'dependencyInstallation': False,
              'remoteMutation': False, 'rootQualificationReview': 'separate composition supplement'},
    'ReleaseEnabled': 0,
    'packagedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(REPO / INDEX).write_text(json.dumps(index, indent=2) + '\n')
for item in artifacts:
    compressed = (REPO / item['storedPath']).read_bytes()
    raw = gzip.decompress(compressed)
    assert sha(compressed) == item['compressedSha256'] and sha(raw) == item['decodedSha256']
    assert len(compressed) == item['compressedBytes'] and len(raw) == item['decodedBytes']
assert not git('diff', '--binary', 'HEAD').strip()
git('diff', '--check', '8e836baa877b676a863c877003e277b638fc5061', SOURCE)
result = {'index': INDEX, 'indexSha256': sha((REPO / INDEX).read_bytes()), 'report': REPORT,
          'source': SOURCE, 'tree': identity(SOURCE)['tree'], 'artifacts': len(artifacts),
          'executions': len(records), 'upstreamArtifacts': 98, 'upstreamSnapshots': 27,
          'sourcePreserved': True, 'ReleaseEnabled': 0}
(OUT / 'source-review-package-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
