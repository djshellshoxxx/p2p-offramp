// Independent fixed-oracle probes with genuine native-client prepared/signed/marked synthetic fixtures.
import test from 'node:test';
import assert from 'node:assert/strict';
import { parseSolanaLocalnetConfig, solanaLocalnetConfigDocument } from './apps/web/src/solana-localnet/config.ts';
import { configOption } from './apps/web/test/solana-localnet-support.mjs';
import { createSolanaFundingProposalRecord, decodeSolanaFundingProposalRecord,
  SOLANA_FUNDING_PROPOSAL_FORMAT } from './apps/web/src/solana-localnet/funding-proposal.ts';
import { setupClient, connected } from './packages/chain-solana/test/lifecycle-support.mjs';
import { ok } from './packages/chain-solana/test/support.mjs';
import { base58Encode } from './contracts/solana/vectors/derive.mjs';
import { assertSolanaFundingSendMarked } from './scripts/lib/solana-localnet-send-evidence.mjs';

const bytes = value => new TextEncoder().encode(JSON.stringify(value));
async function fixture(t) {
  const env = setupClient('native', { clusterOptions: { absent: true } }); t.after(() => env.client.dispose());
  const option = change => configOption(network => {
    network.genesisHash = network.chainIdentity = env.terms.genesisHash;
    network.deployments[0].address = env.terms.programId;
    network.deployments[0].artifactSha256 = env.trade.deployment.artifactSha256;
    network.deployments[0].runtime.programDataSha256 = env.trade.deployment.runtime.programDataSha256;
    change?.(network);
  });
  const config = await parseSolanaLocalnetConfig(solanaLocalnetConfigDocument(option()));
  const proposalBytes = bytes({ format: SOLANA_FUNDING_PROPOSAL_FORMAT, terms: env.terms });
  const proposal = await createSolanaFundingProposalRecord(proposalBytes, config, '12'.repeat(16));
  let marker, wire;
  env.cluster.handle = input => {
    if (input.method === 'sendTransaction') {
      wire = input.params[0]; marker = structuredClone(env.journalFake.records(env.binding)[0]);
    }
  };
  const wallet = await connected(env, 'seller');
  ok(await env.client.confirm(ok(await env.client.prepareFunding(env.trade, wallet)), wallet));
  const pins = { genesisHash: env.terms.genesisHash, programId: env.terms.programId,
    programDataSha256: env.trade.deployment.runtime.programDataSha256 };
  return { env, option, config, proposalBytes, proposal, marker, wire, pins,
    profileId: env.journalFake.journal.profileId() };
}

test('independent: aligned corrupted wire and marker signatures fail validation without consuming the signature', async t => {
  const f = await fixture(t), wire = Buffer.from(f.wire, 'base64'), seen = new Set();
  wire[1] ^= 1;
  const marker = { ...f.marker, signature: base58Encode(wire.subarray(1, 65)) };
  // The maintained intent parser verifies first; accepted proofs also reach the separate OpenSSL check.
  await assert.rejects(() => assertSolanaFundingSendMarked([marker], [f.proposal], wire.toString('base64'),
    f.profileId, f.pins, f.config, seen), error => error.code === 'INTEGRITY_FAILURE');
  assert.equal(seen.size, 0);
  await assertSolanaFundingSendMarked([f.marker], [f.proposal], f.wire, f.profileId, f.pins, f.config, seen);
  assert.equal(seen.size, 1);
});

test('independent: a valid saved proposal under different registry IDs cannot borrow the installed binding', async t => {
  const f = await fixture(t);
  const alternate = await parseSolanaLocalnetConfig(solanaLocalnetConfigDocument(f.option(network => {
    network.id = 'another-local-network'; network.deployments[0].id = 'another-deployment';
  })));
  const proposal = await createSolanaFundingProposalRecord(f.proposalBytes, alternate, '34'.repeat(16));
  assert.deepEqual(await decodeSolanaFundingProposalRecord(proposal.record), proposal.value);
  assert.equal(proposal.value.binding.tradeId, f.marker.binding.tradeId, 'physical fixed terms are identical');
  const seen = new Set(), marker = { ...f.marker, binding: proposal.value.binding };
  await assert.rejects(() => assertSolanaFundingSendMarked([marker], [proposal], f.wire,
    f.profileId, f.pins, f.config, seen));
  assert.equal(seen.size, 0);
});
