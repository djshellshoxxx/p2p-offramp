import hashlib
import json
import subprocess
from pathlib import Path

REPO = Path('/workspace/scratch/dcf03ef9bee8/p2p-browser-funding-flow-review-g37')
BASE = 'b785a01ffc54a75d497641d0e758d077adff41d0'
SOURCE = 'd8dbf9e82743fd670c7d3af80a024720cbfb0538'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def blob(ref, path):
    return git('show', f'{ref}:{path}')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
paths = git('diff', '--name-only', BASE, SOURCE).decode().splitlines()
assert paths == sorted([
    'apps/web/test/solana-localnet-funding-send-evidence.test.mjs',
    'scripts/lib/solana-localnet-browser-fixture.mjs',
    'scripts/lib/solana-localnet-send-evidence.mjs',
    'scripts/test-solana-localnet-browser.mjs',
])
helper = 'scripts/lib/solana-localnet-send-evidence.mjs'
before, after = blob(BASE, helper), blob(SOURCE, helper)
start = b'export function assertSolanaSendMarked('
legacy_before = before[before.index(start):]
legacy_after = after[after.index(start):after.index(b'\n/** Separate fixed funding proof.')]
assert legacy_after.rstrip(b'\n') == legacy_before.rstrip(b'\n')
reader_start = b'export function readSolanaVaultRecords('
readers_before = before[before.index(reader_start):before.index(start)]
readers_after = after[after.index(reader_start):after.index(start)]
assert readers_before == readers_after
driver = 'scripts/test-solana-localnet-browser.mjs'
old, new = blob(BASE, driver), blob(SOURCE, driver)
helpers_start = b'const PASS = '
helpers_end = b'\ntry {\n'
assert old[old.index(helpers_start):old.index(helpers_end)] == new[new.index(helpers_start):new.index(helpers_end)]
refund_start = b'  const deadline = Number(chain.documents.refund.terms.escrowExpirySeconds);'
refund_end = b'  assert.equal(await getBalance(chain.rpc, chain.seller, \'finalized\'), sellerBefore + 100000000 - fees);'
refund_before = old[old.index(refund_start):old.index(refund_end) + len(refund_end)]
refund_after = new[new.index(refund_start):new.index(refund_end) + len(refund_end)]
assert refund_before == refund_after
unchanged = [
    'scripts/lib/solana-localnet-fixture.mjs',
    'packages/chain-solana/src/compose.ts', 'packages/chain-solana/src/plan.ts',
    'packages/chain-solana/src/intent.ts', 'packages/chain-solana/src/submit.ts',
    'packages/chain-solana/src/vaultjournal.ts', 'apps/web/src/solana-localnet/config.ts',
]
for path in unchanged:
    assert blob(BASE, path) == blob(SOURCE, path)
print(json.dumps({
    'baseline': BASE, 'source': SOURCE, 'tree': git('rev-parse', SOURCE + '^{tree}').decode().strip(),
    'changedPaths': paths,
    'legacyExitVerifier': {'unchanged': True, 'bytes': len(legacy_before), 'sha256': digest(legacy_before)},
    'legacyReaders': {'unchanged': True, 'bytes': len(readers_before), 'sha256': digest(readers_before)},
    'originalDriverHelperAndWaitBodiesUnchanged': True,
    'originalRealRefundWaitAndBalanceBody': {'unchanged': True, 'sha256': digest(refund_before)},
    'unchangedNativeSemanticsConfigurationAndFixtureDeadlines': unchanged,
    'reviewScriptSha256': digest(Path(__file__).read_bytes()),
    'scope': 'Read-only source preservation verification; no native, validator, browser or financial execution.',
}, indent=2))
