import datetime
import gzip
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path('/workspace/scratch/dcf03ef9bee8')
REPO = ROOT / 'p2p-browser-funding-flow-review-g37'
OUT = Path(__file__).resolve().parent
PROBES = sorted(REPO.glob('independent-*.g37.mjs'))
expected, name, *command = sys.argv[1:]
assert re.fullmatch(r'[a-f0-9]{40}', expected)
assert re.fullmatch(r'[a-z0-9-]+', name) and command


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def keep(label, raw):
    path = OUT / f'{name}-{label}'
    assert not path.exists() and not Path(str(path) + '.gz').exists()
    path.write_bytes(raw)
    compressed = gzip.compress(raw, mtime=0)
    Path(str(path) + '.gz').write_bytes(compressed)
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw),
            'gzipPath': str(path) + '.gz', 'gzipBytes': len(compressed),
            'gzipSha256': sha(compressed), 'gzipMtime': 0}


source = git('rev-parse', 'HEAD').decode().strip()
assert source == expected
assert not git('diff', '--binary', 'HEAD').strip(), 'Tracked source must be frozen before execution'
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
source_snapshot = keep('source-tree.bin', git('ls-tree', '-rz', '--full-tree', 'HEAD'))
probe_snapshots = {probe.name: keep(probe.name, probe.read_bytes()) for probe in PROBES}
log = OUT / f'{name}.log'
receipt = OUT / f'{name}.json'
assert not log.exists() and not receipt.exists()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with log.open('xb') as stream:
    result = subprocess.run(command, cwd=REPO, stdout=stream, stderr=subprocess.STDOUT)
raw = log.read_bytes()
compressed = gzip.compress(raw, mtime=0)
Path(str(log) + '.gz').write_bytes(compressed)
lines = raw.decode('utf-8', errors='replace').splitlines()
counts = {}
for line in lines:
    match = re.match(r'^[#ℹ]\s+(tests|suites|pass|fail|cancelled|skipped|todo)\s+(\d+)\s*$', line)
    if match:
        counts[match[1]] = int(match[2])
record = {
    'source': source, 'tree': tree, 'command': command, 'workingDirectory': str(REPO),
    'startedAt': started, 'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exitCode': result.returncode, 'sourceTreeSnapshot': source_snapshot, 'independentProbeSnapshots': probe_snapshots,
    'log': {'path': str(log), 'bytes': len(raw), 'sha256': sha(raw), 'gzipPath': str(log) + '.gz',
            'gzipBytes': len(compressed), 'gzipSha256': sha(compressed), 'gzipMtime': 0},
    'counts': counts, 'finalSource': git('rev-parse', 'HEAD').decode().strip(),
    'cleanTrackedWorktree': not bool(git('diff', '--binary', 'HEAD').strip()),
    'probeUnchanged': all(sha(probe.read_bytes()) == probe_snapshots[probe.name]['sha256'] for probe in PROBES),
}
receipt.write_text(json.dumps(record, indent=2) + '\n')
assert record['finalSource'] == source and record['cleanTrackedWorktree'] and record['probeUnchanged']
print(json.dumps(record, indent=2))
raise SystemExit(result.returncode)
