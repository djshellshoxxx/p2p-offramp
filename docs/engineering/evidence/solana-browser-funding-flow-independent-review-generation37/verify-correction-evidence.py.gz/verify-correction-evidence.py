import gzip
import hashlib
import json
import os
import re
import subprocess
import tempfile
from pathlib import Path

REPO = Path('/workspace/scratch/dcf03ef9bee8/p2p-browser-funding-flow-review-g37')
OUT = Path(__file__).resolve().parent
REVIEW_SOURCE = '28fa8516d2e1f26740a5370077f9b2fdbaa2c086'
INITIAL_APP = '107ce93d030298f2668285067e156979c883184d'
INITIAL_APP_EVIDENCE = 'cc144c69b7ee190880aff7f51a86d74fde863522'
CORRECTION = '3ccf809e01e729980b3ab5fbe12ba3993fbe9982'
EVIDENCE = '12f7d98ba7f133da77d18c62df790c957df93b1c'
RECEIPT_PATH = 'docs/execution/solana-browser-funding-snapshot-correction-generation37-20261120/receipt.json'


def git(*args, env=None, input=None):
    return subprocess.check_output(['git', *args], cwd=REPO, env=env, input=input)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(ref, path):
    return git('show', f'{ref}:{path}')


def entries(ref, nondoc=False):
    return {path: entry for entry, path in (item.split(b'\t', 1)
            for item in git('ls-tree', '-rz', '--full-tree', ref).split(b'\0') if item)
            if not nondoc or not path.startswith(b'docs/')}


def counts(raw):
    return {name: int(number) for name, number in re.findall(
        r'^[#ℹ]\s+(tests|pass|fail|cancelled|skipped|todo)\s+(\d+)\s*$', raw.decode(), re.M)}


def reconstruct(head, patch, expected):
    with tempfile.TemporaryDirectory(prefix='g37-independent-correction-index-') as temporary:
        env = {**os.environ, 'GIT_INDEX_FILE': str(Path(temporary) / 'index')}
        git('read-tree', head, env=env)
        if patch:
            git('apply', '--cached', '--binary', '--whitespace=nowarn', '-', env=env, input=patch)
        assert git('write-tree', env=env).decode().strip() == expected


assert git('rev-parse', 'HEAD').decode().strip() == REVIEW_SOURCE
assert git('rev-parse', EVIDENCE + '^').decode().strip() == CORRECTION
assert git('rev-parse', CORRECTION + '^').decode().strip() == INITIAL_APP_EVIDENCE
paths = git('diff', '--name-only', CORRECTION, EVIDENCE).decode().splitlines()
assert len(paths) == 25 and all(path.startswith('docs/') for path in paths)
assert entries(EVIDENCE, True) == entries(CORRECTION, True)
assert len(entries(CORRECTION, True)) == 1042
original_docs = {path: entry for path, entry in entries(INITIAL_APP_EVIDENCE).items()
                 if path.startswith(b'docs/')}
assert all(entries(EVIDENCE)[path] == entry for path, entry in original_docs.items())
receipt_raw = blob(EVIDENCE, RECEIPT_PATH)
receipt = json.loads(receipt_raw)
assert receipt['source']['source'] == CORRECTION
assert receipt['source']['tree'] == git('rev-parse', CORRECTION + '^{tree}').decode().strip()
values = {}
for item in receipt['artifacts']:
    compressed = blob(EVIDENCE, item['storedPath'])
    assert len(compressed) == item['compressedBytes'] and sha(compressed) == item['compressedSha256']
    assert int.from_bytes(compressed[4:8], 'little') == 0
    raw = gzip.decompress(compressed)
    assert len(raw) == item['decodedBytes'] and sha(raw) == item['decodedSha256']
    name = Path(item['originalPath']).name
    assert name not in values
    values[name] = raw
assert len(values) == 23

snapshots = []
for execution in receipt['executions']:
    name = execution['name']
    raw = values[name + '.log']
    patch = values[name + '.patch']
    original = json.loads(values[name + '.json'])
    for key in ['head', 'tree', 'startedAt', 'completedAt', 'exitCode', 'bytes', 'sha256', 'finalHead']:
        assert original[key] == execution[key]
    assert original['command'] == execution['command']
    assert len(raw) == execution['bytes'] and sha(raw) == execution['sha256']
    assert sha(patch) == execution['patchSha256']
    assert counts(raw) == execution['counts']
    assert execution['finalHead'] == execution['head']
    reconstruct(execution['head'], patch, execution['tree'])
    snapshots.append({'name': name, 'head': execution['head'], 'executionTree': execution['tree'],
                      'exitCode': execution['exitCode'], 'counts': execution['counts'],
                      'logSha256': execution['sha256'], 'reconstructed': True})
assert len(snapshots) == 4
assert [item['exitCode'] for item in snapshots] == [1, 0, 0, 0]
assert snapshots[0]['counts'] == {'tests': 1, 'pass': 0, 'fail': 1, 'cancelled': 0, 'skipped': 0, 'todo': 0}
assert snapshots[1]['counts'] == {'tests': 100, 'pass': 100, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}
assert snapshots[1]['executionTree'] == receipt['source']['tree']
assert snapshots[2]['head'] == snapshots[3]['head'] == CORRECTION
assert values['12-corrected-types.log'].decode().count('--noEmit') == 4
boundary_log = values['13-corrected-boundaries.log'].decode()
assert '244 production source files' in boundary_log and '157 module(s)' in boundary_log

failure_name = '10-snapshot-ownership-expiry'
failure_receipt = json.loads(values[failure_name + '.json'])
assert values[failure_name + '.json'] == (OUT / (failure_name + '.json')).read_bytes()
assert receipt['independentFailure']['source'] == failure_receipt['source']
assert receipt['independentFailure']['tree'] == failure_receipt['tree']
independent_materials = [failure_receipt['log'], failure_receipt['sourceTreeSnapshot'],
                         *failure_receipt['independentProbeSnapshots'].values()]
for record in independent_materials:
    name = Path(record['path']).name
    raw = values[name]
    assert len(raw) == record['bytes'] and sha(raw) == record['sha256']
    assert raw == Path(record['path']).read_bytes()
    compressed = Path(record['gzipPath']).read_bytes()
    assert len(compressed) == record['gzipBytes'] and sha(compressed) == record['gzipSha256']
    assert gzip.decompress(compressed) == raw and int.from_bytes(compressed[4:8], 'little') == 0
assert values[failure_name + '-source-tree.bin'] == git('ls-tree', '-rz', '--full-tree', failure_receipt['source'])
assert blob(failure_receipt['source'], 'apps/web/src/solana-localnet/controller.ts') == blob(
    INITIAL_APP, 'apps/web/src/solana-localnet/controller.ts')
assert 'TypeError' in values[failure_name + '.log'].decode()
assert 'null' in values['10-snapshot-expiry-baseline.log'].decode()
assert receipt['nativeExecuted'] is False and receipt['fullSuiteExecuted'] is False and receipt['ReleaseEnabled'] == 0
for path in receipt['source']['paths']:
    assert blob(CORRECTION, path) == blob(REVIEW_SOURCE, path)
git('diff', '--check', '8e836baa877b676a863c877003e277b638fc5061', EVIDENCE)
result = {
    'reviewedSource': REVIEW_SOURCE,
    'correctionSource': CORRECTION,
    'correctionEvidence': EVIDENCE,
    'correctionEvidenceTree': git('rev-parse', EVIDENCE + '^{tree}').decode().strip(),
    'receiptPath': RECEIPT_PATH,
    'receiptSha256': sha(receipt_raw),
    'docsOnlyPaths': 25,
    'nonDocumentationEntries': 1042,
    'artifactsVerified': len(values),
    'allGzipMtimeZero': True,
    'dualHashesAndLengthsVerified': True,
    'originalAuthorDocumentationUnchanged': True,
    'snapshots': snapshots,
    'originalIndependentFailurePreservedExactly': True,
    'originalFailingControllerMatchesInitialAuthor': True,
    'correctedSourceMatchesReviewedPaths': True,
    'typescriptProjects': 4,
    'boundaries': {'productionFiles': 244, 'coreModules': 157},
    'fullMainBaselineWhitespace': 'pass',
    'reviewScriptSha256': sha(Path(__file__).read_bytes()),
    'limits': 'Read-only evidence/source verification; no suite/build/browser/native/validator execution in this command.',
}
(OUT / 'correction-evidence-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
