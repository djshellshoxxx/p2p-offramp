// Independent G37 contract probes. Controlled cluster/wallet fixtures, real controller/native client/encrypted vault.
// This file is executed only after the author's source is frozen; it is not native browser acceptance evidence.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { SolanaRecoveryController } from './apps/web/src/solana-localnet/controller.ts';
import { parseSolanaLocalnetConfig, solanaLocalnetConfigDocument } from './apps/web/src/solana-localnet/config.ts';
import { configOption } from './apps/web/test/solana-localnet-support.mjs';
import { SOLANA_FUNDING_PROPOSAL_FORMAT } from './apps/web/src/solana-localnet/funding-proposal.ts';
import { setupClient } from './packages/chain-solana/test/lifecycle-support.mjs';
import { createRecoveryDocument } from './packages/chain-solana/src/recovery.ts';
import { EncryptedVaultService } from './packages/storage/index.ts';
import { openEnvelope, disposeMaterial } from './packages/storage/src/vault-crypto.ts';
import { VaultStorageError } from './packages/storage/src/idb-vault-store.ts';
import { encodeBase64url } from './packages/schemas/index.ts';
import { readSolanaBrowserVaultRecords } from './scripts/lib/solana-localnet-send-evidence.mjs';

const PASS = 'independent G37 source profile passphrase';
const DEST = 'independent G37 destination profile passphrase';
const FORMAT = 'p2p-offramp/solana-local-recovery/v1';
const text = new TextEncoder();
const success = result => { assert.equal(result.ok, true, JSON.stringify(result)); return result; };
const value = result => success(result).value;
const gate = () => { let resolve; const promise = new Promise(done => { resolve = done; }); return { promise, resolve }; };
const recordId = hash => createHash('sha256').update(`${FORMAT}\0${hash}`).digest('hex').slice(0, 32);
function memoryStore() {
  const rows = new Map();
  return {
    rows, writes: 0, beforeCAS: null,
    async get(id) { return structuredClone(rows.get(id)); },
    async add(row, options) {
      options?.assertCurrent?.(); assert.equal(rows.has(row.profileId), false);
      rows.set(row.profileId, structuredClone(row));
    },
    async compareAndSwap(before, after, options) {
      await this.beforeCAS?.(); options?.assertCurrent?.();
      if (JSON.stringify(rows.get(before.profileId)) !== JSON.stringify(before)) throw new VaultStorageError('CONFLICT');
      rows.set(after.profileId, structuredClone(after)); this.writes++;
    },
    async addWithSource(before, after, options) {
      assert.deepEqual(rows.get(before.profileId), before); await this.add(after, options);
    },
    async listProfileIds() { return { profileIds: [...rows.keys()].sort(), truncated: false }; },
    subscribeInvalidation() { return () => {}; },
  };
}
async function fixture(t) {
  const env = setupClient('native', { clusterOptions: { absent: true } }), store = memoryStore();
  const option = configOption(network => {
    network.genesisHash = network.chainIdentity = env.terms.genesisHash;
    network.deployments[0].artifactSha256 = env.trade.deployment.artifactSha256;
    network.deployments[0].runtime.programDataSha256 = env.trade.deployment.runtime.programDataSha256;
  });
  const config = await parseSolanaLocalnetConfig(solanaLocalnetConfigDocument(option));
  let wall = 1700000000000;
  const controller = new SolanaRecoveryController(config, env.walletFake.wallet, env.cluster.rpc,
    { store, now: () => wall, monotonicNow: () => 0 });
  t.after(() => { controller.dispose(); env.client.dispose(); });
  const id = success(await controller.dispatch({ type: 'profile.create', passphrase: PASS })).snapshot.profileId;
  const proposal = { format: SOLANA_FUNDING_PROPOSAL_FORMAT, terms: env.terms };
  const saved = success(await controller.dispatch({ type: 'funding.proposal.import', text: JSON.stringify(proposal) }));
  const proposalId = saved.snapshot.proposals[0].id;
  const raw = async (profileId = id, passphrase = PASS) => {
    const opened = await openEnvelope(store.rows.get(profileId), passphrase, crypto);
    try { return structuredClone(opened.snapshot); } finally { disposeMaterial(opened.material); }
  };
  const read = async (profileId = id, passphrase = PASS) => {
    const snapshot = await raw(profileId, passphrase);
    return { snapshot, ...await readSolanaBrowserVaultRecords(snapshot) };
  };
  const connect = async (selected = proposalId) => success(await controller.dispatch({ type: 'funding.wallet.connect', proposalId: selected }));
  const prepare = async (extra = {}) => success(await controller.dispatch({ type: 'funding.prepare', proposalId, ...extra }));
  const confirm = async reviewId => success(await controller.dispatch({ type: 'review.confirm', reviewId }));
  const refresh = async () => success(await controller.dispatch({ type: 'refresh' }));
  const seed = async records => {
    success(await controller.dispatch({ type: 'profile.lock' }));
    const vault = new EncryptedVaultService(store, crypto, { lifecycle: false });
    try {
      const session = value(await vault.unlock(id, PASS));
      value(await vault.commit(session.sessionId, session.revision, records.map(record => ({ op: 'put', record }))));
    } finally { vault.dispose(); }
    return success(await controller.dispatch({ type: 'profile.unlock', profileId: id, passphrase: PASS }));
  };
  const backup = async () => success(await controller.dispatch({ type: 'backup.export' })).backupBytes;
  const restore = async bytes => success(await controller.dispatch({ type: 'backup.restore', bytes,
    sourcePassphrase: PASS, destinationPassphrase: DEST }));
  return { env, store, config, controller, id, proposal, proposalId, raw, read, connect, prepare, confirm, refresh,
    seed, backup, restore, advanceWall(milliseconds) { wall += milliseconds; } };
}

test('independent: explicit refresh preserves the original live funding review and prepared journal record', async t => {
  const f = await fixture(t); await f.connect();
  const prepared = await f.prepare(), original = (await f.read()).intents[0];
  assert.equal(prepared.snapshot.review.action, 'fund');
  assert.equal(prepared.snapshot.review.proposalId, f.proposalId);
  const refreshed = await f.refresh();
  assert.equal(refreshed.snapshot.review.id, prepared.snapshot.review.id);
  assert.deepEqual((await f.read()).intents[0], original);
  assert.equal(original.state, 'prepared');
  assert.equal(f.env.walletFake.calls.sign.length, 0); assert.equal(f.env.cluster.sent.length, 0);
  success(await f.controller.dispatch({ type: 'review.cancel' }));
  assert.equal((await f.read()).intents[0].state, 'cancelled');
});

test('independent: orphan recovery cancels only the local preparation; fresh-key restore retains foreign uncertainty', async t => {
  const f = await fixture(t); await f.connect(); await f.prepare();
  const original = (await f.read()).intents[0], bytes = await f.backup();
  f.controller.walletChanged(); await f.connect();
  assert.equal((await f.read()).intents[0].state, 'cancelled');
  const beforeRpc = f.env.cluster.calls.length, restored = await f.restore(bytes), current = restored.snapshot.profileId;
  assert.notEqual(current, f.id); assert.equal(f.env.cluster.calls.length, beforeRpc, 'activation only loads proposal journal display');
  assert.deepEqual((await f.read(current, DEST)).intents[0], original);
  await f.refresh();
  assert.deepEqual((await f.read(current, DEST)).intents[0], original, 'foreign pre-marker origin is never locally cancelled');
  assert.equal(f.env.walletFake.calls.sign.length, 0); assert.equal(f.env.cluster.sent.length, 0);
});

test('independent: newly funded restored proposal separates original proposal provenance from current intent provenance', async t => {
  const f = await fixture(t), originalProposal = (await f.read()).proposals[0];
  const restored = await f.restore(await f.backup()), current = restored.snapshot.profileId;
  await f.connect(); const prepared = await f.prepare(); await f.confirm(prepared.snapshot.review.id);
  assert.equal(f.controller.snapshot().trades.length, 0, 'sent signature alone is not escrow finality');
  const sent = (await f.read(current, DEST)).intents[0];
  assert.equal(sent.originProfileId, current); assert.equal(sent.state, 'sent');
  f.env.cluster.setEscrow(); f.env.cluster.land(sent.signature); await f.refresh();
  const promoted = await f.read(current, DEST), snapshot = f.controller.snapshot();
  assert.deepEqual(promoted.proposals, [originalProposal]);
  assert.equal(promoted.documents.length, 1, JSON.stringify({ snapshot, intents: promoted.intents }));
  assert.equal(promoted.documents[0].originProfileId, f.id); assert.equal(promoted.documents[0].role, 'seller');
  assert.equal(snapshot.trades[0].restored, true); assert.equal(snapshot.proposals[0].recoveryRetained, true);
  assert.equal(snapshot.tradeCapacity.used, 1); assert.equal(promoted.intents[0].originProfileId, current);
  const exported = success(await f.controller.dispatch({ type: 'recovery.export', tradeId: f.env.binding.tradeId }));
  assert.deepEqual(JSON.parse(exported.recoveryJson), value(createRecoveryDocument(f.env.trade)));
  const before = await f.raw(current, DEST); await f.refresh();
  assert.deepEqual(await f.raw(current, DEST), before, 'repeat observation does not rewrite a recovery or proposal');
  assert.equal(f.env.walletFake.calls.sign.length, 1); assert.equal(f.env.cluster.sent.length, 1);
});

test('independent: trusted escrow observation may create recovery while an unknown funding intent still blocks exits', async t => {
  const f = await fixture(t);
  f.env.cluster.sendBehavior = () => { throw new Error('independent synthetic lost acknowledgement'); };
  await f.connect(); const prepared = await f.prepare(); await f.confirm(prepared.snapshot.review.id);
  const original = (await f.read()).intents[0]; assert.equal(original.state, 'unknown');
  assert.notEqual(original.sendMarkedAt, null); assert.equal(f.controller.snapshot().trades.length, 0);
  f.env.cluster.setEscrow(); await f.refresh();
  const observed = await f.read(), snapshot = f.controller.snapshot();
  assert.equal(observed.documents.length, 1); assert.deepEqual(observed.intents[0], original);
  assert.equal(snapshot.trades[0].state, 'funded'); assert.equal(snapshot.trades[0].canRelease, false);
  assert.equal(snapshot.trades[0].canRefund, false); assert.equal(snapshot.trades[0].canPayout, false);
  assert.equal(snapshot.trades[0].intents[0].state, 'unknown');
  await f.refresh(); assert.equal(f.env.walletFake.calls.sign.length, 1); assert.equal(f.env.cluster.sent.length, 1);
});

test('independent: a paired buyer recovery survives restored proposal observation without role or origin rewrites', async t => {
  const f = await fixture(t); f.env.cluster.setEscrow();
  const document = value(createRecoveryDocument(f.env.trade));
  success(await f.controller.dispatch({ type: 'recovery.import', text: JSON.stringify(document), role: 'buyer' }));
  const restored = await f.restore(await f.backup()), current = restored.snapshot.profileId;
  const before = await f.raw(current, DEST); await f.refresh(); const after = await f.raw(current, DEST);
  assert.deepEqual(after, before);
  const decoded = await f.read(current, DEST);
  assert.equal(decoded.documents[0].role, 'buyer'); assert.equal(decoded.documents[0].originProfileId, f.id);
  assert.equal(f.controller.snapshot().trades[0].role, 'buyer');
  assert.equal(f.controller.snapshot().tradeCapacity.used, 1);
  assert.equal(f.env.walletFake.calls.sign.length, 0); assert.equal(f.env.cluster.sent.length, 0);
});

for (const kind of ['trade', 'journal']) {
  test(`independent: promotion never overwrites an occupied ${kind} record ID and propagates conflict to lock`, async t => {
    const f = await fixture(t);
    const occupied = { id: recordId(f.env.binding.tradeId), kind, schemaVersion: 1,
      payload: encodeBase64url(text.encode(JSON.stringify({ format: 'independent/occupied-recovery-slot/v1' }))) };
    await f.seed([occupied]); f.env.cluster.setEscrow(); const before = await f.raw();
    const result = await f.controller.dispatch({ type: 'refresh' });
    assert.equal(result.ok, false); assert.equal(result.code, 'CONFLICT'); assert.equal(result.snapshot.profileId, null);
    assert.deepEqual(await f.raw(), before); assert.equal(f.env.cluster.sent.length, 0);
  });
}

test('independent: promotion CAS uses the revision captured before the occupancy read', async t => {
  const f = await fixture(t), target = recordId(f.env.binding.tradeId);
  const occupied = { id: target, kind: 'trade', schemaVersion: 1,
    payload: encodeBase64url(text.encode(JSON.stringify({ format: 'independent/concurrent-occupancy/v1' }))) };
  const originalRead = EncryptedVaultService.prototype.read;
  let injected = false;
  EncryptedVaultService.prototype.read = async function (sessionId, id) {
    const result = await Reflect.apply(originalRead, this, [sessionId, id]);
    if (!injected && id === target && result.ok && result.value === null) {
      injected = true;
      const revision = value(await this.assertFresh(sessionId));
      value(await this.commit(sessionId, revision, [{ op: 'put', record: occupied }]));
    }
    return result;
  };
  let result;
  try { f.env.cluster.setEscrow(); result = await f.controller.dispatch({ type: 'refresh' }); }
  finally { EncryptedVaultService.prototype.read = originalRead; }
  assert.equal(injected, true); assert.equal(result.ok, false); assert.equal(result.code, 'CONFLICT');
  assert.equal(result.snapshot.profileId, null);
  const records = (await f.raw()).records;
  assert.deepEqual(records.find(record => record.id === target), occupied);
  assert.equal(records.filter(record => record.id === f.proposalId).length, 1);
  assert.equal(f.env.walletFake.calls.sign.length, 0); assert.equal(f.env.cluster.sent.length, 0);
});

test('independent: profile lock at the held promotion CAS prevents the recovery write', async t => {
  const f = await fixture(t), before = await f.raw(), entered = gate(), release = gate();
  f.env.cluster.setEscrow();
  f.store.beforeCAS = async () => { entered.resolve(); await release.promise; };
  const pending = f.controller.dispatch({ type: 'refresh' });
  await entered.promise; success(await f.controller.dispatch({ type: 'profile.lock' })); release.resolve();
  const result = await pending;
  assert.equal(result.ok, false); assert.equal(result.snapshot.profileId, null);
  assert.deepEqual(await f.raw(), before); assert.equal(f.env.cluster.sent.length, 0);
});

test('independent: switching proposal wallet ownership cannot prepare the previous proposal', async t => {
  const f = await fixture(t); await f.connect(); await f.prepare();
  const original = (await f.read()).intents[0];
  const second = { ...f.proposal, terms: { ...f.env.terms, sellerNonce: 'ab'.repeat(32) } };
  const saved = success(await f.controller.dispatch({ type: 'funding.proposal.import', text: JSON.stringify(second) }));
  const secondId = saved.snapshot.proposals.find(proposal => proposal.id !== f.proposalId).id;
  const connected = await f.connect(secondId);
  assert.equal(connected.snapshot.proposals.find(proposal => proposal.id === f.proposalId).walletConnected, false);
  assert.equal(connected.snapshot.proposals.find(proposal => proposal.id === secondId).walletConnected, true);
  assert.equal(connected.snapshot.review, null);
  const refused = await f.controller.dispatch({ type: 'funding.prepare', proposalId: f.proposalId });
  assert.equal(refused.ok, false);
  assert.equal((await f.read()).intents.find(intent => intent.intentId === original.intentId).state, 'cancelled');
  assert.equal(f.env.walletFake.calls.sign.length, 0); assert.equal(f.env.cluster.sent.length, 0);
});
