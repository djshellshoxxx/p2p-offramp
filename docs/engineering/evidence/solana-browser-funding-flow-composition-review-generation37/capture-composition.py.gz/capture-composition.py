import datetime
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/workspace/scratch/dcf03ef9bee8')
REPO = ROOT / 'p2p-browser-funding-flow-review-g37'
OUT = Path(__file__).resolve().parent
NAME = '01-root-composition-verification'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def keep(name, raw):
    path = OUT / name
    assert not path.exists()
    path.write_bytes(raw)
    compressed = gzip.compress(raw, mtime=0)
    Path(str(path) + '.gz').write_bytes(compressed)
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw),
            'compressedPath': str(path) + '.gz', 'compressedBytes': len(compressed),
            'compressedSha256': sha(compressed), 'gzipMtime': 0}


source = git('rev-parse', 'HEAD').decode().strip()
assert source == '62e9e5147e0bfd31f5d2e95e14001672256ca766'
assert not git('status', '--porcelain').strip()
script = OUT / 'verify-composition.py'
script_snapshot = keep(NAME + '-script.py', script.read_bytes())
source_snapshot = keep(NAME + '-reviewer-source-tree.bin', git('ls-tree', '-rz', '--full-tree', source))
command = ['python3', str(script)]
log = OUT / (NAME + '.log')
assert not log.exists()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with log.open('xb') as stream:
    result = subprocess.run(command, cwd=REPO, stdout=stream, stderr=subprocess.STDOUT)
raw = log.read_bytes()
compressed = gzip.compress(raw, mtime=0)
Path(str(log) + '.gz').write_bytes(compressed)
receipt = {
    'command': command, 'workingDirectory': str(REPO), 'source': source,
    'tree': git('rev-parse', source + '^{tree}').decode().strip(),
    'startedAt': started, 'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exitCode': result.returncode, 'scriptSnapshot': script_snapshot, 'sourceTreeSnapshot': source_snapshot,
    'log': {'path': str(log), 'bytes': len(raw), 'sha256': sha(raw),
            'compressedPath': str(log) + '.gz', 'compressedBytes': len(compressed),
            'compressedSha256': sha(compressed), 'gzipMtime': 0},
    'finalSource': git('rev-parse', 'HEAD').decode().strip(),
    'cleanWorktree': not bool(git('status', '--porcelain').strip()),
    'verificationScriptUnchanged': sha(script.read_bytes()) == script_snapshot['sha256'],
    'testsOrBuildsExecuted': False,
}
(OUT / (NAME + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
assert receipt['finalSource'] == source and receipt['cleanWorktree'] and receipt['verificationScriptUnchanged']
print(json.dumps(receipt, indent=2))
raise SystemExit(result.returncode)
