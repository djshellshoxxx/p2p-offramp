import datetime
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/workspace/scratch/dcf03ef9bee8')
REPO = ROOT / 'p2p-browser-funding-flow-review-g37'
OUT = Path(__file__).resolve().parent
SOURCE_REVIEW = '62e9e5147e0bfd31f5d2e95e14001672256ca766'
CORRECTED = '88bd126bace2b88886017b0ff4eb5daffcdc060e'
INTEGRATED = '9fe97a05759980f445d63231ede47edef9038261'
INDEX = 'docs/engineering/browser-funding-flow-composition-review-generation37.json'
REPORT = 'docs/engineering/SOLANA_BROWSER_FUNDING_FLOW_COMPOSITION_REVIEW_GENERATION37_20261120.md'
ARTIFACT_DIR = 'docs/engineering/evidence/solana-browser-funding-flow-composition-review-generation37'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE_REVIEW
assert not git('diff', '--binary', 'HEAD').strip()
assert not (REPO / INDEX).exists()
verification = json.loads((OUT / 'composition-verification.json').read_text())
capture = json.loads((OUT / '01-root-composition-verification.json').read_text())
inputs = json.loads((OUT / 'frozen-inputs.json').read_text())
packager = json.loads((OUT / 'packaging-assertion-review.json').read_text())
assert capture['exitCode'] == 0 and capture['source'] == capture['finalSource'] == SOURCE_REVIEW
assert capture['cleanWorktree'] is True and capture['verificationScriptUnchanged'] is True
assert capture['testsOrBuildsExecuted'] is False
for record in [capture['log'], capture['scriptSnapshot'], capture['sourceTreeSnapshot']]:
    raw = Path(record['path']).read_bytes()
    compressed = Path(record['compressedPath']).read_bytes()
    assert len(raw) == record['bytes'] and sha(raw) == record['sha256']
    assert len(compressed) == record['compressedBytes'] and sha(compressed) == record['compressedSha256']
    assert gzip.decompress(compressed) == raw and int.from_bytes(compressed[4:8], 'little') == 0
assert len(inputs) == verification['frozenInputs'] == 76
for record in [*inputs, packager]:
    snapshot = Path(record['snapshotPath']).read_bytes()
    original = Path(record['originalPath']).read_bytes()
    assert snapshot == original and len(snapshot) == record['bytes'] and sha(snapshot) == record['sha256']
assert verification['correctedRootSource']['source'] == CORRECTED
assert verification['integratedEvidenceHead']['source'] == INTEGRATED
assert verification['nonDocumentationEntries'] == 1043 and verification['mappedArtifactRecordsVerified'] == 181
assert verification['qualifications']['corrected']['fullCounts'] == {
    'tests': 2915, 'pass': 2915, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}
assert verification['qualifications']['initial']['fullCounts']['tests'] == 2914
assert verification['ordinaryOutputsIdenticalBetweenRuns'] is True
assert verification['ReleaseEnabled'] == 0 and packager['scriptExecuted'] is False
assert len(verification['outputs']['initial']) == len(verification['outputs']['corrected']) == 27

artifact_folder = REPO / ARTIFACT_DIR
artifact_folder.mkdir(parents=True, exist_ok=False)
artifacts = []
for path in sorted(OUT.rglob('*')):
    if not path.is_file() or path.suffix == '.gz' or path.name == 'composition-package-result.json':
        continue
    raw = path.read_bytes()
    gzip_path = Path(str(path) + '.gz')
    compressed = gzip_path.read_bytes() if gzip_path.exists() else gzip.compress(raw, mtime=0)
    assert gzip.decompress(compressed) == raw and int.from_bytes(compressed[4:8], 'little') == 0
    relative = path.relative_to(OUT)
    destination = artifact_folder / (str(relative) + '.gz')
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(compressed)
    artifacts.append({'originalPath': str(path), 'storedPath': str(destination.relative_to(REPO)),
                      'decodedBytes': len(raw), 'decodedSha256': sha(raw),
                      'compressedBytes': len(compressed), 'compressedSha256': sha(compressed), 'gzipMtime': 0})
assert len(artifacts) == 92
retained = {item['originalPath'] for item in artifacts}
assert all(record['snapshotPath'] in retained for record in inputs)
assert packager['snapshotPath'] in retained
assert str(Path(__file__).resolve()) in retained
report = (REPO / REPORT).read_bytes()
index = {
    'schema': 'p2p-offramp.browser-funding-flow-composition-review-generation37.v1',
    'reviewer': 'browser_funding_flow_review_g37',
    'verdict': 'accepted-corrected-local-qualification-and-composition',
    'openBlockers': [],
    'testedSource': CORRECTED,
    'testedTree': verification['correctedRootSource']['tree'],
    'integratedEvidenceHead': verification['integratedEvidenceHead'],
    'sourceReview': {'original': SOURCE_REVIEW, 'mapped': INTEGRATED,
                     'indexPath': 'docs/engineering/browser-funding-flow-independent-review-generation37.json'},
    'report': {'path': REPORT, 'bytes': len(report), 'sha256': sha(report)},
    'verification': verification,
    'readOnlyExecution': capture,
    'packagingAssertionReview': packager,
    'frozenInputs': inputs,
    'retention': {'initialQualificationSeparatedFromCorrected': True,
                  'initialReceiptAndSevenLogsRetained': True, 'initialBuildOutputsRetained': 27,
                  'correctedReceiptAndSevenLogsRetained': True, 'correctedBuildOutputsRetained': 27,
                  'immutableMappingsRetained': 6, 'allGzipMtimeZero': True,
                  'rawAndCompressedHashesVerified': True, 'sourceManifestsRetained': 6},
    'artifacts': artifacts,
    'artifactCount': len(artifacts),
    'rootFinalPackage': {'executedByReviewer': False, 'statusAtReview': 'awaiting composition integration'},
    'scope': {'testsRerun': False, 'buildsRerun': False, 'browserExecuted': False,
              'validatorExecuted': False, 'financialTransactionExecuted': False,
              'remoteMutation': False, 'hostedAcceptanceClaimed': False},
    'ReleaseEnabled': 0,
    'packagedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(REPO / INDEX).write_text(json.dumps(index, indent=2) + '\n')
for artifact in artifacts:
    compressed = (REPO / artifact['storedPath']).read_bytes()
    raw = gzip.decompress(compressed)
    assert sha(raw) == artifact['decodedSha256'] and len(raw) == artifact['decodedBytes']
    assert sha(compressed) == artifact['compressedSha256'] and len(compressed) == artifact['compressedBytes']
assert not git('diff', '--binary', 'HEAD').strip()
result = {'index': INDEX, 'indexSha256': sha((REPO / INDEX).read_bytes()), 'report': REPORT,
          'testedSource': CORRECTED, 'testedTree': verification['correctedRootSource']['tree'],
          'documentationPaths': len(artifacts) + 2, 'artifacts': len(artifacts),
          'originalInputsPreserved': 76, 'packagerSnapshotPreserved': True,
          'testsOrBuildsRerun': False, 'ReleaseEnabled': 0}
(OUT / 'composition-package-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
