import datetime
import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/workspace/scratch/dcf03ef9bee8')
REPO = ROOT / 'p2p-browser-funding-flow-review-g37'
ROOT_REPO = ROOT / 'p2p-continuation-g37'
OUT = Path(__file__).resolve().parent
INITIAL = 'dcdb86d19b8d1e1b09cd12a0f5cbf9626eff0fd3'
CORRECTED = '88bd126bace2b88886017b0ff4eb5daffcdc060e'
INTEGRATED = '9fe97a05759980f445d63231ede47edef9038261'
REVIEWED = '28fa8516d2e1f26740a5370077f9b2fdbaa2c086'
REVIEW_DOCS = '62e9e5147e0bfd31f5d2e95e14001672256ca766'
SOURCE_INDEX = 'docs/engineering/browser-funding-flow-independent-review-generation37.json'
MAPPING_NAMES = [
    'g37-combined-source.json', 'g37-corrected-source.json',
    'g37-integrated-component-evidence.json', 'g37-integrated-correction-evidence.json',
    'g37-integrated-independent-source-review.json', 'g37-initial-qualification-preservation.json',
]
EXPECTED_COMMANDS = [
    ('full-node', ['npm', 'test']), ('typecheck', ['npm', 'run', 'typecheck']),
    ('build-policy', ['npm', 'run', 'test:build-policy']),
    ('boundaries', ['npm', 'run', 'check:boundaries']),
    ('default-build', ['node', 'apps/web/scripts/build.mjs']),
    ('demo-build', ['node', 'apps/web/scripts/build.mjs', 'demo']),
    ('native-fixture-preparation', ['node', 'scripts/test-update-runtime-browser.mjs', '--build-only']),
]
input_records = []
blob_cache = {}
tree_cache = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args, root_repo=False):
    return subprocess.check_output(['git', *args], cwd=ROOT_REPO if root_repo else REPO)


def blob(ref, path):
    key = (ref, path)
    if key not in blob_cache:
        blob_cache[key] = git('show', f'{ref}:{path}')
    return blob_cache[key]


def tree(ref, nondoc=False):
    if ref not in tree_cache:
        tree_cache[ref] = {path.decode(): entry.decode() for entry, path in (
            row.split(b'\t', 1) for row in git('ls-tree', '-rz', '--full-tree', ref).split(b'\0') if row)}
    return {p: e for p, e in tree_cache[ref].items() if not nondoc or not p.startswith('docs/')}


def identity(ref):
    return {'source': ref, 'tree': git('rev-parse', ref + '^{tree}').decode().strip()}


def freeze(path, label):
    data = path.read_bytes()
    target = OUT / 'inputs' / label
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    target.write_bytes(data)
    input_records.append({'originalPath': str(path), 'snapshotPath': str(target),
                          'bytes': len(data), 'sha256': sha(data)})
    return data


def counts(raw):
    return {name: int(number) for name, number in re.findall(
        r'^[#ℹ]\s+(tests|pass|fail|cancelled|skipped|todo)\s+(\d+)\s*$', raw.decode(), re.M)}


def stamp(value):
    return datetime.datetime.fromisoformat(value)


def verify_mapping(mapping, docs_only=False):
    original, integrated = mapping['original'], mapping['integrated']
    original_patch = git('diff', '--binary', original + '^', original)
    integrated_patch = git('diff', '--binary', integrated + '^', integrated)
    assert original_patch == integrated_patch
    paths = git('diff', '--name-only', integrated + '^', integrated).decode().splitlines()
    if docs_only:
        assert len(paths) == mapping['documentationPaths'] and all(p.startswith('docs/') for p in paths)
        assert tree(integrated, True) == tree(integrated + '^', True)
    else:
        assert paths == mapping['paths'] and not any(p.startswith('docs/') for p in paths)
    assert identity(integrated)['tree'] == mapping['tree']
    assert subprocess.run(['git', 'merge-base', '--is-ancestor', integrated, INTEGRATED], cwd=REPO).returncode == 0
    return {'role': mapping['role'], 'original': original, 'integrated': integrated,
            'tree': mapping['tree'], 'paths': paths, 'binaryPatchSha256': sha(original_patch),
            'binaryPatchExact': True, 'documentationOnly': docs_only}


assert git('rev-parse', 'HEAD').decode().strip() == REVIEW_DOCS
assert not git('status', '--porcelain').strip()
assert git('rev-parse', 'HEAD', root_repo=True).decode().strip() == INTEGRATED
assert not git('status', '--porcelain', root_repo=True).strip()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
mappings = {name: json.loads(freeze(ROOT / name, 'mappings/' + name)) for name in MAPPING_NAMES}
initial_mapping = mappings['g37-combined-source.json']
correction_mapping = mappings['g37-corrected-source.json']
assert initial_mapping['source'] == INITIAL and correction_mapping['mappedSource'] == CORRECTED
assert initial_mapping['tree'] == identity(INITIAL)['tree']
assert correction_mapping['mappedTree'] == identity(CORRECTED)['tree']
assert tree(INITIAL, True) == tree('cbda12a11c24014e2a791d058460e642bad9f995', True)
assert tree(CORRECTED, True) == tree(REVIEWED, True) == tree(INTEGRATED, True) == tree(REVIEW_DOCS, True)
assert len(tree(CORRECTED, True)) == 1043
source_maps = [verify_mapping(item) for item in initial_mapping['components']]
corrective_paths = git('diff', '--name-only', CORRECTED + '^', CORRECTED).decode().splitlines()
assert corrective_paths == ['apps/web/src/solana-localnet/controller.ts', 'apps/web/test/solana-funding-flow-support.mjs',
                            'apps/web/test/solana-localnet-funding-flow.test.mjs']
correction = correction_mapping['originalSource']
assert correction == '3ccf809e01e729980b3ab5fbe12ba3993fbe9982'
assert git('diff', '--binary', correction + '^', correction) == git('diff', '--binary', CORRECTED + '^', CORRECTED)
assert git('rev-parse', CORRECTED + '^').decode().strip() == correction_mapping['priorRoot']
published = initial_mapping['actualPublishedAncestor']
assert published == '29491c2842e0aedcb00a674cbfffb9edc2424013'
assert subprocess.run(['git', 'merge-base', '--is-ancestor', published, CORRECTED], cwd=REPO).returncode == 0
base_entries, current_entries = tree(published, True), tree(CORRECTED, True)
modified = sorted(p for p, entry in base_entries.items() if p in current_entries and current_entries[p] != entry)
added = sorted(current_entries.keys() - base_entries.keys())
deleted = sorted(base_entries.keys() - current_entries.keys())
assert len(base_entries) == 1033 and len(modified) == 11 and len(added) == 10 and not deleted
doc_mappings = mappings['g37-integrated-component-evidence.json'] + [
    mappings['g37-integrated-correction-evidence.json'], mappings['g37-integrated-independent-source-review.json']]
documentation_maps = [verify_mapping(item, docs_only=True) for item in doc_mappings]
assert sum(len(item['paths']) for item in documentation_maps) == 189
assert git('rev-parse', INTEGRATED + '^').decode().strip() == mappings['g37-integrated-correction-evidence.json']['integrated']
for label, ref in [('initial-root', INITIAL), ('corrected-root', CORRECTED), ('integrated-root', INTEGRATED),
                   ('independent-reviewed', REVIEWED), ('independent-review-documentation', REVIEW_DOCS)]:
    path = OUT / (label + '-source-tree.bin')
    assert not path.exists()
    path.write_bytes(git('ls-tree', '-rz', '--full-tree', ref))

prior = json.loads(blob(INTEGRATED, 'docs/engineering/qualification-generation36.json'))
qualifications = {}
output_records = {}
graph_module_records = {}
for label, folder, source, total in [
    ('initial', 'p2p-g37-qualification', INITIAL, 2914),
    ('corrected', 'p2p-g37-corrected-qualification', CORRECTED, 2915),
]:
    receipt_path = ROOT / folder / 'qualification.json'
    receipt_bytes = freeze(receipt_path, label + '/qualification.json')
    q = json.loads(receipt_bytes)
    assert q['source'] == q['finalSource'] == source and q['tree'] == identity(source)['tree']
    assert q['cleanTrackedWorktree'] is True and q['nativeExecuted'] is False and q['completedAt']
    assert len(q['commands']) == 7
    previous_end = stamp(q['startedAt'])
    full_log = None
    for command, (expected_name, expected_command) in zip(q['commands'], EXPECTED_COMMANDS):
        assert command['name'] == expected_name and command['command'] == expected_command
        assert command['source'] == source and command['tree'] == q['tree'] and command['exitCode'] == 0
        assert previous_end <= stamp(command['startedAt']) <= stamp(command['completedAt']) <= stamp(q['completedAt'])
        previous_end = stamp(command['completedAt'])
        raw = freeze(Path(command['log']), label + '/logs/' + command['name'] + '.log')
        assert len(raw) == command['bytes'] and sha(raw) == command['sha256']
        assert counts(raw) == command['counts']
        if expected_name == 'full-node':
            assert command['counts'] == {'tests': total, 'pass': total, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}
            full_log = raw.decode()
        elif expected_name == 'typecheck':
            assert raw.decode().count('--noEmit') == 4
        elif expected_name == 'build-policy':
            assert command['counts'] == {'tests': 58, 'pass': 58, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}
        elif expected_name == 'boundaries':
            assert '244 production source files' in raw.decode() and '157 module(s)' in raw.decode()
        elif expected_name == 'native-fixture-preparation':
            assert json.loads(raw.decode().splitlines()[-1]) == command['preparation']
            prep = command['preparation']
            assert prep['nativeExecuted'] is False and prep['strictFixtureCompilation'] is True
            assert prep['fixtureModules'] == 37 and prep['ReleaseEnabled'] == 0 and prep['defaultUpdaterIncluded'] is False
    assert ('idle expiry between snapshot ownership checks' in full_log) == (label == 'corrected')
    output_records[label] = []
    graph_module_records[label] = {}
    for mode, directory in [('default', 'dist'), ('demo', 'dist-demo')]:
        a = q['artifacts'][mode]
        evidence = a['evidence']
        assert evidence['ReleaseEnabled'] == 0 and evidence['signedRelease'] is False
        assert evidence['releaseAcceptance'] is False and evidence['framingAttestation'] is False
        assert evidence['inspection']['completeXssProof'] is False and evidence['testnet'] is False
        assert evidence['syntheticDemo'] is (mode == 'demo')
        output_dir = ROOT / 'p2p-g37-initial-build-outputs' / mode if label == 'initial' else ROOT_REPO / 'apps/web' / directory
        expected_paths = {item['path'] for item in evidence['assets']} | {'local-build-evidence.json'}
        actual_paths = {p.relative_to(output_dir).as_posix() for p in output_dir.rglob('*') if p.is_file()}
        assert expected_paths == actual_paths and len(expected_paths) == (13 if mode == 'default' else 14)
        outputs = {}
        for path in sorted(expected_paths):
            raw = freeze(output_dir / path, label + '/outputs/' + mode + '/' + path)
            outputs[path] = raw
            output_records[label].append({'path': mode + '/' + path, 'bytes': len(raw), 'sha256': sha(raw)})
        assert json.loads(outputs['local-build-evidence.json']) == evidence
        for item in evidence['assets']:
            raw = outputs[item['path']]
            assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
        policy = json.loads(outputs['content-policy.json'])
        assert policy['manifest']['connectOrigins'] == [] and "connect-src 'none'" in policy['csp']
        graph_module_records[label][mode] = {}
        for name, graph_record in a['graphs'].items():
            raw = outputs[name]
            graph = json.loads(raw)
            assert sha(raw) == graph_record['sha256'] and graph == graph_record['graph']
            graph_paths = {module['path'] for module in graph['modules']}
            assert len(graph_paths) == len(graph['modules'])
            assert graph_paths == {module['path'] for module in prior['artifacts'][mode]['graphs'][name]['graph']['modules']}
            assert not any(p.startswith('packages/chain-solana/') or p.startswith('apps/web/src/solana-localnet/') for p in graph_paths)
            assert not any(re.search(r'packages/security/src/release-update(?:-http|-store)?\.ts$', p) for p in graph_paths)
            tracked, dependencies = 0, 0
            for module in graph['modules']:
                path = module['path']
                if path in tree(source):
                    data = blob(source, path)
                    tracked += 1
                else:
                    assert path.startswith('node_modules/')
                    data = (ROOT_REPO / path).read_bytes()
                    dependencies += 1
                assert sha(data) == module['sha256']
            if name == 'qr-graph-worker.json':
                assert graph['authority'] == 'none' and graph['privateRuntime'] is False and graph['network'] is False
            graph_module_records[label][mode][name] = {
                'modules': len(graph['modules']), 'trackedInputsVerified': tracked,
                'installedDependencyInputsVerified': dependencies, 'membershipUnchangedFromG36': True,
                'sha256': graph_record['sha256'],
            }
        prep = q['commands'][-1]['preparation']
        if mode == 'default':
            assert sha(outputs[prep['emittedWorker']['path']]) == prep['emittedWorker']['sha256']
            for item in prep['defaultGraphs']:
                assert sha(outputs[item['path']]) == item['sha256']
                assert len(json.loads(outputs[item['path']])['modules']) == item['modules']
    qualifications[label] = {
        'source': source, 'tree': q['tree'], 'receiptSha256': sha(receipt_bytes),
        'startedAt': q['startedAt'], 'completedAt': q['completedAt'],
        'commands': q['commands'], 'buildOutputsVerified': len(output_records[label]),
        'fullCounts': q['commands'][0]['counts'], 'nativeExecuted': False,
    }

preservation = mappings['g37-initial-qualification-preservation.json']
assert preservation['source'] == INITIAL and preservation['tree'] == identity(INITIAL)['tree']
assert preservation['counts'] == qualifications['initial']['fullCounts']
assert sorted(preservation['buildFiles'], key=lambda item: item['path']) == output_records['initial']
assert stamp(preservation['preservedAt']) < stamp(qualifications['corrected']['startedAt'])
ordinary_outputs_identical = output_records['initial'] == output_records['corrected']

receipt_paths = {
    'author': 'docs/execution/solana-browser-funding-generation37-20261120/receipt.json',
    'native': 'docs/execution/solana-browser-funding-native-generation37-20261120/receipt.json',
    'author-correction-evidence': 'docs/execution/solana-browser-funding-snapshot-correction-generation37-20261120/receipt.json',
    'independent-source-review': SOURCE_INDEX,
}
retained_evidence = []
for item in doc_mappings:
    path = receipt_paths[item['role']]
    receipt_raw = blob(INTEGRATED, path)
    assert receipt_raw == blob(item['original'], path)
    receipt = json.loads(receipt_raw)
    for artifact in receipt['artifacts']:
        stored = artifact.get('storedPath', artifact.get('path'))
        compressed = blob(INTEGRATED, stored)
        assert len(compressed) == artifact['compressedBytes'] and sha(compressed) == artifact['compressedSha256']
        assert int.from_bytes(compressed[4:8], 'little') == 0
        raw = gzip.decompress(compressed)
        assert len(raw) == artifact.get('decodedBytes', artifact.get('rawBytes'))
        assert sha(raw) == artifact.get('decodedSha256', artifact.get('rawSha256'))
    retained_evidence.append({'role': item['role'], 'original': item['original'], 'mapped': item['integrated'],
                              'receiptPath': path, 'receiptSha256': sha(receipt_raw),
                              'artifactsVerified': len(receipt['artifacts']), 'allGzipMtimeZero': True})
assert sum(item['artifactsVerified'] for item in retained_evidence) == 181
native = json.loads(blob(INTEGRATED, receipt_paths['native']))
assert len(native['compilation']['inputs']) == 70
for module in native['compilation']['inputs']:
    assert sha(blob(CORRECTED, module['path'])) == module['sha256']
assert native['compilation']['compiledOutputExecuted'] is False and native['compilation']['nativeBrowserExecuted'] is False
assert native['compilation']['nativeValidatorExecuted'] is False and native['compilation']['ReleaseEnabled'] == 0

for record in input_records:
    current = Path(record['originalPath']).read_bytes()
    assert len(current) == record['bytes'] and sha(current) == record['sha256']
assert tree(git('rev-parse', 'HEAD', root_repo=True).decode().strip(), True) == tree(CORRECTED, True)
assert not git('status', '--porcelain', root_repo=True).strip()
assert git('rev-parse', 'HEAD').decode().strip() == REVIEW_DOCS and not git('status', '--porcelain').strip()
git('diff', '--check', '8e836baa877b676a863c877003e277b638fc5061', INTEGRATED)
git('diff', '--check', '01f6f4feca051d68de24a04299cd3bb444bce40c', INTEGRATED)
(OUT / 'frozen-inputs.json').write_text(json.dumps(input_records, indent=2) + '\n')
result = {
    'schema': 'p2p-offramp.browser-funding-composition-verification-generation37.v1',
    'startedAt': started, 'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'initialRootSource': identity(INITIAL), 'correctedRootSource': identity(CORRECTED),
    'integratedEvidenceHead': identity(INTEGRATED), 'independentlyReviewedSource': identity(REVIEWED),
    'independentSourceReview': identity(REVIEW_DOCS), 'nonDocumentationEntries': 1043,
    'initialSourceEqualsOriginalReview': True, 'correctedSourceEqualsCorrectedReview': True,
    'sourceMappings': source_maps, 'correctivePaths': corrective_paths, 'correctionBinaryPatchExact': True,
    'documentationMappings': documentation_maps, 'mappedDocumentationPaths': 189,
    'publishedScope': {'ancestor': published, 'baseEntries': 1033, 'modified': modified, 'added': added, 'deleted': deleted},
    'qualifications': qualifications, 'outputs': output_records,
    'initialOutputsPreservedBeforeCorrectedRun': True,
    'ordinaryOutputsIdenticalBetweenRuns': ordinary_outputs_identical,
    'ordinaryGraphInputVerification': graph_module_records,
    'mappedEvidence': retained_evidence, 'mappedArtifactRecordsVerified': 181,
    'nativeCompanionCompilationInputsStillExact': 70,
    'nativeCompanionGeneratedOutputExecuted': False,
    'frozenInputs': len(input_records), 'allOriginalInputsStillMatchSnapshots': True,
    'fullWhitespaceOldAndObservedMain': 'pass', 'verificationScriptSha256': sha(Path(__file__).read_bytes()),
    'limits': {'testsRerun': False, 'buildsRerun': False, 'browserExecuted': False,
               'validatorExecuted': False, 'financialTransactionExecuted': False,
               'remoteMutation': False, 'nativeAcceptanceClaimed': False, 'rootFinalPackageNotYetExecuted': True},
    'ReleaseEnabled': 0,
}
(OUT / 'composition-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'source': CORRECTED, 'tree': identity(CORRECTED)['tree'],
                  'fullCounts': qualifications['corrected']['fullCounts'], 'allSevenCommandsVerified': True,
                  'initialCountsRetained': qualifications['initial']['fullCounts'],
                  'nonDocumentationEntries': 1043, 'mappedDocumentationPaths': 189,
                  'mappedArtifactsVerified': 181, 'buildOutputsPerRun': 27,
                  'ordinaryOutputsIdenticalBetweenRuns': ordinary_outputs_identical,
                  'frozenInputs': len(input_records), 'noTestsOrBuildsRerun': True,
                  'ReleaseEnabled': 0}, indent=2))
