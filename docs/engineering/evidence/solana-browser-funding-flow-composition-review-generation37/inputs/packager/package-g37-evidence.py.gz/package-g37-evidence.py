import gzip, hashlib, json, subprocess
from pathlib import Path

repo = Path('/workspace/scratch/dcf03ef9bee8/p2p-continuation-g37')
raw = Path('/workspace/scratch/dcf03ef9bee8/p2p-g37-corrected-qualification')
q = json.loads((raw / 'qualification.json').read_text())
base = '29491c2842e0aedcb00a674cbfffb9edc2424013'
assert q['source'] == '88bd126bace2b88886017b0ff4eb5daffcdc060e'
assert q['tree'] == '5ecf56b74e82f04b4fed8961179a46bcbd330def'
assert len(q['commands']) == 7 and all(c['exitCode'] == 0 for c in q['commands'])
assert q['commands'][0]['counts'] == {'tests':2915,'pass':2915,'fail':0,'cancelled':0,'skipped':0,'todo':0}
assert q['completedAt'] and q['nativeExecuted'] is False
assert q['finalSource'] == q['source'] and q['cleanTrackedWorktree'] is True
def digest(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=repo)
def entries(ref):
    result = {}
    for row in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if row:
            metadata, path = row.split(b'\t', 1)
            result[path.decode()] = metadata.decode()
    return result
def nondoc(items): return {k:v for k,v in items.items() if not k.startswith('docs/')}
b,t,h = entries(base),entries(q['source']),entries('HEAD')
assert nondoc(t) == nondoc(h)
modified = sorted(k for k,v in nondoc(b).items() if nondoc(t).get(k) != v)
added = sorted(nondoc(t).keys() - nondoc(b).keys())
assert len(nondoc(b)) == 1033 and len(nondoc(t)) == 1043
assert len(modified) == 11 and len(added) == 10
assert not (nondoc(b).keys() - nondoc(t).keys())
q.update(schema='p2p-offramp.generation37-qualification.v1', publishedParent={'pr':241,'head':base,'tree':'484aed89e4839dd914e430f77b474e3c4c1549db','branch':'codex/native-funding-consolidation-g34-20261120'}, intendedBranch='codex/browser-funding-continuation-g37-20261120')
q['integrationPlan'] = 'Publish one complete G35 proposal-codec plus G36 explicit admission/inventory plus G37 seller browser funding candidate above frozen actual PR241, preserving its actual PR240 ancestry. No standalone G35/G36 PR. Earlier standalone PR237-239 retain separate named gates; PR240 remains held under241.'
q['mergePolicy'] = {'tier':'C','ownerApproval':'Matching actual-source/actual-target owner authorization explicitly recorded in the eventual PR is required. Local source work and independent review do not establish approval.','hostedAcceptance':'Require applicable current-source/current-target hosted checks and the actual new browser proposal/funding/promotion journey. Local driver compilation and controlled tests are not native acceptance.','parentNamedGates':'Standalone PR237-239 require CodeRabbit or Qodo pass with findings answered. PR237 current-main synthetic proposal readback remains separately pending.'}
q['componentParent']='b94066283fe33bc8174ab72e5539a2fa98da92c5'
q['actualMainMergeEvidence']='docs/engineering/generation28-main-merge.json'
q['mainMergeEvidenceCommit']='1dd6a00cb24547ffe80cf0b33ff9b9beec035be4'
q['mainObservation']={'head':'01f6f4feca051d68de24a04299cd3bb444bce40c','scope':'Actual earlier PR236 main merge, independently recorded. This is not the immediate parent of the frozen browser funding stack.'}
mapping=json.loads((repo.parent/'g37-combined-source.json').read_text()); assert mapping['source']=='dcdb86d19b8d1e1b09cd12a0f5cbf9626eff0fd3'
correction=json.loads((repo.parent/'g37-corrected-source.json').read_text()); assert correction['mappedSource']==q['source'] and correction['mappedTree']==q['tree']
q['authorship']={'initialComposition':mapping,'correction':correction}
q['correctiveEvidence']=json.loads((repo.parent/'g37-integrated-correction-evidence.json').read_text())
q['dependencyPreparation']='Immutable physical hardlinks to established dependencies; no install or mutation.'
q['sourceScope']={'baseNonDocumentationEntries':len(nondoc(b)),'testedNonDocumentationEntries':len(nondoc(t)),'preservedBaseNonDocumentationEntries':sum(t.get(k)==v for k,v in nondoc(b).items()),'modified':modified,'added':added,'deleted':[]}
q['nonDocumentationEntriesIdenticalAfterEvidence']=len(nondoc(t))
author='28fa8516d2e1f26740a5370077f9b2fdbaa2c086'
paths=[p for p in git('diff','--name-only',base,author).decode().splitlines() if not p.startswith('docs/')]
assert len(paths)==21 and set(paths)==set(modified+added) and nondoc(entries(author))==nondoc(t)
q['reviewedSourceBlobs']={'correctedIndependentCombinedSource':author,'publishedScopeBase':base,'entries':{p:{'gitEntry':t[p],'sha256':digest(git('show',f'{author}:{p}'))} for p in paths}}
for head in [base,'7bd5cf595bddadaa204e51e418d0060a1d43a1bc','708a3a2bc167cbbc15eaa3d3c168e058499c7f8e','1c658181fb2bd04ffc4df0d0fbdf6735da3e7fce','33232f62dc9cd250528ef3eb0313c0c319d99495','d9ddcf53d82100f05de7346143a0ad00d43c2c1a','92663e46508b06645111d9c713beb82d3a6d1a0f','477777dc152cd3148ba7f25a75ce8f00dc1b03b5','bca96b796db18d69563ae5f0395452494a0dacd5']:
    subprocess.run(['git','merge-base','--is-ancestor',head,q['source']],cwd=repo,check=True)
prior=json.loads((repo/'docs/engineering/qualification-generation36.json').read_text())
for mode,directory in [('default','dist'),('demo','dist-demo')]:
    a=q['artifacts'][mode]; policy=json.loads((repo/'apps/web'/directory/'content-policy.json').read_text())
    assert a['evidence']['ReleaseEnabled']==0 and not a['evidence']['signedRelease'] and not a['evidence']['releaseAcceptance']
    assert policy['manifest']['connectOrigins']==[] and "connect-src 'none'" in policy['csp']
    a['contentPolicy']=policy; a['graphMembershipChanges']={}
    for name,graph in a['graphs'].items():
        paths={m['path'] for m in graph['graph']['modules']}; previous={m['path'] for m in prior['artifacts'][mode]['graphs'][name]['graph']['modules']}
        expected=set()
        assert paths-previous==expected and not previous-paths
        a['graphMembershipChanges'][name]={'added':sorted(paths-previous),'removed':[]}
    for asset in a['evidence']['assets']:
        actual=(repo/'apps/web'/directory/asset['path']).read_bytes()
        assert len(actual)==asset['bytes'] and digest(actual)==asset['sha256']
    a['vaultWorker']=next(x for x in a['evidence']['assets'] if x['path'].startswith('assets/vault.worker-'))
    assert a['vaultWorker']==next(x for x in prior['artifacts'][mode]['evidence']['assets'] if x['path'].startswith('assets/vault.worker-'))
    a['vaultWorkerIdenticalToPublishedParent']=True
    assert a['evidence']['assets'] == prior['artifacts'][mode]['evidence']['assets']
    a['allAssetsIdenticalToPublishedParent']=True
prep=next(c['preparation'] for c in q['commands'] if c['name']=='native-fixture-preparation')
worker=q['artifacts']['default']['vaultWorker']
assert prep['emittedWorker']=={'path':worker['path'],'sha256':worker['sha256']}
assert prep['nativeExecuted'] is False and prep['strictFixtureCompilation'] is True
assert prep['fixtureModules']==37 and prep['defaultUpdaterIncluded'] is False and prep['ReleaseEnabled']==0
published=json.loads((repo/'docs/engineering/qualification-generation34.json').read_text())
for mode in ['default','demo']:
    assert q['artifacts'][mode]['evidence']['assets']==published['artifacts'][mode]['evidence']['assets']
q['authorAndIndependentIndexes']=[
    'docs/execution/solana-browser-funding-generation37-20261120/receipt.json',
    'docs/execution/solana-browser-funding-native-generation37-20261120/receipt.json',
    'docs/execution/solana-browser-funding-snapshot-correction-generation37-20261120/receipt.json',
    'docs/engineering/browser-funding-flow-independent-review-generation37.json',
    'docs/engineering/browser-funding-flow-composition-review-generation37.json',
    'docs/engineering/qualification-generation35.json',
    'docs/engineering/qualification-generation36.json',
    'docs/engineering/generation28-main-merge.json']
assert all((repo/p).is_file() for p in q['authorAndIndependentIndexes'])
q['limits']=[
    'Complete seller-direct local native-SOL proposal import, explicit seller connection, native preparation, exact G33 review, one-shot confirmation, uncertainty reconciliation and finalized-only recovery promotion. No bilateral or peer acceptance is established.',
    'Dedicated funding commands use the private proposal record ID. Existing RecoveryAction and review.prepare remain exit-only. The original proposal, bound trade, actual wallet/client/profile/session/epoch and original PreparedSolanaFunding remain private authority; public copies and projections cannot substitute.',
    'Existing wallet bridge single physical prompt, one-shot exact bytes, revocation and late-result rules remain unchanged. Document grants/unblocking and proposal wallet redaction recognize the two new explicit commands.',
    'Proposal import remains one encrypted CAS and zero RPC/wallet/preparation. Unlock/restore load validated journal display without proposal RPC. Explicit refresh reconciles a live review instead of canceling it through recovery; foreign-origin uncertainty and no automatic resend remain.',
    'Only trusted finalized native escrow observation materializes recovery. The ordinary deterministic ID must be unoccupied; a captured revision spans occupancy read and CAS. Storage/revision/lock errors propagate to revocation. Existing recovery role/origin, original proposal bytes/origin and pending-intent settlement gates are preserved; paired quota counts once even in legacy overflow.',
    'Native companion adds a fixed funding physical-send oracle with maintained saved-proposal/full-binding/message validation and independent Ed25519 verification; legacy exit-only verifier and both readers remain byte-identical. Driver adds one early fund using existing acceptance/deadline/margins and no new long wait: exact8sends=1fund+7originalexits,9prompts=1fund+8original. All original refund/payout/withheld financial assertions remain.',
    'Initial author208/208 includes41new app cases; native19/19 includes9new and10existing cases. Initial root2914/2914 passed but independent idle-expiry review subsequently blocked acceptance. Narrow correction adds one maintained regression: author100/100 and independent38/38 on their exact corrected source, then root2915/2915. These overlapping counts are never added. All missing-command/helper, fixture and genuine snapshot failure outputs retain actual source attribution.',
    'Native driver strict build-only compilation ran on original combinedb695:70modules/3chunks/429784rawbytes,zero warnings,output never evaluated. Independent review verified all70 input hashes remain identical after the three-path correction, so no second driver compilation is claimed. Root corrected native updater preparation remains37modules/build-only. Hosted browser/validator/financial acceptance is separate.',
    'All1043 non-documentation entries match the frozen corrected independent combined source. G37 alone changes16paths overG36; completeG35-37 delta versus actualPR241 is21paths,11modified10added. Actual241/240 ancestry is preserved. Current main01f is separately recorded, not falsely described as this stack parent.',
    'Default/demo listed assets and module graphs remain identical to qualifiedG36 and publishedG34. The full suite builds the separate configured local-Solana profile; unchanged ordinary builds do not establish native or physical-device acceptance.',
    'Actual earlier PR236 acceptance and merged main01f remain separately attributed. Their success is not transferred to later funding code. Standalone237-239 gates and TierC hosted acceptance/explicit matching owner authorization remain. No production trust, optional default activation, deployment or release. ReleaseEnabled=0.']
destination=repo/'docs/execution/continuation-generation37-20261120'; destination.mkdir(parents=True,exist_ok=True)
def retain(original, relative):
    data=original.read_bytes(); compressed=gzip.compress(data,mtime=0)
    assert gzip.decompress(compressed)==data and compressed[4:8]==bytes(4)
    target=destination/relative; assert not target.exists(), f'Refusing overwrite: {target}'
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(compressed)
    return {'originalPath':str(original),'storedPath':str(target.relative_to(repo)),'decodedBytes':len(data),'compressedBytes':len(compressed),'decodedSha256':digest(data),'compressedSha256':digest(compressed)}
initialRaw=repo.parent/'p2p-g37-qualification';initial=json.loads((initialRaw/'qualification.json').read_text())
assert initial['source']=='dcdb86d19b8d1e1b09cd12a0f5cbf9626eff0fd3' and initial['tree']=='3e1f569f57fbc3ee01f6f4b32ea6bfd32abba65a'
assert initial['commands'][0]['counts']=={'tests':2914,'pass':2914,'fail':0,'cancelled':0,'skipped':0,'todo':0}
assert len(initial['commands'])==7 and all(c['exitCode']==0 for c in initial['commands'])
assert initial['finalSource']==initial['source'] and initial['cleanTrackedWorktree'] is True and initial['nativeExecuted'] is False
initialArtifacts=[retain(initialRaw/'qualification.json','initial/qualification.json.gz')]
for command in initial['commands']:
    original=Path(command['log']);data=original.read_bytes();assert len(data)==command['bytes'] and digest(data)==command['sha256']
    initialArtifacts.append(retain(original,'initial/'+command['name']+'.log.gz'))
preserved=json.loads((repo.parent/'g37-initial-qualification-preservation.json').read_text());assert len(preserved['buildFiles'])==27
for item in preserved['buildFiles']:
    original=repo.parent/'p2p-g37-initial-build-outputs'/item['path'];data=original.read_bytes()
    assert len(data)==item['bytes'] and digest(data)==item['sha256']
    mode,rel=item['path'].split('/',1);directory='dist' if mode=='default' else 'dist-demo'
    assert data==(repo/'apps/web'/directory/rel).read_bytes()
    initialArtifacts.append(retain(original,'initial/build/'+item['path']+'.gz'))
for mode in ['default','demo']:
    assert initial['artifacts'][mode]['evidence']['assets']==q['artifacts'][mode]['evidence']['assets']
initialArtifacts.append(retain(repo.parent/'g37-initial-qualification-preservation.json','initial/preservation.json.gz'))
assert len(initialArtifacts)==36
q['initialQualification']={'source':initial['source'],'tree':initial['tree'],'startedAt':initial['startedAt'],'completedAt':initial['completedAt'],'counts':initial['commands'][0]['counts'],'acceptance':'Superseded after genuine independent idle-expiry snapshot failure; retained evidence, not corrected-source acceptance.','artifacts':initialArtifacts,'ordinaryBuildFilesPreserved':27,'ordinaryBuildFilesIdenticalAfterCorrection':True}
q['snapshotCorrection']={'originalSource':'3ccf809e01e729980b3ab5fbe12ba3993fbe9982','mappedSource':q['source'],'sourcePaths':3,'maintainedRegressionAdded':1,'behavior':'Snapshot uses a pure ownership-reference predicate after its one currentness admission; authority-bearing paths retain currentness/epoch/reference checks. Next expired snapshot redacts; subsequent prepare is LOCKED without RPC/sign/send.','originalIndependentFailureRetained':True,'maintainedBeforeCorrection':{'tests':1,'pass':0,'fail':1},'authorCorrectedFocused':100,'independentCorrectedFocused':38}
mappingArtifacts=[]
for name in ['g37-combined-source.json','g37-corrected-source.json','g37-integrated-component-evidence.json','g37-integrated-correction-evidence.json','g37-integrated-independent-source-review.json','g37-integrated-composition-review.json']:
    mappingArtifacts.append(retain(repo.parent/name,'mapping/'+name+'.gz'))
q['mappingArtifacts']=mappingArtifacts
remote=json.loads((repo.parent/'g37-parent-gate-readback.json').read_text())
assert remote['main']['sha']=='01f6f4feca051d68de24a04299cd3bb444bce40c'
assert remote['pr237']['head']=='33232f62dc9cd250528ef3eb0313c0c319d99495' and remote['pr237']['baseBranch']=='main'
assert remote['checks237']['total']==12 and all(c['conclusion']=='success' for c in remote['checks237']['checks'])
assert remote['pr241']['head']==base and remote['pr241']['draft'] is True
nativeReceipt=json.loads((repo.parent/'g29-native-program-log-receipt.json').read_text())
rawParentLog=(repo.parent/'g29-native-program-136499578114.log').read_bytes()
assert len(rawParentLog)==nativeReceipt['decodedBytes'] and digest(rawParentLog)==nativeReceipt['decodedSha256']
assert b'HEAD is now at b7fb1df Merge 33232f62dc9cd250528ef3eb0313c0c319d99495 into d9ddcf53d82100f05de7346143a0ad00d43c2c1a' in rawParentLog
parentAcceptance=json.loads((repo.parent/'g29-native-acceptance-receipts.json').read_text())
assert parentAcceptance['currentTargetQualification'] is False and all(r['ok'] for r in parentAcceptance['receipts'])
parentGateArtifacts=[retain(repo.parent/name,'parent-gates/'+name+'.gz') for name in ['g37-parent-gate-readback.json','g29-native-program-log-receipt.json','g29-native-program-136499578114.log','g29-native-acceptance-receipts.json']]
q['parentGateArtifacts']=parentGateArtifacts
q['parentGateObservation']={'observedAt':remote['observedAt'],'main':remote['main']['sha'],'pr237Head':remote['pr237']['head'],'pr237Checks':'12/12 success','pr237ExecutedProposal':parentAcceptance['executedProposal'],'currentMainTargetQualified':False,'namedReviewSatisfied':False,'note':'PR237 has an owner-account coordination observation, not a qualifying named review. PR238/239 named reviews remain absent. PR241 remains frozen draft with hosted checks still incomplete and no matching recorded approval. This dated parent receipt is not later G37 source acceptance.','hostedNativeJob':136499578114,'clientChecks':62,'clientDurationSeconds':1908,'browserJourneys':6,'browserDurationSeconds':2055,'browserPrompts':8,'browserAppSends':7,'originalArchiveDownloaded':False}
logs=[]
for command in q['commands']:
    original=Path(command['log']); data=original.read_bytes()
    assert digest(data)==command['sha256'] and len(data)==command['bytes']
    target=destination/(command['name']+'.log.gz'); assert not target.exists(), f'Refusing overwrite: {target}'
    compressed=gzip.compress(data,mtime=0); assert gzip.decompress(compressed)==data; target.write_bytes(compressed)
    logs.append({'originalPath':str(original),'storedPath':str(target.relative_to(repo)),'decodedBytes':len(data),'compressedBytes':len(compressed),'decodedSha256':digest(data),'compressedSha256':digest(compressed)})
index={'schema':'p2p-offramp.generation37-retained-logs.v1','testedSource':q['source'],'testedTree':q['tree'],'logs':logs,'initialQualification':q['initialQualification'],'mappingArtifacts':mappingArtifacts,'parentGateArtifacts':parentGateArtifacts,'authorAndIndependentIndexes':q['authorAndIndependentIndexes'],'limits':q['limits']}
for name,value in [('qualification-generation37.json',q),('retained-logs-generation37.json',index)]:
    target=repo/'docs/engineering'/name; assert not target.exists(), f'Refusing overwrite: {target}'
    target.write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({'source':q['source'],'tree':q['tree'],'rootLogs':len(logs),'scope':q['sourceScope'],'nonDocumentationPreserved':q['nonDocumentationEntriesIdenticalAfterEvidence']}))
